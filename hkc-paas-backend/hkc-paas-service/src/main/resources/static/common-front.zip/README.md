# 1.概述

通用前端的作用：
1. 解决前端应用膨胀的问题。

   随着应用的开发，如果前端一直开发，应用越来越大不可避免，因此，我们可以将应用分离成一个个的小应用，这样便于维护，并且代码不会一直膨胀。
2. 通过设计器设计的表单，列表可以在通用前端进行展示。

# 2.项目运行

## 2.1 下载代码

```
git clone http://dev.redxun.cn:7990/scm/jpaas_web/jpaas-common-front.git
```

## 2.2 安装依赖

```
npm install   --registry=http://nexus.redxun.cn:18081/repository/npm-redxun-group/
```

## 2.3 运行
```
npm run serve
```

## 2.4 编译
```
npm run build
```

## 2.5 使用nginx 运行

在nginx 增加配置

```
location /appPortal {
	proxy_set_header Host       $host;
	proxy_pass http://localhost:8083;
}
```
