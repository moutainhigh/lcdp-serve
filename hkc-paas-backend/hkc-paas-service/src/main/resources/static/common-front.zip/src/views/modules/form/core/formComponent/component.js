import FormComponent from "./FormComponent";
import ListComponent from "./ListComponent";
import TreeCompoment from "./TreeCompoment";

Vue.component(FormComponent.name, FormComponent);
Vue.component(ListComponent.name, ListComponent);
Vue.component(TreeCompoment.name, TreeCompoment);
