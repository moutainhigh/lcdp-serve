import Vue from "vue";
import RxFormBoList from "@/views/modules/form/core/expandRow/RxFormBoList";
import RxFormSolutionShow from "@/views/modules/form/core/expandRow/RxFormSolutionShow";


Vue.component(RxFormBoList.name, RxFormBoList);
Vue.component(RxFormSolutionShow.name, RxFormSolutionShow);

var customFn = {
    findAuthRight(type) {
        if (this.curTree && this.curTree.right) {
            var json = JSON.parse(this.curTree.right);
            var ary = type.split('.');
            for (var i = 0; i < ary.length; i++) {
                json = json[ary[i]];
            }
            return json;
        }
        return true;
    }
}


Object.assign(Vue.prototype, customFn);