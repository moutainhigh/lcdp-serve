import rxAjax from '@/assets/js/ajax.js';

export const OsGroupApi = {};

OsGroupApi.baseUrl= '/api-user/user/org/osGroup';
OsGroupApi.exportUrl= OsGroupApi.baseUrl + '/export';


/**
 * 父节点切换
 */
OsGroupApi.changeParent= function(groupId,parentId) {
  var url=OsGroupApi.baseUrl + '/changeParent?groupId='+groupId+"&parentId="+parentId;
  return rxAjax.get(url);
}

/**
 * 获得第一级的部门列表
 * @returns {AxiosPromise}
 */
OsGroupApi.getAdminOrg= function() {
  var url=OsGroupApi.baseUrl + '/getAdminOrg';
  return rxAjax.get(url);
}

OsGroupApi.getParentGroup= function(parentId) {
  var url=OsGroupApi.baseUrl + '/getByParentId?parentId='+parentId;
  return rxAjax.get(url);
}

OsGroupApi.getGroupListByDimId= function(parameter) {
  var url=OsGroupApi.baseUrl + '/getGroupListByDimId';
  return rxAjax.postJson(url,parameter);
}


OsGroupApi.getOsGroupList= function(parameter) {
  var url=OsGroupApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then(res =>{
    return res.result;
  })
}

OsGroupApi.queryByDimId=function(dimId){
  var url=OsGroupApi.baseUrl + '/queryByDimId?dimId='+dimId;
  return rxAjax.get(url);
}

OsGroupApi.queryByGradeDimId=function(dimId){
  var url=OsGroupApi.baseUrl + '/queryByGradeDimId?dimId='+dimId;
  return rxAjax.get(url);
}


OsGroupApi.getAllOsGroupList= function(parameter) {
  var url=OsGroupApi.baseUrl + '/getAll';
  return rxAjax.get(url,parameter).then(res =>{
    return res.data
  })
}

OsGroupApi.getGroupPermIds= function(groupId) {
  var url=OsGroupApi.baseUrl + '/group/' + groupId;
  return rxAjax.get(url);
}

/**
 * 获取单记录
 * @param pkId
 * @returns {*}
 */
OsGroupApi.getOsGroup =function(pkId) {
  var url= OsGroupApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

OsGroupApi.saveOsGroup= function(parameter) {
  var url=OsGroupApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

OsGroupApi.delOsGroup= function(parameter) {
  var url=OsGroupApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

OsGroupApi.removeById= function(parameter) {
    var url=OsGroupApi.baseUrl + '/removeById';
    return rxAjax.postUrl(url,parameter);
}

OsGroupApi.joinGroups =function (parameter) {
  var url=OsGroupApi.baseUrl + '/joinGroups';
  return rxAjax.postForm(url,parameter);
}

OsGroupApi.queryGroups=function(dimId,parentId,isGrade,tenantId){
  var url=OsGroupApi.baseUrl + '/queryGroups?dimId='+dimId+"&parentId="+parentId+"&isGrade="+isGrade;
  if(tenantId){
    url+="&tenantId="+tenantId;
  }
  return rxAjax.get(url);
}

/**
 * 获取组织分级管理开关配置
 * @returns {*}
 */
OsGroupApi.getSupportGradeConfig= function() {
    var url= OsGroupApi.baseUrl + '/getSupportGradeConfig' ;
    return rxAjax.get(url);
}



//导入用户组
OsGroupApi.importData=function(formData,callback) {
    var url= OsGroupApi.baseUrl+"/importData";
    return rxAjax.upload(url,formData,callback);
}

//根据公司查询分组列表。
OsGroupApi.getByCompanyId=function(companyId) {
    var url= "/api-user/user/core/osCompanyAuth/getByCompanyId";
    let params={companyId:companyId};
    return rxAjax.postForm(url,params);
}

/**
 * 保存
 * @param companyId
 * @returns {*}
 */
OsGroupApi.saveAuth=function(json) {
    var url= "/api-user/user/core/osCompanyAuth/saveAuth";
    return rxAjax.postJson(url,json);
}

/**
 * 删除权限。
 * @param parameter
 * @returns {*}
 */
OsGroupApi.delAuth=function(parameter) {
    var url= '/api-user/user/core/osCompanyAuth/del';
    return rxAjax.postUrl(url,parameter);
}

/**
 * 获取当前公司数据
 * @param companyId
 * @returns {*}
 */
OsGroupApi.getCompanys=function() {
    var url= OsGroupApi.baseUrl+'/getCompanys';
    return rxAjax.get(url);
}

/**
 * 设置公司。
 * @param companyId
 * @returns {*}
 */
OsGroupApi.setCompany=function(companyId) {
    let params={companyId:companyId};
    var url= '/api-uaa/oauth/user/switchCompany';
    return rxAjax.postForm(url,params);
}

/**
 * 退出公司切换。
 * @returns {*}
 */
OsGroupApi.exitSwitchCompany=function() {
    var url= '/api-uaa/oauth/user/exitSwitchCompany';
    return rxAjax.postForm(url);
}


export  default OsGroupApi;