<template>
  <rx-dialog @handOk="revokeCommu" @cancel="cancel" oktext="撤销沟通" order="buttom" btnalign="center">
    <template #toolbar >
      <a-checkbox :checked="delOpinion" @change="onChange">
        删除沟通意见
      </a-checkbox>
    </template>
    <a-table :columns="columns" :data-source="dataSource" :pagination="false">
      <span slot="serial" slot-scope="text, record,index">{{index+1}}</span>
      <span slot="assignee" slot-scope="text, record,index">
        <rx-user-info :userId="text"></rx-user-info>
      </span>
      <span slot="status" slot-scope="text, record,index">
        <a-tag :color="statusMap[text].color">
              <span>{{statusMap[text].text}}</span>
            </a-tag>
      </span>
      <span slot="updateTime" slot-scope="text, record,index">
          <template v-if="record.status=='COMPLETED'">{{text}}</template>
      </span>
      <span slot="remark" slot-scope="text, record,index">
          <template v-if="record.status=='COMPLETED'">{{record.bpmCheckHistory.remark}}</template>
      </span>
    </a-table>

  </rx-dialog>
</template>

<script>
    import {BaseFormModel, RxDialog,Dialog,Util,RxUserInfo} from 'jpaas-common-lib';
    import BpmtaskApi from "@/api/bpm/core/bpmTask";

    export default {
        name: "bpm-task-commu",
        components: {
            RxUserInfo,
            RxDialog
        },
        props:{
            taskId:"",

            layerid: String,
            lydata: Object,
            destroy:Function
        },

        data (){
            return {
                columns:[
                    {
                        title: '序号',
                        dataIndex:'serial',
                        scopedSlots: { customRender: 'serial' },
                        width: 80
                    },
                    {
                        title: '沟通人',
                        dataIndex: 'assignee',
                        width:180,
                        ellipsis:false,
                        scopedSlots: { customRender: 'assignee' },
                    },
                    {
                        title: '发起时间',
                        dataIndex: 'createTime',
                        width:100
                    },
                    {
                        title: '状态',
                        dataIndex: 'status',
                        width:120,
                        scopedSlots: { customRender: 'status' },
                    },
                    {
                        title: '回复时间',
                        dataIndex: 'updateTime',
                        width:120,
                        scopedSlots: { customRender: 'updateTime' },
                    },
                    {
                        title: '意见',
                        dataIndex: 'remark',
                        width:120,
                        scopedSlots: { customRender: 'remark' },
                    }


                ],
                delOpinion:false,
                dataSource:[],
                statusMap: {
                    "UNHANDLE": { color: 'red', text: '未处理' },
                    "COMPLETED": { color: 'green', text: '已回复' },
                    "HANDLE": { color: 'red', text: '正在处理' }

                }
            }
        },
        created(){
          this.init();
        },
        methods:{
          init(){
              BpmtaskApi.getCommuTasks(this.taskId).then(res=>{
                  this.dataSource=res.data;
              })
          },
          cancel(){
            Util.closeWindow(this,"cancel");
          },
          onChange(e){
              this.delOpinion= e.target.checked;
          },
          revokeCommu(e){
              var self_=this;
              if(!this.dataSource || this.dataSource.length==0){
                  e.loading=false;
                  this.$message.error("没有需要撤回的沟通！");
                  return;
              }
              this.$confirm({
                  title: '提示信息',
                  content: '确定撤销吗?',
                  zIndex: 20000,
                  okText: '确认',
                  cancelText: '取消',
                  onOk() {
                      BpmtaskApi.revokeCmTask(self_.taskId,self_.delOpinion).then(res=>{
                          e.loading=false;
                          if(res.success){
                              Util.closeWindow(self_,"ok");
                          }
                      })
                  },
              });
          }

        }
    }
</script>

<style scoped>

</style>