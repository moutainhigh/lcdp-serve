<template>
<div>
	这是我开发的组件
</div>
</template>

<script>
export default {
	name: "Demo"
}
</script>

<style scoped>

</style>
