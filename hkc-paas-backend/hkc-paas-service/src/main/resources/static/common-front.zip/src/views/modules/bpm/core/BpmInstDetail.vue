<template>
    <div style="width: 100%;height:100%;padding:5px;">

        <rx-fit >
          <div slot="toolheader" align="right" foldbtn="false">
            <a-row style="padding: 10px 0">
              <a-button-group>
                <template v-if="!buttons || buttons.length==0">
                    <a-button  key="btnTracked" v-if="canTrack" @click="doTracked()" >
                        <a-icon type="star" :theme="trackedTheme" :style="{'color':trackedColor}"/>
                        {{ trackText }}
                    </a-button>
                    <a-button v-if="allowTransfer" @click="transferTo" >转发</a-button>
                    <a-button v-if="allowTransReply" @click="transferReply" >回复转发</a-button>
                    <a-button @click="retrieveTaskNode" v-show="canRevoke" >取回任务</a-button>

                    <a-button @click="showCheckHistory">审批历史</a-button>
                    <a-button @click="showBpmInstLog">活动日志</a-button>
                    <a-button @click="showProcessImg">流程图</a-button>
                    <a-button v-if="status!='ARCHIVED'" icon="profile" @click="showMsg" >留言</a-button>
                    <a-button @click="formPrint()">打印</a-button>
                </template>
                <template v-else v-for="btn in buttons">
                    <a-button v-if="btn.id=='btnTrack' && canTrack" :key="btn.id" :type="btn.type" @click="handMethod(btn)" ><a-icon type="star" :theme="trackedTheme" :style="{'color':trackedColor}"/>{{ trackText }}</a-button>
                    <a-button v-else-if="btn.id=='btnTransfer' && allowTransfer" :key="btn.id" :type="btn.type" @click="handMethod(btn)">{{btn.name}}</a-button>
                    <a-button v-else-if="btn.id=='btnTransReply' && allowTransReply" :key="btn.id" :type="btn.type" @click="handMethod(btn)">{{btn.name}}</a-button>
                    <a-button v-else-if="btn.id=='btnBack' && backNodeId!=null && backNodeId!=''" :key="btn.id" :type="btn.type" @click="handMethod(btn)">{{btn.name}}</a-button>
                    <a-button v-else-if="btn.id=='btnMessage' && status!='ARCHIVED'" icon="profile" :key="btn.id" :type="btn.type" @click="handMethod(btn)">{{btn.name}}</a-button>
                    <a-button v-else-if="!isBuildinBtn(btn.id)" :key="btn.id" :type="btn.type" @click="handMethod(btn)">{{btn.name}}</a-button>
                </template>
                <a-button @click="close()">关闭</a-button>
              </a-button-group>
            </a-row>
          </div>
          <!--单据实例信息-->
          <div class="fitContainer" style="text-align: center;padding-right:10px;">
            <div class="contents">
                  <bpm-inst-info :bpmInst="bpmInst" />
                <!--   流程状态图   -->
                <bpm-status class="contentsStatus" :status="status"></bpm-status>
                  <rx-forms ref="rxForms" v-if="processConfig.formType=='online'"> </rx-forms>
                  <component ref="customForm" :is="formComponent" :pk="pk" v-else></component>
            </div>
          </div>
        </rx-fit>

        <!-- 流程实例日志 -->
        <bpm-inst-logs :instId="instId" :log-show.sync="logShow" />
        <!--流程实例消息-->
        <bpm-inst-msgs :instId="instId" v-if="status=='DRAFT' ||  status=='RUNNING' || status=='SUPSPEND'" :msg-show.sync="msgShow"/>
        <!--审批历史-->
        <bpm-check-history
          :inst-id="instId"
          :historyShow.sync="historyShow" />
    </div>
</template>

<script>
  import {RxDialog,Util,RxFit} from 'jpaas-common-lib';
  import BpmInstMsgs from "./BpmInstMsgs"
  import BpmInstLogs from "./BpmInstLogs";
  import BpmInstApi from '@/api/bpm/core/bpmInst'
  import BpmImageView from "../comps/BpmImageView";
  import RxForms from "./RxForms";
  import BpmCheckHistory from "./BpmCheckHistory";
  import BpmInstInfo from "./BpmInstInfo";
  import formbase from '@/api/formbase';
  import BpmInstTransfer from "../core/BpmInstTransfer";
  import BpmInstTakeBack from "@/views/modules/bpm/core/BpmInstTakeBack";
  import BpmStatus from "@/views/modules/bpm/core/component/BpmStatus";
  import BpmInstTrackedApi from "@/api/bpm/core/bpmInstTracked";
  import userState from "@/assets/js/userState";

  export default {
      name: "BpmInstDetail",
      components:{
        RxDialog,
        RxFit,
        RxForms,
        BpmInstMsgs,
        BpmInstLogs,
        BpmCheckHistory,
        BpmInstInfo,
        BpmInstTransfer,
        BpmInstTakeBack,
        BpmStatus
      },
      mixins:[formbase,userState],
      props:{
          layerid:{type:String} ,
          lydata:{type:Object},
          destroy:{type:Function},
          instId:{
            type:String,
            required:true
          },
          backNodeId:{//在流程明细中进行回退时指定的目标节点
            type:String,
            required:false
          },
          allowTransfer:{
              type:Boolean,
              required:false,
              default: false
          },
          allowTransReply:{
              type:Boolean,
              required:false,
              default: false
          },

          //来自页面(mydone:我完成的审批,mystart:我发起的流程)
          from:{
              type:String,
              default:""
          }
      },
      computed:{
          trackedTheme(){
              return this.bpmInstDetail.tracked=='1'?'filled':'outlined';
          },
          trackedColor(){
              return this.bpmInstDetail.tracked=='1'?'#eab207':'#1890ff';
          },
          trackText(){
              return this.bpmInstDetail.tracked=="1"?"已跟踪":"跟踪";
          },
          canTrack(){
              return this.bpmInst.status=="RUNNING" || this.bpmInst.status=='REVOKE';
          }
      },
      data(){
        return {
          historyShow:false,
          logShow:false,
          msgShow:false,
          bpmInstDetail:{},
          bpmInst:{},
          status:"",
          processConfig:{
            buttons:[],
            startConfirm:false,
            fillOpinion:false,
            assignFlowUsers:false,
            startCalFlowusers:false,
            //是否允许选择路径。
            allowSelectPath:false,

            formType:"online"
          },
          buttons:[],
          pkId:"",
          formComponent:"",
          pk:"",
          backBtnLoading:false,//撤回按钮加载状态
          //根实例
          rootVm: true,
          //是否可以撤回
          canRevoke:false,

        }
      },
      created() {
        this.loadDetail();
      },
      methods: {
        isBuildinBtn(btn){
              var btns=['btnTransfer','btnTransReply','btnBack','btnMessage'];
              return btns.indexOf(btn)>-1;
        },
        showCheckHistory(){
          this.historyShow=true;
        },
        showBpmInstLog(){
            this.logShow=true;
        },
        showMsg(){
          this.msgShow=true;
        },
        retrieveTaskNode(){
              let self_=this;
              Util.open({
                  component:BpmInstTakeBack,
                  curVm:this,
                  widthHeight:['600px','320px'],
                  title:'撤回流程',
                  data:{
                      bpmInst:this.bpmInst,
                      from:this.from
                  }
              },function (action){
                  Util.closeWindow(self_,"ok");
              });

          },
        //显示流程图
        showProcessImg(){
          Util.open({
            component:BpmImageView,
            curVm:this,
            widthHeight:['1024px','600px'],
            title:'流程图',
            data:{
              instId:this.instId,
              formData:this.getFormData()
            }
          },function (action){
          });
        },
        loadDetail() {
              let self = this;
              if(!this.instId){
                  this.instId=this.$route.params.instId;
              }
              var self_=this;
              BpmInstApi.getInstDetail(this.instId,this.from).then(res => {
                  this.bpmInst=res.bpmInst;
                  var contextData={
                      type:"detail",
                      instNo:res.bpmInst.instNo,
                      instId:self.instId,
                      opinionHistorys:res.bpmCheckHistories
                  };
                  var config=Util.deepClone(self_.processConfig);
                  self_.processConfig=Object.assign(config,res.data) ;
                  self_.buttons = self_.processConfig.buttonDetailConfigs;
                  self_.canRevoke= res.canRevoke;
                  self_.status=res.bpmInst.status;
                  self.pkId=res.bpmInst.busKey;
                  self.handFormConfig(res.processConfig,res.bpmInst);
                  self.$refs.rxForms.setData(res.formData.data,true,contextData);
              })
        },
        printForm(){
            var baseUrl=process.env.VUE_APP_API_CTX_PATH;
            var defId=this.bpmInst.defId;
            var instId=this.bpmInst.instId;

            var url=baseUrl +"/flowprint/" + defId ;
            if(instId){
                url+= "/" + instId;
            }
            else {
                url+= "/-1" ;
            }
            window.open(url);
        },
        loadView(view)  { // 路由懒加载
          return () => import(`@/views/${view}`);
        },
        //处理表单配置。
        handFormConfig(conf,bpmInst){
          var config=Util.deepClone(this.processConfig);
          this.processConfig=Object.assign(config,conf);
          if(!this.processConfig.formType){
            this.processConfig.formType="online"
          }
          //获取全局。
          if( conf.globalForm.formpc && conf.globalForm.formpc.length>0){
            var form= conf.globalForm.formpc[0];
            if(form && form.type=="custom"){
              this.pk=bpmInst.busKey;
              this.processConfig.formType="custom";
              this.formComponent=this.loadView(form.component);
              return;
            }
          }
        },
        Ureport(name){
          if(!this.pkId){
            this.$message.warning('非法操作');
            return;
          }
          var url="/ureport/preview?_u=qiaolin-"+name+"&Id="+this.pkId;
          window.open(url);
        },
        formPrint(){
            this.printForm();
        },
        close(){
            if(this.destroy){
                Util.close(this,"cancel");
            }else{
                window.close();
            }
        },

        transferTo(){
            Util.open({
                component: BpmInstTransfer,
                curVm: this,
                widthHeight: ['800px', '500px'],
                title: '转发流程实例' + this.bpmInst.subject  ,
                data: {
                    instId: this.instId,
                    send:true
                },
            }, function (action) {
                console.log(action)
            })
        },
        transferReply(){
            Util.open({
                component: BpmInstTransfer,
                curVm: this,
                widthHeight: ['800px', '500px'],
                title: '回复转发[' + this.bpmInst.subject +"]" ,
                data: {
                    instId: this.instId,
                    send:false
                },
            }, function (action) {
                console.log(action)
            })
        },
        doTracked(){
            let instId=this.bpmInst.instId;
            BpmInstTrackedApi.doTracked(instId).then(res=>{
                this.bpmInstDetail.tracked=res.data;
            })
        }
      }
    }
</script>

<style scoped>
.fitContainer{
  background: #fff;
  padding: 10px;
  padding-right: 0;
  box-sizing: border-box;
  height: 100%;
  width: 100%;
  overflow: auto;
}
.contents{
  background: #fff;
  border-radius: 6px;
  min-height: 100%;
  box-sizing: border-box;
    display:inline-block;
    width: 100%;
    max-width: 1300px;
    text-align: left;
    border: solid 1px #dadde0;
    position: relative;
}
.contentsStatus{
    position: absolute;
    z-index: 9999999999;
    top: 0px;
    right: 10px;
}
</style>