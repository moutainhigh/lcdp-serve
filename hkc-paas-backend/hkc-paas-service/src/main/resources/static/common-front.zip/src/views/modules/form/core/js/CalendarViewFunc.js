/**
 * 日历视图方法
 */

import FormSolutionApi from '@/api/form/core/formSolution'

export default {
    data() {
        return {
            dialogBox: {},
        }
    },
    created() {
        var files = require.context('@/assets/js', true, /\.js$/);
        files.keys().forEach(key => {
            if (key.indexOf('/DialogBox.js') != -1) {
                this.dialogBox = files(key).default || files(key)
            }
        })
    },
    methods: {
        caShowForm(obj) {
            if (!obj.alias) {
                this.$message.error("请绑定表单方案！");
                return;
            }
            if (!obj.readOnly) {
                obj.readOnly = false;
            }
            var self = this;
            let config = {
                title: obj.title,
                curVm: self,
                data: {
                    alias: obj.alias,
                    pkId: obj.pkId,
                    readOnly: obj.readOnly,
                    parent: obj.parent,
                    //将表单映射数据提交到表单数据。
                    setInitData(data) {
                        if (self.formdata) {
                            Object.assign(data, self.formdata);
                        }
                        return data;
                    }
                },
                shade: true,
                urlType: obj.urlType,//用于区分表单按钮的打开方式
            }
            //是否全屏
            if(this.calendarView.isMax=="NO"){
                var width=this.calendarView.width?this.calendarView.width+"px":"650px";
                var height=this.calendarView.height?this.calendarView.height+"px":"350px";
                config.widthHeight= [width, height];
            }else {
                config.max=true;
            }
            this.dialogBox.showForm(config, function (action) {
                self.onRefresh();
            });
        },
        onAdd() {//增加
            let _obj = {
                title: this.calendarView.name + '--添加',
                alias: this.calendarView.formAddAlias ? this.calendarView.formAddAlias : this.calendarView.formAlias,
                urlType: 'Add'
            }
            this.caShowForm(_obj);
        },
        onEdit(data) {//編輯
            let _obj = {
                title: this.calendarView.name + '--编辑',
                alias: this.calendarView.formAlias,
                pkId: data.pkId,
                urlType: 'Edit'
            }
            this.caShowForm(_obj);
        },
        onRemove(data) {
            let self_ = this;
            this.$confirm({
                title: '操作提示',
                zIndex: 20000,
                content: '您确定需要删除选中的记录吗？',
                okText: '确认',
                cancelText: '取消',
                onOk() {
                    FormSolutionApi.removeById({alias: self_.calendarView.formAlias, id: data.pkId}).then(res => {
                        self_.onRefresh();
                    });
                }
            })
        },
        onDetail(data) {
            let _obj = {
                title: this.calendarView.name + '--明细',
                alias: this.calendarView.formDetailAlias ? this.calendarView.formDetailAlias : this.calendarView.formAlias,
                pkId: data.pkId,
                readOnly: true,
                urlType: 'Details'
            }
            this.caShowForm(_obj);
        },
        onRefresh(){
            this.loadData(this.calendarView.key);
        }
    }
}