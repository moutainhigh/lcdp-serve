import formBoListButtonFunction from "@/api/form/core/formBoListButtonFunction";

import FormQueryStrategyApi from "@/api/form/core/formQueryStrategy";
import rxAjax from "@/assets/js/ajax";
import {Util,Api,Dialog} from 'jpaas-common-lib';
import FormCustomView from "@/views/modules/form/core/formComponent/FormCustomView";
import SaveExportApi from "@/api/form/core/saveExport";
import FormBoListApi from "./formBoList";
import {mapState} from "vuex";
import userState from "@/assets/js/userState";
import {getCurApp} from  '@/utils/curApp'
import formBoListFieldCompare from "@/api/form/core/formBoListFieldCompare";
import BoListApi from "@/api/form/core/formBoListFunc.js";
import moment from "moment";



export default {
    mixins: [formBoListButtonFunction,userState,formBoListFieldCompare],
    props:{
        "onload":{
            type:Function
        },"dialogVm":{
            type:Object
        },
        //表单映射数据。
        "formdata":{
            type:Object
        },
        "layerid": {
            type: String
        },
        "destroy": {
            type: Function
        },
        "lydata":{
            type: Object
        }
    },
    data() {
        return {
            configList:[],
            queryParam: {},
            selectedRows: [],
            visible:false,
            queryStrategy: '全部',
            searchList: [],
            searchCommonList:[],
            searchCommonActive:'all',
            visibleModal:false,
            curDelId:null,
            findShow:false,
            isUser:false,
            isPublic:false,
            fieldDatas:[],
            queryCondition:[],
            curSearchItem:{},
            curRow:{},
            // 高级搜索 展开/关闭
            advanced: false,
            //弹窗是否显示 ；
            fitSearch:false,
            //搜索栏布局参数:span="colSpan"
            colSpan:24,
            //搜索栏 a-form :layout="colLayout"
            colLayout:'vertical',
            summaryLoad:false,
            summaryData:[],
            dialogBox:{},
            isList:true,
            //临时参数变量。
            params:{}
        }
    },
    computed:{
        table(){
            return this.$refs.table;
        },
        ...mapState({
            // 动态主路由
            buttons: state => state.appSetting.buttons,
            allButtons: state => state.appSetting.allButtons,
            idKey: state => state.appSetting.idKey,
        })
    },
    created(){
        this.loadConfigList();
        this.getFieldData();
        this.loadCommonList();
        this.initRxFit();
        this.initColumns();
        if(this.onload){
            this.onload();
        }
        var files= require.context('@/assets/js', true, /\.js$/);
        files.keys().forEach(key => {
            if(key.indexOf('/DialogBox.js')!=-1){
                this.dialogBox= files(key).default || files(key)
            }
        })
    },
    methods: {
        ...BoListApi,
        initRxFit(){
            //初始化rx-fit模板 ；
            this.colLayout = this.isheader ? 'inline':'vertical' ;
            this.colSpan = this.isheader ? 8:24 ;
            this.advanced = this.isheader ? false : true ;
            this.fitSearch = this.isheader ? true :false ;
        },
        toggleAdvanced() {
            this.advanced = !this.advanced
        },
        showBtn(alias){
            var hasRight=this.checkRight(alias);
            if(hasRight){
                return true;
            }
            return true;
        },
        checkRight(alias){
            if(this.user && this.user.admin){
                return true;
            }
            var bottonKeys =this.buttons[this.idKey];
            if(this.idKey !==''){
                var isClude= bottonKeys.includes(this.alias);
                if(!isClude){
                    //如果没有权限，比对所有按钮，如果没有配置，则有权限
                    var allBottonKeys =this.allButtons[this.idKey];
                    if(!allBottonKeys){
                        return true;
                    }
                    var isConfigured= allBottonKeys.includes(this.alias);
                    return !isConfigured;
                }
                return true;
            }
            return  false;
        },
        loadCommonList(){
            if(this.formBoList && this.formBoList.id){
                FormQueryStrategyApi.getByListId(this.formBoList.id,'YES').then(res => {
                    this.searchCommonList = res.data.map(item => {
                        return {key: item.id, label: item.name};
                    })
                });
            }
        },
        loadTreeByParent(treeNode,ctlName){
            if (!treeNode || treeNode.dataRef.children) {
                return;
            }
            var ctl;
            if(this.activeKey){
                ctl=this.$refs[this.activeKey];
            }else{
                ctl=this.$refs.rxTree;
            }
            var params=ctl.params;
            if(!params){
                params={};
            }
            params[ctl.idField]=treeNode.dataRef[ctl.idField];
            return Api.getAjax().postJson(ctl.url, params).then(res => {
                var data=res.result.data;
                var source=Util.listToTree(data,ctl.idField,ctl.parentField);
                Util.genTreeData(source,ctl.textField,ctl.idField,ctl.idField)
                treeNode.dataRef.children=source;
                ctl.$forceUpdate();
            })
        },
        rowExpand(expanded,record){
            var self=this;
            if(expanded&&record.children&&record.children.length==0){
                var ctl=this.table;
                var params={};
                params[ctl.idField]=record[ctl.idField];
                Api.getAjax().postJson(ctl.url, {params:params}).then(res => {
                    var data=res.result.data;
                    record.children=data;
                    ctl.$forceUpdate();
                })
            }
        },
        rightClick({event, node}){
            this.curRow = node._props.dataRef;
            const postition = {top: event.clientY, left: event.clientX};
            this.$refs.contextmenu.show(postition);
        },
        initSearchList() {
            FormQueryStrategyApi.getByListId(this.formBoList.id,'NO').then(res => {
                this.searchList = res.data.map(item => {
                    return {key: item.id, label: item.name};
                })
            });
        },
        getData(self_, this_) {
            var isDialog = this_.formBoList.isDialog;
            var isTreeDlg = this_.formBoList.isTreeDlg;
            var multiSelect = this_.formBoList.multiSelect;
            var rows = [];

            if (multiSelect) {
                if (isTreeDlg == 'YES') {
                    rows = this_.$refs.rxTree.getCheckedNodes(false);
                } else if (isDialog == 'YES') {
                    rows=this_.selectedTable.dataSource;
                }
            } else {
                if (isTreeDlg == 'YES') {
                    rows=this_.$refs.rxTree.getCheckedNodes(false);
                } else if(isDialog == 'YES') {
                    rows=this_.selectedRows;
                }
            }
            var data={rows:rows,multiSelect:multiSelect};
            return data;
        },
        parseTimeByDateFormat(dateFormat){
            dateFormat = dateFormat.replace(new RegExp("-","gm"),"/");
            return (new Date(dateFormat)).getTime();
        },
        searchDateChange(date,dateString,e){
            if(date){
                if(e.format=='YYYY-MM-DD HH:mm:ss'){
                    e.format='YYYY-MM-DDTHH:mm:ss';
                }
                var dataVal=date.format(e.format);
                if(e.queryField.indexOf("Q_")==-1){
                    this.queryParam[e.queryField] = this.parseTimeByDateFormat(dataVal);
                }else{
                    this.queryParam[e.queryField]=dataVal;
                }
            }else {
                delete this.queryParam[e.queryField];
            }
        },
        searchMonthChange(date,dateString,e) {
            if (date) {
                if (e.autoFilter == 'YES') {
                    this.queryParam["Q_" + e.queryField + "_D_GE"] = date.format('YYYY-MM') + "-01";
                    this.queryParam["Q_" + e.queryField + "_D_LE"] = date.format('YYYY-MM') + "-" + date.daysInMonth();
                } else {
                    this.queryParam[e.queryField + "_START"] = this.parseTimeByDateFormat(date.format('YYYY-MM') + "-01");
                    this.queryParam[e.queryField + "_END"] = this.parseTimeByDateFormat(date.format('YYYY-MM') + "-" + date.daysInMonth());
                }
            } else {
                if (e.autoFilter == 'YES') {
                    delete this.queryParam["Q_" + e.queryField + "_D_GE"];
                    delete this.queryParam["Q_" + e.queryField + "_D_LE"];
                } else {
                    delete this.queryParam[e.queryField + "_START"];
                    delete this.queryParam[e.queryField + "_END"];
                }
            }
        },
        searchRangeDateChange(date,format,e){
            if(!format){
                format='YYYY-MM-DD';
            }

            if(date.length==2){
                if (e.autoFilter == 'YES') {
                    this.queryParam["Q_" + e.queryField + "_D_GE"] = date[0].format(format);
                    this.queryParam["Q_" + e.queryField + "_D_LE"] = date[1].format(format);
                    let ref=this.$refs["queryField_" + e.queryField];
                    ref.value=date;
                }else{
                    this.queryParam[e.queryField + "_START"] = this.parseTimeByDateFormat(date[0].format(format));
                    this.queryParam[e.queryField + "_END"] = this.parseTimeByDateFormat(date[1].format(format));

                }
            }else {
                if (e.autoFilter == 'YES') {
                    delete this.queryParam["Q_" + e.queryField + "_D_GE"];
                    delete this.queryParam["Q_" + e.queryField + "_D_LE"];
                }else{
                    delete this.queryParam[e.queryField+"_START"];
                    delete this.queryParam[e.queryField+"_END"];
                }
            }
        },
        handTreeClick(selectedKeys,paramName){
            var params={};
            params[paramName]=selectedKeys[0];
            this.table.loadByParams(params);
        },
        getAjax(){
            return rxAjax;
        },
        handButtonClick(url) {
            var rows = [];
            if (this.formBoList.dataStyle == 'tree') {
                rows = this.table.getSelectedNodes();
            } else {
                rows = this.table.getSelectedRows();
            }
            rxAjax.postJson(url, {data: JSON.stringify(rows)}).then(res => {
                this.searchAll();
            });
        },
        closeSearchbar(){
            //关闭过滤弹窗；（点击X触发）
            this.fitSearch = false ;
        },
        saves(){
            //保存
            this.curSearchItem.listId=this.formBoList.id;
            this.curSearchItem.isPublic=this.isPublic?this.isPublic:'NO';
            this.curSearchItem.isUser=this.isUser?this.isUser:'NO';
            this.curSearchItem.queryCondition=JSON.stringify(this.queryCondition);
            FormQueryStrategyApi.save(this.curSearchItem).then(res=>{
                if(!res.success){
                    return;
                }
                this.loadCommonList();
            })
        },
        searchShow(){
            //点击过滤显示搜索框
            this.fitSearch = true ;
        },
        saveEdit(key){
            //编辑；
            this.findShow = true ;
            FormQueryStrategyApi.get(key).then(res=>{
                if(res.success) {
                    this.curSearchItem = res.data;
                    this.isPublic=this.curSearchItem.isPublic;
                    this.isUser=this.curSearchItem.isUser;
                    this.queryCondition=JSON.parse(this.curSearchItem.queryCondition);
                }
            })
        },
        itemClose(key){
            //删除；
            this.visibleModal = true ;
            this.curDelId=key;
        },
        handleCancel(){
            //选中的
            this.visibleModal = false ;
        },
        handleOk(){
            FormQueryStrategyApi.del({ids:this.curDelId}).then(res=>{
                this.visibleModal = false ;
                this.loadCommonList();
            })
        },
        listSearch(){
            //搜索
            this.findShow = !this.findShow  ;
            this.clacHeight();
        },
        listSearchAll(){
            this.clearJson(this.queryParam);
            for (var i = 0; i < this.queryCondition.length; i++) {
                var query = this.queryCondition[i];
                this.queryParam['Q_' + query.fieldName + '_' + query.dataType + '_' + query.fieldOp] = (query.fieldOp=='ISNULL' || query.fieldOp=='NOTNULL')?"1":query.fieldValue;
                this.searchAll();
            }
        },
        listResetSearch(){
            for (var i = 0; i < this.queryCondition.length; i++) {
                var query = this.queryCondition[i];
                delete query.fieldValue;
            }
            this.resetSearch();
        },
        isPublicChange(e) {
            if (e.target.checked) {
                this.isPublic = "YES";
            } else {
                this.isPublic = "NO";
            }
        },
        isUserChange(e) {
            if (e.target.checked) {
                this.isUser = "YES";
            } else {
                this.isUser = "NO";
            }
        },
        deployMenu() {
            var data = this.curSearchItem;
            if(!data.id){
                this.$message.error("请保存后再进行发布菜单！");
                return;
            }
            var component = "modules/form/core/FormBoListPreview";
            var params={listKey:this.formBoList.key,query:{queryId:data.id}}
            this.dialogBox.openDeploymenuDialog({
                name: this.formBoList.name,
                key: this.formBoList.key + 'List',
                component: component,
                params: params,
            }, {
                curVm: this, widthHeight: ['800px', '600px']
            })
        },
        findClose(){
            //关闭搜索弹窗
            this.queryCondition=[];
            this.isPublic=false;
            this.isUser=false;
            this.curSearchItem={};
            this.findShow = false ;
        },
        getFieldData() {
            if(this.formBoList && this.formBoList.id){
                FormBoListApi.getEdit2(this.formBoList.id).then(data => {
                    this.fieldDatas = data.fieldColumns.map(field => {
                        return {label: field.header, value: field.field, key: field.queryDataType}
                    });
                })
            }
        },
        fieldNameChange(value,item){
            for (var i = 0; i < this.fieldDatas.length; i++) {
                var field = this.fieldDatas[i];
                if (field.value == value) {
                    item.dataType = field.key;
                    break;
                }
            }
        },
        findCancel(idx){
            //删除条件;
            this.queryCondition.splice(idx,1);
        },
        addItem() {
            this.queryCondition.push({});
            this.scrollHeight();
        },
        clacHeight(){
            this.$nextTick(function () {
                let _rxfit = this.$refs['rxfit_'+this.formBoList.key] ;
                if(_rxfit) {
                    let _gridContent = _rxfit.$el.getElementsByClassName('gridContent')[0];
                    let _height = _gridContent.offsetHeight;
                    let _findItemContent = this.$refs.findBox.getElementsByClassName('find-item-content')[0];
                    _findItemContent.setAttribute('style', "max-height:" + _height * 0.35 + "px");
                }
            })
        },
        scrollHeight(){
            //增加时 让滚动条一直在下;
            this.$nextTick(function () {
                let _findItemContent = this.$refs.findBox.getElementsByClassName('find-item-content')[0];
                if(_findItemContent.scrollHeight>_findItemContent.scrollTop){
                    _findItemContent.scrollTop = _findItemContent.scrollHeight;
                }

            })
        },
        handSearchCommonClick(key){
            this.queryStrategy = "全部";
            this.searchCommonActive=key;
            if (key == 'all') {
                this.clearJson(this.queryParam);
                this.searchAll();
            }else {
                this.loadDataByQuery(key);
            }
        },
        handSearchClick(e) {
            var key = e.key;
            this.searchCommonActive='all';
            if (key == 'all') {
                this.queryStrategy = "全部";
                this.clearJson(this.queryParam);
                this.searchAll();
            } else {
                var self_=this;
                this.loadDataByQuery(key,function(data){
                    self_.queryStrategy = data.name;
                });
            }
        },
        loadDataByQuery(key,callback) {
            FormQueryStrategyApi.get(key).then(res => {
                if (res.success && res.code == 200) {
                    var data = res.data;
                    if(callback) {
                        callback(data);
                    }
                    this.clearJson(this.queryParam);
                    var queryCondition = JSON.parse(data.queryCondition);
                    for (var i = 0; i < queryCondition.length; i++) {
                        var query = queryCondition[i];
                        this.queryParam['Q_' + query.fieldName + '_' + query.dataType + '_' + query.fieldOp] = (query.fieldOp=='ISNULL' || query.fieldOp=='NOTNULL')?"1":query.fieldValue;
                        this.searchAll();
                    }
                }
            })
        },
        visibleChange(visible) {
            this.visible=visible;
            if (visible) {
                this.initSearchList();
            }
        },
        clearJson(json) {
            for (var x in json) {
                delete json[x];
            }
            return json;
        },
        searchAll() {
            // for(var key in this.queryParam){
            //     if(key.indexOf("queryField_")!=-1){
            //         delete  this.queryParam[key];
            //     }
            // }
            var ext={};
            /*这个代码负责将 {text:"",value:""} 这种类型的数据转成两个参数
             比如 : Q_NAME_S_EQ ={text:"",value:""}；
             转成:
             Q_NAME_S_EQ_=value;
             Q_NAME_name_S_EQ_=text;
            */
            for(var key in this.queryParam) {
                var val = this.queryParam[key];
                if (!val) {
                    continue;
                }
                if (val instanceof Array) {
                    ext[key]=val.join(",");
                    delete this.queryParam[key];
                } else {
                    if (typeof val == "object") {
                        var reg = /Q_(.*)?_(.*)?_(.*)/i;
                        var match = reg.exec(key);
                        if (match != null) {
                            var field = match[1];
                            var nameKey = key.replace(field, field + "_display");

                            ext[key] = val.key;
                            ext[nameKey] = val.label;
                            delete this.queryParam[key];
                        }
                    } else {
                        if (val.indexOf && val.indexOf("{") != -1 && val.indexOf("}") != -1) {
                            var reg = /Q_(.*)?_(.*)?_(.*)/i;
                            var match = reg.exec(key);
                            if (match != null) {
                                var field = match[1];
                                var nameKey = key.replace(field, field + "_display");
                                var json = JSON.parse(val);
                                ext[key] = json.value;
                                ext[nameKey] = json.text;
                                delete this.queryParam[key];
                            }
                        }
                    }
                }
            }
            Object.assign(this.queryParam,ext);
            this.summaryLoad=false;
            this.table.loadData();
        },
        resetSearch() {
            this.clearJson(this.queryParam);
            this.queryParam={};
            this.params={};
            let refs = Object.keys(this.$refs);
            for (let i = 0; i < refs.length; i++) {
                if(refs[i].indexOf("queryField_") != -1 ){
                    this.$refs[refs[i]].value=undefined;
                }
            }
            this.queryStrategy = "全部";
            this.searchCommonActive='all';
            this.searchAll();
        },
        handleDeleteSelected(record, index) {
            this.selectedTable.dataSource.splice(index, 1);
        },
        selectChange(selectedRowKeys,selectedRow){

            //发布事件。
            this.publishEvent(selectedRow[selectedRow.length-1]);

            if (this.formBoList.isDialog == 'NO') {
                return;
            }
            if (this.formBoList.multiSelect) {
                var ary = this.selectedTable.dataSource;
                for (var j = 0; j < selectedRow.length; j++) {
                    var flag = false;
                    var record = selectedRow[j];
                    if (record.children) {
                        delete record.children;
                    }
                    for (var i = 0; i < ary.length; i++) {
                        if (ary[i][this.formBoList.idField] == record[this.formBoList.idField]) {
                            flag = true;
                        }
                    }
                    if (!flag) {
                        ary.push(record);
                    }
                }
            } else {

                this.selectedRows = selectedRow;
            }
        },
        publishEvent(row){

            if(!this.formBoList.publishConf){
                return;
            }
            //[ {key:"ID_",label:""},{key:"ID_",label:""}]
            var ary=this.formBoList.publishConf;
            var params={};
            if(row) {
                for (var i = 0; i < ary.length; i++) {
                    var o = ary[i];
                    params[o.key] = row[o.key.toUpperCase()]
                }
            }
            var obj={component: this.formBoList.key,params:params};
            this.$bus.emit('formEvent', obj) ;
        },
        getCheckboxPropsFun(record){
            if(this.getCheckboxPropsMethod){
                return this.getCheckboxPropsMethod(record);
            }
            return {};
        },
        rowExpandMethod(expanded,record){
            if(this.rowExpandExt){
                this.rowExpandExt(expanded,record);
            }
            else{
                this.rowExpand(expanded,record);
            }
        },
        customCellMethod(field,row,index,data){
            var data=this.table.dataAction;
            if(this.customCell){
                return this.customCell(field,row,index,data) || {};
            }
            return {};
        },
        getSubData(data,pid){
            for(var i=0;i<data.length;i++){
                if(data[i][this.formBoList.idField]==pid){
                    return data[i].children;
                }
                if(data[i].children) {
                    var subData = this.getSubData(data[i].children, pid);
                    if (subData) {
                        return subData;
                    }
                }
            }
            return null;
        },
        getRowSpan(field,row,index,data){
            var rowSpan=1;
            if(row[field]) {
                if(row[this.formBoList.parentField] && row[this.formBoList.parentField]!='0'){
                    data=this.getSubData(data,row[this.formBoList.parentField]);
                }
                if ((index - 1) >= 0 && data[index - 1][field] == row[field]) {
                    //被合并
                    return 0;
                }
                for (var i = 0; i < data.length; i++) {
                    if (i > index) {
                        if(data[i][field] == row[field]){
                            rowSpan += 1;
                        }else{
                            break;
                        }
                    }
                }
            }
            return rowSpan;
        },
        activeEditFunMethod(col,row) {
            //col:{column,index} row:{record,index}
            if (this.activeEditFun) {
                var flag = this.activeEditFun(col, row);
                return typeof flag == 'boolean' ? flag : true;
            }
            return true;
        },
        rowSummaryFunMethod(record){
            if(this.rowSummaryFun){
                return this.rowSummaryFun(record) || {};
            }
            return null;
        },
        drawSummaryFunMethod(e){
            //e:{sender,data,column,field,cellHtml,width}
            if(this.drawSummaryFun){
                this.drawSummaryFun(e);
            }
        },
        /*
        处理行点击事件。
        */
        rowClick(record,index){
            if(this.handRowClick){
                this.handRowClick(record,index);
            }
        },
        getListData(data){
            //用于列表控件使用
        },
        getOpenDialogComponet(data){
            var template=`<div style="width:100%;height:100%;"> 
              <component v-if="!url" ref="current" :is="currentView" :layerid="layerid" :destroy="destroy" `;
            if(data) {
                for (var key in data) {
                    var value=data[key];
                    if(typeof value=='string' && value.constructor==String){
                        template += key + '="' + value + '" ';
                    }else if(typeof value=='object' && value.constructor==Object){
                        template += ' :' + key + '=\'' + JSON.stringify(value) + '\' ';
                    }else{
                        template += ' :' + key + '="' + value + '" ';
                    }
                }
            }
            template +=`      ></component>
             <iframe v-else style="height:700px;width:100%;" 
                      id="iframeId" :src="url" frameborder="0" scrolling="auto"> 
              </iframe>
           </div>`;
            var openDialogComponet= Vue.component('open-dialog', {
                template:template,
                ...eval('({\n' +
                    '        name: "DialogView",\n' +
                    '        props:["currentView","url","layerid","destroy"]\n' +
                    '    })')
            })
            return openDialogComponet;
        },
        selectFocus(ctl,params){
            var paramData={};
            if(params) {
                for (var i = 0; i < params.length; i++) {
                    paramData[params[i].fieldName] = this.queryParam[params[i].bindVal];
                }
            }
            this.$refs[ctl].loadData(paramData);
        },
        //查询条件变化后 联动修改
        searchChange(fieldName,selectParam){
            for (let i = 0; i < this.searches.length; i++) {
                if(this.searches[i].fieldName!=fieldName){
                    if(this.searches[i].params&&this.searches[i].params.length>0){
                        var params=this.searches[i].params;
                        for (var j = 0; j <params.length ; j++) {
                            if(params[j].bindVal==selectParam){
                                var param="Q_";
                                if(this.searches[i].tablePre&&this.searches[i].tablePre!=""){
                                    param=param+this.searches[i].tablePre+"_";
                                }
                                param=param+this.searches[i].fieldName+"_S_"+this.searches[i].fieldOp;
                                this.$refs[param].setSelectVal("");
                                this.searchChange(this.searches[i].fieldName,param);
                            }
                        }
                    }
                }
            }
        },

        /**
         * 打开页面定制组件
         * @param alias     定制页面别名
         * @param params    需要传递的参数
         */
        openCustom(alias,params){
            var baseConf= {
                "curVm": this,
                component: FormCustomView,
                title: "表单定制-"+alias,
                max:true,
                "data": {
                    "alias": alias,
                    "params": JSON.stringify(params)
                }
            };
            Util.open(baseConf, function (action) {});
        },
        open(conf,destroy){
            var data= conf.data;
            var component=conf.component;
            if(component) {
                conf.component = this.getOpenDialogComponet(data);
                var obj=require(`@/views/${component}`).default;
                conf.data={currentView:obj};
                Util.open(conf,destroy);
            }else{
                this.$message.warning("请填写相应组件路径！");
            }
        },
        openUrl(conf,destroy){
            var url=conf.url;
            if(url) {
                conf.component = this.getOpenDialogComponet();
                conf.data={url:url};
                Util.open(conf,destroy);
            }else{
                this.$message.warning("请填写相应URL路径！");
            }
        },
        loadByParams(params){
            this.table.loadByParams(params);
        },
        loadData(){
            this.table.loadData();
        },
        getDialogBox(){
            return  this.dialogBox;
        },
        getDialog(){
            return Dialog;
        },
        loadConfigList(){
            if(this.formBoList && this.formBoList.key){
                SaveExportApi.getByList(this.formBoList.key).then(res => {
                    this.configList = res.data;
                })
            }
        },
        exportById(id,columns){
            var parameter = {};
            parameter.boListKey = this.formBoList.key;
            if(id) {
                parameter.id = id;
            }
            else{
                parameter.columns = columns;
            }
            var temp = this.queryParam;
            for(var key in temp){
                parameter[key] = temp[key].replace(/\+/g,'%2B');
            }

            FormBoListApi.export(parameter).then(res => {
                if(!res){
                    return;
                }
                let blob = new Blob([res], {
                    type: 'application/vnd.ms-excel'
                });
                let fileName = this.formBoList.name + '.xlsx';
                if (window.navigator.msSaveOrOpenBlob) {
                    navigator.msSaveBlob(blob, fileName);
                } else {
                    var link = document.createElement('a');
                    link.href = window.URL.createObjectURL(blob);
                    link.download = fileName;
                    link.click();
                    //释放内存
                    window.URL.revokeObjectURL(link.href)
                }
            })
        },
        exportByColumns(columns){
            var parameter = {};
            parameter.boListKey = this.formBoList.key;
            parameter.columns=columns;
            var temp = this.queryParam;
            for(var key in temp){
                parameter[key] = temp[key].replace(/\+/g,'%2B');
            }

            FormBoListApi.export(parameter).then(res => {
                let blob = new Blob([res], {
                    type: 'application/vnd.ms-excel'
                });
                let fileName = this.formBoList.name + '.xlsx';
                if (window.navigator.msSaveOrOpenBlob) {
                    navigator.msSaveBlob(blob, fileName);
                } else {
                    var link = document.createElement('a');
                    link.href = window.URL.createObjectURL(blob);
                    link.download = fileName;
                    link.click();
                    //释放内存
                    window.URL.revokeObjectURL(link.href)
                }
            })
        },
        /**
         * 调用第三方接口
         * @param apiId
         * @param params
         * @param callback
         */
        invokeInterface(apiId,params,callback){
            FormBoListApi.executeInterfaceApi(apiId,params).then(res=>{
                if(callback){
                    callback(res);
                }
            })
        },
        /*
        * 调用脚本。
        */
        invokeScript(alias, params, callback) {
            FormBoListApi.invoke(alias, params).then(res => {
                if(callback) {
                    callback(res);
                }
            })
        },
        /**
         * 调用脚本返回Promise 对象。
         * @param alias
         * @param params
         * @returns {*}
         */
        invokeScriptPromise(alias,params){
            return FormBoListApi.invoke(alias, params);
        },
        /**
         * 调用脚本返回Promise。
         * @param alias
         * @param params
         * @returns {AxiosPromise}
         */
        invokeCustomQueryPromise(alias,params){
            return FormBoListApi.queryForJson(alias, {params: JSON.stringify(params)});
        },
        /**
         * 调用自定义查询。
         */
        invokeCustomQuery(alias,params,callback){
            FormBoListApi.queryForJson(alias, {params: JSON.stringify(params)})
                .then(res=>{
                    if(res.success && callback) {
                        callback(res.data);
                    }
                })
        },
        /**
         * 打开列表对话框。
         *
         * {
        "destField": "F_KH",
        "srcField": "ID_",
        "idx_": 1,
        "key": "F_KH",
        "label": "客户ID",
        "fieldOp": "EQ",
        "tablePre": "",
        "dataType": "string"
        }


         * @param record    当前记录
         * @param alias     别名
         * @param fieldMap  字段映射关系
         */
        openListDialog(record,alias,fieldMap){

            var ary=[];
            var jsonAry=JSON.parse(fieldMap);

            var typeJson={string:"S",int:"I",date:"D",float:"F"};

            for(var i=0;i<jsonAry.length;i++){
                var o=jsonAry[i];

                var tablePre=o.tablePre ? o.tablePre +"." :"";

                var type=typeJson[o.dataType]?typeJson[o.dataType]:"S";

                var params="Q_" + tablePre + o.destField +"_" +type +"_" +o.fieldOp;

                var tmp=params +"=" + record[o.srcField?o.srcField.toUpperCase():""];
                ary.push(tmp);
            }
            this.dialogBox.dialog(
                { key: alias ,params:ary.join("&")},
                {
                    curVm: this,
                    max: true,
                }
            )
        },
        /**
         * 启动流程。
         * @param record
         * @param conf
         */
        openStartFlowDialog(record,alias){
            var idfield=this.formBoList.idField;
            var id=record[idfield];
            var view="modules/bpm/core/BpmInstStart";
            var component=require(`@/views/${view}`).default;

            //传入流程ID和主键。
            let obj = {menuParams:JSON.stringify({defKey:alias}),pkId:id,formData:record};
            var baseConf = {
                component: component,
                data: obj,
                title: "启动流程",
                curVm: this,
                max:true
            };
            var self_=this;
            Util.open(baseConf, function (action, data) {
                if (action != 'ok') return;
                self_.table.loadData();
            });

        },
        /**
         * 是否能启动流程。
         * @param record
         * @param statusField
         * @returns {boolean}
         */
        canStartFlow(record,statusField){
            var status=record[statusField];
            if(!status || status=="DRAFTED"){
                return true;
            }
            return false;

        },
        getUtil(){
            return Util;
        },
        validRule(record,field,regular,prompt,index,text,blur) {
            //验证行编辑中文本控件的校验规则
            var value = record[field];
            if(value) {
                var regularObj = new RegExp(regular, "ig");
                if (!regularObj.test(value)) {
                    this.$message.error(prompt);
                    record[field] = "";
                    return;
                }
            }
            blur(index,field,text,record);
        },
        handRowClass(record,index){
            if(this.rowClassName){
                return this.rowClassName(record,index);
            }
        },
        /**
         * 修改日期范围参数，用于初始设置查询条件。
         * @param start
         * @param end
         */
        changeRangeParams(queryField, start,end,format){
            this.queryParam["Q_"+ queryField +"_D_GE"] = start;
            this.queryParam["Q_"+queryField +"_D_LE"] = end;
            let startDate;
            let endDate
            if(format){
                startDate=moment(start,format);
                endDate=moment(end,format);
            }
            else{
                startDate=moment(start);
                endDate=moment(end);
            }
            this.params['queryField_' +queryField]=[startDate,endDate];

        },
        /**
         * 设置日期查询范围。
         * @param queryField    需要定义的字段
         * @param amount        数量
         * @param unit          单位(days,months)
         */
        setRangeQuery(queryField, amount,unit){
            let format="YYYY-MM-DD";
            let end=moment().format(format);
            let start=moment().subtract(amount,unit).format(format);

            this.queryParam["Q_"+ queryField +"_D_GE"] = start;
            this.queryParam["Q_"+queryField +"_D_LE"] = end;
            let startDate=moment(start,format);
            let endDate=moment(end,format);

            this.params['queryField_' +queryField]=[startDate,endDate];
        },
        initColumns(){
            //当前用户租户标签
            var tenantLabel=this.user.tenantLabel;
            if(this.formBoList && this.formBoList.instColumnConfig){
                var instColumnConfig=this.formBoList.instColumnConfig;
                var columnConfs=[];
                for (let i = 0; i < instColumnConfig.length; i++) {
                    //判断租户标签
                    if(instColumnConfig[i].instLabel==tenantLabel){
                        columnConfs=instColumnConfig[i].columnConfs;
                    }
                }
                if(columnConfs && columnConfs.length>0){
                    var columns=[];
                    for (let i = 0; i < columnConfs.length; i++) {
                        var columnConf= columnConfs[i];
                        this.columns.find(function (item) {
                            if(item.dataIndex==columnConf.field){
                                item.title=columnConf.columnName || columnConf.oldName;
                                columns.push(item);
                            }
                        });
                    }
                    this.columns=columns;
                }
            }
        }
    },

}
