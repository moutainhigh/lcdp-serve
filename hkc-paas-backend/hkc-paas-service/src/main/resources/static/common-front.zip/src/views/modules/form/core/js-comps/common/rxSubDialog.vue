<template>
    <rx-dialog @handOk="handleSubmit" @cancel="cancel" ref="rxDialog">
        <div id="formContainer" style="width: 100%;">
            <component v-bind:is="currentView" :topVm="false" ref="component"
                       :permission="permissions"
                       :metadata = "metadata"
                       :data = "data"
                       :item="item"
            ></component>
        </div>
    </rx-dialog>
</template>

<script>
import Vue from 'vue'
import {RxDialog, Util} from 'jpaas-common-lib';
import '../index.js';

export default {
    name: "rxSubDialog",
    props: {
        html: {
            type: String
        },
        data: {
            type: Object,
            default:{}
        },
        script: {
            type: String
        },
        item: {
            type: Object
        },
        subName: {
            type: String
        },
        rowIndex: {
            type: String
        },
        layerid: {
            type: String
        },
        lydata: {
            type: Object
        },
        destroy: {
            type: Function
        },
        mainAlias: {
            type: String
        }
    },
    computed:{
        permissions(){
            let _data = this.data ;
            if(_data){
                return _data.permission ;
            }
        }
    },
    components: {
        RxDialog
    },
    data() {
        return {
            currentView: loadingComponent,
            formVm: {},
            metadata:this.lydata.data.metadata || {},
        }
    },
    created(){},
    mounted() {
        this.loadForm();
    },
    methods: {
        loadForm() {
            var formContainerId = "formContainer";
            if (this.mainAlias) {
                formContainerId += "_" + this.mainAlias;
            }
            customFormComponet.options.template = this.html;
            if (this.script) {
                //插入脚本
                Util.insertScript(formContainerId, this.script);
            }

            this.currentView = customFormComponet;
            this.$nextTick(function () {
                this.formVm = this.$refs.component;
                this.formVm.permission = this.data.permission;
                this.formVm.alias = this.data.alias;
                this.formVm.idField = this.data.idField;
                this.formVm.readonly = false;
                this.formVm.html = this.html;
                this.formVm.script = this.script;
                this.formVm.subName = this.subName;
                this.formVm.item = this.item;
            });
            return this.formVm;
        },
        isNull(val) {
            if (val === 0) {
                return false;
            }
            if (val == '' || val == undefined || val == 'undefined' || val == '[]') {
                return true;
            }
            return false;
        },
        valid(validRequired, validType) {
            let _metadat = this.lydata.data.metadata;
            let _data = this.item;
            if (_metadat) {
                let _fields = _metadat.fields;
                if (_fields) {
                    for (let item of _fields) {
                        let _key = item.name;
                        if (item.required) {
                            if (this.isNull(_data[_key])) {
                                return {
                                    required: true,
                                    content: '字段【' + item.comment + '】必填'
                                };
                            }
                        }
                    }
                }
            }
            return {
                required: false
            };
        },
        handleSubmit(e) {
            let _valid = this.valid();
            if (_valid.required) {
                this.$message.warning({
                    content: _valid.content
                })
                this.$refs.rxDialog.loading = false;
            } else {
                if(this.$parent.func_beforeClose){
                    let rtn=this.$parent.func_beforeClose(this.subName,this.item);
                    if(rtn && !rtn.success){
                        this.$message.warning(rtn.msg);
                        e.loading=false;
                        return;
                    }
                }
                Util.closeWindow(this, "ok")
            }
        },
        cancel() {
            Util.closeWindow(this, "cancel")
        },
    }
}
</script>

<style>
.ant-message {
    z-index: 99999;
}

/*子表弹窗样式*/
.table-detail {
    width: 100%;

    table-layout: fixed;
}

.dialog-header {
    padding: 10px;
    text-align: center;
    font-size: 16px;
    font-weight: bold;
}

.table-detail td {
    padding: 5px 10px;
}

.table-detail.column-two > tbody > tr > td:nth-child(odd) {
    width: 20%;
    text-align: right;
}

.table-detail.column-two > tbody > tr > td:nth-child(even) {
    width: 80%;
    text-align: left;
}

.table-detail.column-four > tbody > tr > td:nth-child(odd) {
    width: 15%;
    text-align: center;
    text-align: right;
}

.table-form.column-four > tbody > tr > td:nth-child(even) {
    width: 35%;
    text-align: left;
    padding: 10px;
}

#formContainer {
    background: #fff;
}
</style>
