import Vue from 'vue';

const CurAppKey='CUR_APP_KEY';

/**
 *  缓存当前的应用ID和名称    Elwin ZHANG  2021-5-18
 * @param appId  应用ID
 * @param appName  应用名称
 */
export function  setCurApp(appId,appName){
    if(!appId){
        appId='';
    }
    if(!appName){
        appName='';
    }
    let curApp={appId:appId,appName:appName};
    Vue.ls.set(CurAppKey,curApp);
}

/**
 *  获取缓存的应用ID和名称    Elwin ZHANG  2021-5-18
 * @returns {{appName: string, appId: string}}
 */
export  function  getCurApp(){
    let curApp=Vue.ls.get(CurAppKey);
    if(!curApp){
        curApp={appId:'',appName:''}
    }
    return curApp;
}