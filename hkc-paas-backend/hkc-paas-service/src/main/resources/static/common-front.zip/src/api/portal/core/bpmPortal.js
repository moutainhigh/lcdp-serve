import {Util} from  "jpaas-common-lib";
import FlowUtil from "@/views/modules/bpm/js/FlowUtil";
/**
 * 流程任务扩展。
 */
export default {
	mixins:[FlowUtil],
    methods:{
        /**
         * 待办任务办理
         * @param record
         */
        handleTask(record) {
            this.openInst(record.instId);
        },
        //显示流程实例明细
        handleBpmInst(record){
        	this.openDetail(record.instId);
        },

        /**
         * 打开表单
         * @param record
         */
        openForm(record,alias,readOnly,title) {
            var view="modules/form/core/FormSolutionShow";
            var component=require(`@/views/${view}`).default;
            let self_=this;
            Util.open({
                component: component,
                curVm: this,
                max:true,
                title: title || "打开表单",
                data: {
                    alias: alias,
                    pkId: record.ID_,
                    readOnly: readOnly,
                }
            }, function (action) {
                //这里没回调
                if(action=='ok'){
                    self_.loadColumn();
                }
            })
        },

    }
}