import rxAjax from '@/assets/js/ajax.js';
import FormUtil from "@/assets/js/FormUtil.js"

//表单方案 api接口
const FormSolutionApi = {};

FormSolutionApi.baseUrl= '/api-form/form/core/formSolution';
FormSolutionApi.exportUrl= FormSolutionApi.baseUrl + '/export';

/**
 * 获取满足条件的流程定义ID
 */
FormSolutionApi.getFlowDefId=function(params){
    var url =FormSolutionApi.baseUrl+"/getFlowDefId";
    return rxAjax.postJson(url,params);
}
/**
 *  表单方案导入
 * @param formData
 * @param callback
 * @returns {*}
 */
FormSolutionApi.doImport=function(formData,callback) {
  var url= FormSolutionApi.baseUrl+"/doImport";
  return rxAjax.upload(url,formData,callback);
}

/**
 * 表单方案导出
 * @param solutionIds
 * @returns {*}
 */
FormSolutionApi.doExport = function(solutionIds) {
  window.location.href='/api/api-form/form/core/formSolution/doExport?solutionIds=' + solutionIds;
}

//查询列表
FormSolutionApi.query=function (parameter) {
  var url= FormSolutionApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
* 获取单记录
* @param pkId
* @returns {*}
*/
FormSolutionApi.get =function(pkId) {
  var url= FormSolutionApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

//保存数据
FormSolutionApi.save =function(parameter) {
  var url= FormSolutionApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

//删除数据
FormSolutionApi.del =function(parameter) {
  var url= FormSolutionApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

FormSolutionApi.getTreeByAlias=function(alias,id){
  var url=FormSolutionApi.baseUrl + '/getTreeByAlias?alias=' + alias;
  if(id){
    url += "&pk=" + id;
  }
  return rxAjax.get(url);
}

FormSolutionApi.getByAlias =function(alias,id,params) {
  var url= FormSolutionApi.baseUrl + '/getByAlias?alias=' + alias ;
  if(id){
    url += "&pk=" + id;
  }
  return rxAjax.postJson(url,params);
}

/**
 * 保存表单数据。
 * {setting: {action: action, alias: self.formSolutionAlias}, data: data};
 * @param parameter
 * @returns {AxiosPromise|*}
 */
FormSolutionApi.saveForm = function (parameter) {
  var url = FormSolutionApi.baseUrl + '/saveForm';
  return rxAjax.postJson(url, parameter);
}

//查找所查询的数据并导出
FormSolutionApi.listExport= function (parameter){
    var url= FormSolutionApi.baseUrl + '/listExport';
    FormUtil.doExport(url,parameter);
}

FormSolutionApi.removeById = function (parameter) {
  var url = FormSolutionApi.baseUrl + '/removeById';
  return rxAjax.postJson(url, parameter);
}

FormSolutionApi.rowsSave = function (parameter) {
  var url = FormSolutionApi.baseUrl + '/rowsSave';
  return rxAjax.postJson(url, parameter);
}

FormSolutionApi.getConfig = function () {
  var url = FormSolutionApi.baseUrl + '/getConfig';
  return rxAjax.get(url);
}

FormSolutionApi.publish = function () {
  var url = FormSolutionApi.baseUrl + '/publish';
  return rxAjax.get(url);
}

FormSolutionApi.getListFields = function (formAlias) {
    var url = FormSolutionApi.baseUrl + '/getListFields?formAlias='+formAlias;
    return rxAjax.get(url);
}

FormSolutionApi.getBoEnts=function(formAlias){
    var url = FormSolutionApi.baseUrl + '/getBoEnts?formAlias='+formAlias;
    return rxAjax.get(url);
}

FormSolutionApi.getValueByCustomFormConfig=function(params){
    var url = FormSolutionApi.baseUrl + '/getValueByCustomFormConfig';
    return rxAjax.postJson(url,params);
}

FormSolutionApi.getBoEntityBySolId=function(solutionId){
    var url = FormSolutionApi.baseUrl + '/getBoEntityBySolId?solutionId='+solutionId;
    return rxAjax.get(url);
}

/**
 * 保存业务表单数据。
 * [{setting: {action: action, alias: self.formSolutionAlias}, data: data}]
 */
FormSolutionApi.saveBusForm = function (parameter) {
    var url = '/api-form/form/core/formBusinessSolution/saveBusForm';
    return rxAjax.postJson(url, parameter);
}

FormSolutionApi.getButtonsByFormJson=function(formSolutionAlias,formJson){
    var url = FormSolutionApi.baseUrl + '/getButtonsByFormJson?formSolutionAlias='+formSolutionAlias;
    return rxAjax.postJson(url,formJson);
}

FormSolutionApi.validPreByButton=function(preCondConfig,formJson){
    var url = FormSolutionApi.baseUrl + '/validPreByButton';
    return rxAjax.postJson(url,{config:preCondConfig,formJson:formJson});
}

export  default FormSolutionApi;

