import ajax from '@/assets/js/ajax.js';


export const FormApi = {};

FormApi.baseUrl= '/api-form/form/core/formPc';

FormApi.checkUniqueValue =function(params) {
  var url= "/api-form/form/core/formPc/checkUniqueValue";
  return  ajax.postJson(url,params)
}


FormApi.getPinyin =function(chinese) {
  var url= "/api-form/form/share/pinyin/getPinyin";
  var params={chinese:chinese,lower:true};
  return ajax.get(url,params);
}


//ueditor上传附件
FormApi.ueditorUrl= '/api/api-system/system/core/ueditor/upload';

FormApi.uploadUrl='/api-system/system/core/sysFile/upload';

//加载数据字典
FormApi.listDicTree =function(appId) {
  var url= "/api-system/system/core/sysTree/listDicTree";
  var params={appId:appId};
  return ajax.get(url,params);
}

FormApi.loadDic=function(dicKey) {
  var url= "/api-system/system/core/sysDic/listByKey";
  var params={key:dicKey};
  return ajax.get(url,params);
}

FormApi.loadByGrant=function(typeId){
  var url = "/api-form/form/core/formEntityDataSetting/queryData_"+typeId;
  return ajax.get(url);
}

FormApi.loadDicByPidAndDicId=function(dicKey,parentId) {
  var url= "/api-system/system/core/sysDic/getByPidAndDicId";
  var params={dicKey:dicKey,parentId:parentId};
  return ajax.get(url,params);
}

FormApi.upload=function(formData,callback) {
  var url= FormApi.uploadUrl;
  return ajax.upload(url,formData,callback);
}
FormApi.executeInterfaceApi=function(apiId,params){
    var url = "/api-system/system/core/sysInterfaceApi/executeApi?apiId="+apiId;
    return ajax.postJson(url,params);
}
FormApi.queryForJson=function(sqlKey,params) {
  var url= "/api-form/form/core/formCustomQuery/queryForJson_"+sqlKey;
  return ajax.postForm(url,params);
}

FormApi.getBoDefConstruct=function(boDefId){
	var url= "/api-form/form/bo/formBoDef/getBoDefConstruct?boDefId="+boDefId;
	return ajax.get(url);
}

//获取自定义列表单体
FormApi.getBoList=function(conf){
  var url= '/api-form/form/core/formBoList/' + conf.key +'/dialog';
  if(conf.params){
    url+="?" + conf.params;
  }
  if(conf.single){
    if(url.indexOf("?")==-1){
      url+="?single=" +conf.single;
    } else{
      url+="&single=" +conf.single;
    }
  }
  return ajax.get(url);
}

//导出Excel
FormApi.exportExcel=function(params) {
    var config={responseType:'arraybuffer'}
    return ajax.download(FormApi.baseUrl+"/exportExcel",params,config);
}

//导入Excel
FormApi.uploadExcel=function(formData,beginRow,sheetNo,callback) {
  return ajax.upload(FormApi.baseUrl+"/uploadExcel?beginRow="+beginRow+"&sheetNo="+sheetNo,formData,callback);
}

//导入Excel模板
FormApi.downloadTemplate=function(fieldsConfig,comment,accessToken) {
  var params={fieldsConfig:JSON.stringify(fieldsConfig),comment:comment};
  var config={responseType:'arraybuffer'}
  return ajax.download(FormApi.baseUrl+"/downloadTemplate?accessToken="+accessToken,params,config);
}

FormApi.queryAddress=function(addressKey,config) {
  var params={config:JSON.stringify(config),addressKey:addressKey};
  var url= "/api-form/form/share/formAddress/queryAddress";
  return ajax.postForm(url,params);
}


FormApi.getSignature=function (timestamp,timeout) {
  var url="/api-system/system/core/sysSignature/getSignature";
  var params={timestamp:timestamp};
  var conf={timeout:timeout};
  return ajax.postTimeout(url,params,conf);
}

FormApi.getSignatureList=function () {
  var url="/api-system/system/core/sysSignature/getSignatureList";
  return ajax.get(url);
}

FormApi.delSignature=function (ids) {
  var parameter={ids:ids};
  var url="/api-system/system/core/sysSignature/del";
  return ajax.postUrl(url,parameter);
}

FormApi.getSignatureAddress=function () {
  var url="/api-system/system/core/sysSignature/getSignatureAddress";
  return ajax.get(url);
}

FormApi.getCheckHistorys=function (instId) {
  var url="/api-bpm/bpm/core/bpmCheckHistory/getCheckHistorys?instId="+ instId;
  return ajax.get(url);
}

FormApi.invoke= function(alias,params){
	var url="/api-system/system/core/sysInvokeScript/invoke/"+alias;
	return  ajax.postJson(url,params)
}

/**
 * 给指定的URL提交JSON对象。
 * @param  url
 * @param  params json对象
 */
FormApi.postJson= function(url,params){
	return  ajax.postJson(url,params)
}

/**
 * 给指定的URL提交JSON对象。
 * @param  url
 * @param  params json对象
 */
FormApi.get= function(url,params){
  return  ajax.get(url,params);
}

/**
 * 提交数据。
 * params 两种方式 ： 对象 {name:"RAY"} 传键值对 name=ray
 * @param url
 * @param params
 */
FormApi.postForm= function(url,params){
  return  ajax.postForm(url,params);
}






//获取office模板
FormApi.getOfficeTemplateList=function(parameter) {
  var url= "/api-system/system/core/sysOfficeTemplate/query";
  return ajax.postJson(url,parameter);
}

//获取服务器路径
FormApi.getServerAddress=function(parameter) {
  var url="/api-form/form/core/formPc/getServerAddress";
  return ajax.get(url);
}

//获取组织维度
FormApi.getDimList=function(){
	var url= "/api-user/user/org/osDimension/getDimList";
	return ajax.get(url);
}

//获取组织维度等级
FormApi.getRankLevelByDimId=function(dimId){
	var url= "/api-user/user/org/osRankType/getByDimId?dimId="+dimId;
	return ajax.get(url);
}

//获取流程图
FormApi.getBpmnXmlFromParam=function (bpmParams) {
  var url ='/api-bpm/bpm/core/bpmImage/getBpmnXmlFromParam';
  return ajax.postJson(url,bpmParams);
}

//获取流程图节点信息
FormApi.getBpmnImageNodeInfo =function(bpmParams) {
  let url = '/api-bpm/bpm/core/bpmImage/getBpmnImageNodeInfo';
  return ajax.postJson(url,bpmParams);
}

FormApi.getUsersByIds=function (userIds){
  let url ='/api-user/user/org/osUser/getUsersByIds?userIds='+userIds;
  return ajax.postForm(url);
}

/**
 * 根据流程实例Id获取抄送记录
 * @param instId
 * @returns {*}
 */
FormApi.getCcRecordByInstId=function (instId){
    let url ='/api-bpm/bpm/core/bpmInstCc/getCcRecordByInstId?instId='+instId;
    return ajax.postForm(url);
}

//获取审批类型
FormApi.getCheckTypes=function (){
    let url ="/api-system/system/core/sysProperties/getCheckTypes";
    return ajax.get(url);
}

//获取审批类型
FormApi.getOpinionTemplate=function (){
    var url ="/api-form/form/core/formPc/getOpinionTemplate";
    return ajax.get(url);
}

export  default FormApi;

