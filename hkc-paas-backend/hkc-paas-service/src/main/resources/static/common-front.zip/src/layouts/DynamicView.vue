<template>
  <div style="width:100%;height:100%;">
    <component ref="current"
               :is="currentView"
               :data="data"
               :lydata="data"
               :pkId="data.pkId"
               :layerid="layerid"
               :destroy="destroy"></component>
  </div>
</template>

<script>
    export default {
        name: "dynamic-view",
        props:["currentView","data","layerid","destroy"]
    }
</script>

<style scoped>

</style>