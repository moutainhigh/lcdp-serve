import rxAjax from '@/assets/js/ajax.js';
import FormSolutionApi from "@/api/form/core/formSolution";

//表单业务方案 api接口
export const FormBusinessSolutionApi = {};

FormBusinessSolutionApi.baseUrl= '/api-form/form/core/formBusinessSolution';
FormBusinessSolutionApi.exportUrl= FormBusinessSolutionApi.baseUrl + '/export';

//查询列表
FormBusinessSolutionApi.query=function (parameter) {
    var url= FormBusinessSolutionApi.baseUrl + '/query';
    return rxAjax.postJson(url,parameter).then (res => {
        return res.result
    })
}

/**
 * 获取单记录
 * @param pkId
 * @returns {*}
 */
FormBusinessSolutionApi.get =function(pkId) {
    var url= FormBusinessSolutionApi.baseUrl + '/get?pkId=' + pkId;
    return rxAjax.get(url);
}

//保存数据
FormBusinessSolutionApi.save =function(parameter) {
    var url= FormBusinessSolutionApi.baseUrl + '/save';
    return rxAjax.postJson(url,parameter);
}

//删除数据
FormBusinessSolutionApi.del =function(parameter) {
    var url= FormBusinessSolutionApi.baseUrl + '/del';
    return rxAjax.postUrl(url,parameter);
}

/**
 * 获取单记录
 * @param pkId
 * @returns {*}
 */
FormBusinessSolutionApi.getByIdAndMainPk =function(pkId,mainPk) {
    var url= FormBusinessSolutionApi.baseUrl + '/getByIdAndMainPk?pkId=' + pkId+"&mainPk="+mainPk;
    return rxAjax.get(url);
}

FormBusinessSolutionApi.removeById = function (parameter) {
    var url = FormBusinessSolutionApi.baseUrl + '/removeById';
    return rxAjax.postJson(url, parameter);
}

export  default FormBusinessSolutionApi;

