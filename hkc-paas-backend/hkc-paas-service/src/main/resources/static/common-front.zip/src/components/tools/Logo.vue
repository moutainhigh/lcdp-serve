<template>
  <div class="logo">
      <div class="floa_left">
        <img v-if="systemStyle =='fluctuate' && background!='#ffffff'" src="../../image/logo_white.png" />
        <img v-else src="../../image/log.png" />
      </div>
      <div class="floa_h1" v-if="!collapsed">
          <h1 v-if="!collapsed && systemStyle =='fluctuate' && background!='#ffffff'"  style="color: #FFFFFF">{{appName}}</h1>
          <h1 v-else :class="{background_white:background=='#ffffff',sideBar_white:sideBar_Background=='#fafafa',}">{{appName}}</h1>
      </div>
  </div>
</template>

<script>
import SysPublicApi from "@/api/system/core/public";
import {mapState} from "vuex";
export default {
  name: 'Logo',
  props: {
    data:{
        type: Boolean
    },
    title: {
      type: String,
      default: 'JPAAS企业平台',
      required: false
    }
  },
    data (){
        return {
            appName:'企业平台'
        }
    },
    computed: {
        ...mapState({
            sideBar_Background: (state) => state.appSetting.sideBar_Background,
            systemStyle: (state) => state.appSetting.systemStyle,
            background: (state) => state.appSetting.background,
            collapsed: (state) => state.appSetting.collapsed,
        })
    },
    created() {
        let self=this;
        SysPublicApi.getSysAppConfigs().then(resp=>{
            if(resp.appName ){
                self.appName = resp.appName;
            }
        });
    }
}
</script>
<style scoped>
.sideBar_white{
    color: #46494d!important;
}
.background_white{
    color: #46494d!important;
}
.floa_left {
  margin-right: 6px;
  width: 66px;
    float: left;
}
.logo h1{
  font-size: 24px;
  background: transparent;
  color: #fff;
  white-space: nowrap;
  margin-top: 5px;

}
.logo{
    margin-left: 8px;
    padding-top: 15px;
    height: 77px;
    overflow: hidden;
}
.floa_h1{
    float: left;
    max-width: 165px;
}
  .floa_left img{
    max-width: 100%;
    width: 50px;
  }
</style>