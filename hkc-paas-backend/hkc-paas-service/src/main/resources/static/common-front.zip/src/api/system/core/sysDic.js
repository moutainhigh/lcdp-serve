import rxAjax from '@/assets/js/ajax.js';

const SysDicApi = {};

SysDicApi.baseUrl= '/api-system/system/core/sysDic';
SysDicApi.exportUrl= SysDicApi.baseUrl + '/export';


SysDicApi.doImport=function(formData,callback) {
  var url= SysDicApi.baseUrl+"/doImport";
  return rxAjax.upload(url,formData,callback);
}


SysDicApi.doExport = function(solutionIds) {
  window.location.href='/api/api-system/system/core/sysDic/doExport?solutionIds=' + solutionIds;
}

SysDicApi.query=function (parameter) {
  var url= SysDicApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
 * 获取单记录
 * @param pkId
 * @returns {*}
 */
SysDicApi.get =function(pkId) {
  var url= SysDicApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

SysDicApi.save =function(parameter) {
  var url= SysDicApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

SysDicApi.del =function(parameter) {
  var url= SysDicApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}


SysDicApi.getTopDicByTreeId =function(treeId) {
  var url= SysDicApi.baseUrl + '/getTopDicByTreeId?treeId='+ treeId;
  return rxAjax.get(url);
}

SysDicApi.getByTreeId =function(treeId) {
  var url= SysDicApi.baseUrl + '/getByTreeId?treeId='+treeId;
  return rxAjax.get(url);
}

SysDicApi.getByAlias =function(alias){
  var url= SysDicApi.baseUrl + '/getByAlias?alias='+alias;
  return rxAjax.get(url);
}

SysDicApi.getByParentId =function(parentId) {
  var url= SysDicApi.baseUrl + '/getByParentId?parentId='+parentId;
  return rxAjax.get(url);
}



SysDicApi.getById = function (dicId) {
  var url = SysDicApi.baseUrl + '/getById?dicId=' + dicId;
  return rxAjax.get(url);
}

SysDicApi.delByDicId = function (dicId,treeId) {
  var url = SysDicApi.baseUrl + '/delByDicId';
  return rxAjax.postForm(url, {dicId: dicId,treeId:treeId});
}

SysDicApi.delByDicIds = function (dicIds,treeId) {
  var url = SysDicApi.baseUrl + '/delByDicIds';
  return rxAjax.postForm(url, {dicIds: dicIds,treeId:treeId});
}

SysDicApi.rowSave = function (parameter) {
  var url = SysDicApi.baseUrl + '/rowSave';
  return rxAjax.postJson(url, parameter);
}

SysDicApi.batchSave = function (parameter) {
  var url = SysDicApi.baseUrl + '/batchSave';
  return rxAjax.postJson(url, parameter);
}


export default SysDicApi;


