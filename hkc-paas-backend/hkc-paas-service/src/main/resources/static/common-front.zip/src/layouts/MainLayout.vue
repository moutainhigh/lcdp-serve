<template>
		<a-layout id="components-layout-demo-custom-trigger" style="height: 100%">
			<a-layout-sider v-if="openAppType!='inner'"  class="aLayout" v-model="collapsed" :trigger="null" collapsible><div class="login">
					<img :style="{marginLeft:collapsed ? '10px':'0'}" src="@/image/log.png" />
					<span v-if="!collapsed">{{appName}}</span>
				</div>
				<left-menu :menu="leftMenu" :collapsed="collapsed"></left-menu>
			</a-layout-sider>
			<a-layout>
				<a-layout-header v-if="openAppType!='inner'" style="background: #fff; padding: 0;height: 50px">
					<a-icon
						class="trigger"
						:type="collapsed ? 'menu-unfold' : 'menu-fold'"
						@click="() => (collapsed = !collapsed)"
					/>
					<header-menu class="headerment" :collapsed="collapsed"></header-menu>

				</a-layout-header>
				<navigation-bar v-if="openAppType!='inner'" :collapsed="collapsed"></navigation-bar>
				<a-layout-content :style="{ margin: '10px', padding: '10px', background: '#fff', minHeight: '280px' }">

					<home-index v-if="(showHome || isOpenPop ) && appId" :appId="appId"></home-index>
					<router-view  v-else/>
				</a-layout-content>
			</a-layout>
			<a-spin class="load-span" v-if="loading" />
		</a-layout>
</template>

<script>
import {mapState,mapMutations} from 'vuex';
import headerMenu from "./compoment/HeaderMenu";
import leftMenu from "./compoment/LeftMenu";
import NavigationBar from "./compoment/NavigationBar";
import DialogView from "./DialogView";
import layoutContent from "@/layouts/js/layoutContent";
import HomeIndex from "@/views/HomeIndex";
import EventListener from "@/views/modules/form/core/formsolution/EventListener";
export default {
	name: "MainLayout",
	components: {
		leftMenu,
		headerMenu,
		DialogView,
		HomeIndex,
		NavigationBar
	},
	mixins:[layoutContent,EventListener],
	props: {
		appKey:{
			type:String,
			default:""
		}
	},
	computed: {
		...mapState({
			menus: state => state.appSetting.menus,
			menuMap: state => state.appSetting.menuMap,
			navigation: state => state.appSetting.navigation,
			loading: state => state.appSetting.loading,
			switching: state => state.appSetting.switching,
			activeKey: state => state.appSetting.activeKey,
			showType: state => state.appSetting.showType,
			background: (state) => state.appSetting.background,
			sideBar_Background: (state) => state.appSetting.sideBar_Background,
			systemStyle: (state) => state.appSetting.systemStyle,
			openAppType: (state) => state.appSetting.openAppType,
		})
	},
	data() {
		return {
			collapsed: false,
			leftMenu: {},
		}
	},
	created() {
		if(this.$route.meta && this.$route.meta.id){
			var menuId= this.$route.meta.id
			var selectMenu=this.getSelectMenus(this.menus,menuId);
			if(selectMenu && selectMenu.length>0){
				if(selectMenu[0].showType=="NEW_WIN"){
					this.setNewPageMenu(selectMenu[0].id);
				}
				this.setSelectMenu(selectMenu[0]);
			}
			this.setIdKey(this.appKey);
		}
	},
	methods: {
		...mapMutations('appSetting', ['setAppKey','setShowHome','setSelectMenu','setIdKey','setMenuPath','setNewPageMenu','setNavigations','setOpenAppType']),
	},
	watch: {
		selectMenu: {
			handler: function (val, oldVal) {
				this.handlerFun(val);
				if(val.settingType != "iframe"  ){
					var navigations=this.getNavigations(val,this.menus);
					this.setNavigations(navigations);
				}
			},
			deep: true,
			immediate:true
		}
	}
}
</script>

<style scoped>
.aLayout{
	position: relative;
	z-index: 99;
}
.headerment{
	width: calc(100% - 70px);
	float: right;
}
.login{
	width: 100%;
    background:#002140;
	padding: 10px;
	overflow: hidden;
	height: 50px;

}
.login img{
	width: 35px;
	height: 35px;
	margin: auto;
}
.login span{
	color: white;
	margin-left: 10px;
}
#components-layout-demo-custom-trigger .trigger {
	font-size: 18px;
	line-height: 64px;
	padding: 0 24px;
	cursor: pointer;
	transition: color 0.3s;
}

#components-layout-demo-custom-trigger .trigger:hover {
	color: #1890ff;
}

#components-layout-demo-custom-trigger .logo {
	height: 32px;
	background: rgba(255, 255, 255, 0.2);
	margin: 16px;
}

</style>
