/**
 * 自定义验证规则。
 */
export var VTypes={
	isEnglish:{
		msg:"必须输入英文或下划线",
		valid:function(v){
			if (/^[a-zA-Z\_]+$/g.test(v)) return true;
    		return false;
		}
	},
	isEnglishAndNumber:{
		msg:"必须输入英文或数字",
		valid:function(v){
			if (/^[0-9a-zA-Z\_]+$/g.test(v)) return true;
    		return false;
		}
	},
	isKeyLabel:{
		msg:"必须输入英文开头",
		valid:function(v){
			if (/^[a-zA-Z][a-zA-Z0-9]*$/.test(v)) return true;
    		return false;
		}
	},
	isNumber:{
		msg:"必须输入数字",
		valid:function(v){
			if (/^[-+]?[0-9]+(\.[0-9]+)?$/g.test(v)) return true;
    		return false;
		}
	},
	isInteger:{
		msg:"必须输入整数",
		valid:function(v){
			var re = new RegExp("^[-+]?[0-9]+$");
    		if (re.test(v)) return true;
    		return false;
		}
	},
	isPositiveInteger:{
		msg:"必须输入正整数",
		valid:function(v){
			if (/^[1-9]\d*$/g.test(v)) return true;
    		return false;
		}
	},
	isNegtiveInteger:{
		msg:"必须输入负整数",
		valid:function(v){
			if (/^-[0-9]\d*$/g.test(v)) return true;
    		return false;
		}
	},
	isFloat:{
		msg:"必须输入浮点数",
		valid:function(v){
			if (/^-?([1-9]\d*\.\d*|0\.\d*[1-9]\d*|0?\.0+|0)$/g.test(v)) return true;
    		return false;
		}
	},
	isPositiveFloat:{
		msg:"必须输入正浮点数",
		valid:function(v){
			if (/^([1-9]\d*\.\d*|0\.\d*[1-9]\d*)$/g.test(v)) return true;
    		return false;
		}
	},
	isNegtiveFloat:{
		msg:"必须输入负浮点数",
		valid:function(v){
			if (/^-([1-9]\d*\.\d*|0\.\d*[1-9]\d*)$/g.test(v)) return true;
    		return false;
		}
	},
	isChinese:{
		msg:"必须输入中文",
		valid:function(v){
			var re = new RegExp("^[\u4e00-\u9fa5]+$");
    		if (re.test(v)) return true;
    		return false;
		}
	},
	IDCard:{
		msg:"必须输入15-18位数字",
		valid:function(v){
			if (/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(v)) return true;
    		return false;
		}
	},
	isUrl:{
		msg:"必须输入合法Url地址",
		valid:function(v){
			var reg=new RegExp("^[A-Za-z]+://[A-Za-z0-9-_]+\\.[A-Za-z0-9-_%&\?\/.=]+$");
    		if (reg.test(v)) return true;
    		return false;
		}
	},
	isEmail:{
		msg:"必须输入合法Email地址",
		valid:function(v){
			if (/^(\w)+(\.\w+)*@(\w)+((\.\w+)+)$/g.test(v)) return true;
    		return false;
		}
	},
	isChinesePostCode:{
		msg:"必须输入合法中国邮编地址",
		valid:function(v){
			if (/^[1-9]\d{5}(?!\d)$/g.test(v)) return true;
    		return false;
		}
	},
	isChinesePhone:{
		msg:"必须输入合法中国固话号码",
		valid:function(v){
			if (/^\d{3}-\d{8}|\d{4}-\d{7}$/g.test(v)) return true;
    		return false;
		}
	},
	isChineseMobile:{
		msg:"必须输入合法中国手机号码",
		valid:function(v){
			var re=new RegExp("^((13[0-9])|(15[^4,\\D])|(18[0,2,3,5-9]))\\d{8}$");
    		if (re.test(v)) return true;
    		return false;
		}
	},
	isIP:{
		msg:"必须输入合法IP地址",
		valid:function(v){
			if (/^\d+\.\d+\.\d+\.\d+$/g.test(v)) return true;
    		return false;
		}
	},
	isQQ:{
		msg:"必须输入正确QQ号码",
		valid:function(v){
			if (/^[1-9][0-9]{4,}$/g.test(v)) return true;
    		return false;
		}
	},
	float:{
		msg:"必须输入浮点数",
		valid:function(v){
			if (/^-?([1-9]\d*\.\d*|0\.\d*[1-9]\d*|0?\.0+|0|\d*)$/g.test(v)) return true;
    		return false;
		}
	},
	len:{
		msg:function(v,args){
    		return "只允许输入长度为"+args;
		},
		valid:function(v,args){
			if(!v) return true;
			if(v.toString().length<=parseInt(args)){
				return true;
			}
    		return false;
		}
	},
	length:{
		msg:function(v,args){
    		return "只允许输入长度为"+args;
		},
		valid:function(v,args){
			if(!v) return true;
			if(v.toString().length<=parseInt(args)){
				return true;
			}
    		return false;
		}
	},
	minnum:{
		msg:"小于最小边界" ,
		valid:function(v,args){
			if(v<parseFloat( args)){
				return false;
			}
    		return true;
		}
	},
	maxnum:{
		msg:"大于最小边界" ,
		valid:function(v,args){
			if(v>parseFloat(args)){
				return false;
			}
    		return true;
		}
	}


}


/**
 * 根据vtype 进行验证。
 */
export  default function _validVtype (val,vtype){
	var aryRule=vtype.split(";");
	for(var i=0;i<aryRule.length;i++){
		var rule=aryRule[i];
		var aryTmp=rule.split(":");
		var pre=aryTmp[0];
		var params="";
		var validObj=VTypes[pre];
		if(!validObj) continue;
		if(aryTmp.length==1){
			var rtn=validObj.valid(val);
			if(!rtn) {
				return {success:false,msg:validObj.msg};
			}
		}
		else  if(aryTmp.length==2){
			params=aryTmp[1];
			var rtn=validObj.valid(val,params);
			if(!rtn) {
				return {success:false,msg:(typeof validObj.msg== 'function')?validObj.msg(val,params):validObj.msg};
			}
		}
	}
	return {success:true,msg:validObj.msg};
}


