import bpmPortal from "@/api/portal/core/bpmPortal";
import messageBoxPortal from "@/api/portal/core/messageBoxPortal";
import schedulePortal from "@/api/portal/core/schedulePortal";
import newsPortal from "@/api/portal/core/newsPortal";
import menuPortal from "@/api/portal/core/menuPortal";


/**
 * 栏目类型扩展。
 */
export default {
    mixins:[bpmPortal,messageBoxPortal,schedulePortal,newsPortal,menuPortal]
}