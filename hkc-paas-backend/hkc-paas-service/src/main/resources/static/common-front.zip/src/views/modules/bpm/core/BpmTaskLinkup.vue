<template>
  <rx-dialog @handOk="submitForm" @cancel="cancel" order="buttom" btnalign="center">
    <rx-fit>
      <div style="height:100%;width:100%;padding:20px;">
      <a-form-model ref="form" :model="form" :rules="rules">
        <a-row>
          <a-col :span="24">
            <a-form-model-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="任务名称">
              {{subject}}
            </a-form-model-item>
          </a-col>
        </a-row>
        <a-form-item label="沟通人" :labelCol="labelCol1" :wrapperCol="wrapperCol1">
          <rx-user-component ref="toUser" v-model="form.toUser" :single="false"></rx-user-component>
        </a-form-item>
        <a-form-model-item label="意见" :labelCol="labelCol1" :wrapperCol="wrapperCol1">
          <a-textarea v-model="form.opinion" style="width: 100%"/>
        </a-form-model-item>
        <a-form-model-item label="附件" :labelCol="labelCol1" :wrapperCol="wrapperCol1">
          <rx-attach-component v-model="fileList" ></rx-attach-component>
        </a-form-model-item>
        <a-form-model-item label="通知方式" :labelCol="labelCol1" :wrapperCol="wrapperCol1">
          <a-checkbox-group :options="msgOptions" v-model="form.informTypes"></a-checkbox-group>
        </a-form-model-item>
      </a-form-model>
      </div>
    </rx-fit>
  </rx-dialog>
</template>

<script>
    import {BaseFormModel, RxDialog,Dialog,Util,RxAttachComponent,RxUserComponent} from 'jpaas-common-lib';
    import BpmtaskApi from "@/api/bpm/core/bpmTask";
    import BpmPublicApi from '@/api/bpm/core/BpmPublicApi'


    export default {
        name: "bpm-task-linkup",
        props:{
            subject:String,
            taskId:String,
            layerid: String,
            lydata: Object,
            destroy:Function
        },
        mixins:[BaseFormModel],
        components:{
          RxAttachComponent,
          RxUserComponent,
            RxDialog
        },
        data (){
            return {
                rules: {
                    toUser:[{ required: true, message: '请选沟通人', trigger: 'change' }]
                },
                msgOptions:[],
                form:{
                    opinion:"",
                    opFiles:"",
                    toUser:[],
                    informTypes:[]
                },
                fileList:[]
            }
        },
        created(){
            this.init();
        },
        methods:{
            init(){
                this.form.taskId=this.taskId;
                BpmPublicApi.getMessageHandler().then(res=>{
                    res.forEach((val)=> {
                        this.msgOptions.push({label:val.name,value:val.type})
                    })
                })
            },
            closeWindow(){
                Util.closeWindow(this,'cancel');
            },
            submitForm(e){
                var self_=this;
                var userIds=this.$refs.toUser.getUserIds();
                if(!userIds){
                  e.loading=false;
                  this.$message.error('请选择沟通人！');
                  return;
                }
                this.form.opFiles=JSON.stringify(this.fileList);
                this.$refs.form.validate(valid=>{
                    if(!valid){
                        e.loading=false;
                        return;
                    }
                    this.form.msgTypes=this.form.informTypes.join(",");
                    this.form.toUserAccounts=userIds;
                    this.$confirm({
                        zIndex:20000,
                        title: '提示信息',
                        content: '确认发送沟通任务吗?',
                        okText:'确认',
                        cancelText: '取消',
                        onOk() {
                            delete  self_.form.informTypes;
                            delete  self_.form.toUser;
                            BpmtaskApi.submitTasklinkup(self_.form).then(resp=>{
                                e.loading=false;
                                if(resp.success){
                                    Util.closeWindow(self_,"ok");
                                }
                            });
                        },
                        onCancel() {
                            e.loading=false;
                        }
                    });

                });
            }
        }
    }
</script>

<style scoped>

</style>