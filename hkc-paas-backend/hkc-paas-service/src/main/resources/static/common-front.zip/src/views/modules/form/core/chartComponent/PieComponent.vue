<template>
    <div class="wrap">
        <div><filter-params @paramsChange="paramsChange" :config="config" :filterParams="config.filterParams" ></filter-params></div>
        <div style="height: 100%" :ref="config.alias"></div>
    </div>
</template>

<script>
import ChartPublic from '../formComponent/ChartPublic'

export default {
    /**
     * 饼图
     */
    name: "pie-component",
    mixins: [ChartPublic],
    data() {
        return {
        }
    },
    methods: {

        setOption(){
            //图例组件
            var legend = [];
            var dimensions = [];
            /**
             *系列列表
             [{name: 名称,
             type: 类型,
             data: 数据 []
             }]
             */
            var series = [];

            dimensions=this.getDimensions();

            //获取度量
            for (var i = 0; i < this.config.measures.length; i++) {
                var array=[];
                var measure = this.config.measures[i];
                legend.push(measure.fieldLabel);
                for (var j = 0; j < this.data.length; j++) {
                    var value= this.data[j][measure.tableName+'_'+measure.fieldName];
                    if(value){
                        array.push({
                            value:value,
                            name:dimensions.data[j]
                        });
                    }else {
                        array.push({
                            value:0,
                            name:dimensions.data [j]
                        });
                    }
                }
                var obj={
                    name: measure.fieldLabel,
                    type:this.config.reportType,
                    data:array,
                }
                if(this.config.advConfig.inside && this.config.advConfig.outside){
                    var radius=[];
                    //内
                    radius.push(this.config.advConfig.inside);
                    //外
                    radius.push(this.config.advConfig.outside);
                    obj.radius=radius;
                }
                series.push(obj);
            }

            this.option={
                tooltip: {
                    trigger: 'item'
                },
                toolbox: {
                    feature: {
                        saveAsImage: {show:this.config.advConfig.saveAsImage},
                        restore: {show: this.config.advConfig.restore}
                    }
                },
                color:this.getColors(),
                legend: {
                    orient: 'vertical',
                    show:this.config.advConfig.legendShow,
                    left:this.config.advConfig.legendLeft,
                    top:this.config.advConfig.legendTop
                },
                series: series
            };

        }
    }
}
</script>

<style>

</style>