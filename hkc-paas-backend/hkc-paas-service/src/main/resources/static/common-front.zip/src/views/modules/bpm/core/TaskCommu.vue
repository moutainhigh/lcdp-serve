<template>
  <a-row style="padding-top:10px;" v-if="taskLinkupParam.bpmCmTaskInfos.length>0">
    <a-alert :message="'你正与进行事项审批沟通，沟通事项完成后，才能事项的下一步处理，目前的沟通反馈如下：'" type="info" closeText="关闭" >
      <p slot="description">
      <ul>
        <li v-for="item in taskLinkupParam.bpmCmTaskInfos">
          沟通:<span>{{item.cmUserName}}</span>,
          <span v-if="item.opinion==''">
                  <span style="color:red">暂无回复。</span><a-button type="link" icon="edit" @click="revokeCmTask(item.taskId)" size="small">撤回沟通</a-button>
                </span>
          <span v-else>回复：{{item.opinion}}</span>
        </li>
      </ul>
      </p>
    </a-alert>
  </a-row>
</template>

<script>
    import BpmtaskApi from "@/api/bpm/core/bpmTask";


    export default {
        name: "task-commu",
        props:{
            taskLinkupParam:{
                type:Object
            }
        },
        methods:{
            //撤回沟通任务
            revokeCmTask(taskId){
                let self=this;
                //进行任务撤回处理
                BpmtaskApi.revokeCmTask(taskId).then(resp=>{
                    this.$emit("commuTaskRevoked")
                });
            },
        }
    }
</script>

<style scoped>

</style>