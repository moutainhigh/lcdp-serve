<template>
	<div style="height: 100%">
		<div id="app">
			<router-view />
		</div>
	</div>
</template>

<script>

export default {
	name: 'App',
	data(){
		return {
		}
	},
	created() {
	}
}
</script>

<style>
.tabFuns .ant-tabs-content{
	height: 100% !important;
}
#app {
	font-family: Avenir, Helvetica, Arial, sans-serif;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;

	color: #2c3e50;
}
.aDrawer .ant-drawer-mask{
	height: calc(100% - 63px) !important;
	margin-top: 63px;
	margin-left: 10px;
}
.aDrawer .ant-drawer-content-wrapper{
	width: 324px!important;
	margin-left: 210px;
	height:calc(100% - 83px) !important;
	border-radius: 10px;
	overflow: auto;
	margin-top: 73px;
}
.aDrawerLeft .ant-drawer-content-wrapper{
	margin-left: 0px!important;
}
html, body, #app {
	height: 100%;

}
.layersty{
  width: 100%;
}
.defaultContent{
	height: 100%;
}
.defaultContent >div{
	height: 100%;
}
</style>
