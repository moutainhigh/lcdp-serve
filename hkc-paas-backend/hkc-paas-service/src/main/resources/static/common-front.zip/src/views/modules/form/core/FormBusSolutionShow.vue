<template>
    <div style="width: 100%">
        <div v-if="busSolution.navigationPosition=='horizontal'" class="FormBusSolutionShow">
            <div>
                <div class="FormBusSolutionShow_button">
                    <a-button
                        v-if="current < formSolutions.length -1 && !readOnly && mode=='form'"
                        type="primary"
                        style="margin-right: 8px"
                        @click="save"
                    >
                        保存
                    </a-button>
                    <a-button
                        v-if="current == formSolutions.length - 1 && !readOnly"
                        type="primary"
                        style="margin-right: 8px"
                        @click="submit"
                    >
                        提交
                    </a-button>
                    <a-button style="margin-right: 8px" @click="prev">
                        上一步
                    </a-button>
                    <a-button style="margin-right: 8px" type="primary" @click="next">
                        下一步
                    </a-button>
                </div>
                <div class="FormBusSolutionShow_asteps" :style="`width:${formAllConfig.allWidth}`" >
                    <a-steps :current="current" size="small" :direction="busSolution.navigationPosition">
                        <a-step v-for="item in formSolutions" :status="item.status" :key="item.idx_" :title="item.navigationName" />
                    </a-steps>
                </div>
            </div>
            <div :style="`max-width:${formAllConfig.allWidth};margin:auto;`">
                <rx-form v-if="mode=='form'" ref="rxForm" :layerid="layerid" :destroy="destroy"></rx-form>
                <component ref="customView" :is="customView" :busFormData="busFormData" :readOnly="readOnly" v-else></component>
            </div>
        </div>
        <div v-else class="FormBusSolutionShow_vertical">
            <div class="FormBusSolutionShow_Asteps">
                <a-steps  :current="current" size="small" :direction="busSolution.navigationPosition">
                    <a-step v-for="item in formSolutions" :status="item.status" :key="item.idx_" :title="item.navigationName" />
                </a-steps>
            </div>
            <div>
                <div :style="`max-width:${formAllConfig.allWidth};;margin:auto;`">
                    <rx-form v-if="mode=='form'" style="height: 100%" ref="rxForm" :layerid="layerid" :destroy="destroy"></rx-form>
                    <component ref="customView" :is="customView" :busFormData="busFormData" :readOnly="readOnly" v-else></component>
                </div>
            </div>
            <div>
                <div class="FormBusSolutionShow_vertical_button"><a-button type="primary" @click="prev">上一步</a-button></div>
                <div class="FormBusSolutionShow_vertical_button"><a-button type="primary" @click="next">下一步</a-button></div>
                <div class="FormBusSolutionShow_vertical_button"><a-button v-if="current == formSolutions.length - 1 && !readOnly" type="primary" @click="submit">提交</a-button></div>
                <div class="FormBusSolutionShow_vertical_button"> <a-button v-if="current < formSolutions.length -1 && !readOnly" type="primary" @click="save">保存</a-button></div>
            </div>
        </div>
    </div>
</template>

<script>
import FormBusinessSolutionApi from '@/api/form/core/formBusinessSolution'
import {rxForm} from "jpaas-form-component";
import FormSolutionApi from "@/api/form/core/formSolution";
import FormUtil from "@/views/modules/form/core/FormUtil";
import userState from "@/assets/js/userState";
import FormSolutionFunc from "@/views/modules/form/core/formsolution/FormSolutionFunc";
import {Util} from 'jpaas-common-lib';

export default {
    name: "FormBusSolutionShow",
    components: {
        rxForm
    },
    mixins: [userState,FormSolutionFunc],
    props: {
        alias: {
            type: String
        },
        busSolId: {
            type: [String, Number]
        },
        rowData: {
            type: Object
        },
        /**
         * 不使用主键打开表单数据。
         * {
         *     param1:"",
         *     param2:""
         * }
         */
        params: {
            type: Object
        },
        readOnly: {
            type: Boolean,
            default: false
        },
        setInitData: {
            type: Function
        },
        layerid: {
            type: String,
            default: ""
        },
        destroy: {
            type: Function
        }
    },
    data() {
        return {
            //业务方案配置得表单方案
            formSolutions: [],
            //表单业务数据
            formBusInstData: [],
            //业务方案
            busSolution:{},
            //当前表单方案
            curFormSolution:{},
            //当前导航
            current: 0,
            //业务表单数据 用于存放表单得数据
            busFormData:{},
            //主表单方案
            mainSolution:{
                alias:"",
                relPk:""
            },
            formAllConfig:{
                allWidth: "1300px",
                bg: "#fff"
            },
            mode:"form",
            customView:""
        }
    },
    created() {
        this.getBusinessSolution();
    },
    methods: {
        //获取业务方案
        getBusinessSolution(){
            if(this.busSolId){
                var mainPk=this.rowData?this.rowData["ID_"]:"";
                FormBusinessSolutionApi.getByIdAndMainPk(this.busSolId,mainPk).then(res=>{
                    if(res.success){
                        this.busSolution=res.data.busSolution;
                        this.formBusInstData=res.data.formBusInstData;
                        this.mainSolution=JSON.parse(this.busSolution.mainFormSolution);
                    }
                });
            }
        },
        init(data,alias,pkId,params,callback){
            var _self=this;
            FormSolutionApi.getByAlias(alias, pkId,params).then(res => {
                if (res.metadata) {
                    res.metadata = JSON.parse(res.metadata);
                }
                if (res.metadata.formAllConfig) {
                    _self.formAllConfig = res.metadata.formAllConfig
                }
                var tmp = FormUtil.getTemplate(res);
                res.template = `<div class="previewBox">${tmp}</div>`;
                if(data){
                    res.data=data;
                }
                _self.busFormData[alias]= res.data;
                if(callback){
                    callback();
                }
                _self.initForm(res);
            })
        },
        initForm(res) {
            var curUser = this.user;
            var contextData = {
                type: "form",
                curUserId: curUser.userId,
                curUserName: curUser.fullName,
                account: curUser.account,
                deptId: curUser.deptId,
                busFormData:this.busFormData
            };
            this.$refs.rxForm.loadForm(res, this.readOnly, contextData);
        },
        //初始化业务表单的表单数据
        initBusFormData(alias,pkId) {
            var self=this;
            FormSolutionApi.getByAlias(alias, pkId).then(res => {
                self.busFormData[alias]=res.data;
                //是否为当前表单
                if(self.curFormSolution.value==alias){
                    if (res.metadata) {
                        res.metadata = JSON.parse(res.metadata);
                    }
                    var tmp = FormUtil.getTemplate(res);
                    res.template = `<div class="previewBox">${tmp}</div>`;
                    self.initForm(res);
                }
            })
        },
        //下一步
        async next() {
            var self=this;
            if(this.mode!="custom"){
                var formData =this.$refs.rxForm.getData();
                this.busFormData[this.curFormSolution.value]=formData;
            }
            if(this.current < this.formSolutions.length - 1){
                //处理当前页面函数
                var curSol=self.formSolutions[self.current];
                //只读与自定义页面不需要验证必填
                if(!this.readOnly && curSol.mode!="custom"){
                    var validResult = await this.validForm(true);
                    if (!validResult.success) {
                        this.$message.warning(validResult.msg);
                        return;
                    }
                }
                //处理下一步的条件函数
                var nextSol=self.formSolutions[self.current+1];
                var result=this.handleNextFunc(nextSol,self.current+1,"next");
                if(result.success){
                    this.$message.warning(result.message);
                    return;
                }
                self.mode=nextSol.mode;
                //下一个
                this.formSolutions[this.current].status="finish";
                this.current=result.index || this.current+1;
                this.formSolutions[this.current].status="process";
                //显示自定义页面
                if("custom"==nextSol.mode){
                    self.customView=self.loadView(nextSol.formSolution);
                    return;
                }
                this.curFormSolution=JSON.parse(this.formSolutions[this.current].formSolution);
                this.curFormSolution["relField"]=this.formSolutions[this.current].relField;
                var relPk="";
                if(self.formBusInstData && self.formBusInstData.length>0){
                    relPk=self.getRelPk(this.curFormSolution.value);
                }
                var pk="";
                var params={};
                if(this.curFormSolution.relField!="ID_"){
                    params[this.curFormSolution.relField]=relPk;
                }else {
                    pk=relPk;
                }
                this.init(this.busFormData[this.curFormSolution.value],this.curFormSolution.value,pk,params,this.handleCurFunc);
            }else {
                this.$message.warning('无下一步!');
            }
        },
        //上一步
        prev() {
            if(this.current !=0){
                //当前为表单
                if("form"==this.mode){
                    var formData =this.$refs.rxForm.getData();
                    this.busFormData[this.curFormSolution.value]=formData;
                }
                var result={};
                if(this.current-1!=0){
                    //处理下一步的条件函数
                    result=this.handleNextFunc(this.formSolutions[this.current-1],this.current-1,"prev");
                    if(result.success){
                        this.$message.warning(result.message);
                        return;
                    }
                }
                this.formSolutions[this.current].status="wait";
                this.current=result.index || this.current-1;
                this.formSolutions[this.current].status="process";
                var prevSol=this.formSolutions[this.current];
                this.mode=prevSol.mode;
                //上一步页面为自定义页面
                if(prevSol.mode=="custom"){
                    this.customView=this.loadView(prevSol.formSolution);
                    return;
                }
                this.curFormSolution=JSON.parse(this.formSolutions[this.current].formSolution);
                this.curFormSolution["relField"]=this.formSolutions[this.current].relField;
                var relPk="";
                if(this.formBusInstData && this.formBusInstData.length>0){
                    relPk=this.getRelPk(this.curFormSolution.value);
                }
                var pk="";
                var params={};
                if(this.curFormSolution.relField!="ID_"){
                    params[this.curFormSolution.relField]=relPk;
                }else {
                    pk=relPk;
                }
                this.init(this.busFormData[this.curFormSolution.value],this.curFormSolution.value,pk,params);
            }else {
                this.$message.warning('无上一步!');
            }
        },
        //保存当前表单 注:主表单得数据会先保存
        async save(){
            var validResult = await this.validForm(true);
            if (!validResult.success) {
                this.$message.warning(validResult.msg);
                return;
            }
            var self=this;
            this.$confirm({
                title: '操作提示',
                content: '确定要保存当前表单数据吗?',
                okText: '确认',
                cancelText: '取消',
                zIndex:99999,
                onOk() {
                    var data=[];
                    var formData =self.$refs.rxForm.getData();
                    self.removeSpaces(formData);
                    //先将当前表单数据存放到busFormData
                    if(!self.busFormData[self.curFormSolution.value]){
                        self.busFormData[self.curFormSolution.value]=formData;
                    }
                    //判断当前是否为主表单
                    if(self.curFormSolution.value!=self.mainSolution.value && !self.busFormData[self.mainSolution.value].ID_){
                        data.push({setting: {action: "save", alias: self.mainSolution.value}, data: self.busFormData[self.mainSolution.value],relField:self.mainSolution.relField});
                    }
                    data.push({setting: {action: "save", alias: self.curFormSolution.value}, data: formData,relField:self.curFormSolution.relField});
                    var relField= self.mainSolution.relField?self.mainSolution.relField:"ID_";
                    var mainPk=self.busFormData[self.mainSolution.value][relField];
                    var parameter={
                        action:"save",
                        busSolutionId:self.busSolution.id,
                        mainPk:mainPk?mainPk:"",
                        data:data
                    }
                    FormSolutionApi.saveBusForm(parameter).then(res => {
                        if(!res.success){
                            return;
                        }
                        for (let i = 0; i < res.data.length; i++) {
                            //提交后事件处理
                            if (self.$refs.rxForm.formVm._afterSubmit) {
                                self.$refs.rxForm.formVm._afterSubmit(res.data[i], res.data[i].data);
                            }
                            var pk=res.data[i].data.pk;
                            var solutionAlias=res.data[i].data.solutionAlias;
                            self.initBusFormData(solutionAlias,pk)
                        }
                    })
                },
                onCancel() {
                }
            });
        },
        async submit(){
            if(this.mode=="form"){
                var validResult = await this.validForm(true);
                if (!validResult.success) {
                    this.$message.warning(validResult.msg);
                    return;
                }
            }
            var self=this;
            this.$confirm({
                title: '操作提示',
                content: '确定要保存所有表单数据吗?',
                okText: '确认',
                cancelText: '取消',
                zIndex:99999,
                onOk() {
                    var data=[];
                    if(self.mode=="form"){
                        //先将当前表单数据存放到busFormData
                        var formData =self.$refs.rxForm.getData();
                        self.busFormData[self.curFormSolution.value]=formData;
                    }
                    var arr=Object.keys(self.busFormData);
                    for (let i = 0; i < arr.length; i++) {
                        self.removeSpaces(self.busFormData[arr[i]]);
                        var formSolution = self.getFormSolution(arr[i]);
                        data.push({setting: {action: "save", alias: arr[i]}, data: self.busFormData[arr[i]],relField:formSolution?formSolution.relField:""});
                    }
                    var relField= self.mainSolution.relField?self.mainSolution.relField:"ID_";
                    var mainPk=self.busFormData[self.mainSolution.value][relField];
                    var parameter={
                        action:"submit",
                        busSolutionId:self.busSolution.id,
                        mainPk:mainPk?mainPk:"",
                        data:data
                    }
                    FormSolutionApi.saveBusForm(parameter).then(res => {
                        if(!res.success){
                            return;
                        }
                        // for (let i = 0; i < res.data.length; i++) {
                        //     //提交后事件处理
                        //     if (self.$refs.rxForm.formVm._afterSubmit) {
                        //         self.$refs.rxForm.formVm._afterSubmit(res.data[i], res.data[i].data);
                        //     }
                        // }
                        Util.closeWindow(self, 'ok', res.data);
                    })
                },
                onCancel() {
                }
            });
        },
        //表单验证
        async validForm(required) {
            var formVm = this.$refs.rxForm.formVm;
            //提交前校验
            if (formVm._beforeSubmit) {
                var rtn = await formVm._beforeSubmit(formVm);
                if (!rtn.success) {
                    return rtn;
                }
            }
            //数据必填，类型校验
            var res = formVm.valid(required, true);
            if (!res.success) {
                return res;
            }
            //表单唯一性校验
            let validMainUnique = await formVm.validMainUnique();
            if (!validMainUnique.success) {
                return validMainUnique;
            }
            return {success: true, msg: "验证通过"};
        },
        //获取表单关联值
        getRelPk(formSolAlias){
            var obj= this.formBusInstData.find(item=> item.relFormsolAlias==formSolAlias);
            return obj?obj.relPk:"";
        },
        //获取表单方案配置
        getFormSolution(alias){
            var formSolutions = JSON.parse(this.busSolution.formSolutions);
            var formSolution= formSolutions.find(item=>{
                if(JSON.parse(item.formSolution).value==alias){
                    return item;
                }
            });
            return formSolution;
        },
        // 路由懒加载
        loadView(view)  {
            return () => import(`@/views/${view}`);
        },
        //处理当前页面的下一步函数
        handleCurFunc(){
            var curSol=this.formSolutions[this.current-1];
            var formSolution=JSON.parse(curSol.formSolution);
            if(curSol.extendFunc){
                var curSolExtendFunc= JSON.parse(curSol.extendFunc);
                if(curSolExtendFunc.nextFunc){
                    var func=`this.curNextFunc=(formData,busFormData)=>{${curSolExtendFunc.nextFunc}};`;
                    eval(func);
                    var formData={};
                    //当前为表单
                    if(this.mode=="form"){
                        formData=this.busFormData[formSolution.value];
                    }
                    this.curNextFunc(formData,this.busFormData);
                }
            }
        },
        //处理下一步页面的跳过条件函数
        handleNextFunc(formSolution,index,type){
            var success=true;
            var message="";
            //下一页面为最后的表单则不判断条件
            if(index+1==this.formSolutions.length){
                return {success:false,message:""};
            }
            //下一步
            if(type=="next"){
                //处理下一步页面的条件
                if(formSolution.extendFunc){
                    var formSolutionExtendFunc= JSON.parse(formSolution.extendFunc);
                    if(formSolutionExtendFunc.condition){
                        var func=`this.nextCondition=(busFormData)=>{${formSolutionExtendFunc.condition}};`;
                        eval(func);
                        success=this.nextCondition(this.busFormData);
                    }
                }
                if(success){
                    if(index+1<this.formSolutions.length){
                        return this.handleNextFunc(this.formSolutions[index+1],index+1,type);
                    }
                    return {success:success,message:"无下一步或后续都不符合条件!"};
                }
            }
            //上一步
            else if(type=="prev"){
                //处理上一步页面的条件
                if(formSolution.extendFunc){
                    var formSolutionExtendFunc= JSON.parse(formSolution.extendFunc);
                    if(formSolutionExtendFunc.condition){
                        var func=`this.nextCondition=(busFormData)=>{${formSolutionExtendFunc.condition}};`;
                        eval(func);
                        success=this.nextCondition(this.busFormData);
                    }
                }
                if(success){
                    return this.handleNextFunc(this.formSolutions[index-1],index-1,type);
                }
            }
            return {success:success,message:message,index:index};
        }
    },
    watch: {
        "busSolution":function (val){
            if(val && val.formSolutions){
                this.formSolutions=JSON.parse(val.formSolutions);
                this.formSolutions.find(item=>{
                    item.status="wait";
                });
                if(this.formSolutions[0].formSolution){
                    this.curFormSolution=JSON.parse(this.formSolutions[0].formSolution);
                    this.curFormSolution["relField"]=this.formSolutions[0].relField;
                    this.mainSolution["relField"]=this.formSolutions[0].relField;
                    var pk="";
                    var params={};
                    if(this.formBusInstData){
                        var formBusData= this.formBusInstData.find(item=> item.relFormsolAlias==this.mainSolution.value);
                        if(formBusData && formBusData["relPk"] && this.mainSolution["relField"]!="ID_"){
                            params[this.mainSolution["relField"]]=formBusData["relPk"];
                        }else {
                            pk=this.rowData["ID_"];
                        }
                    }
                    this.formSolutions[0].status="process";
                    this.init(null,this.curFormSolution.value,pk,params);
                }
            }
        }
    }
}
</script>

<style scoped>
.FormBusSolutionShow_vertical_button{
  overflow: hidden;
    width: 100%;
}
.FormBusSolutionShow_vertical_button >button:hover{
    width: 110px;
}
.FormBusSolutionShow_vertical_button >button{
    border-radius: 18px 0px 0px 18px;
    display: block;
    margin-bottom: 10px;
    width: 90px;
    float: right;
}
.FormBusSolutionShow_vertical{
    display: flex;
    width: 100%;
}
.FormBusSolutionShow_vertical>div:nth-child(1){
    width: 132px;
    background-color: #ffffff;
    box-shadow: 0px 0px 4px 0px
    rgba(44, 62, 83, 0.21);
    border-radius: 5px;
    margin: 35px 57px;
    padding: 15px;
    font-size: 14px;
    color: #46494d;
}
.FormBusSolutionShow_vertical>div:nth-child(2){
    flex: 1;
}
.FormBusSolutionShow_vertical>div:nth-child(3){
    width: 334px;
    margin-top: 50px;
}
.FormBusSolutionShow{
    display: flex;
    flex-direction: column;
    overflow: hidden;
}
.FormBusSolutionShow_button{
    height: 60px;
    background-color: #ffffff;
    border: solid 1px #e8e8e8;
    padding-right: 10px;
}
.FormBusSolutionShow_button button{
    float: right;
    margin-top: 10px;
}
.FormBusSolutionShow_asteps{
    max-width:1307px;
    height:50px;
    background-color: #ffffff;
    box-shadow: 0px 0px 4px 0px
    rgba(44, 62, 83, 0.21);
    border-radius: 5px;
    padding: 12px 16px 0px 16px;
    overflow: hidden;
    margin:19px auto;
}
.FormBusSolutionShow >div:nth-child(1){
    width: 100%;

}
.FormBusSolutionShow >div:nth-child(2){
    flex: 1;
    overflow: auto;
}
</style>