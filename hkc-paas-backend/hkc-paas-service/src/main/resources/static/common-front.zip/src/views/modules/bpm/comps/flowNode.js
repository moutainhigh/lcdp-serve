var tmp =`
<div class="rx-npmn-window">
<!--<%=JSON.stringify(data.taskNodeUser) %>-->
<div class="flow-window-container">
<div class="flow-window-content">
<ul>
   <% var configExecutors = data.taskNodeUser.configExecutors ;
        for(let i=0,j=configExecutors.length;i<j;i++){
        var name = configExecutors[i].name ;
        var id = configExecutors[i].id ;
        var idx = i ;
        %>
    <li class="flow-item-li  <%if(idx == 0 ){%> active <%}%>" >
        
        <div class="flow-item-icon"></div>
         <div class="flow-item-text">
            <div class="flow-item-header">
                <span class="flow-item-name"><%= name %></span>     
                <% var _hist  = data.histories ; 
                if(histories && histories.length > 0){                    
                    if(idx == 0 ){%> 
                      <span class="flow-item-btn">收起</span>
                   <%}else{%>
                      <span class="flow-item-btn">展开</span>
                   <%}
                }%>  
            </div>
            <div class="flow-item-title">
                <span class="flow-node-text"><%=data.taskNodeUser.nodeText %></span>
                <% var type = data.taskNodeUser.multiInstance;
                if(type && type == 'parallel'){%>
                    <span class="flow-node-text flow-node-text-type">并行</span>
                <%}else if(type == 'sequential'){%>
                    <span class="flow-node-text flow-node-text-type">串行</span>
                <%}%>
               
            </div>
            <div class="flow-item-content">
            <% var histories = data.histories ;
            var flag=false;
            for(var n = 0,m = histories.length;n < m ;n++ ){
            var handlerId = histories[n].handlerId ;
            if(handlerId == id){
                flag=true; 
                var createTime = histories[n].createTime ; 
                var jumpTypeName = histories[n].jumpTypeName;
                var updateTime =histories[n].updateTime ;
                var remark = histories[n].remark ;
            %>
                <div class="flow-item-details">
                    <dl>
                        <dd>
                            <span class="leftText">到达时间</span>
                            <span class="rightText"><%=createTime%></span>
                        </dd>
                        <dd>
                            <span class="leftText">审批动作</span>
                            <span class="rightText"><%=jumpTypeName%></span>
                        </dd>
                        <dd>
                            <span class="leftText">审批时间</span>
                            <span class="rightText"><%=updateTime%></span>
                        </dd>
                        <dd>
                            <span class="leftText">审批意见</span>
                            <span class="rightText"><%=remark%></span>
                        </dd>
               
                    </dl>
                </div>
            <%}%>        
             <%}if(!flag){%>
                <div class="noedit">暂无操作</div>
            <%}%>   
             </div> 
        </div>            
    </li>      
      <%} %>  
</ul>
</div>
</div>
</div>
`



export default tmp;