<template>
    <div class="wrap">
        <div><filter-params @paramsChange="paramsChange" :filterParams="config.filterParams" ></filter-params></div>
        <div style="height: 100%" :ref="config.alias"></div>
    </div>
</template>

<script>
import ChartPublic from '../formComponent/ChartPublic';
import * as echarts from 'echarts';


export default {
    /**
     * 地图
     */
    name: "map-component",
    mixins: [ChartPublic],
    data() {
        return {
        }
    },
    methods: {
        setOption() {
            //echarts.registerMap('china', chinaJson);
            this.option= {
                tooltip: {
                    trigger: 'item',
                    formatter: '{b}<br/>{c} (p / km2)'
                },
                toolbox: {
                    show: true,
                    orient: 'vertical',
                    left: 'right',
                    top: 'center',
                    feature: {
                        saveAsImage: {show: false}
                    }
                },
                visualMap: {
                    min: 800,
                    max: 50000,
                    text: ['High', 'Low'],
                    realtime: false,
                    calculable: true,
                    inRange: {
                        color: ['lightskyblue', 'yellow', 'orangered']
                    }
                },
                series: [
                    {
                        name: '人口密度',
                        type: 'map',
                        mapType: 'china', // 自定义扩展图表类型
                        label: {
                            show: true
                        },
                        data: [
                            {name: '广东省', value: 200000},
                            {name: '云南省', value: 1000},
                        ]
                    }
                ]
            }
        }
    }
}
</script>

<style>

</style>