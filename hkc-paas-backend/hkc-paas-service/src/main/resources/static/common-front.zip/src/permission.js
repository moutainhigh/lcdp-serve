import NProgress from 'nprogress' ;
import 'nprogress/nprogress.css' ;
NProgress.configure({showSpinner: false})
let RouterBeforeEach = (router,Vue,store,ACCESS_TOKEN,LOGIN_URL,isSolo)=>{
	NProgress.start();
	router.beforeEach((to, from, next) => {
		if (Vue.ls.get(ACCESS_TOKEN)) {
			if (from.path != '/') {
				next()
			}
			if(store.state.appSetting.routers.length>0){
				next()
			}
			else {
				if(to.params && to.params.appKey){
					//设置应用标识
					store.commit('appSetting/setAppKey',to.params.appKey)
				}else {
					var ary = to.path.split("/");
					store.commit('appSetting/setAppKey',ary[1])
				}
				if(store.state.appSetting.appKey && isSolo){
					store.dispatch('appSetting/buildRoutes').then((routers) => {
						if(routers.length==0){
							next();
						}
						router.options.routes = [...router.options.routes,...routers]
						router.addRoutes(routers);
						/*for (var i = 0; i < routers.length; i++) {
							router.addRoute(routers[i]);
						}*/
						next({...to, replace: true})
					});
				}else {
					next();
				}
			}

		} else {
			//跳单点登录页面
			if(to.params.appKey){
				var redirect=window.location.href;
				window.open(LOGIN_URL+'?redirect='+redirect,'_self');
			}
		}
	})
	router.afterEach(() => {
		NProgress.done() // finish progress bar
		setTimeout(function () {
			store.state.appSetting.loading = false
		}, 300)
	})
}
export default  RouterBeforeEach ;

