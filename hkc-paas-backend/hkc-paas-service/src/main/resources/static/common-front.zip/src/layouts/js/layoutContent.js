import Vue from 'vue'
import DialogView from "@/layouts/DialogView";
import {Util} from 'jpaas-common-lib';
import {getComponent} from "@/utils/routerUtil";
import {mapState,mapMutations} from "vuex";

export  default {
	computed: {
		...mapState({
			selectMenu: state => state.appSetting.selectMenu,
			menus: state => state.appSetting.menus,
			showHome: state => state.appSetting.showHome,
			appId: state => state.appSetting.appId,
			appName: state => state.appSetting.appName,
			menuMap: state => state.appSetting.menuMap,
			newPageMenu: state => state.appSetting.newPageMenu
		})
	},
	data(){
		return {
			isOpenPop:false,
			handlerFuns:{
				"URL": {fn: 'openUrl'},  //URL访问
				"POP_WIN": {fn: 'openPopWin'},   //弹窗
				"NEW_WIN": {fn: 'openNewWin'},        //新窗口
				"FUNS": {fn: 'openFuns', parames: 'MenuViewFuns'},    //功能面板集（标签）
				"FUNS_BLOCK": {fn: 'openFuns', parames: 'MenuViewFunsBlock'},   //功能面板集（单页）
				"FUN": {fn: 'openFuns', parames: 'MenuViewFun'},   //功能面板
			}
		}
	},
	methods:{
		handlerFun(selectMenu){
			if(!selectMenu.showType){
				return;
			}
			var fun = this.handlerFuns[selectMenu.showType].fn;
			var parames = this.handlerFuns[selectMenu.showType].parames;
			//弹窗方式
			if(fun=="openPopWin"){
				this.isOpenPop=true;
			}else {
				this.isOpenPop=false;
			}
			this.setShowHome(false);
			if(this[fun]){
				this[fun](selectMenu, parames);
			}
		},
		openUrl(item){
			//Iframe
			if (item.settingType == "iframe") {
				this.getIframeConfig(item);
				return ;
			}
			var menuId = item.id;
			var path = this.handMenuPath(item);
			this.generatePath(menuId);
			this.$router.push(path);
		},
		openNewWin(item) {
			//当前为新窗口打开的页面不执行 防止死循环
			if(this.newPageMenu==item.id){
				return;
			}
			var url ="";
			var aryMenuPath = this.getMenuPath(item.id);
			for (var i = 0; i < aryMenuPath.length; i++) {
				url += "/" + aryMenuPath[i].menuKey;
				if (i == 0) {
					url =aryMenuPath[i].appPath+url+"/home";
				}
			}
			if(url.indexOf("//")==-1){
				url=location.protocol +"//" + location.host +url.replace("//","/");
			}
			setTimeout(() => {
				window.open(url, '_blank');
			}, 500)
		},
		openPopWin(item){
			var data = {};
			if (item.settingType == 'iframe') {
				data.url = item.params;
			} else {
				data.menu = item;
				data.currentView = getComponent(item);
			}
			var conf = {
				component: DialogView,
				curVm: this,
				max: true,
				title: item.title,
				data: data
			};
			Util.open(conf,function (action) {});
		},
		loadView(view) { // 路由懒加载
			return () => import(`@/views/${view}`)
		},
		//功能面板集
		openFuns(item, name) {
			var path =this.handMenuPath(item);
			this.$router.push(path);
		},
		getSelectMenus (menus,menuId) {
			var selectMenus=[];
			for (var i = 0; i < menus.length; i++) {
				if(menus[i].id==menuId){
					selectMenus.push(menus[i]);
					break;
				}else {
					if(menus[i].children&&menus[i].children.length>0){
						var res=this.getSelectMenus(menus[i].children,menuId);
						if(res&&res.length>0){
							selectMenus= res;
							break;
						}
					}
				}
			}
			return selectMenus;
		},
		//Iframe方式
		getIframeConfig(selectMenu){
			var url=selectMenu.params;
			if(url){
				let jsonToken = Vue.ls.storage['pro__Access-Token'];
				var token = "";
				if (jsonToken) {
					jsonToken = JSON.parse(jsonToken);
					token = jsonToken.value;
				}
				if (url.indexOf("?") == -1) {
					url += "?authorization=" + token;
				} else {
					url += "&authorization=" + token;
				}
			}
			var path =this.handMenuPath(selectMenu);
			this.$router.push(path);
		},
		handMenuPath(menu) {
			var pathParams = {name: menu.key};
			return pathParams;
		},
		generatePath(id) {
			var aryMenuPath = this.getMenuPath(id);
			//将菜单路径发布到VUEX
			this.setMenuPath(aryMenuPath)
		},
		getMenuPath(id) {
			var aryMenuPath = [];
			var obj = this.menuMap[id];
			aryMenuPath.push(obj)
			while (obj.parentId != '0') {
				obj = this.menuMap[obj.parentId];
				//往数组开头增加元素。
				aryMenuPath.unshift(obj);
			}
			return aryMenuPath;
		},
		//获取选择菜单的上层
		getNavigations(selectMenu,menus){
			var navigations=[];
			if(selectMenu.showType != "POP_WIN"){
				for (var i = 0; i < menus.length; i++) {
					var menu=menus[i];
					if(menu.id==selectMenu.id){
						navigations.push({key:menu.key,title:menu.title});
						break;
					}else if(menu.children && menu.children.length>0){
						var list=this.getNavigations(selectMenu,menu.children);
						if(list.length>0){
							navigations.push({key:menu.key,title:menu.title});
							navigations.push(...list);
							break;
						}
					}
				}
			}
			return navigations;
		}
	}
}
