<template>
	<rx-fit>
		<div class="itmsFont">
			<ul>
				<li class="item-li" v-for="menu in curMenus"
					:class="{ itemClass:(menu.children && menu.children.length>0)}">
					<div class="itmsBos" v-if="menu.children && menu.children.length>0">
						<header>{{ menu.title }}</header>
						<ul>
							<li v-for="subMenu in menu.children" @click="handMenuClick(subMenu)" class="item-li">
								<div class="item-icon-box">
									<i class="iconfont " :class="JSON.parse(subMenu.icon).icon"></i>
									<a-icon :type="JSON.parse(subMenu.icon).icon"></a-icon>
								</div>
								<p>
									<span class="spanlist">{{ subMenu.title }}</span>
								</p>
							</li>
						</ul>
					</div>
					<div class="itmsBos2" v-if="!menu.children || menu.children.length==0"
						 :class="{ itemClass2:(menu.children && menu.children.length == 0)}"
						 @click="handMenuClick(menu)">
						<div class="item-icon-box">
							<i class="iconfont " :class="JSON.parse(menu.icon).icon"></i>
							<a-icon :type=" JSON.parse(menu.icon).icon"></a-icon>
						</div>
						<p>
							<span class="spanlist">{{ menu.title }}</span>
						</p>
					</div>
				</li>
			</ul>
		</div>
	</rx-fit>
</template>

<script>
/**
 * 功能面板集（单页）
 */
import {RxFit, Util} from 'jpaas-common-lib';
import {mapMutations, mapState} from 'vuex';
import router from "@/router";
import menuView from "@/layouts/js/menuView";

export default {
	name: "MenuViewFunsBlock",
	props: {},
	mixins: [menuView],
	components: {
		RxFit
	},
	data() {
		return {
			curMenus: [],
			itemClass: '',
			curMenuId: '',
		}
	},
	created() {
		this.initMenus();
	},
	methods: {
		...mapMutations('appSetting', ['setSelectMenu']),
		initMenus() {
			this.curMenuId = this.selectMenu.id;
			this.curMenus = this.getSelectMenus(this.menus, this.curMenuId);
		},
		handMenuClick(menu) {
			this.setSelectMenu(menu);
		},
	},
	watch:{
		"selectMenu.id":function (val,oldVal){
			if(val){
				this.initMenus();
			}
		}
	}
}
</script>

<style scoped>
.spanlist {
	width: 100%;
	display: block;
	text-align: center;
	text-overflow: ellipsis;
	display: -webkit-box;
	-webkit-line-clamp: 1;
	-webkit-box-orient: vertical;
}

.itmsBos2 p {
	margin-top: 6px;
}

.itmsBos2 {
	overflow: hidden;
	height: 110px;
	border-radius: 6px;
}

.itmsFont {
	font-size: 0;
	padding: 10px 10px 0;
}

.itmsBos {
	font-size: 14px;
	border-radius: 6px;
	background: #fff;
	margin: 0 6px;
	margin-bottom: 12px;
}

.itmsBos header {
	line-height: 40px;
	padding-left: 20px;
	border-bottom: 1px solid #eef2f4;
}

.itmsBos ul {
	font-size: 0;
	padding-top: 10px;
	margin: 0 6px;
}

.itmsBos ul li {
	vertical-align: middle;
	font-size: 14px;
	width: 12.5%;
	display: inline-block;
	color: #555;
	text-align: center;
}


.itmsBos ul li p {
	margin-top: 6px;
	white-space: nowrap;
	text-overflow: ellipsis;
	overflow: hidden;
}

.itmsFont > ul {
	display: flex;
	flex-flow: wrap;

}

.item-icon-box {
	width: 60px;
	height: 60px;
	margin: auto;
	text-align: center;
	border-radius: 50%;
	background: #09bcb9;
	color: white;
	margin-top: 15px;
}


.itmsFont .item-li {
	width: 100px;
	height: 110px;
	border-radius: 6px;
	margin-right: 15px;
	margin-bottom: 10px;
	position: relative;
	background: white;
}

.itmsFont .itmsBos li:hover {
	border: 1px solid #4D9EFF;
}

.itmsFont .itmsBos2:hover {
	border: 1px solid #4D9EFF;
}

.item-li.itemClass .item-li:hover {
	top: -2px;
	box-shadow: 0 6px 18px 2px #e0e5e7;
}

.itmsFont .item-li:nth-child(6n + 6) {
	margin-right: 0;
}

.itmsFont .item-li p {
	font-size: 14px;
	text-align: center;
	width: 100%;
	box-sizing: border-box;
	white-space: nowrap;
	text-overflow: ellipsis;
	overflow: hidden;
	min-height: 42px;
}

.itmsFont .item-li p > span {
	display: inline-block;
	vertical-align: middle;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;

}

.itmsFont .item-li p:before {
	content: '';
	display: inline-block;
	height: 100%;
	width: 0;
	vertical-align: middle;
}

.itmsFont .itemClass {
	width: 100%;
	margin-right: 0;
	height: auto;
	padding-bottom: 0;
}

.item-icon-box i {
	font-size: 30px;
	line-height: 60px;
}

.itmsFont ul li:nth-child(1) .item-icon-box {
	background-color: #0595fe;
}

.itmsFont ul li:nth-child(2) .item-icon-box {
	background-color: #458bff;
}

.itmsFont ul li:nth-child(3n) .item-icon-box {
	background-color: #09bcb9;
}

.itmsFont ul li:nth-child(4n) .item-icon-box {
	background-color: #76d32c;
}

.itmsFont ul li:nth-child(5n) .item-icon-box {
	background-color: #f0cb39;
}
</style>