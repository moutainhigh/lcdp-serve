<template>
  <rx-dialog @handOk="cancel" :showcancel="false" oktext="关闭" btnalign="right" order="top">
      <div slot="toolbar">
        <a-button type="primary" @click="downTemp">下载EXCEL模板</a-button>
        <a-button type="primary"
                  :disabled="fileList.length === 0"
                  :loading="uploading" @click="onUpload">上传</a-button>
      </div>
    <rx-layout>
      <div slot="center" style="padding: 10px;">
        <a-upload :file-list="fileList" :remove="handleRemove" :before-upload="beforeUpload">
          <a-button> <a-icon type="upload" />请选择文件</a-button>
        </a-upload>
        <form ref="hiform" action="/api/api-form/form/core/formBoList/downTemp" method="post">
          <input ref="boListKey" type="hidden" name="boListKey" v-model="boListKey">
        </form>
      </div>
    </rx-layout>

  </rx-dialog>
</template>

<script>
    import {RxDialog,Util} from 'jpaas-common-lib';
    import FormBoListApi from "@/api/form/core/formBoList";
    export default {
      name: "FormBoListImportExcelDialog",
      props: {
        boListKey: {
          type: String,
          default: ""
        },
        layerid: {
          type: String,
          default: ""
        },
        destroy: {
          type: Function
        }
      },
      components: {
        RxDialog
      },
      created() {
      },
      data(){
        return {
          fileList: [],
          uploading: false
        }
      },
      methods:{
        cancel(){
          Util.closeWindow(this,"cancel");
        },
        downTemp(){
          this.$refs.hiform.submit();
        },
        onUpload(){
          const { fileList,boListKey } = this;
          this.uploading = true;
          const formData = new FormData();
          fileList.forEach(file => {
            formData.append('files[]', file);
          });
          formData.append('boListKey',boListKey);
          FormBoListApi.importExcel(formData).then(res=>{
            if(res.success) {
              Util.closeWindow(this,"ok");
            }
            this.uploading = false;
          }).catch(res => {
            this.uploading = false;
          });
        },
        handleRemove(file) {
          const index = this.fileList.indexOf(file);
          const newFileList = this.fileList.slice();
          newFileList.splice(index, 1);
          this.fileList = newFileList;
        },
        beforeUpload(file) {
          this.fileList = [...this.fileList, file];
          return false;
        }
      }
    }
</script>

<style scoped>

</style>