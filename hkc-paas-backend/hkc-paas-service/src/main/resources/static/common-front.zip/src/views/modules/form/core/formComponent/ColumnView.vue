<template>
    <div v-if="insColumnDef" style="height: 100%;width: 100%">
        <portal-layoutview  ref="columnLayoutview" :insColumnDef="insColumnDef"></portal-layoutview>
    </div>
</template>

<script>
import Vue from 'vue';
import FormCustomApi from "@/api/form/core/formCustom";
import PortalLayoutview from '@/views/modules/portal/core/PortalLayoutview';

Vue.component('portal-layoutview', PortalLayoutview);

export default {
    name: "column-view",
    props: {
        config:{
            type:Object,
            default:{}
        }
    },
    components: {
    },
    data() {
        return {
            insColumnDef:""
        }
    },
    created() {
        this.getInsColumnDef();
    },
    methods: {
        getInsColumnDef(){
            if(this.config.colId){
                FormCustomApi.getColumnById(this.config.colId).then(res=>{
                    this.insColumnDef=res.data;
                });
            }
        }
    },
    watch: {
        config:{
            handler: function (val, oldVal) {
                if(val){
                    this.getInsColumnDef();
                }
            },
            deep: true
        }
    }
}
</script>

<style scoped>

</style>