import "./public-path"
import Vue from 'vue'
import App from './App.vue'
import Storage from 'vue-ls';
import store from './store/'
import "./css/common/commons.css"
import './css/iconfont/iconfont.css'
import './css/customIcon/iconfont.css'
//import './permission'
import AntDesign from 'ant-design-vue'
import 'ant-design-vue/dist/antd.css';
import 'ant-design-vue/dist/antd.less'
Vue.use(AntDesign);
//import router from './router'
import {constantRouterMap} from "./router/router";
import '@/assets/js/share';
import '@/assets/js/directive.js'
import {ACCESS_TOKEN,LOGIN_URL} from '@/store/mutation-types';
import  RouterBeforeEach  from './permission'
import moment from 'moment'
moment.locale('zh-cn')

var options = {
	namespace: 'pro__', // key prefix
	name: 'ls', // name variable Vue.[ls] or this.[$ls],
	storage: 'local', // storage name session, local, memory
};

// 引入jpaas图标库
import {
	Icon
} from 'ant-design-vue'
import iconFront from '@/css/iconfont/iconfont.js'
const myicon = Icon.createFromIconfontCN({
	scriptUrl: iconFront
})
//引用
Vue.component('my-icon', myicon)

Vue.use(Storage, options);

/*右键菜单*/
import contentmenu from 'v-contextmenu'
import 'v-contextmenu/dist/index.css'
Vue.use(contentmenu)

import layer from 'rx-vue-layer'
import 'rx-vue-layer/lib/vue-layer.css';
Vue.prototype.$layer = layer(Vue);

//引用
Vue.config.productionTip = false
/*bus*/
/*import {VueBus} from 'jpaas-common-lib';
Vue.use(VueBus);*/


import VueRouter from 'vue-router'
Vue.use(VueRouter);
const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
	return originalPush.call(this, location).catch(err => err)
}

import {ClientUtil} from "jpaas-form-component";
ClientUtil.setConfig("webApp","webApp");
import rxFullcalendar from 'rx-fullcalendar'
Vue.use(rxFullcalendar)

// 全局事件总线，创建一个vue实例，挂载到根实例
window.eventBus = new Vue();


/*
new Vue({
	router,
	store,
	render: h => h(App),
}).$mount('#app')
*/


function loadingRender(routes,props){
	const { container,baseUrl} = props;
	router = new VueRouter({
		base: window.__POWERED_BY_QIANKUN__ ? baseUrl : process.env.BASE_URL,
		mode: 'history',
		routes:routes,
	});
	let isSolo = container ? false : true ;
	RouterBeforeEach(router,Vue,store,ACCESS_TOKEN,LOGIN_URL,isSolo)
	instance = new Vue({
		router,
		store,
		render: (h) => h(App),
	}).$mount(container ? container.querySelector('#app') : '#app');
}

let getCustomRouter = async function  (props){
	const { data } = props;
	let {  key:appKey } = data ;
	store.commit('appSetting/setAppKey',appKey)
	store.commit('appSetting/setOpenAppType','inner')
	let routers = await store.dispatch('appSetting/buildRoutes')
	if(routers && routers.length > 0){
		let _routes = [...constantRouterMap,...routers]
		loadingRender(_routes,props)
	}
}
Vue.config.productionTip = false
let router = null;
let instance = null;
function render(props = {}) {
	init();
	const { container,data ,baseUrl} = props;

	if(container){
		getCustomRouter(props)
	}else {
		let obj = {
			path: '/:appKey',
			name: 'index',
			props: true,
			component: () => import( '@/layouts/MainLayout')
		}
		let _routes = [ ...constantRouterMap,obj];
		_routes = [..._routes,obj]
		loadingRender(_routes,props)
	}
}

//container.querySelector('#app')原来qiankun在父应用中插入了一个#app 我们在这里需要这样来获取 并挂载到这里：
// 独立运行时
if (!window.__POWERED_BY_QIANKUN__) {
	/*store.commit('appSetting/setIsOpenType','current')*/
	render();
}

export async function bootstrap() {

}


function init(){
	if(instance){
	/*	store.commit('appSetting/setAppKey','');
		store.commit('appSetting/setRouters',[]);*/
		instance.$destroy();
		instance.$el.innerHTML = '';
		instance = null;
		router = null;
	}
}
import { openRouter } from './openRouters'
export async function mount(props) {
	props.onGlobalStateChange((state, prev) => {
		// state: 变更后的状态; prev 变更前的状态、
		if(state && state.data){
			//instance.$router.push({name:state.name})
			openRouter(instance.$router,state.data);
		}
	});
	/*store.commit('appSetting/setIsOpenType','inner');*/
	render(props);
}
// 增加 update 钩子以便主应用手动更新微应用
export async function update(props) {
	render(props);
}
export async function unmount() {
	init();
}
