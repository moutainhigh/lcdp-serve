import moment from "moment";

var Formula={};
/**
 * 设置缓存。
 */
Formula.IF_ELSE=function(express,res1,res2){
	if(eval(express)){
		return res1;
	}
	return res2;
}

/**
 * 子表求和
 * @param {Object} ary
 */
Formula.SUB_SUM = function(ary,fixed) {
	if(!ary || ary.length == 0) return 0;
	var tmp = 0,
		x = 0,
		size = ary.length;
	for(var i = 0; i < size; i++) {
		x = this.NUM(ary[i]);
		tmp += x;
	}
	if(!isNaN(fixed)){
		tmp=tmp.toFixed(fixed);
	}
	return parseFloat(tmp);
};

/**
 * 子表求平均数
 * @param {Object} ary
 */
Formula.SUB_AVERAGE = function(ary,fixed) {
  if(!ary || ary.length == 0) return 0;
  var tmp = 0,
    x = 0,
    size = ary.length;
  for(var i = 0; i < size; i++) {
    x = this.NUM(ary[i]);
    tmp += x;
  }
  if(!isNaN(fixed)){
    tmp=tmp.toFixed(fixed);
  }
  return parseFloat(tmp/size);
};


/**
 * 子表求最数
 * @param {Object} ary
 */
Formula.SUB_EXTREME = function(ary,extreme) {
  if(!ary || ary.length == 0) return ;
  //最大值
  if("max"==extreme){
    var max=parseInt(ary[0]);
    if(isNaN(max)) max= "";
    for(var i = 1; i < ary.length; i++) {
      if(parseInt(ary[i])>max){
        max=ary[i];
      }
    }
    return max;
  }
  //最小值
  else if("min"==extreme){
    var min=parseInt(ary[0]);
    if(isNaN(min)) min= "";
    for(var i = 1; i < ary.length; i++) {
      if(parseInt(ary[i])<min){
        min=ary[i];
      }
    }
    return min;
  }
  else {
    return;
  }
};


/**
 * 获取数据为空则为0
 * @param {Object} num
 */
Formula.NUM = function(num) {
	if(!num) return 0;
	if(isNaN(num)) return 0;
	return parseFloat(num);
}

Formula.CONCAT = function(char1,char2) {
	return char1+char2;
}

/**
 * 比较两个日期的差值
 * @param date1     日期1
 * @param date2     日期2
 * @param unit      单位 （years,months,weeks,days,hours,minutes,seconds)
 * @param fixed     小数位数
 * @param amend     修正值
 * @returns {string|number}
 * @constructor
 */
Formula.DATEDIF=function(date1,date2,unit,fixed,amend){
	if(!date1||!date2) return "";
  var val = moment(date1).diff( moment(date2), unit,true);
  if(!isNaN(fixed)){
    val=Number( val.toFixed(fixed));
  }
  if(amend){
  	val+=amend;
  }
  return val;
}

/**
 * 对JSON字符串进行解析，并返回 value值。
 * @param str
 * @returns {*}
 * @constructor
 */
Formula.GETVALUE = function(str){
	if( !str ){ return ""};
	return JSON.parse(str).value;
}


/*
 * 日期计算 例如日期+天数=日期
 *
 * CALC_DATE({开始时间},{时间数},[单位],[方式]),
 * 单位可以是'Y(years)'、Q(quarters)'、'M(months)'、
	'w(weeks)'、'd(days)、'h(hours)'、
	'm(minutes)'、's(seconds)',
	方式可以是 ‘+’、‘-’
	日期格式: ‘YYYY-MM-DD HH:mm:ss’
 */
Formula.CALC_DATE=function(date,time,unit,mode,formatStr){
  if(!date) return "";
  if(!time){
    return date;
  }
  var val;
  if(!formatStr){
    formatStr='YYYY-MM-DD HH:mm:ss';
  }


  if(mode=='-'){
    val=moment(date).subtract(time, unit);
  }else {
    val=moment(date).add(time, unit);
  }
  if(formatStr){
  	val=val.format(formatStr)
  }

  return val;
}

//IOS 日期为2020/02/05
Formula.getTime=function(obj){
	if(obj instanceof Date) {
		return obj.getTime();
	} else if(obj) {
		var dateObj = new Date(obj);
		//没有转换到
		if(isNaN(dateObj.getTime()) || !dateObj instanceof Date) {
			dateObj = new Date(obj.replace(/-/g, '/'));
		}
		return dateObj.getTime();
	}
}


/**
 * 四舍五入函数
 * @param {Object} numberRound		需要四舍五入的函数
 * @param {Object} roundDigit		位数
 */
Formula.ROUND=function(numberRound,roundDigit){
	if   (numberRound>=0){
		var   tempNumber   =   parseInt((numberRound   *   Math.pow(10,roundDigit)+0.5))/Math.pow(10,roundDigit);
		return   tempNumber;
	} else{
		var   tempNumber   =   parseInt((-numberRound   *   Math.pow(10,roundDigit)+0.5))/Math.pow(10,roundDigit);
		return   -tempNumber;
	}
}






Date.prototype.Format = function(fmt){ //author: meizz
  var o = {
    "M+" : this.getMonth()+1,                 //月份
    "d+" : this.getDate(),                    //日
    "h+" : this.getHours(),                   //小时
    "m+" : this.getMinutes(),                 //分
    "s+" : this.getSeconds(),                 //秒
    "q+" : Math.floor((this.getMonth()+3)/3), //季度
    "S"  : this.getMilliseconds()             //毫秒
  };
  if(/(y+)/.test(fmt))
    fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));
  for(var k in o)
    if(new RegExp("("+ k +")").test(fmt))
  fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));
  return fmt;
}

/**
 * 日期相减。
 * 参数1： date
 * 参数2：减的日期格式。
 * @param {Object} date
 * @param {Object} format
 */
Date.prototype.subtract = function(date,format,fixed){
	  var minute= (this.getTime() - date.getTime())/(60 * 1000);
	  var day=parseFloat(minute / (24*60));
	  var hour=parseFloat(minute / 60);
	  var rtn=0;
	  switch(format){
	    //分钟
	  	case 1:
	  		rtn=minute  ;
	  		break;
	  	//小时
	  	case 2:
	  		rtn=hour ;
	  		break;
	  	//天数
	  	default :
	  		rtn=day;
	  }
	  if(fixed){
	  	rtn=rtn.toFixed(fixed);
	  }
	  return rtn;
}

String.prototype.replaceAll=function(toReplace,replaceWith){
	  var reg=new RegExp(toReplace,"igm");
	  var rtn= this.replace(reg,replaceWith);
	  return rtn;
}

String.prototype.startWith=function(str){
	  var reg=new RegExp("^"+str);
	  return reg.test(this);
}

String.prototype.endWith=function(str){
  var reg=new RegExp(str+"$");
  return reg.test(this);
}

String.prototype.trim=function(){
    return this.replace(/(^\s*)|(\s*$)/g, "");
}

/**
 * 将字符串解析为日期。
 */
String.prototype.parseDate=function(){
	//yyyy-MM-dd
	var year=1970;
	//yyyy-MM-dd
	var aryDateTime=this.split(" ");

	var date=aryDateTime[0];
	var aryTmp=date.split("-");
	var year=parseInt(aryTmp[0]);
	var mon=parseInt(aryTmp[1])-1;
	var day=parseInt(aryTmp[2]);
	var hour=0;
	var minute=0;
	if(aryDateTime.length==2){
		var time=aryDateTime[1];
		var aryTmp=time.split(":");
		hour=parseInt(aryTmp[0]);
		minute=parseInt(aryTmp[1]);
	}
	return new Date(year,mon,day,hour,minute);


}

Array.prototype.contains = function (obj) {
	for(var i=0;i<this.length;i++){
		if(this[i]==obj){
			return true;
		}
	}
    return false;
}

/**
 * 自定义验证规则。
 */
var VTypes={
	isEnglish:{
		msg:"必须输入英文或下划线",
		valid:function(v){
			if (/^[a-zA-Z\_]+$/g.test(v)) return true;
    		return false;
		}
	},
	isEnglishAndNumber:{
		msg:"必须输入英文或数字",
		valid:function(v){
			if (/^[0-9a-zA-Z\_]+$/g.test(v)) return true;
    		return false;
		}
	},
	isKeyLabel:{
		msg:"必须输入英文开头",
		valid:function(v){
			if (/^[a-zA-Z][a-zA-Z0-9]*$/.test(v)) return true;
    		return false;
		}
	},
	isNumber:{
		msg:"必须输入数字",
		valid:function(v){
			if (/^[-+]?[0-9]+(\.[0-9]+)?$/g.test(v)) return true;
    		return false;
		}
	},
	isInteger:{
		msg:"必须输入整数",
		valid:function(v){
			var re = new RegExp("^[-+]?[0-9]+$");
    		if (re.test(v)) return true;
    		return false;
		}
	},
	isPositiveInteger:{
		msg:"必须输入正整数",
		valid:function(v){
			if (/^[1-9]\d*$/g.test(v)) return true;
    		return false;
		}
	},
	isNegtiveInteger:{
		msg:"必须输入负整数",
		valid:function(v){
			if (/^-[0-9]\d*$/g.test(v)) return true;
    		return false;
		}
	},
	isFloat:{
		msg:"必须输入浮点数",
		valid:function(v){
			if (/^-?([1-9]\d*\.\d*|0\.\d*[1-9]\d*|0?\.0+|0)$/g.test(v)) return true;
    		return false;
		}
	},
	isPositiveFloat:{
		msg:"必须输入正浮点数",
		valid:function(v){
			if (/^([1-9]\d*\.\d*|0\.\d*[1-9]\d*)$/g.test(v)) return true;
    		return false;
		}
	},
	isNegtiveFloat:{
		msg:"必须输入负浮点数",
		valid:function(v){
			if (/^-([1-9]\d*\.\d*|0\.\d*[1-9]\d*)$/g.test(v)) return true;
    		return false;
		}
	},
	isChinese:{
		msg:"必须输入中文",
		valid:function(v){
			var re = new RegExp("^[\u4e00-\u9fa5]+$");
    		if (re.test(v)) return true;
    		return false;
		}
	},
	IDCard:{
		msg:"必须输入15-18位数字",
		valid:function(v){
			if (/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(v)) return true;
    		return false;
		}
	},
	isUrl:{
		msg:"必须输入合法Url地址",
		valid:function(v){
			var reg=new RegExp("^[A-Za-z]+://[A-Za-z0-9-_]+\\.[A-Za-z0-9-_%&\?\/.=]+$");
    		if (reg.test(v)) return true;
    		return false;
		}
	},
	isEmail:{
		msg:"必须输入合法Email地址",
		valid:function(v){
			if (/^(\w)+(\.\w+)*@(\w)+((\.\w+)+)$/g.test(v)) return true;
    		return false;
		}
	},
	isChinesePostCode:{
		msg:"必须输入合法中国邮编地址",
		valid:function(v){
			if (/^[1-9]\d{5}(?!\d)$/g.test(v)) return true;
    		return false;
		}
	},
	isChinesePhone:{
		msg:"必须输入合法中国固话号码",
		valid:function(v){
			if (/^\d{3}-\d{8}|\d{4}-\d{7}$/g.test(v)) return true;
    		return false;
		}
	},
	isChineseMobile:{
		msg:"必须输入合法中国手机号码",
		valid:function(v){
			var re=new RegExp("^((13[0-9])|(15[^4,\\D])|(18[0,2,3,5-9]))\\d{8}$");
    		if (re.test(v)) return true;
    		return false;
		}
	},
	isIP:{
		msg:"必须输入合法IP地址",
		valid:function(v){
			if (/^\d+\.\d+\.\d+\.\d+$/g.test(v)) return true;
    		return false;
		}
	},
	isQQ:{
		msg:"必须输入正确QQ号码",
		valid:function(v){
			if (/^[1-9][0-9]{4,}$/g.test(v)) return true;
    		return false;
		}
	},
	float:{
		msg:"必须输入浮点数",
		valid:function(v){
			if (/^-?([1-9]\d*\.\d*|0\.\d*[1-9]\d*|0?\.0+|0|\d*)$/g.test(v)) return true;
    		return false;
		}
	},
	len:{
		msg:function(v,args){
    		return "只允许输入长度为"+args;
		},
		valid:function(v,args){
			if(!v) return true;
			if(v.toString().length<=parseInt(args)){
				return true;
			}
    		return false;
		}
	},
	length:{
		msg:function(v,args){
    		return "只允许输入长度为"+args;
		},
		valid:function(v,args){
			if(!v) return true;
			if(v.toString().length<=parseInt(args)){
				return true;
			}
    		return false;
		}
	},
	minnum:{
		msg:"小于最小边界" ,
		valid:function(v,args){
			if(v<parseFloat( args)){
				return false;
			}
    		return true;
		}
	},
	maxnum:{
		msg:"大于最小边界" ,
		valid:function(v,args){
			if(v>parseFloat(args)){
				return false;
			}
    		return true;
		}
	}


}


/**
 * 根据vtype 进行验证。
 */
function _validVtype (val,vtype){
	var aryRule=vtype.split(";");
	for(var i=0;i<aryRule.length;i++){
		var rule=aryRule[i];
		var aryTmp=rule.split(":");
		var pre=aryTmp[0];
		var params="";
		var validObj=VTypes[pre];
		if(!validObj) continue;
		if(aryTmp.length==1){
			var rtn=validObj.valid(val);
			if(!rtn) {
				return {valid:false,msg:validObj.msg};
			}
		}
		else  if(aryTmp.length==2){
			params=aryTmp[1];
			var rtn=validObj.valid(val,params);
			if(!rtn) {
				return {valid:false,msg:(typeof validObj.msg== 'function')?validObj.msg(val,params):validObj.msg};
			}
		}
	}
	return {valid:true,msg:validObj.msg};
}


export {
	Formula,
	_validVtype,
	VTypes
}
