import store from "./store";
let openRouter = (router,data)=>{
	//清除左边菜单选中的key
	store.commit('appSetting/setSelecteKeys',[data.key]);
	//清除tab选中key
	store.commit('appSetting/setActiveKey',data.key);
	//设置选中的树
	store.commit('appSetting/setSelectMenu',data);
}
export { openRouter }
