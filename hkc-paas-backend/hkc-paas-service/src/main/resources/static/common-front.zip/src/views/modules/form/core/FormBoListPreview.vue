<template>
    <comment ref="current"
             :is="currentView"
             :html="html"
             :isTreeDialog="isTreeDialog"
             :formdata="formdata"
             :layerid="layerid"
             :destroy="destroy"
             :lydata="lydata"
             class="commentBoxs"></comment>
</template>

<script>
import FormBoListDialog from "./FormBoListDialog";
import FormBoListPreviewList from "./FormBoListPreviewList";
import FormBoListApi from "@/api/form/core/formBoList";
import rxEmpty from "@/views/exception/rxEmpty";
import {mapState} from 'vuex';
export default {
    name: "FormBoListPreview",
    props: {
        //对话框别名
        "alias": {
            type: String
        },
        //菜单ID
        "menuId":{
            type: String
        },
        //是否单选
        "single": {
            type: Boolean,
            default: false
        },
        //参数例如 name=ray&address=guangzhou
        "params": {
            type: String
        },
        //这个是从DialogView打开时需要用到的。
        menuParams: {
            type: String
        },
        //表单关联数据 {name:"ray"}
        "formdata": {
            type: Object,
            default: ()=>{
                return {}
            }
        },
        //加载后执行
        "onload": {
            type: Function
        },
        "layerid": {
            type: String
        },
        "destroy": {
            type: Function
        },
        "lydata":{
            type: Object
        }
    },
    computed: {
        ...mapState({
            showType: state => state.appSetting.showType
        })
    },
    data() {
        return {
            currentView: rxEmpty,
            html: "",
            isTreeDialog: "",
            isCls: '',
            params_: "",
            aliasKey:this.alias,
            curMenuId:this.menuId
        }
    },
    mounted() {
        this.initParams();
    },
    methods: {
        newPageInit(key) {//该方法在MainLayout.vue里面调用；
            this.handParams(this.menuParams,{},key);
        },
        /**
         * 初始化参数
         */
        initParams() {
            //通过弹窗打开 Util.open
            if (this.alias) {
                this.params_ = this.params;
                this.init();
            }
            //从弹窗打开 DialogView
            else if (this.menuParams) {
                this.handParams(JSON.parse(this.menuParams),{});
            }
            //使用路由打开
            else {
                this.curMenuId=this.$route.meta.id;
                var params=this.$route.meta.params || this.$route.params;
                this.handParams(params,this.$route.query || {});
            }

        },
        handParams(params,query,key) {
            var params_;
            if (typeof params == 'string') {
                params_ = JSON.parse(params);
            } else {
                params_ = params;
            }
            let _key = key ? key.substring(0, key.lastIndexOf('List')) : ""
            this.aliasKey = params_.listKey || this.alias || _key;
            if (params_.query) {
                Object.assign(params_.query,query);
            }
            var queryParams = this.getQueryParams(query);
            this.params_ = queryParams;
            this.init();
        },

        getQueryParams(query) {
            var ary = [];
            for (var key in query) {
                ary.push(key + "=" + query[key]);
            }
            return ary.join("&")
        },
        async init() {
            if (!this.aliasKey) {
                return;
            }
            let self = this ;
            let parameter = {key: this.aliasKey,menuId:this.curMenuId, single: this.single, params: this.params_};
            let res = await FormBoListApi.dialog(parameter);
            if(!res.success){
                return;
            }
            let record = res.data;
            self.html = record.listHtml;
            self.isCls = record.isDialog;
            self.isTreeDialog = record.isTreeDlg;
            self.currentView = record.isDialog == 'YES' ? FormBoListDialog : FormBoListPreviewList;
        }
    },
    watch: {
        '$route': {
            handler: function (val) {
                if(this.showType == "window"){
                    this.curMenuId=val.meta.id;
                    var params=val.meta.params || val.params;
                    this.handParams(params,val.query || {});
                }
            },
            deep: true
        }
    }
}
</script>

<style scoped>
.commentBoxs >>> .rx-layout {
    padding: 0 !important;
}

</style>
