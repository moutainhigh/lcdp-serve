import rxAjax from '@/assets/js/ajax.js';

//ins_app_collect api接口
export const InsAppCollectApi = {};

InsAppCollectApi.baseUrl= '/api-portal/portal/core/insAppCollect';
InsAppCollectApi.exportUrl= InsAppCollectApi.baseUrl + '/export';

//查询列表
InsAppCollectApi.query=function (parameter) {
  var url= InsAppCollectApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
* 获取单记录
* @param pkId
* @returns {*}
*/
InsAppCollectApi.get =function(pkId) {
  var url= InsAppCollectApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

//保存数据
InsAppCollectApi.save =function(parameter) {
  var url= InsAppCollectApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

//删除数据
InsAppCollectApi.del =function(parameter) {
  var url= InsAppCollectApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

export  default InsAppCollectApi;

