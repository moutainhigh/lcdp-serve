import DynamicView from "@/layouts/DynamicView";

var DialogBox = {};

import FormBoListApi from "@/api/form/core/formBoList";
import FormSolutionShow from "@/views/modules/form/core/FormSolutionShow";
import FormSolutionTreeShow from "@/views/modules/form/core/FormSolutionTreeShow";
import FormBoListPreview from "@/views/modules/form/core/FormBoListPreview";
import FormBoListExportExcelDialog from "@/views/modules/form/core/FormBoListExportExcelDialog";
import FormBoListImportExcelDialog from "@/views/modules/form/core/FormBoListImportExcelDialog";
import LodopError from "@/views/modules/form/core/LodopError";
import BpmInstStart from "@/views/modules/bpm/core/BpmInstStart";
import FormBusSolutionShow from "@/views/modules/form/core/FormBusSolutionShow";

import {Util} from 'jpaas-common-lib'
import store from '@/store'

DialogBox.openLodopError = function (config) {
    var baseConf = {
        component: LodopError,
        widthHeight: ['400px', '300px'],
        title: '错误提示'
    };
    let conf = {...baseConf, ...config};
    Util.open(conf, function (action) {
    })
}

/**
 *  DialogBox.showForm({
        title:title,
        curVm: self,
        data: {alias: alias, pkId: pkId, readOnly: readOnly, parent: parent},
        max:true
      }, function (action) {
        self.onRefresh();
      });
 * @param config
 * @param callback
 */
DialogBox.showForm = function (config, callback) {
    //是否是树形表单方案
    var component = config.tree == 1 ? FormSolutionTreeShow : FormSolutionShow;
    let _showType = store.state.appSetting.showType;
    if (_showType && _showType == "newPage") {//新页面打开，非弹窗类型；
        let _key  = component.name + config.urlType ;
        //获取当前打开组件的 path。component.__source (生产环境下组件path),component.__file (开发环境下path)
        let _path = component.__source || component.__file ;
        _path = _path.replace('src/views/','');
        let obj = {
            component:_path,//组件路径
            props:config.data,
            key:_key,
            title:config.title,
            cmptKey:_key + new Date().getTime()
        }
        if(config.data && config.data.alias){
            obj.key=config.data.alias;
        }
        store.commit('appSetting/setActiveKey',obj.key);
        let _navigation = store.state.appSetting.navigation;
        //如果this.navigation没有存在当前要打开的控件则返回 -1 ；
        let _isObj = _navigation.findIndex(item => { return item.key == obj.key && item.title == obj.title });
        if(_isObj == -1){
            let _arr = [..._navigation,obj];
            store.commit('appSetting/setNavigation',_arr);
        }else {
            //存在的情况下，替换；
            let _idx = null ;
            let _navArr = _navigation.concat();
            for (let i in _navArr){
                if(_navArr[i].key == obj.key){
                    _idx = i ;
                }
            }
            _navArr[_idx] = obj ;
            store.commit('appSetting/setNavigation',_navArr);
        }
    } else {//弹窗打开；
        var title = config.title ? config.title : "使用表单";
        var baseConf = {
            component: component,
            title: title
        };
        let conf = {...baseConf, ...config};
        Util.open(conf, function (action,data) {
            callback(action,data);
        });
    }


}

/**
 * 打开列表对话框。
 * @param parameter {key:"对话框KEY",params:"Q_NAME__S_EQ=老王"}
 * @param config  {max:true,widthHeight:[data.width + 'px', data.height + 'px']}
 * @param callback
 */
DialogBox.dialog = function (parameter, config, callback) {
    FormBoListApi.setConf(parameter).then(res => {
        if (!res.success) return;
        var data = res.data;
        if (!config.widthHeight && data.isDialog == 'YES') {
            config.widthHeight = [data.width + 'px', data.height + 'px'];
        }
        let obj = {alias: parameter.key};
        let _parameter = {...obj, ...parameter}
        var baseConf = {
            component: FormBoListPreview,
            data: _parameter,
            title: data.name
        };
        let conf = {...baseConf, ...config};
        Util.open(conf, function (action, data) {
            if (action != 'ok') return;
            if (callback) {
                callback(data);
            }
        })
    });
}


DialogBox.openExportExcelDialog = function (config) {
    var name = config.data.name;
    var baseConf = {
        component: FormBoListExportExcelDialog,
        title: name + '导出EXCEL表单',
        max:true
    }
    let conf = {...baseConf, ...config};
    Util.open(conf, function (action) {
        if (action != 'ok') return;
    })
}

DialogBox.openImportExcelDialog = function (config, callback) {
    var name = config.data.name;
    var baseConf = {
        component: FormBoListImportExcelDialog,
        title: name + '导入EXCEL表单'
    }
    let conf = {...baseConf, ...config};
    Util.open(conf, function (action) {
        if (action != 'ok') return;
        if (callback) {
            callback();
        }
    })
}

DialogBox.loadView = (view) => { // 路由懒加载
    return require(`@/views/${view}`).default;
    //return () => import(`@/views/${view}`)
}

/**
 * 打开自定义组件。
 *
 * @param config {
 *   component:"组件的URL",
 *   title:"标题",
 *   max:true,
 *   curVm:this,
 *   widthHeight:['800px','600px'],
 *   data:{user:{name:"ray",address:"gz"}},
 * }
 * @param callBack 回调方法 function(action,data){
 *
 * }
 */
DialogBox.openComponent = function (config, callBack) {
    var component = DialogBox.loadView(config.component);
    var title = config.title || "自定义对话框";

    var conf = {
        component: DynamicView,
        curVm: config.curVm,
        title: title,
        data: {currentView: component, data: config.data}
    };
    if (config.widthHeight) {
        conf.widthHeight = config.widthHeight;
    } else {
        conf.max = true;
    }
    if (config.cancel) {
        conf.cancel = config.cancel;
    }

    Util.open(conf, function (action, data) {
        if (callBack) {
            callBack(action, data);
        }
    })
}

/**
 * 启动流程。
 * @param config
 * var data={defId:"1418459535940534274",formData:{address:"gz"}};
 var config={
        curVm:this,
        max:true,
        data: data
    }
 * @param callback (action,data)
 */
DialogBox.openStartFlow = function (config,callback) {
    var baseConf = {
        component: BpmInstStart,
        title:  '启动流程'
    }
    let conf = {...baseConf, ...config};
    Util.open(conf, function (action,data) {
        if (callback) {
            callback(action,data);
        }
    })
}


DialogBox.showBusSolutionForm = function (config, callback) {
    var baseConf = {
        component: FormBusSolutionShow,
        title: config.title
    };
    let conf = {...baseConf, ...config};
    Util.open(conf, function (action,data) {
        if (action != 'ok') return;
        if (callback) {
            callback(data);
        }
    })
}


export default DialogBox;
