<template>
    <div>
        <rx-params-tree ref="paramsTree" @select="handSelect"
                        @rightClick="rightClick"
                        :treeCat="treeCat"
                        :searchTopNodesUrl="searchTopNodesUrl"
                        :searchParams="searchParams"
                        :treeRelation="treeRelation"
                        :searchChildrenUrl="searchChildrenUrl"
                        :searchChildrenParams="searchChildrenParams"
        ></rx-params-tree>
        <v-contextmenu ref="contextmenu">
            <v-contextmenu-item @click="addNode">新增子节点</v-contextmenu-item>
            <v-contextmenu-item v-if="isTreeCat" @click="addSibling">添加同级</v-contextmenu-item>
            <v-contextmenu-item v-if="isTreeCat" @click="editNode">编辑节点</v-contextmenu-item>
            <v-contextmenu-item v-if="isTreeCat" @click="deleteNode">删除节点</v-contextmenu-item>
        </v-contextmenu>
    </div>
</template>

<script>
    import {Util,RxParamsTree} from "jpaas-common-lib";

    export default {
        name: "rx-category-treeeditor",
		components:{
			RxParamsTree
		},
        props: {
            edit: {
                type: Boolean,
                default: true
            },
            treeCat: {
                type: Object,
                default: () => {
                }
            },
            searchTopNodesUrl:{
                type:String,
                default:''
            },
            searchParams: {
                type: Object,
                default: () => {
                }
            },
            treeRelation: {
                type: Object,
                default: () => {
                }
            },
            searchChildrenUrl:{
                type:String,
                default:''
            },
            searchChildrenParams: {
                type: Object,
                default: () => {
                }
            },
        },
        data() {
            return {
                isTreeCat:true,
            }
        },
        computed: {
            paramsTree() {
                return this.$refs.paramsTree;
            },
            curRow() {
                return this.$refs.paramsTree.curRow;
            },
        },
        methods: {
            handSelect(selKeys, e) {
                this.$emit("handSelect", this.curRow);
            },
            rightClick({event, node}) {
                if (this.edit) {
                    const postition = {top: event.clientY, left: event.clientX};
                    if (this.curRow.key=="0"){
                        this.isTreeCat=false;
                    }else {
                        this.isTreeCat=true;
                    }
                    this.$refs.contextmenu.show(postition);
                }
            },
            addNode() {
                this.$emit("addNode", this.curRow);
            },
            addSibling() {
                this.$emit("addSibling", this.curRow);
            },
            editNode() {
                this.$emit("editNode", this.curRow);
            },
            deleteNode() {
                this.$emit("deleteNode", this.curRow);
            },
            handClick(row,operator){
                if("delete"==operator){
                    this.paramsTree.remove();
                    return;
                }
                this.paramsTree.setRreeRelation(row,"obj", this.treeRelation);
                switch (operator) {
                    case "add":
                        this.paramsTree.addRoot(row, "name", "treeId");
                        break;
                    case "edit":
                        this.paramsTree.merge(row, "name", "treeId");
                        break;
                    case "addchild":
                        this.paramsTree.addChild(row, "name", "treeId");
                        break;
                    case "addSibling":
                        this.paramsTree.addRow(row, "name", "treeId");
                        break;
                }
            },
        }
    }
</script>

<style scoped>

</style>