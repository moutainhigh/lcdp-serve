/**
 * 代码模板。
 */
export default [
    {label:"PostJson请求",value: "//参考文档:http://doc.redxun.cn/docs/jpaas/axioReqUtil\n" +
            "rxAjax.postJson(url,params).then(res=>{console.info(res)})\n"},
    {label:"PostForm请求",value: "//参考文档:http://doc.redxun.cn/docs/jpaas/axioReqUtil\n" +
            "rxAjax.postForm(url,params).then(res=>{console.info(res)})\n"},
    {label:"Get请求",value: "//参考文档:http://doc.redxun.cn/docs/jpaas/axioReqUtil\n" +
            "rxAjax.get(url,params).then(res=>{console.info(res)})\n"},
    {label:"打开自定义组件",value:"this.open({\n" +
    "        component:'',\n" +
    "        curVm:this.parentVm,\n" +
    "        max:true,\n" +
    "        title: '',\n" +
    "        data:{}\n" +
    "        },function (action){\n" +
    "        });"},
        {label:"打开URL地址",value:"this.openUrl({\n" +
                "        url:'',\n" +
                "        curVm:this.parentVm,\n" +
                "        max:true,\n" +
                "        title: ''\n" +
                "        },function (action){\n" +
                "      })"}
];