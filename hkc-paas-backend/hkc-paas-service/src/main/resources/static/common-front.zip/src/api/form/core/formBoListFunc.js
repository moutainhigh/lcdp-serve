import rxAjax from '@/assets/js/ajax.js';

var BoListApi={
    bpmInstUrl: '/api-bpm/bpm/core/bpmInst',
    formSolUrl:'/api-form/form/core/formSolution'
}

/**
 *启动流程
 * {
 *   formJson:"表单数据字符串",
 *   defId:"流程定义ID",
 *  instId:"流程实例ID",
 *  systemHand:"false 表示数据需要自己处理"
 *
 * }
 */
BoListApi.startProcess =function(parameter) {
    parameter.checkType="AGREE";
    let url = BoListApi.bpmInstUrl+ '/startProcess';
    return rxAjax.postJson(url,parameter);
}

/**
 * 保存流程草稿
 * {
 *   formJson:"表单数据字符串",
 *   defId:"流程定义ID",
 *  instId:"流程实例ID",
 *  systemHand:"false 表示数据需要自己处理"
 *
 * }
 */
BoListApi.saveDraft =function(parameter) {
    let url = BoListApi.bpmInstUrl+ '/saveDraft';
    return rxAjax.postJson(url,parameter);
}

/**
 * 根据表单方案 和主键ID获取表单数据。
 * @param alias     表单方案
 * @param id        主键
 * @param params
 * @returns {AxiosPromise|*}
 */
BoListApi.getByAlias =function(alias,id,params) {
    var url= BoListApi.formSolUrl + '/getByAlias?alias=' + alias ;
    if(id){
        url += "&pk=" + id;
    }
    return rxAjax.postJson(url,params);
}

/**
 * 保存表单数据。
 * {setting: {action: action, alias: self.formSolutionAlias}, data: data};
 * @param parameter
 * @returns {AxiosPromise|*}
 */
BoListApi.saveForm = function (parameter) {
    var url = BoListApi.formSolUrl + '/saveForm';
    return rxAjax.postJson(url, parameter);
}

/**
 * 在列表删除数据。
 * @param {
 *     alias:"表单方案名称",
 *     id:"主键数据,可以多个使用逗号分隔"
 * }
 * @returns {AxiosPromise|*}
 */
BoListApi.removeById = function (parameter) {
    var url = BoListApi.formSolUrl + '/removeById';
    return rxAjax.postJson(url, parameter);
}


export  default BoListApi;