<template>
    <div class="layoutContainer">
        <grid-layout v-show="type=='drag'"
                     :layout="layout"
                     :col-num="24"
                     :row-height="2"
                     :is-draggable="false"
                     :is-resizable="false"
                     :is-mirrored="false"
                     :vertical-compact="true"
                     :autoSize="true"
                     :margin="[10, 10]"
                     :use-css-transforms="true"
        >

            <grid-item class="griditem" v-for="item in layout"
                       :x="item.x"
                       :y="item.y"
                       :w="item.w"
                       :h="item.h"
                       :i="item.i"
                       :key="item.i">
                <!--Tab-->
                <layout-tab :ref="item.id" v-if="item.defConf=='tab'" :config="item.config"></layout-tab>
                <!--图表-->
                <chart-view v-else-if="item.defConf=='chart'" :layoutItem="item" :config="item.config"></chart-view>
                <!--ureport报表-->
                <ureport-view v-else-if="item.defConf=='ureport'" :config="item.config" :layoutItem="item"></ureport-view>
                <!--栏目-->
                <column-view v-else-if="item.defConf=='column'" :config="item.config" ></column-view>
                <!--自定义组件-->
                <custom-view v-else-if="item.defConf=='custom'" :config="item.config" ></custom-view>
                <!--日历组件-->
                <calendar-view v-else-if="item.defConf=='calendar'" :config="item.config" ></calendar-view>
                <!--Form List Tree-->
                <component v-else :ref="item.config.alias" :is="item.config.component"
                           :config="item.config"></component>
            </grid-item>
        </grid-layout>
        <custom-layout class="griditem" style="height: 100%" v-show="type=='custom'" :key="layoutKey" :allModel="allModel">
            <div
                v-for="item of lay"
                :slot="item"
                v-if="allModel.layoutModel[item]"
                :layoutStyle="allModel[item].toolStyle"
                style="height:100%"
                :key="item"
            >
                <template v-if="allModel[item].showTab =='no' && allModel[item].selectModel.config">
                    <component :ref="allModel[item].selectModel.config.alias"
                               :is="allModel[item].selectModel.config.component"
                               :config="allModel[item].selectModel.config"
                               :key='new Date().getTime()'
                    >
                    </component>
                </template>
                <template v-if="allModel[item].showTab =='yes'">
                    <layout-tab :ref="item" :config="allModel[item].tabData"  :key='item'></layout-tab>
                </template>
            </div>
        </custom-layout>
    </div>

</template>

<script>
import Vue from "vue"
import FormCustomApi from "@/api/form/core/formCustom";
import customLayout from "../formCustomLayout/CustomLayout.vue";
import layoutTab from "../formCustomLayout/LayoutTab.vue";
import ChartView from "../formComponent/ChartView";
import UreportView from "../formComponent/UreportView";
import ColumnView from '../formComponent/ColumnView.vue';
import FormComponent from "./FormComponent";
import ListComponent from "./ListComponent";
import TreeCompoment from "./TreeCompoment";
import CustomView from './CustomView.vue';
import CalendarView from "./CalendarView";
Vue.component(FormComponent.name, FormComponent);
Vue.component(ListComponent.name, ListComponent);
Vue.component(TreeCompoment.name, TreeCompoment);

export default {
    name: "form-custom-view",
    props: {
        layout: {
            type: Array,
            default: () => []
        },
        alias: {
            type: String
        },
        params: {
            type: String
        },
        //这个是从DialogView打开时需要用到的。
        menuParams:{
            type:String
        },
    },
    components: {
        customLayout,
        layoutTab,
        ChartView,
        UreportView,
        ColumnView,
        CustomView,
        CalendarView
    },
    data() {
        return {
            isFormCustom:true,
            layoutKey: 'mainLayout',
            lay: ["header", "inheader", "left", "right", "center", "footer", "infooter"],
            allModel: {
                layoutModel: {
                    header: false,
                    inheader: false,
                    left: false,
                    right: false,
                    footer: false,
                    infooter: false,
                    center: false
                },
                header: {
                    selectModel: {
                        name: "",
                        config: {}
                    },
                    toolStyle: "",
                    showTab: 'no',
                    tabData: []
                },
                inheader: {
                    selectModel: {
                        name: "",
                        config: {}
                    },
                    toolStyle: "",
                    showTab: 'no',
                    tabData: []
                },
                left: {
                    selectModel: {
                        name: "",
                        config: {}
                    },
                    toolStyle: "",
                    showTab: 'no',
                    tabData: []
                },
                right: {
                    selectModel: {
                        name: "",
                        config: {}
                    },
                    toolStyle: "",
                    showTab: 'no',
                    tabData: []
                },
                center: {
                    selectModel: {
                        name: "",
                        config: {}
                    },
                    toolStyle: "",
                    showTab: 'no',
                    tabData: []
                },
                footer: {
                    selectModel: {
                        name: "",
                        config: {}
                    },
                    toolStyle: "",
                    showTab: 'no',
                    tabData: []
                },
                infooter: {
                    selectModel: {
                        name: "",
                        config: {}
                    },
                    toolStyle: "",
                    showTab: 'no',
                    tabData: []
                },
            },
            type: 'drag',
            dataAlias:''
        }
    },
    mounted() {
        if (!this.layout || this.layout.length == 0) {
            this.initParams();
            this.init();
        }
    },
    methods: {
        initParams(){

            if (!this.alias) {
                if(this.menuParams){
                    var json=JSON.parse(this.menuParams);
                    this.dataAlias=json.alias;
                }
                else {
                    if(this.$route.meta.params){
                        var json=JSON.parse(this.$route.meta.params);
                        this.dataAlias=json.alias;
                        this.$route.meta.query = this.$route.meta.params;
                    }else {
                        this.dataAlias=this.$route.params.alias;
                    }
                }
            }else {
                this.dataAlias=this.alias;
            }
            if (this.params) {
                this.$route.meta.query = this.params;
            }
        },
        init() {
            var self = this;
            FormCustomApi.getByAlias(this.dataAlias).then(res => {
                self.type = res.type;
                if (res.type == 'drag') {
                    self.layout = JSON.parse(res.json);
                } else {
                    if(res){
                        self.allModel = JSON.parse(res.json);
                    }
                }
            })
        },
        getCustomById(customId) {
            var self = this;
            FormCustomApi.get(customId).then(res => {
                var data=res.data;
                self.type = data.type;
                if (data.type == 'drag') {
                    self.layout = JSON.parse(data.json);
                } else {
                    self.allModel = JSON.parse(data.json);
                }
            })
        }
    },
    watch: {
        '$route': {
            handler: function (val) {
                if(val.meta.param){
                    var json=JSON.parse( val.meta.params);
                    this.dataAlias = json.alias;
                    val.meta.query = val.meta.params;
                    if(this.params){
                        val.meta.query=this.params;
                    }
                }else {
                    this.dataAlias=val.params.alias;
                }
                this.initParams();
                this.init();
            },
            deep: true
        }
    }
}
</script>

<style scoped>
.layoutContainer {
    width: 100%;
    height: 100%;
    background: #f0f2f5;
}

.ant-btn-primary {
    margin-right: 6px;
}

.btnSpan {
    border-radius: 10px;
    width: 20px;
    height: 20px;
    text-align: center;
    line-height: 18px;
    background: #1890ff;
    display: inline-block;
    margin-right: 6px;
    cursor: pointer;
}

.btnSpan i {
    color: #fff;
    font-size: 10px;
    margin-top: 3px;
}

.gridLayoutClass {
    background: #fff;
    border: 1px solid #ddd;
    height: 100%;
    width: 100%;
    display: flex;
    flex-direction: column
}

.headPClass {
    line-height: 40px;
    height: 40px;
    box-sizing: border-box;
    border-bottom: 1px solid #ddd;
}

.bodyDivClass {
    flex: 1;
    position: relative;
    bottom: -2px;
    background-color: #fff;
    cursor: default;
}

.active {
    background-color: #5cb85c;
    /*background-color:#ec971f;*/
    cursor: default;
}

.main {
    background-color: #ec971f;
    cursor: default;
}

.toolTabs {
    height: 100%;
}

ul, li {
    list-style: none;
}

.bodyDivClass .itmelist {
    display: flex;
    align-items: center;
}

.itmelist p {
    flex: 1;
    margin: 0;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
}

.itmelist p:hover {
    color: #0000cc;
    cursor: pointer;
}

.bodyDivClass > ul {
    padding: 0 10px;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 1px;
    overflow: auto;
}

.itmelist {
    padding-left: 20px;
    position: relative;
    line-height: 30px;
}

.itmelist:before {
    content: "■";
    display: inline-block;
    position: absolute;
    left: 0px;
    top: 50%;
    margin-top: -2px;
    font-size: 8px;
    width: 8px;
    height: 8px;
    line-height: 8px;
    color: #ccc;
}

.itmelist b {
    font-style: normal;
    display: inline-block;
    padding: 4px 8px;

}

</style>