import {UserLayout} from "@/layouts";

/**
 * 扩展的静态路由，客户的定制路由可以在此添加。
 * 路由是一个JSON数组。
 * @type {Array}
 */
var ExtendRouters=[


];

export  default ExtendRouters;