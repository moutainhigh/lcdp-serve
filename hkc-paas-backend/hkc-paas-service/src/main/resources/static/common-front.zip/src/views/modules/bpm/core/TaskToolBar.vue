<template>

    <a-button-group v-if="btns.length==0" class="btnContainerBox">

        <template v-if="canCheck">
            <a-button :disabled="!allowApprove" key="btnApprove" @click="approve">审批</a-button>
            <a-button key="btnSave" :loading="saveStatus" @click="doSaveData">保存</a-button>
            <a-button key="btnLock" v-if="candicate!=-1 && !isTransferRoam" @click="doLock()">{{ lockStatus }}
            </a-button>
            <a-button key="btnTracked" @click="doTracked()">
                <a-icon type="star" :theme="trackedTheme" :style="{'color':trackedColor}"/>
                {{ trackText }}
            </a-button>
            <a-button v-if="addSignBtn && !isTransferRoam" key="btnAddSign" @click="addSign">加签</a-button>
            <a-button key="btnReject" v-if="isCanBack && !isTransferRoam" @click="reject">驳回</a-button>
            <a-button v-if="!isCanRoamTransfer" key="btnRoamTransfer" @click="doRoamTransfer">流转</a-button>
            <a-button v-if="isCanRoamTransfer" key="btnCancelRoamTransfer" @click="doCancelRoamTransfer">取消流转</a-button>
            <a-button v-if="isCanRoamTransfer" key="btnRoamInfo" @click="roamInfo">流转情况</a-button>
            <a-button key="btnTransfer" v-if="canTransfer && !isTransferRoam" @click="doTransfer">转办</a-button>
            <a-button v-if="showDisCardBtn && !isTransferRoam" key="btnDiscard" @click="doDiscard">作废</a-button>
            <a-button v-if="!isTransferRoam" key="btnCommu" @click="communicate">沟通</a-button>
            <a-button v-if="bpmTaskDetail.communicated && !isTransferRoam" key="btnCommuInfo" @click="commuInfo()">
                沟通情况
            </a-button>
        </template>
        <template v-else-if="bpmTaskDetail.bpmTask && bpmTaskDetail.bpmTask.taskType=='LINKUP_TASK' && !isTransferRoam">
            <a-button key="btnReply" @click="doReplyCommu" :disabled="!bpmTaskDetail.canReply">回复沟通</a-button>
            <a-button key="btnCommu" @click="communicate" :disabled="!bpmTaskDetail.canReply">沟通</a-button>
            <a-button v-if="bpmTaskDetail.communicated" key="btnCommuInfo" @click="commuInfo()">沟通情况</a-button>
        </template>
        <a-button key="btnPrint" @click="doPrint()">打印</a-button>
        <a-button key="btnFlowImg" @click="doFlowImg">流程图</a-button>
        <a-button key="btnHistory" @click="doHistory">审批历史</a-button>
        <a-button key="btnMessage" @click="doMessage">留言</a-button>
    </a-button-group>
    <a-button-group v-else class="btnContainerBox">

        <template v-for="btn in btns">
            <!--可以审批的任务-->
            <template v-if="canCheck">
                <!--审批-->
                <a-button v-if="btn.id=='btnApprove' && allowApprove" :type="btn.style" :key="btn.id"
                          @click="approve">{{ btn.name }}
                </a-button>
                <!--跟踪-->
                <a-button v-if="btn.id=='btnTracked'" :key="btn.id" :type="btn.style"  @click="doTracked()">
                    <a-icon type="star" :theme="trackedTheme" :style="{'color':trackedColor}"/>
                    {{ trackText }}
                </a-button>
                <!--保存-->
                <a-button v-if="btn.id=='btnSave'" :key="btn.id" :type="btn.style" @click="doSaveData">{{ btn.name }}
                </a-button>
                <!--加签-->
                <a-button v-else-if="btn.id=='btnAddSign' && addSignBtn && !isTransferRoam" :type="btn.style"
                          :key="btn.id" @click="addSign(btn)">{{ btn.name }}
                </a-button>
                <!--锁定释放任务-->
                <a-button v-else-if="btn.id=='btnLock' && candicate!=-1 && !isTransferRoam" :type="btn.style"
                          key="btnLock" @click="doLock()">{{ lockStatus }}
                </a-button>
                <!--流转-->
                <a-button v-else-if="btn.id=='btnRoamTransfer' && !isCanRoamTransfer" :type="btn.style"
                          key="btnRoamTransfer" @click="doRoamTransfer">{{ btn.name }}
                </a-button>
                <!--取消流转-->
                <a-button v-else-if="btn.id=='btnCancelRoamTransfer' && isCanRoamTransfer" :type="btn.style"
                          key="btnCancelRoamTransfer" @click="doCancelRoamTransfer">{{ btn.name }}
                </a-button>
                <!--流转情况-->
                <a-button v-else-if="btn.id=='btnRoamInfo' && isCanRoamTransfer" :type="btn.style" key="btnRoamInfo"
                          @click="roamInfo">{{ btn.name }}
                </a-button>
                <!--转办-->
                <a-button v-else-if="btn.id=='btnTransfer' && canTransfer && !isTransferRoam" :type="btn.style"
                          key="btnTransfer" @click="doTransfer">{{ btn.name }}
                </a-button>
                <!--驳回-->
                <a-button v-else-if="btn.id=='btnReject' && isCanBack && !isTransferRoam" :type="btn.style"
                          :key="btn.id" @click="reject(btn)">{{ btn.name }}
                </a-button>
                <!--作废-->
                <a-button v-else-if="btn.id=='btnDiscard' && showDisCardBtn && !isTransferRoam" :type="btn.style"
                          :key="btn.id" @click="doDiscard(btn)">{{ btn.name }}
                </a-button>
                <!--沟通-->
                <a-button v-else-if="btn.id=='btnCommu' && !isTransferRoam" :key="btn.id" :type="btn.style"
                          @click="communicate(btn)">{{ btn.name }}
                </a-button>

                <a-button v-else-if="btn.id=='btnCommuInfo'  && bpmTaskDetail.communicated && !isTransferRoam"
                          :type="btn.style" :key="btn.id" @click="commuInfo(btn)">{{ btn.name }}
                </a-button>

                <a-button v-else-if="btn.id=='btnPrint' " :type="btn.style" key="btnPrint" @click="doPrint()">
                    {{ btn.name }}
                </a-button>

                <a-button v-else-if="!isBuildinBtn(btn.id)" :type="btn.style"
                          :key="btn.id" @click="handMethod(btn)">{{ btn.name }}
                </a-button>

            </template>
            <!--当前为沟通任务-->
            <template v-else-if="bpmTaskDetail.bpmTask.taskType=='LINKUP_TASK' && !isTransferRoam">
                <a-button v-if="btn.id=='btnReply'" :type="btn.style" key="btnReply" @click="doReplyCommu"
                          :disabled="!bpmTaskDetail.canReply">回复沟通
                </a-button>
                <a-button v-if="btn.id=='btnCommu'" :type="btn.style" key="btnCommu" @click="communicate"
                          :disabled="!bpmTaskDetail.canReply">沟通
                </a-button>
                <a-button v-if="btn.id=='btnCommuInfo'  && bpmTaskDetail.communicated" :type="btn.style"
                          key="btnCommuInfo" @click="commuInfo()">沟通情况
                </a-button>
            </template>
        </template>
    </a-button-group>
</template>

<script>
import BpmtaskApi from "@/api/bpm/core/bpmTask";
import BpmInstApi from "@/api/bpm/core/bpmInst";
import BpmInstTrackedApi from "@/api/bpm/core/bpmInstTracked";

import {Util} from "jpaas-common-lib";
import BpmTaskCheck from "./BpmTaskCheck";
import BpmTaskTransferCheck from "./BpmTaskTransferCheck";
import BpmTaskBack from "./BpmTaskBack";
import BpmTaskAddSign from "./BpmTaskAddSign";
import BpmTaskTransferEdit from "./BpmTaskTransferEdit";
import BpmTaskLinkup from "./BpmTaskLinkup";
import BpmTaskCommu from "./BpmTaskCommu";
import BpmTaskRoam from "./BpmTaskRoam";
import TaskCommuReply from "./TaskCommuReply";

import BpmImageView from "../comps/BpmImageView";
import formbase from '@/api/formbase';
import BpmInstStart from "./BpmInstStart";
import BpmTaskRoamTransfer from "./BpmTaskRoamTransfer";
import FlowUtil from "@/views/modules/bpm/workbench/js/FlowUtil";

export default {
    name: "task-tool-bar",
    props: ["bpmTaskDetail", "taskConfig"],
    mixins: [formbase,FlowUtil],
    data() {

        return {
            btns: [],
            showDisCardBtn: false,
            isCanBack: false,
            isTransferRoam: false,
            isCanRoamTransfer: false,
            addSignBtn: false,
            allowSelectExecutor: false,
            allowSelectGroup: false,
            backOptions: [],
            canCheck: true,
            allowApprove: true,
            canTransfer: '',
            candicate: -1,
            lockStatus: "",
            //保存状态
            saveStatus: false
        }
    },
    computed:{
        trackedTheme() {
            return this.bpmTaskDetail.tracked == '1' ? 'filled' : 'outlined';
        },
        trackedColor() {
            return this.bpmTaskDetail.tracked == '1' ? '#eab207' : '#1890ff';
        },
        trackText() {
            return this.bpmTaskDetail.tracked == "1" ? "已跟踪" : "跟踪";
        },
    },

    methods: {
        isBuildinBtn(btn) {
            var btns = ['btnApprove', 'btnSave', 'btnLock', 'btnAddSign',
                'btnReject', 'btnTransfer', 'btnDiscard',
                'btnCommu', 'btnCommuInfo', 'btnReply', 'btnPrint'];
            return btns.indexOf(btn) > -1;
        },
        getCandicate() {
            if (!this.bpmTaskDetail.bpmTask || !this.bpmTaskDetail.bpmTask.hasCandicate) {
                this.candicate = -1;
                this.lockStatus = "";
                return;
            }
            //有侯选人
            if (this.bpmTaskDetail.bpmTask.assignee) {
                this.candicate = 1;
                this.lockStatus = "释放任务";
            } else {
                this.candicate = 2;
                this.lockStatus = "锁定任务";
            }
        },
        doPrint() {
            var baseUrl = process.env.VUE_APP_API_CTX_PATH;
            var bpmInst = this.bpmTaskDetail.bpmInst;
            var defId = bpmInst.defId;
            var instId = bpmInst.instId;
            var url = baseUrl + "/flowprint/" + defId;
            if (instId) {
                url += "/" + instId;
            } else {
                url += "/-1";
            }
            window.open(url);
        },
        startSubProcess(alias) {
            var self_ = this;
            var formType = this.parentVm.processConfig.formType;
            var formData = {};
            if (formType == "online") {
                formData = this.rxForms.getData();
            } else {
                formData = this.customForm.getData();
            }
            BpmInstApi.getSubProcessFormData({
                defKey: alias, mainDefId: this.parentVm.bpmTask.defId, instId: this.parentVm.instId, formData: formData
            }).then(res => {
                if (!res.success) {
                    return;
                }
                self_.startFlowPage(res.data);
            })
        },
        startFlowPage(data) {
            Util.open({
                component: BpmInstStart,
                curVm: this,
                max: true,
                title: data.defName + '流程启动',
                data: {
                    defId: data.defId,
                    mainDefId: this.parentVm.bpmTask.defId,
                    mainTaskId: this.parentVm.bpmTask.actTaskId,
                    formData: data.formData,
                    vars: data.vars
                }
            }, function (action) {
            });
        },
        async approve() {
            let self = this.parentVm;
            if (self.isCanRoamTransfer) {
                this.$message.error("当前任务正在流转，请取消流转后重试!");
                return;
            }
            if (self.processConfig.formType == "custom") {
                var res = await this.customForm.valid();
                if (!res) {
                    return;
                }
            } else {
                let res = await this.rxForms.valid(true, true);
                if (!res.success) {
                    this.$message.error(res.msg);
                    return;
                }
            }
            var data = {
                taskId: self.taskId,
                nodeExecutors: self.nodeExecutors,
                allowSelectExecutor: this.allowSelectExecutor,
                allowSelectGroup: this.allowSelectGroup,
                opinionObj: {},
                systemHand: true,
                taskConfig: this.taskConfig
            }
            var formData = {};
            if (self.processConfig.formType == "custom") {
                formData = this.customForm.getData();
                data.systemHand = false;
            } else {
                formData = this.rxForms.getData();
                let opinionObj = this.rxForms.getOpinionData();
                data.opinionObj = opinionObj;
            }

            let formJson = JSON.stringify(formData);
            data.formJson = formJson;
            let self_=this;
            Util.open({
                component: !this.isTransferRoam ? BpmTaskCheck : BpmTaskTransferCheck,
                curVm: self,
                widthHeight: ['860px', '620px'],
                title: '任务审批',
                data: data
            }, function (action) {
                if (action == 'ok') {
                    //如果是独立打开的那么就关闭窗口。
                    if(self_.isAlone){
                        if (self.destroy) {
                            Util.closeWindow(self, "ok");
                        } else {
                            self.loadTaskInfo();
                        }
                    }
                    //如果是使用统一URL的方式走下面的代码。
                    else{
                        self_.reload();
                    }
                }
            });
        },
        addSign() {
            let self = this.parentVm;
            Util.open({
                component: BpmTaskAddSign,
                curVm: self,
                widthHeight: ['600px', '380px'],
                title: '加签',
                data: {
                    taskId: self.taskId
                }
            }, function (action) {
            });
        },
        reject() {
            let self = this.parentVm;
            let formData = this.rxForms.getData();
            let formJson = JSON.stringify(formData);
            var opinionObj = this.rxForms.getOpinionData();
            Util.open({
                component: BpmTaskBack,
                curVm: self,
                widthHeight: ['860px', '560px'],
                title: '任务回退',
                data: {
                    taskId: self.taskId,
                    formJson: formJson,
                    backOptions: this.backOptions,
                    opinionObj: opinionObj
                }
            }, function (action) {
                if (action == 'ok') {
					if(self.isAlone) {
						Util.closeWindow(self, "ok");
					}else{
						self.reload();
					}
                }
            });
        },
		reload() {
			let parentVm = this.parentVm;
			let eventObj = {action: "inst", data: parentVm.instId};
			this.$bus.emit("flowEvent", eventObj);
		},
        doCancelRoamTransfer() {
            let self_ = this
            this.$confirm({
                title: '确认取消流转任务吗？',
                okText: '确认',
                cancelText: '取消',
                zIndex:999999,
                onOk() {
                    BpmtaskApi.cancelTransRoamTask(self_.parentVm.taskId).then(res => {
						if(self_.isAlone) {
							Util.closeWindow(self_.parentVm, "ok")
						}else{
							self_.reload();
						}
                    })
                },
            });
        },
        roamInfo() {
            let self = this.parentVm;
            Util.open({
                component: BpmTaskRoam,
                curVm: self,
                widthHeight: ['800px', '450px'],
                title: '任务流转',
                data: {
                    taskId: self.taskId,
                    subject: self.bpmInst.subject,
                }
            }, function (action) {
                if (action == 'ok') {
                    self.loadTaskInfo();
                }
            });
        },
        doRoamTransfer() {
            let self = this.parentVm;
            let this_ = this;
            Util.open({
                component: BpmTaskRoamTransfer,
                curVm: self,
                widthHeight: ['800px', '600px'],
                title: '任务流转',
                data: {
                    taskId: self.taskId,
                    subject: self.bpmInst.subject,
                }
            }, function (action) {
                if (action == "ok") {
                    this_.doSaveData(function () {
						if(self.isAlone) {
							Util.closeWindow(self, "ok");
						}else{
							self.reload();
						}
                    });
                }
            });
        },
        doTransfer() {
            let self = this.parentVm;
            Util.open({
                component: BpmTaskTransferEdit,
                curVm: self,
                widthHeight: ['800px', '450px'],
                title: '任务转办',
                data: {
                    taskId: self.taskId,
                    subject: self.bpmInst.subject,
                }
            }, function (action) {
                if (action == "ok") {
					if(self.isAlone) {
						Util.closeWindow(self, "ok");
					}else{
						self.reload();
					}
                }
            });
        },
        doDiscard() {
            let self_ = this.parentVm;
            this.$confirm({
                title: '操作提示',
                content: '您确定作废当前任务吗？',
                okText: '确认',
                cancelText: '取消',
                zIndex: 20000,
                onOk() {
                    BpmInstApi.cancelProcess(self_.instId, "").then(res => {
						if(self_.isAlone) {
							Util.closeWindow(self_, "ok");
						}else{
							self_.reload();
						}
                    })
                },
                onCancel() {
                }
            })
        },
        doReplyCommu() {
            let self = this.parentVm;
            var taskId = this.bpmTaskDetail.bpmTask.taskId;
            BpmtaskApi.canReplyCommu(taskId).then(res => {
                if (!res.success) {
                    return;
                }
                //回复沟通。
                Util.open({
                    component: TaskCommuReply,
                    curVm: self,
                    widthHeight: ['800px', '450px'],
                    title: '回复沟通',
                    data: {
                        taskId: self.taskId
                    }
                }, function (action) {
                    if (action == 'ok') {
						if(self.isAlone) {
							Util.closeWindow(self, "ok");
						}else{
							self.reload();
						}
                    }
                });
            })


        },
        communicate() {
            let self = this.parentVm;
            Util.open({
                component: BpmTaskLinkup,
                curVm: self,
                widthHeight: ['800px', '550px'],
                title: '任务沟通',
                data: {
                    taskId: self.taskId,
                    subject: self.bpmInst.subject,
                }
            }, function (action) {
                if (action == 'ok') {
                    self.loadTaskInfo();
                }
            });
        },
        doRevoke() {
            let self = this.parentVm;
            //进行任务撤回处理
            BpmtaskApi.revokeCmTask(self.taskId).then(resp => {
                self.loadTaskInfo();
            });
        },

        async doSaveData(callback) {
            var self = this;
            this.saveStatus = true;
            if (self.parentVm.processConfig.formType == "custom") {
                var res = await this.customForm.valid();
                if (!res) {
                    return;
                }
            } else {
                let res = await this.rxForms.valid(true, true);
                if (!res.success) {
                    this.saveStatus = false;
                    this.$message.error(res.msg);
                    return;
                }
            }
            let data = {taskId: this.parentVm.taskId, systemHand: true};
            var formData = {};
            if (this.parentVm.processConfig.formType == "custom") {
                formData = this.customForm.getData();
                data.systemHand = false;
            } else {
                formData = this.rxForms.getData();
            }
            var formJson = JSON.stringify(formData);
            data.formJson = formJson;
            BpmtaskApi.saveFormData(data).then(resp => {
                self.saveStatus = false;
                if (self.parentVm.processConfig.formType != "custom") {
                    //表单保存时重新加载表单数据。
                    self.parentVm.loadTaskInfo();
                    self.rxForms.afterSubmit(resp, formData);
                }
                if (callback && typeof callback == 'function') {
                    callback();
                }
            });
        },
        doFlowImg() {
            let self = this.parentVm;
            var formData = {};
            if (self.processConfig.formType == "custom") {
                formData = this.customForm.getData();
            } else {
                formData = this.rxForms.getData();
            }
            Util.open({
                component: BpmImageView,
                curVm: self,
                widthHeight: ['1024px', '600px'],
                title: '流程图',
                data: {
                    taskId: self.taskId,
                    formData: formData
                }
            }, function (action) {
            });
        },
        doHistory() {
            this.parentVm.historyShow = true;
        },
        doMessage() {
            this.parentVm.msgShow = true;
        },
        //更新任务的状态
        doLock() {
            let self = this.parentVm;


            let title = this.candicate == 1 ? "释放任务吗?" : "锁定任务吗?";

            this.$confirm({
                title: '操作提示',
                content: title,
                zIndex: 299999,
                okText: '确认',
                cancelText: '取消',
                onOk() {
                    let data = {taskId: self.taskId};
                    BpmtaskApi.updateLocked(data).then(resp => {
                        self.loadTaskInfo();
                    });
                }
            })
        },
        commuInfo() {
            let self = this.parentVm;
            Util.open({
                component: BpmTaskCommu,
                curVm: self,
                widthHeight: ['800px', '450px'],
                title: '任务沟通',
                data: {
                    taskId: self.taskId,
                    subject: self.bpmInst.subject,
                }
            }, function (action) {
                if (action == 'ok') {
                    self.loadTaskInfo();
                }
            });

        },
        doTracked() {
            let instId = this.bpmTaskDetail.bpmInst.instId;
            BpmInstTrackedApi.doTracked(instId).then(res => {
                this.bpmTaskDetail.tracked = res.data;
            })
        },
    },
    watch: {
        bpmTaskDetail: {
            handler: function (val, oldval) {
                this.btns = val.taskConfig.buttons;
                this.canCheck = val.canCheck;
                this.canTransfer = val.canTransfer;
                this.isCanBack = val.isCanBack;
                this.showDisCardBtn = val.isShowDiscardBtn;
                this.isTransferRoam = val.isTransferRoam;
                this.isCanRoamTransfer = val.isCanRoamTransfer;
                this.addSignBtn = val.canAddSign;
                this.allowApprove = val.allowApprove.success;
                this.allowSelectExecutor = val.taskConfig.switchOptions.includes("allowSelectExecutor");
                this.allowSelectGroup = val.taskConfig.switchOptions.includes("allowSelectGroup");
                this.backOptions = val.taskConfig.backOptions;
                //
                this.getCandicate();
            },
            deep: true
        }
    },
}
</script>

<style scoped>
.btnContainerBox >>> .ant-btn:first-child {
    background: #1890ff;
    border-color: #1890ff;
    color: #fff;
}

.btnContainerBox >>> .ant-btn:first-child:hover {
    background-color: #40a9ff;
    border-color: #40a9ff;
}
</style>