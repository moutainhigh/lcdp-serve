import rxAjax from '@/assets/js/ajax.js';

const SysMenuApi = {};

SysMenuApi.baseUrl= '/api-system/system/core/sysMenu';
SysMenuApi.exportUrl= SysMenuApi.baseUrl + '/export';

/**
 * 获取可授权菜单。
 * @param parameter
 * @returns {*}
 */
SysMenuApi.selectMenus= function(parameter) {
  var url=SysMenuApi.baseUrl + '/selectMenus';
  if(parameter && parameter.isGrade=="yes"){
    url=SysMenuApi.baseUrl + '/getGradeMenu';
  }
  return rxAjax.get(url,parameter);
}


SysMenuApi.getAllSysMenuListByAppId= function(parameter) {
  var url=SysMenuApi.baseUrl + '/getMenusByAppId';
  let data = rxAjax.get(url,parameter);
  return data;
}


SysMenuApi.getSysMenuList= function(parameter) {
  var url=SysMenuApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then(res => {
    return res.result
  })
}

SysMenuApi.getAllSysMenuList= function(parameter) {
  var url=SysMenuApi.baseUrl + '/getAll';
  return rxAjax.get(url,parameter).then(res =>{
    return res.data
  })
}


/**
 * 获取单记录
 * @param pkId
 * @returns {*}
 */
SysMenuApi.getSysMenu= function(pkId) {
  var url=SysMenuApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

SysMenuApi.saveSysMenu= function(parameter) {
  var url=SysMenuApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

SysMenuApi.saveBatchSysMenu= function(json,appId,parentId) {
    var url=SysMenuApi.baseUrl + '/saveBatch?appId='+appId + '&parentId=' + parentId;
    return rxAjax.postJson(url,json);
}


SysMenuApi.delSysMenu= function(parameter) {
  var url=SysMenuApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

SysMenuApi.syncMenuBtns= function(parameter){
  var url=SysMenuApi.baseUrl + '/syncMenuBtns';
  return rxAjax.postJson(url,parameter);
}

SysMenuApi.toMoveMenu=function (parameter) {
  var url=SysMenuApi.baseUrl + '/toMoveMenu';
  return rxAjax.postForm(url,parameter);
}
//批量删除
SysMenuApi.delSysMenus= function(parameter) {
  var url=SysMenuApi.baseUrl + '/delSysMenus';
  return rxAjax.postForm(url,parameter);
}

SysMenuApi.getInterfaceByParent=function(parentId){
  var url=SysMenuApi.baseUrl + '/getInterfaceByParent?parentId=' + parentId;
  return rxAjax.get(url);
}
//根据appKey获取菜单
SysMenuApi.getMenusByAppKey= function(appKey) {
    var url = "/api-system/system/core/sysMenu/getMenusByAppKey?appKey=" + appKey;
    return rxAjax.get(url);
}

SysMenuApi.getGrantList=function(appId){
    var url=SysMenuApi.baseUrl + '/getGrantList?appId=' + appId;
    return rxAjax.get(url);
}

export  default SysMenuApi;


