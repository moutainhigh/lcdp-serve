
import rxAjax from '@/assets/js/ajax.js';

const BpmInstApi = {
  baseUrl: '/api-bpm/bpm/core/bpmInst'
}

// 获取流程实例
BpmInstApi.getBpmInstList =function(parameter) {
  let url= BpmInstApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter);
}

/**
 * 获取变量列表
 * @param actInstId
 * @param varData
 * @returns {AxiosPromise}
 */
BpmInstApi.listVars = function(actInstId){
  let url= BpmInstApi.baseUrl + '/listVars';
  return rxAjax.postForm(url, {actInstId:actInstId});
}

/**
 * 删除流程变量
 * @param actInstId
 * @param varKey
 * @returns {AxiosPromise}
 */
BpmInstApi.delVar = function(actInstId,varKey){
  let url= BpmInstApi.baseUrl + '/delVar';
  return rxAjax.postForm(url, {actInstId:actInstId,varKey:varKey});
}

/**
 * 保存流程变量
 * @param actInstId
 * @param varData
 * @returns {AxiosPromise}
 */
BpmInstApi.saveVarRow = function(actInstId,varData){
  let url= BpmInstApi.baseUrl + '/saveVarRow';
  return rxAjax.postForm(url, {actInstId:actInstId,data:varData});
}

/**
 * 获取单记录
 * @param pkId
 * @returns {*}
 */
BpmInstApi.getBpmInst =function(pkId) {
  var url= BpmInstApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}
//保存数据
BpmInstApi.saveBpmInst =function(parameter) {
  let url= BpmInstApi.baseUrl+ '/save';
  return rxAjax.postJson(url,parameter);
}

//更新流程实例状态
BpmInstApi.updateProcessStatus =function(instId,status) {
  let url= BpmInstApi.baseUrl+ '/updateProcessStatus';
  return rxAjax.postForm(url,{instId:instId,status:status});
}

//流程实例作废
BpmInstApi.cancelProcess=function (instId,reason) {
  let url= BpmInstApi.baseUrl+ '/cancelProcess';
  return rxAjax.postForm(url,{instId:instId,reason:reason});
}

/**
 * 根据流程实例ID进行加密操作
 * @param instId
 * @returns {*}
 */
BpmInstApi.getBpmInstEncrypt=function(instId){
	let url =BpmInstApi.baseUrl+ '/getBpmInstEncrypt';
	return rxAjax.postForm(url,{instId:instId});
}
/**
 * 根据流程实例ID进行解密操作
 * @param instId
 * @returns {*}
 */
BpmInstApi.getBpmInstDecrypt=function(instId){
	let url =BpmInstApi.baseUrl+ '/getBpmInstDecrypt';
	return rxAjax.postForm(url,{instId:instId});
}
/**
 * 根据流程实例Id获取流程实例信息
 * @param instIds
 * @returns {*}
 */
BpmInstApi.getBpmInstInfo=function(instIds,relType){
	let url =BpmInstApi.baseUrl+ '/getBpmInstInfo';
	return rxAjax.postForm(url,{instIds:instIds,relType:relType});
}
BpmInstApi.getBpmInstEncryptList=function(instIds,relType){
	let url =BpmInstApi.baseUrl+ '/getBpmInstEncryptList';
	return rxAjax.postJson(url,{instIds:instIds,relType:relType});
}

/**
*启动流程
* {
*   formJson:"表单数据字符串",
*   defId:"流程定义ID",
 *  instId:"流程实例ID",
 *  systemHand:"false 表示数据需要自己处理"
 *
* }
*/
BpmInstApi.startProcess =function(parameter) {
  parameter.checkType="AGREE";
  let url = BpmInstApi.baseUrl+ '/startProcess';
  return rxAjax.postJson(url,parameter);
}

/**
 * 保存流程草稿
 * {
 *   formJson:"表单数据字符串",
 *   defId:"流程定义ID",
 *  instId:"流程实例ID",
 *  systemHand:"false 表示数据需要自己处理"
 *
 * }
 */
BpmInstApi.saveDraft =function(parameter) {
  let url = BpmInstApi.baseUrl+ '/saveDraft';
  return rxAjax.postJson(url,parameter);
}

//删除流程实例
BpmInstApi.delBpmInst =function(parameter) {
  let url= BpmInstApi.baseUrl + '/del';
  return rxAjax.postForm(url,parameter);
}

//通过定义获取视图
BpmInstApi.getViewByDefId=function (obj) {
  var url= BpmInstApi.baseUrl + '/getViewByDefId';

  return rxAjax.postForm(url,obj);
}

// 获取流程实例明细信息
BpmInstApi.getInstDetail = function(instId,from){
    let url= BpmInstApi.baseUrl + '/getInstDetail?instId=' + instId +"&from=" + from;
    return rxAjax.get(url);
}

BpmInstApi.getInstDetailForInterpose = function(instId){
  let url= BpmInstApi.baseUrl + '/getInstDetailForInterpose?instId=' + instId;
  return rxAjax.get(url);
}



BpmInstApi.getProcessConfig = function(defId,defKey){

  let url = BpmInstApi.baseUrl + '/getProcessConfig?defId=' + defId;
  if(defKey){
    url = BpmInstApi.baseUrl + '/getProcessConfigByKey?defKey=' + defKey;
  }

  return rxAjax.get(url);
}
BpmInstApi.getInstIdProcessConfig = function(instId){
  let url = BpmInstApi.baseUrl + '/getInstIdProcessConfig?instId=' + instId;
  return rxAjax.get(url);
}

BpmInstApi.getTaskNodeUsers=function(actInstId,isGetEnd){
  let url = BpmInstApi.baseUrl + '/getTaskNodeUsers?actInstId=' + actInstId;
  if(isGetEnd){
    url+="&isGetEnd="+isGetEnd;
  }
  return rxAjax.get(url);
}

/**
 * 更新当前流程实例的节点干预人员节点
 *  @param
 *  actInstId, // 流程实例Id
 *  nodeId,   //节点Id
 *  userIds   //用户Ids，格式如12,33
 */
BpmInstApi.updateOperatorNodeUser=function(params){
  let url= BpmInstApi.baseUrl + '/updateOperatorNodeUser';
  return rxAjax.postForm(url,params);
}


/**
 * 更新当前流程实例的节点干预人员节点
 *  @param
 *  actInstId, // 流程实例Id
 *  nodeId,   //节点Id
 *  userIds   //用户Ids，格式如12,33
 */
BpmInstApi.updateRunningNodeUser=function(params){
  let url= BpmInstApi.baseUrl + '/updateRunningNodeUser';
  return rxAjax.postForm(url,params);
}

/**
 * 获取归档记录
 */
BpmInstApi.getBpmArchiveLogs =function() {
  var url= '/api-bpm/bpm/core/bpmArchiveLog/getBpmArchiveLogs';
  return rxAjax.get(url);
}

//删除备份的流程实例
BpmInstApi.delArchive =function(parameter) {
  let url= BpmInstApi.baseUrl + '/delArchive';
  return rxAjax.postForm(url,parameter);
}

/*
* 根据流程实例ID获取主键。
* */
BpmInstApi.getPkByInstId =function(instId) {
  var url= BpmInstApi.baseUrl + '/getPkByInstId?instId=' +instId;
  return rxAjax.get(url);
}

BpmInstApi.getSubProcessFormData=function(parameter){
  let url= BpmInstApi.baseUrl + '/getSubProcessFormData';
  return rxAjax.postJson(url,parameter);
}

BpmInstApi.liveProcess=function (parameter) {
  let url = BpmInstApi.baseUrl + '/liveProcess';
  return rxAjax.postJson(url,parameter);
}

BpmInstApi.getAllNodes=function(instId){
  let url = BpmInstApi.baseUrl + '/getAllNodes?instId='+instId;
  return rxAjax.get(url);
}

/**
 * 获取流程实例状态。
 * @param type
 * @param id
 * @param action
 * @returns {*}
 */
BpmInstApi.getInfoByDefKeyInstId=function(type,id,action){
    let url = BpmInstApi.baseUrl + '/getInfoByDefKeyInstId';

    let params={type:type,id:id};
    if(action){
        params.action=action;
    }
    return rxAjax.postForm(url,params);
}


/**
 * 撤销流程。
 * @param instId    流程实例ID
 * @param reason    意见
 * @param from
 * @returns {*}
 */
BpmInstApi.revokeProcess=function (instId,opinion,from) {
    let url= BpmInstApi.baseUrl+ '/revokeProcess';
    return rxAjax.postForm(url,{instId:instId,opinion:opinion,from:from});
}


export default BpmInstApi;
