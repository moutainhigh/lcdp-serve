import * as echarts from 'echarts';
import ChartDataModelApi from "@/api/form/core/chartDataModel";
import {Util} from "jpaas-common-lib";
import FilterParams from "../chartComponent/FilterParams";
import PublicApi from "@/api/form/core/public";
import BusEvent from "@/views/modules/form/core/formComponent/BusEvent";

/**
 * 图表公共JS
 * @type {{methods: {}, props: {config: {type: Object}}}}
 */

const ChartPublic = {
    props: {
        config: {
            type: Object
        },
        layoutItem:{
            type:Object
        }
    },
    mixins:[BusEvent],
    components:{
        FilterParams
    },
    data() {
        return {
            chartPie: null,
            //根据模型查询到的数据
            data: [],
            option:{},
            sql:"",
            //发布事件参数
            params:{},
            //图表过滤参数
            filterParams:[],
            //存放维度数据
            dimensionVals:[],
            //度量的数据
            measureVals:[],
            //存放颜色度量数据
            colorLegendVals:[],
            defColors:['#5470c6', '#91cc75', '#fac858', '#ee6666', '#73c0de', '#3ba272', '#fc8452', '#9a60b4', '#ea7ccc']
        }
    },
    created() {
        var mapping = this.config.receive.mapping;
        if(mapping && mapping.length>0 ){
            var params={};
            if (this.$route.meta.query) {
                params = JSON.parse(this.$route.meta.query);
            }else {
                params=this.$route.query;
            }
            for (var i = 0; i < mapping.length; i++) {
                var value="";
                if(this.config.receive.type=='url'){
                    if(mapping[i].valueSource=='param'){
                        if(params[mapping[i].valueDef]){
                            value=params[mapping[i].valueDef]
                        }else {
                            var arr = mapping[i].name.split(".");
                            var name=arr[arr.length-1];
                            if(params[name]){
                                value=params[name];
                            }
                        }
                    }

                }
                this.params[mapping[i].name]=value;
            }
        }
    },
    beforeDestroy() {
        this.$bus.off("formEvent");
        this.$bus.off("chartEvent");
    },
    mounted() {
        var self=this;
        this.getParams(function (res) {
            if(res){
                Object.assign(self.params,res);
            }
            self.initChart();
        })
    },
    methods: {
        /**
         * 初始化图表
         */
        initChart() {
            if(this.chartPie != null && this.chartPie != "" && this.chartPie != undefined) {
                this.chartPie.dispose();
            }
            var pieEl=this.$refs[this.config.alias];
            //初始化图表
            this.chartPie = echarts.init(pieEl, 'macarons');
            var measures=[];
            if(this.config.reportType=='lineBar'){
                for (var i = 0; i < this.config.measureList.length; i++) {
                    measures.push(...this.config.measureList[i]);
                }
            }else {
                measures=this.config.measures
            }
            var obj={
                dataModel:this.config.dataModel,
                colorLegends:this.config.colorLegends,
                measures:measures,
                dimensions:this.config.dimensions,
                params:this.params,
                filterParams:this.filterParams
            }
            var self=this;
            //获取数据
            ChartDataModelApi.getData(JSON.stringify(obj)).then(res => {
                if (res.data && res.data.length > 0) {
                    this.data = res.data;
                    this.sql = res.sql;
                    //获取初始化数据
                    this.getInitData();
                    this.setOption();
                    //是否开启联动
                    if(this.config.advConfig.linkage){
                        //图表点击节点回调事件
                        this.chartPie.on('click',function(params){
                            var pubilshParams={
                                component:self.config.alias,
                            };
                            if(self.config.publish && self.config.publish.paramMapping.length>0){
                                //未配置颜色图例直接去查data的数据
                                if(self.config.colorLegends.length==0){
                                    pubilshParams.params= self.getParamsByData(params.dataIndex);
                                }else {
                                    pubilshParams.params= self.getParamsByConfig(params);
                                }
                            }
                            self.$bus.$emit('chartEvent',pubilshParams);
                        });
                    }
                    this.chartPie.resize();
                }
            });
        },
        //获取初始化数据
        getInitData(){
            //维度
            this.dimensionVals=[];
            for (var i = 0; i < this.config.dimensions.length; i++) {
                var dimension = this.config.dimensions[i];
                for (var j = 0; j < this.data.length; j++) {
                    var dimensionVal =this.data[j][dimension.tableName+'_'+dimension.fieldName] || "";
                    if(typeof(dimensionVal)!='string'){
                        dimensionVal=dimensionVal.newValue || "";
                    }
                    var number = this.dimensionVals.indexOf(dimensionVal);
                    if(number==-1) {
                        this.dimensionVals.push(dimensionVal);
                    }
                }
            }
            //度量
            this.measureVals=[];
            for (var i = 0; i < this.config.measures.length; i++) {
                var measure = this.config.measures[i];
                for (var j = 0; j < this.data.length; j++) {
                    var measureVal =this.data[j][measure.tableName+'_'+measure.fieldName];
                    var number = this.measureVals.indexOf(measureVal);
                    if(number==-1) {
                        this.measureVals.push({
                            key:measure.tableName+'.'+measure.fieldName,
                            value:measureVal
                        });
                    }
                }
            }
            //颜色图例
            this.colorLegendVals=[];
            for (var i = 0; i < this.config.colorLegends.length; i++) {
                var colorLegend = this.config.colorLegends[i];
                for (var j = 0; j < this.data.length; j++) {
                    var colorValue =this.data[j][colorLegend.tableName+'_'+colorLegend.fieldName];
                    var number = this.colorLegendVals.indexOf(colorValue);
                    if(number==-1) {
                        this.colorLegendVals.push(colorValue);
                    }
                }
            }
        },
        //获取维度
        getDimensions(xAxisArr){
            var xAxisData=[];
            for (var i = 0; i < this.data.length; i++) {
                var xAxisValue="";
                var oldValue="";
                var key="";
                //维度
                for (var j = 0; j < this.config.dimensions.length; j++) {
                    var dimension = this.config.dimensions[j];
                    if(xAxisValue==""){
                        xAxisValue=this.data[i][dimension.tableName+'_'+dimension.fieldName] || "";
                        if(typeof(xAxisValue)!='string'){
                            oldValue=xAxisValue.oldValue || "";
                            xAxisValue=xAxisValue.newValue || "";
                        }
                        key=dimension.tableName+'_'+dimension.fieldName;
                    }else {
                        var val=this.data[i][dimension.tableName+'_'+dimension.fieldName] || "";
                        if(typeof(val)!='string'){
                            oldValue=xAxisValue+"-"+val.oldValue || "";
                            xAxisValue+=xAxisValue+"-"+val.newValue || "";
                        }else {
                            oldValue+="-"+val;
                            xAxisValue+="-"+val;
                        }
                        key+="-"+dimension.tableName+'_'+dimension.fieldName
                    }
                }
                var number = xAxisData.indexOf(xAxisValue);
                if(number==-1){
                    xAxisData.push(xAxisValue);
                }
                if(xAxisArr){
                    if(oldValue){
                        var item = xAxisArr.find((info) => info.value == oldValue )
                        if(!item){
                            xAxisArr.push({
                                key:key,
                                value:oldValue
                            });
                        }
                    }else {
                        var item = xAxisArr.find((info) => info.value == xAxisValue )
                        if(!item){
                            xAxisArr.push({
                                key:key,
                                value:xAxisValue
                            });
                        }
                    }

                }
            }
            var xAxis={
                data: xAxisData,
                axisLine: {
                    show: true,
                    lineStyle: {
                        color:this.config.advConfig.xAxisColor?this.config.advConfig.xAxisColor:"#333"
                    }
                },
            }
            return xAxis;
        },
        //根据data取参数
        getParamsByData(index){
            var params= {};
            var paramMapping=this.config.publish.paramMapping;
            for (var i = 0; i <paramMapping.length ; i++) {
                var key = (paramMapping[i].key).replace(".","_");
                var value = this.data[index][key];
                //配置了字段渲染
                if(typeof(value) !="string"){
                    params[paramMapping[i].key]=value.oldValue;
                }else {
                    params[paramMapping[i].key]=value;
                }
            }
            return params;
        },
        //根据配置取参数 clickObj:点击的对象
        getParamsByConfig(clickObj){
            var params= {};
            var paramMapping=this.config.publish.paramMapping;
            for (var i = 0; i <paramMapping.length ; i++) {
                var value="";
                //维度
                for (var j = 0; j < this.config.dimensions.length; j++) {
                    var dimension = this.config.dimensions[j];
                    var key=dimension.tableName+"."+dimension.fieldName;
                    if(paramMapping[i].key==key){
                        var dimensionVal = this.dimensionVals[clickObj.dataIndex];
                        //配置了字段渲染
                        if(typeof(dimensionVal) !="string" ){
                            value=dimensionVal.oldValue;
                        }else {
                            value=dimensionVal;
                        }
                        break;
                    }
                }
                if(value!=""){
                    params[paramMapping[i].key]=value;
                    continue;
                }
                //度量
                for (var j = 0; j < this.config.measures.length; j++) {
                    var measure = this.config.measures[j];
                    var key=measure.tableName+"."+measure.fieldName;
                    if(paramMapping[i].key==key){
                        var index=(clickObj.dataIndex+1) * (clickObj.componentIndex+1);
                        if(this.measureVals[index-1].key==paramMapping[i].key){
                            value= this.measureVals[index].value;
                        }
                    }
                }
                if(value!=""){
                    params[paramMapping[i].key]=value;
                    continue;
                }
                //颜色图例
                for (var j = 0; j < this.config.colorLegends.length; j++) {
                    var colorLegend = this.config.colorLegends[j];
                    var key=colorLegend.tableName+"."+colorLegend.fieldName;
                    if(paramMapping[i].key==key){
                        var index=(clickObj.componentIndex)%this.colorLegendVals.length;
                        value=this.colorLegendVals[index];
                    }
                }
                if(value!=""){
                    params[paramMapping[i].key]=value;
                    continue;
                }

            }
            return params;
        },
        onSelectChange(selectedRowKeys) {
            this.selectedRowKeys = selectedRowKeys
        },
        /**
         *
         */
        addParams() {
            if (this.config.receive.mapping.length >= this.listParamsDef.length) {
                this.$notification.warning({
                    message: '提示信息',
                    description: '该数据列表未配置传入参数，请去配置!',
                })
                return
            }
            this.config.receive.mapping.push({ idx_: Util.randomId(), name: '', valueSource: '', valueDef: '' })
        },
        moveUp() {
            this.toUp(this.config.receive.mapping, this.selectedRowKeys)
        },
        moveDown() {
            this.toDown(this.config.receive.mapping, this.selectedRowKeys)
        },
        removeSelect() {
            this.removeRows(this.config.receive.mapping, this.selectedRowKeys)
        },
        //处理接收到的事件
        handReceive(args) {
            var receive = this.config.receive;
            if ( receive.type=='event' &&receive.publishComponent == args.component) {
                var inputParams = args.params;
                var params = {};
                //读取配置的参数
                for (var i = 0; i < receive.mapping.length; i++) {
                    var o = receive.mapping[i];
                    if (o.valueSource == 'param' && inputParams[o.valueDef]) {
                        params[o.name] = inputParams[o.valueDef];
                    }
                }
                this.params=params;
                //初始化图表
                this.initChart();
            }
        },
        //图表过滤条件查询
        paramsChange(params){
            this.filterParams=[];
            for (var i = 0; i <params.length ; i++) {
                var value = params[i].value;
                if(value){
                    this.filterParams.push({
                        key:params[i].tableName+"."+params[i].fieldName,
                        value:value,
                        controlType:params[i].condition.controlType,
                        opType:params[i].condition.opType
                    })
                }
            }
            //初始化图表
            this.initChart();
        },
        //获取颜色维度值
        getColorValue(data,colorLegend,measure){
            var colorValue="";
            //是否拼接度量的值 多个度量必须拼接
            if(this.config.advConfig.joinMeasure || this.config.measures.length>1){
                colorValue=data[colorLegend.tableName+'_'+colorLegend.fieldName]+"-"+measure.fieldLabel;
            }else {
                colorValue =data[colorLegend.tableName+'_'+colorLegend.fieldName];
            }
            return colorValue;
        },
        getColors(){
            //颜色配置
            var colors=this.defColors;
            if(this.config.colour.content && this.config.colour.content.length>0 ){
                colors=this.config.colour.content;
            }
            return colors;
        },
        getParams(callback){
            PublicApi.getParams(JSON.stringify(this.config.receive.mapping)).then(res=>{
                callback(res);
            }).catch(err=>{
                callback({});
            })
        }
    },
    watch:{
        option:{
            handler: function (val, oldVal) {
                var self=this;
                self.chartPie.setOption(val);
            },
            deep: true
        },
        config:{
            handler: function (val, oldVal) {
                var self=this;
                setTimeout(function () {
                    self.$emit("setChartComponet",val);
                    self.initChart();
                },2000)
            },
            deep: true
        },
        layoutItem:{
            handler: function (val, oldVal) {
                var pieEl=this.$refs[this.config.alias];
                this.chartPie = echarts.init(pieEl);
                this.chartPie.resize();
            },
            deep: true
        }
    }

}

export default ChartPublic;