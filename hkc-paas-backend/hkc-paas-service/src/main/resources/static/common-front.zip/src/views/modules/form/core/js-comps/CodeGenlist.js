import Vue from 'vue';
import {Util, VueBus,Dialog} from 'jpaas-common-lib';
import SysDicEdit from "@/views/modules/system/core/SysDicEdit";
import FormSolutionApi from "@/api/form/core/formSolution";
Vue.use(VueBus);

export default {
    data() {
        return {
            params:{},
            searches:[],
        }
    },
    created() {
    },
    mounted() {

    },
    computed: {
        rxParamsTreeeditor() {
            return this.$refs.rxParamsTreeeditor;
        },
    },
    methods: {
        //查询条件变化后 联动修改
        searchChange(fieldName,selectParam){
            for (let i = 0; i < this.searches.length; i++) {
                if(this.searches[i].fieldName!=fieldName){
                    if(this.searches[i].params&&this.searches[i].params.length>0){
                        var params=this.searches[i].params;
                        for (var j = 0; j <params.length ; j++) {
                            if(params[j].bindVal==selectParam){
                                var param="Q_";
                                if(this.searches[i].tablePre&&this.searches[i].tablePre!=""){
                                    param=param+this.searches[i].tablePre+"_";
                                }
                                param=param+this.searches[i].fieldName+"_S_"+this.searches[i].fieldOp;
                                this.$refs[param].setSelectVal("");
                                this.searchChange(this.searches[i].fieldName,param);
                            }
                        }
                    }
                }
            }
        },
        selectFocus(ctl,params){
            var paramData={};
            if(params) {
                for (var i = 0; i < params.length; i++) {
                    paramData[params[i].fieldName] = this.queryParam[params[i].bindVal];
                }
            }
            this.$refs[ctl].loadData(paramData);
        },
        searchRangeDateChange(date,format,e){
            if(!format){
                format='YYYY-MM-DD';
            }
            if(date.length==2){
                if (e.autoFilter == 'YES') {
                    this.queryParam["Q_" + e.queryField + "_D_GE"] = date[0].format(format);
                    this.queryParam["Q_" + e.queryField + "_D_LE"] = date[1].format(format);
                    let ref=this.$refs["queryField_" + e.queryField];
                    ref.value=date;
                }else{
                    this.queryParam[e.queryField + "_START"] = this.parseTimeByDateFormat(date[0].format(format));
                    this.queryParam[e.queryField + "_END"] = this.parseTimeByDateFormat(date[1].format(format));

                }
            }else {
                if (e.autoFilter == 'YES') {
                    delete this.queryParam["Q_" + e.queryField + "_D_GE"];
                    delete this.queryParam["Q_" + e.queryField + "_D_LE"];
                }else{
                    delete this.queryParam[e.queryField+"_START"];
                    delete this.queryParam[e.queryField+"_END"];
                }
            }
        },
        searchMonthChange(date, dateString, e) {
            this.queryParam["Q_" + e.queryField + "_D_GE"] = date.format('YYYY-MM') + "-01";
            this.queryParam["Q_" + e.queryField + "_D_LE"] = date.format('YYYY-MM') + "-" + date.daysInMonth();
        },
        searchDateChange(date, dateString, e) {
            this.queryParam[e.queryField] = date.format(e.format);
        },
        _OnDialogShow(vm){
            var config=vm.config;
            var dialog=config.dialog;
            var valueField=config.valueField;
            var textField=config.textField;
            var single=config.single;
            if(!dialog){
                vm.$message.error("请配置对话框");
                return;
            }
            var self=this;
            Dialog.dialog({key:dialog},{
                curVm: vm
            },function(data){
                var rows=data.rows || data;
                if(rows!=null && rows.length>0){
                    var values=[];
                    var texts=[];
                    if(single) {
                        values.push(rows[0][valueField]);
                        texts.push(rows[0][textField]);
                    }else{
                        for (var i = 0; i < rows.length; i++) {
                            values.push(rows[i][valueField]);
                            texts.push(rows[i][textField]);
                        }
                    }
                    if(config.queryField) {
                        var nameKey = config.queryField.replace(config.fieldName, config.fieldName + "_display");
                        self.queryParam[config.queryField] = values.join(',');
                        self.queryParam[nameKey] = texts.join(',');
                    }
                    vm.setVal(values.join(','),texts.join(','));
                }
            })
        },
        add() {
            if(this.treeJson && this.treeJson.listSearchType=='tree' && !this.curTree.treeId){
                this.$message.error("请选择左边树！");
                return;
            }
            var conf = {
                component: this.component,
                title: "添加-" + this.comment,
                urlType: 'Add',
                widthHeight: this.widthHeight
            };
            this.handleEdit(conf);
        },
        editOne() {
            var conf = {
                component: this.component,
                title: "编辑-" + this.comment,
                urlType: 'Edit',
                widthHeight: this.widthHeight
            };
            if (this.selectedRows.length > 0) {
                if (this.selectedRows.length > 1) {
                    alert("选中多条记录时不能编辑!");
                    return;
                }
                conf.pkId = this.selectedRows[0].pkId;
                this.handleEdit(conf)
            }
        },
        edit(record) {
            var conf = {
                pkId: record.pkId,
                component: this.component,
                title: "编辑-" + this.comment,
                urlType: 'Edit',
                widthHeight: this.widthHeight
            };
            this.handleEdit(conf);
        },
        addDicNode(curRow){
            let parentId=curRow.parentId;
            if(parentId=="-1"){
                parentId="0";
            }else {
                parentId=curRow.dicId;
            }
            var data = {treeId: this.treeCat.treeId, parentId: parentId};
            this.handDicClick(data, "添加字典", "addchild");
        },
        handDicClick(data, title, operator) {
            var conf = {
                curVm: this,
                data: {data: data, displayDataShowType: true},
                widthHeight: ['800px', '450px'],
                component: SysDicEdit,
                title: title
            };
            //编辑
            if (data.dicId) {
                conf.data.pkId = data.dicId;
            }
            var self_ = this;
            Util.open(conf, function (action) {
                if (action != "ok") {
                    return;
                }
                self_.rxParamsTreeeditor.handClick(this.resultData,operator);
            });
        },
        addDicSibling(curRow){
            var rs = Object.assign({treeId: this.treeCat.treeId,parentName: '', parentId: curRow.parentId});
            this.handDicClick(rs, "添加同级", "addSibling")
        },
        editDicNode(curRow){
            curRow.treeId=this.treeCat.treeId;
            this.handDicClick(curRow, "编辑分类", "edit");
        },
        deleteDicNode(curRow){
            var treeId = curRow.treeId;
            let self_ = this;
            this.$confirm({
                title: '操作提示',
                content: '您确定需要删除选中的记录吗？',
                okText: '确认',
                cancelText: '取消',
                onOk() {
                    self_.rxParamsTreeeditor.handClick(curRow,"delete");
                },
                onCancel() {
                }
            })
        },
        addFormNode(curRow){
            //新增表单，基于使用表单方案
            let parentId = "";
            if(curRow.parentId !="-1"){
                parentId=curRow[this.treeRelation.treeId];
            }
            this.showForm(curRow,"add","addchild",parentId);
        },
        addFormSibling(curRow){
            //新增同级表单，基于使用表单方案
            this.showForm(curRow,"add","addSibling",curRow.parentId);
        },
        editFormNode(curRow){
            //编辑表单，基于使用表单方案
            this.showForm(curRow,"edit","edit","");
        },
        deleteFormNode(curRow){
            let self_=this;
            //删除表单，基于使用表单方案
            this.$confirm({
                title: '操作提示',
                content: '您确定需要删除选中的记录吗？',
                okText: '确认',
                cancelText: '取消',
                onOk() {
                    FormSolutionApi.removeById({alias: self_.treeCat.treeId, id: curRow[self_.treeRelation.treeId]}).then(res => {
                        self_.rxParamsTreeeditor.handClick(curRow,"delete");
                    });
                },
                onCancel() {
                }
            });
        },
        showForm(curRow,action, operator,parentId){
            let self_=this;
            var params={
                action:action,
                alias:this.treeCat.treeId,
                pk:"",
                isMax:'YES',
                isShade:'YES',
                name:this.treeCat.name,
                table:"",
                destroy:function (action,data) {
                    if("ok"!=action){
                        return;
                    }
                    let formJson =data.formJson;
                    if(!formJson[self_.treeRelation.treeId]){
                        formJson[self_.treeRelation.treeId]=data.result.pk;
                    }
                    self_.rxParamsTreeeditor.handClick(formJson,operator);
                }
            }
            if("edit"==action){
                params.pk =curRow[this.treeRelation.treeId];
            }
            if(parentId){
                params.formdata ={};
                params.formdata[this.treeRelation.parentId]=parentId;
            }
            this.$bus.emit("listButtonEvent",params);
        }
    },
    watch: {
    }
}

