<template>
    <div v-html="msg"></div>
</template>

<script>
    export default {
      name: "LodopError",
      props: {
        layerid: {
          type: String,
          default: ""
        },
        destroy: {
          type: Function
        },
        msg: {
          type: String,
          default: ""
        }
      }
    }
</script>

<style scoped>

</style>