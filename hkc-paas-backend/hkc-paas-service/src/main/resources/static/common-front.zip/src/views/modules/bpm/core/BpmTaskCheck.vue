<template>
    <rx-dialog @handOk="handleCompleteCheck" @cancel="closeWindow" :oktext="'交办'" order="buttom" btnalign="center">
        <template #toolbar>
            <a-button @click="temporaryOpinion">暂存意见</a-button>
        </template>
        <rx-fit>
            <div style="height:100%;width:100%;padding:5px;">
                <a-form-model :rules="rules"  :model="form"  ref="form">
                    <a-form-model-item label="您的意见" :label-col="labelCol" :wrapper-col="wrapperCol" v-show="showOpinion()">
                        <a-radio-group v-model="checkType" @change="checkTypeChange" button-style="solid">
                            <a-radio-button value="AGREE">{{checkTypes["AGREE"]}}</a-radio-button>
                            <a-radio-button value="REFUSE">{{checkTypes["REFUSE"]}}</a-radio-button>
                        </a-radio-group>
                    </a-form-model-item>
                    <a-form-model-item label="常用意见" :label-col="labelCol" :wrapper-col="wrapperCol" >
                        <a-select
                            :value="value"
                            style="width: 70%"
                            :default-active-first-option="false"
                            :filter-option="false"
                            option-label-prop="label"
                            @change="handleChange"
                            @blur="handleBlur"
                            :getPopupContainer="p=>p.parentNode">
                            <a-select-option v-for="item in commonOpinions" :value="item.opText" :label="item.opText">
                                <a-icon type="close" @click.stop="closeOpinion(item)"></a-icon>
                                {{ item.opText }}
                            </a-select-option>
                        </a-select>
                        <a-button style="margin-left: 3px;" @click="saveOpinion" icon="save">保存</a-button>

                    </a-form-model-item>
                    <a-form-model-item label="填写意见" :label-col="labelCol" :wrapper-col="wrapperCol" prop="opinion">
                        <a-textarea placeholder="请填写意见，可保存为常用意见(限500字)" v-model="form.opinion" @change="opinionChange" style="height:150px" ></a-textarea>
                    </a-form-model-item>
                    <div style="text-align:right;">
                        <a @click="toggleAdvanced" style="margin-left: 8px">
                            {{ advanced ? '收起更多选项' : '展开更多选项' }}
                            <a-icon :type="advanced ? 'up' : 'down'"/>
                        </a>
                    </div>
                    <div style="padding:5px;" v-show="advanced">
                        <a-form-model-item label="下一步" :label-col="labelCol" :wrapper-col="wrapperCol">
                            <bpm-task-executors ref="taskExecutors" :nodeExecutors="nodeExecutors"
                                                :allow-select-executor="allowSelectExecutor"
                                                :allow-select-group="allowSelectGroup"
                                                :task-config="taskConfig"></bpm-task-executors>
                        </a-form-model-item>
                        <a-form-model-item label="附件" :label-col="labelCol" :wrapper-col="wrapperCol">
                            <rx-attach-component v-model="fileList"></rx-attach-component>
                        </a-form-model-item>
                        <a-form-model-item label="抄送" :label-col="labelCol" :wrapper-col="wrapperCol">
                            <rx-user-component v-model="copyUsers" :isAccount="true"
                                               :single="false"></rx-user-component>
                        </a-form-model-item>
                        <a-form-model-item label="关联流程" :label-col="labelCol" :wrapper-col="wrapperCol">
                            <rx-text-list v-model="relInsts"
                                          :showclose="true"
                                          :readonly="false"
                                          valuefield="id" textfield="name"
                                          @click="selectBpmInst()">
                                <a-icon type="ellipsis"/>
                            </rx-text-list>
                        </a-form-model-item>
                        <a-form-model-item label="通知方式" :label-col="labelCol" :wrapper-col="wrapperCol">
                            <a-checkbox-group :options="msgOptions" v-model="msgTypes"></a-checkbox-group>
                        </a-form-model-item>
                    </div>
                </a-form-model>
            </div>
        </rx-fit>
    </rx-dialog>
</template>
<script>
import {Dialog, RxDialog, Util, RxFit, RxUserComponent, RxAttachComponent, RxTextList} from 'jpaas-common-lib'
import BpmtaskApi from '@/api/bpm/core/bpmTask'
import BpmPublicApi from '@/api/bpm/core/BpmPublicApi'
import BpmOpinionLibApi from "@/api/bpm/core/bpmOpinionLib";
import BpmTaskExecutors from "./BpmTaskExecutors";
import BpmMyEvents from "./BpmMyEvents";


export default {
    name: 'bpm-task-check',
    components: {
        RxUserComponent,
        BpmTaskExecutors,
        RxAttachComponent,
        RxFit,
        RxDialog,
        BpmMyEvents,
        RxTextList
    },
    props: {
        layerid: String,
        lydata: Object,
        destroy: Function,
        taskId: {
            type: String,
            required: true
        },
        formJson: String,
        systemHand: Boolean,
        nodeExecutors: Array,

        allowSelectExecutor: {
            type: Boolean,
            default: false
        },
        allowSelectGroup: {
            type: Boolean,
            default: false
        },
        opinionObj: {
            type: Object,
            default: {
                name: "",
                value: ""
            }
        },
        taskConfig: {
            type: Object
        }
    },
    data() {
        return {
            labelCol: {span: 3},
            wrapperCol: {span: 9},
            msgOptions: [],
            checkType: 'AGREE',
            msgTypes: [],
            copyUsers: [],
            opinionName: "",
            value: undefined,
            commonOpinions: [],
            fileList: [],
            temporaryOpinionObj: {},
            relInsts: [],
            advanced: false,
            checkTypes: {
                "AGREE": '同意',
                "REFUSE": '不同意'
            },
            rules: {
                opinion: [
                    { required: true, message: '意见必填', trigger: 'blur' },
                    { type:"string", max: 500, message: '长度不能大于500字符', trigger: 'blur' },
                ]
            },
            form:{
                opinion:""
            }
        }
    },
    created() {
        this.opinion = this.lydata.opinionObj.value;
        this.opinionName = this.lydata.opinionObj.name;
        this.initMessageHandler();
        this.getTemporaryOpinion();

        this.getCommonUserOpinions();
        this.getCheckTypes();
        //初始化用户数据。
        this.initUser();

        this.rules.opinion[0].required=this.checkType!="AGREE";
    },
    methods: {
        initUser(){
            BpmtaskApi.getTaskFlowNodesExecutors(this.taskId, 'AGREE', JSON.parse(this.formJson)).then(res => {
                this.nodeExecutors = res;
            })
        },
        checkTypeChange(e) {
            //修改意见必填
            this.rules.opinion[0].required=this.checkType!="AGREE";

            BpmtaskApi.getTaskFlowNodesExecutors(this.taskId, e.target.value, JSON.parse(this.formJson)).then(res => {
                this.nodeExecutors = res;
            })
        },
        //显示高级选择项
        toggleAdvanced() {
            this.advanced = !this.advanced;
        },
        initMessageHandler() {
            BpmPublicApi.getMessageHandler().then(res => {
                for (var i = 0; i < res.length; i++) {
                    var o = res[i];
                    var obj = {label: o.name, value: o.type};
                    this.msgOptions.push(obj);
                }
            })
        },
        handleCompleteCheck(e) {
            let self = this;
            var ctl = this.$refs.taskExecutors;
            //抄送用户
            let copyAccounts = this.getCopyUserAccounts();
            let noticeTypes = this.msgTypes.join(",");
            let nodeUserMap = ctl.getNodeUserMap();
            let destNodeId = ctl.getDestNodeId();
            let cmd = {
                taskId: this.taskId,
                checkType: this.checkType,
                opinion: this.form.opinion,
                msgTypes: noticeTypes,
                copyUserAccounts: copyAccounts,
                nodeExecutors: nodeUserMap,
                formJson: self.formJson,
                systemHand: self.systemHand,
                opinionName: self.opinionName,
                opFiles: JSON.stringify(self.fileList),
                relInsts: JSON.stringify(self.relInsts)
            }
            //设置目标节点。
            if (destNodeId) {
                cmd.destNodeId = destNodeId;
            }

            this.$refs.form.validate(valid => {
                if (valid) {
                    BpmtaskApi.checkComplete(cmd).then(resp => {
                        e.loading = false;
                        if (self.$parent.processConfig.formType == 'online') {
                            self.$parent.$refs.rxForms.afterSubmit(resp, JSON.parse(self.formJson));
                        }
                        if (resp.success) {
                            Util.closeWindow(self, 'ok');
                        }
                    })
                } else {
                    e.loading=false;
                    return false;
                }
            });
        },

        /**
         * 获取抄送用户。
         * @returns {string}
         */
        getCopyUserAccounts() {
            var accounts = [];
            if (this.copyUsers && this.copyUsers.length > 0) {
                this.copyUsers.forEach(item => {
                    accounts.push(item.account);
                })
            }
            return accounts.join(",");
        },
        closeWindow() {
            Util.closeWindow(this, 'cancel')
        },
        saveOpinion() {
            var self = this;
            if(!this.form.opinion){
                this.$message.warning('请填写需要保存的常用意见!');
                return;
            }
            BpmOpinionLibApi.save({opText: this.form.opinion}).then(res => {
                if (res.success) {
                    this.getCommonUserOpinions();
                }
            });
        },
        closeOpinion(opinion) {
            let self_ = this;
            this.$confirm({
                title: '操作提示',
                zIndex: 9999,
                content: '确定要删除此条意见吗？',
                okText: '确认',
                cancelText: '取消',
                onOk() {
                    BpmOpinionLibApi.del({ids: opinion.opId}).then(res => {
                        self_.getCommonUserOpinions();
                    })
                },
                onCancel() {
                }
            })
        },
        getCommonUserOpinions() {
            BpmOpinionLibApi.getUserText().then(res => {
                this.commonOpinions=res;
            })
        },
        handleChange(value) {
            this.form.opinion+=value;
        },
        handleBlur() {
            if (this.value) {
                this.opinion = this.value;
                this.value = undefined;
            }
        },
        //暂存意见
        temporaryOpinion() {
            var id = this.temporaryOpinionObj.id ? this.temporaryOpinionObj.id : "";
            if (this.taskId) {
                BpmtaskApi.temporaryOpinion(this.taskId, this.form.opinion, id).then(res=>{
                    Util.closeWindow(this, 'ok');
                });
            }

        },
        //获取暂存意见
        getTemporaryOpinion() {
            if (this.taskId) {
                BpmtaskApi.getTemporaryOpinion(this.taskId).then(res => {
                    if (res) {
                        this.form.opinion = res.opinion;
                        this.temporaryOpinionObj = res;
                    }
                });
            }
        },
        selectBpmInst() {
            var conf = {
                component: BpmMyEvents,
                title: '关联流程',
                curVm: this, widthHeight: ['1024px', '600px']
            };
            var self_ = this;
            Util.open(conf, function (action, relInsts) {
                if (action != 'ok') return;

                var idAry = [];
                for (var i = 0; i < self_.relInsts.length; i++) {
                    var o = self_.relInsts[i];
                    idAry.push(o.id);
                }

                for (var i = 0; i < relInsts.length; i++) {
                    var o = relInsts[i];
                    if (idAry.includes(o.id)) {
                        continue;
                    }
                    self_.relInsts.push(o);
                }
            });
        },
        getCheckTypes() {
            BpmtaskApi.getCheckTypes().then(res => {
                if (res.success) {
                    this.checkTypes = res.data;
                }
            });

        },
        opinionChange(e){
            if(this.opinion && this.opinion.length>500){
                this.opinion=this.opinion.substring(0,500)
                this.$message.warning('意见限500字!');
            }
        },
        showOpinion(){
            var rtn=this.taskConfig.switchOptions.includes("showOpinion");
            return rtn;
        }


    }
}
</script>