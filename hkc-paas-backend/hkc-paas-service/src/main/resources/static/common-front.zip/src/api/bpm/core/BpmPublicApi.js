import rxAjax from '@/assets/js/ajax.js';
const BpmPublicApi = {};

BpmPublicApi.baseUrl= '/api-bpm/bpm/core/public';


BpmPublicApi.getMessageHandler=function () {
  var url= 'api-system/system/core/message/getMessageHandler';
  return rxAjax.get(url);
}

BpmPublicApi.getEventHandler=function () {
  var url= BpmPublicApi.baseUrl + '/getEventHandler';
  return rxAjax.get(url);
}

BpmPublicApi.getSkipContions=function () {
  var url= BpmPublicApi.baseUrl + '/getSkipContions';
  return rxAjax.get(url);
}

BpmPublicApi.getServiceTasks=function () {
  var url= BpmPublicApi.baseUrl + '/getServiceTasks';
  return rxAjax.get(url);
}

BpmPublicApi.getVariables=function(){
  var url= BpmPublicApi.baseUrl + '/getVariables';
  return rxAjax.get(url);
}

BpmPublicApi.getConstVars=function(){
  var url= BpmPublicApi.baseUrl + '/getConstVars';
  return rxAjax.get(url);
}


export default  BpmPublicApi;