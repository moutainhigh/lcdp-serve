import rxAjax from '@/assets/js/ajax.js';

const FormPcApi = {};

FormPcApi.baseUrl= '/api-form/form/core/formPc';
FormPcApi.exportUrl= FormPcApi.baseUrl + '/export';

FormPcApi.query=function (parameter) {
  var url= FormPcApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
 * 获取单记录
 * @param pkId
 * @returns {*}
 */
FormPcApi.get =function(pkId) {
  var url= FormPcApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

FormPcApi.save =function(parameter) {
  var url= FormPcApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

FormPcApi.del =function(parameter) {
  var url= FormPcApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}


FormPcApi.getVersions =function(alias) {
  var url= FormPcApi.baseUrl + '/getVersions?alias='+alias;
  return rxAjax.get(url);
}

FormPcApi.switchMain =function(id) {
  var url= FormPcApi.baseUrl + '/switchMain?id='+id;
  return rxAjax.get(url);
}

FormPcApi.createVersion =function(id) {
  var url= FormPcApi.baseUrl + '/createVersion?id='+id;
  return rxAjax.get(url);
}

FormPcApi.deploy =function(formId,genSolution) {
  var url= FormPcApi.baseUrl + '/deploy';
  var params={formId:formId,genSolution:genSolution};
  return rxAjax.postForm(url,params);
}

FormPcApi.copyNew =function(newForm) {
  var url= FormPcApi.baseUrl + '/copyNew';
  var params={newForm:JSON.stringify(newForm)};
  return rxAjax.postForm(url,params);
}

FormPcApi.getTemplatesByBoDef=function(parameter){
  var url= FormPcApi.baseUrl+'/getTemplatesByBoDef';
  return rxAjax.postForm(url,parameter);
}

FormPcApi.generateHtml=function(parameter){
  var url= FormPcApi.baseUrl+'/generateHtml';
  return rxAjax.postForm(url,parameter);
}

FormPcApi.generatePrintHtml=function(parameter){
  var url= FormPcApi.baseUrl+'/generatePrintHtml';
  return rxAjax.postForm(url,parameter);
}

FormPcApi.genPdfTemplate=function(parameter){
  var url= FormPcApi.baseUrl+'/genPdfTemplate';
  return rxAjax.postForm(url,parameter);
}

/**
 * 直接保存表单数据。
 * @param parameter
 */
FormPcApi.saveFormDataDirect=function(parameter){
  var url= FormPcApi.baseUrl+'/saveFormDataDirect';
  return rxAjax.postJson(url,parameter);
}

FormPcApi.getHistoryTemplate=function(){
  var url= FormPcApi.baseUrl+'/getHistoryTemplate';
  return rxAjax.get(url);
}

FormPcApi.getBoDefConstruct=function(boDefId){
    var url= "/api-form/form/bo/formBoDef/getBoDefConstruct?boDefId="+boDefId;
    return rxAjax.get(url);
}


export  default FormPcApi;
