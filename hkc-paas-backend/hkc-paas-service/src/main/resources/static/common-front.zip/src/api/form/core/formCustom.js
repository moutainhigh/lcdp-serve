import rxAjax from '@/assets/js/ajax.js';

//表单定制 api接口
export const FormCustomApi = {};

FormCustomApi.baseUrl= '/api-form/form/core/formCustom';
FormCustomApi.exportUrl= FormCustomApi.baseUrl + '/export';

//查询列表
FormCustomApi.query=function (parameter) {
  var url= FormCustomApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
* 获取单记录
* @param pkId
* @returns {*}
*/
FormCustomApi.get =function(pkId) {
  var url= FormCustomApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

FormCustomApi.getByAlias=function(alias){
  var url= FormCustomApi.baseUrl + '/getByAlias?alias=' + alias;
  return rxAjax.get(url);
}

//保存数据
FormCustomApi.save =function(parameter) {
  var url= FormCustomApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

//删除数据
FormCustomApi.del =function(parameter) {
  var url= FormCustomApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

//获取所有的门户栏目
FormCustomApi.getInsColumns =function(parameter) {
  var url= '/api-portal/portal/core/insColumnDef/getAll';
  return rxAjax.get(url);
}

//根据ID获取门户栏目
FormCustomApi.getColumnById =function(pkId) {
    var url= '/api-portal/portal/core/insColumnDef/getColumnById?pkId='+pkId;
    return rxAjax.get(url);
}




export  default FormCustomApi;

