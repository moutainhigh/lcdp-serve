import rxAjax from '@/assets/js/ajax.js';

//流程沟通留言板 api接口
export const BpmInstMsgApi = {};

BpmInstMsgApi.baseUrl= '/api-bpm/bpm/core/bpmInstMsg';
BpmInstMsgApi.exportUrl= BpmInstMsgApi.baseUrl + '/export';

//查询列表
BpmInstMsgApi.query=function (parameter) {
  var url= BpmInstMsgApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
* 获取单记录
* @param pkId
* @returns {*}
*/
BpmInstMsgApi.get =function(pkId) {
  var url= BpmInstMsgApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

//保存数据
BpmInstMsgApi.save =function(parameter) {
  var url= BpmInstMsgApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

//删除数据
BpmInstMsgApi.del =function(parameter) {
  var url= BpmInstMsgApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

BpmInstMsgApi.getByInstId =function(instId) {
  var url= BpmInstMsgApi.baseUrl + '/getByInstId?instId='+instId;
  return rxAjax.get(url);
}

BpmInstMsgApi.addMsg =function(instId,msg) {
  var url= BpmInstMsgApi.baseUrl + '/addMsg';
  return rxAjax.postForm(url,{instId:instId,msg:msg});
}

export  default BpmInstMsgApi;

