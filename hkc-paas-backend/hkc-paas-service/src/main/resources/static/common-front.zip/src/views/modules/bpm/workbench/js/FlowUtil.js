import BpmInstApi from "@/api/bpm/core/bpmInst";
export default {
    computed:{
        //是否时独立打开审批页面还是使用的统一URL打开
        isAlone(){
            return this.$route.name!="openDoc";
        }
    },
    methods:{
		encryptInstId(instId,callback){
			BpmInstApi.getBpmInstEncrypt(instId).then(res=>{
				if(!res.success){
					this.$message.warn(res.message);
					return;
				}
				callback(res.data);
			})
		},
        /**
         * 启动流程页面
         * @param defKey
         */
        startProcess(defKey){
            let obj=this.$router.resolve({
                name:'newDoc',
                params:{
                    defKey:defKey
                }
            });
            let href=obj.href ;
            window.open(href,"_blank" );
        },
		/**
		 * 打开流程实例页面
		 * <pre>
		 *     1.审批页面
		 *     2.流程实例
		 * </pre>
		 * @param instId
		 * @param taskType
		 */
		openInst(instId){
			var self=this;
			this.encryptInstId(instId,function(encryptInstId) {
				let obj = self.$router.resolve({
					name: 'openDoc',
					params: {instId: encryptInstId}
				});
				window.open(obj.href, "_blank");
			})
		},
		/**
		 * 打开明细
		 * @param instId
		 */
		openDetail(instId){
			var self=this;
			this.encryptInstId(instId,function(encryptInstId) {
				let obj = self.$router.resolve({
					name: 'openDoc',
					params: {instId: encryptInstId},
					query: {action: "detail"}
				});
				window.open(obj.href, "_blank");
			})
		},
		pushInst(instId){
			var self=this;
			this.encryptInstId(instId,function(encryptInstId) {
				let time = new Date().getTime();
				self.$router.push({path: '/bpm/workbench/openDoc/' + encryptInstId + '?time=' + time});
			})
		},



    }
}