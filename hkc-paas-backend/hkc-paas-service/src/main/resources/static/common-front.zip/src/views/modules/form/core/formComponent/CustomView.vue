<template>
    <div class="custom-view">
        <component v-bind:is="currentView" ref="component" :config="config"  @customViewEvent="customViewEvent" :customQueryData="customQueryData"></component>
    </div>
</template>

<script>
import Vue from 'vue';
import FormCustomQueryApi from "@/api/form/core/formCustomQuery";
import {debounce} from "lodash";
import PublicApi from "@/api/form/core/public";
import BusEvent from "@/views/modules/form/core/formComponent/BusEvent";

export default {
    name: "custom-view",
    mixins:[BusEvent],
    props: {
        config:{
            type:Object,
            default:{}
        }
    },
    components: {
    },
    data() {
        return {
            currentView:"",
            customQueryData:[]
        }
    },
    created() {
        this.init();
    },
    methods: {
        init(){
            var self=this;
            if(this.config){
                //自定义查询
                var params={};
                if(this.config.customSql){
                    var alias = JSON.parse(this.config.customSql).value;
                    var parameter={};
                    if (this.config.receive.type == 'url') {
                        var routeParams={};
                        if (this.$route.meta.query) {
                            routeParams = JSON.parse(this.$route.meta.query);
                        }else {
                            routeParams=this.$route.query;
                        }
                        var mapping = this.config.receive.mapping;
                        if(mapping && mapping.length>0 ){
                            for (var i = 0; i < mapping.length; i++) {
                                var value="";
                                if(mapping[i].valueSource=='param'){
                                    if(this.config.receive.type== "url"){
                                        if(routeParams[mapping[i].valueDef]){
                                            value=routeParams[mapping[i].valueDef];
                                        }
                                    }else {
                                        if( routeParams[mapping[i].name]){
                                            value=routeParams[mapping[i].name];
                                        }
                                    }
                                }
                                params[mapping[i].name]=value;
                            }
                        }
                    }
                    this.getParams(function (res) {
                        if(res){
                            Object.assign(params,res);
                        }
                        if(params){
                            parameter.params=JSON.stringify(params);
                        }
                        self.getCustomQueryData(alias,parameter);
                    })
                }
                if(this.config.template) {
                    this.currentView = Vue.component("component-view"+this.config.alias, {
                        template: this.config.template,
                        props: {
                            // 自定义查询数据
                            customQueryData: {
                                type: Array,
                                default:[]
                            },
                            // 配置
                            config: {
                                type: Object,
                                default:{}
                            },
                        },
                        data() {
                            return {

                            }
                        },
                        methods:{
                            /**
                             * @param data {key:value}
                             */
                            customViewEvent(data){
                                this.$emit('customViewEvent',{component:this.config.alias,params:data});
                            }
                        }
                    });
                }
            }
        },
        //获取自定义查询数据
        getCustomQueryData(alias,parameter){
            FormCustomQueryApi.doQuery(alias,parameter).then(res=>{
                if(res.success && res.data){
                    this.customQueryData=res.data;
                }
            });
        },
        handReceive :debounce(function (args, self_){
            var receive=self_.config.receive;
            var inputParams=args.params;
            if(self_.config.receive.type=='event' && receive.publishComponent==args.component){
                var params={};
                //自定义查询
                if(self_.config.customSql){
                    var alias = JSON.parse(self_.config.customSql).value;
                    //读取配置的参数
                    for(var i=0;i<receive.mapping.length;i++){
                        var o=receive.mapping[i];
                        if(o.valueSource=='param' && inputParams[o.valueDef]){
                            params[o.name]=inputParams[o.valueDef];
                        }
                    }
                    self_.getCustomQueryData(alias,{params:JSON.stringify(params)});
                }
            }
        },300),
        //发布事件
        customViewEvent(data){
            this.$bus.$emit('customViewEvent',data);
        },
        getParams(callback){
            PublicApi.getParams(JSON.stringify(this.config.receive.mapping)).then(res=>{
                callback(res);
            }).catch(err=>{
                callback({});
            })
        }
    },
    watch: {
        config:{
            handler: function (val, oldVal) {
                this.init();
            },
            deep: true
        }
    }
}
</script>

<style scoped>
.custom-view{
    padding: 10px;
    background: white;
    height: 100%;
    overflow: auto;
}
</style>