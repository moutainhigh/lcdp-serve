<template>
  <rx-dialog @handOk="handleCompleteCheck" @cancel="closeWindow" :oktext="'提交'" order="buttom" btnalign="center">
    <template #toolbar >
      <a-button @click="temporaryOpinion">暂存意见</a-button>
    </template>
    <rx-fit>
      <div style="height:100%;width:100%;padding:20px;">
      <a-form>
        <a-form-item label="审批动作" :label-col="labelCol" :wrapper-col="wrapperCol">
          <a-radio-group v-model="checkType" @change="checkTypeChange">
            <a-radio value="AGREE">同意</a-radio>
            <a-radio value="REFUSE">不同意</a-radio>
          </a-radio-group>
        </a-form-item>
        <a-form-item label="即将流向" :label-col="labelCol" :wrapper-col="wrapperCol">
          <bpm-task-executors ref="taskExecutors" :nodeExecutors="nodeExecutors" :allow-select-executor="false"></bpm-task-executors>
        </a-form-item>
        <a-form-item label="意见" :label-col="labelCol" :wrapper-col="wrapperCol">
          <a-select
            show-search
            :value="value"
            style="width: 200px"
            :default-active-first-option="false"
            :show-arrow="false"
            :filter-option="false"
            :not-found-content="null"
            option-label-prop="label"
            @search="handleSearch"
            @change="handleChange"
            @blur="handleBlur"
            placeholder="输入关键字搜索常用意见"
          >
            <a-select-option v-for="d in data" :value="d.opText" :label="d.opText">
              <a-icon type="close" @click.stop="closeOpinion(d)"></a-icon>
              {{d.opText}}
            </a-select-option>
          </a-select>
          <a-button style="margin-left: 3px;" @click="saveOpinion">保存</a-button>
          <a-textarea placeholder="请填写意见，可保存为常用意见" v-model="opinion"></a-textarea>
        </a-form-item>

        <a-form-item label="附件" :label-col="labelCol" :wrapper-col="wrapperCol">
          <rx-attach-component v-model="fileList" ></rx-attach-component>
        </a-form-item>
          <a-form-item label="通知方式" :label-col="labelCol" :wrapper-col="wrapperCol">
              <a-checkbox-group :options="msgOptions" v-model="msgTypes">
              </a-checkbox-group>
          </a-form-item>
      </a-form>
    </div>
  </rx-fit>
  </rx-dialog>
</template>
<script>
import { Dialog, RxDialog, Util, RxFit, RxUserComponent,RxAttachComponent} from 'jpaas-common-lib'
import BpmtaskApi from '@/api/bpm/core/bpmTask'
import BpmPublicApi from '@/api/bpm/core/BpmPublicApi'
import BpmOpinionLibApi from "@/api/bpm/core/bpmOpinionLib";
import BpmTaskExecutors from "./BpmTaskExecutors";


export default {
  name: 'bpm-task-transfer-check',
  components: {
      RxUserComponent,
      BpmTaskExecutors,
      RxAttachComponent,
      RxFit,
      RxDialog
  },
  props: {
    layerid: String,
    lydata: Object,
    destroy: Function,
    taskId: {
      type: String,
      required: true
    },
    formJson: String,
    systemHand:Boolean,
    nodeExecutors: Array,

    opinionObj:{
      type:Object,
      default:{
        name:"",
        value:""
      }
    }
  },
  data() {
    return {
      labelCol: { span: 4 },
      wrapperCol: { span: 8 },
      msgOptions:[],
      checkType: 'AGREE',
      opinion: '',
      msgTypes: [],
      copyUsers: [],
      opinionName:"",
      value:undefined,
      data:[],
      fileList:[],
      temporaryOpinionObj:{}
    }
  },
  created(){
      this.opinion=this.opinionObj.value;
      this.opinionName=this.opinionObj.name;
      this.initMessageHandler();
      this.getTemporaryOpinion();
      this.fetch('', data => (this.data = data));
  },
  methods: {
    checkTypeChange(e){
      BpmtaskApi.getTaskFlowNodesExecutors(this.taskId,e.target.value,JSON.parse(this.formJson)).then(res=>{
        this.nodeExecutors=res;
      })
    },
    initMessageHandler(){
        BpmPublicApi.getMessageHandler().then(res=>{
            for(var i=0;i<res.length;i++){
                var o=res[i];
                var obj={ label: o.name, value: o.type };
                this.msgOptions.push(obj);
            }
        })
    },
    handleCompleteCheck(e) {
      let self = this;
      var ctl=this.$refs.taskExecutors;
      //抄送用户
      let copyUserIds=this.getCopyUserId();
      let noticeTypes=this.msgTypes.join(",");
      let nodeUserMap = ctl.getNodeUserMap();
      let destNodeId=ctl.getDestNodeId();
      let cmd = {
        taskId: this.taskId,
        checkType: this.checkType,
        opinion: this.opinion,
        msgTypes: noticeTypes,
        copyUserAccounts: copyUserIds,
        nodeExecutors: nodeUserMap,
        formJson:  self.formJson,
        systemHand:self.systemHand,
        opinionName:self.opinionName,
        opFiles:JSON.stringify(self.fileList)
      }
      //设置目标节点。
      if(destNodeId){
          cmd.destNodeId=destNodeId;
      }
      BpmtaskApi.checkComplete(cmd).then(resp => {
          e.loading=false;
        if (resp.success) {
            Util.closeWindow(self,'ok');
        }
      })
    },


    /**
     * 获取抄送用户。
     * @returns {string}
     */
    getCopyUserId(){
        var aryUserId=[];
        if(this.copyUsers && this.copyUsers.length>0){
            this.copyUsers.forEach(item=>{
                aryUserId.push(item.account);
            })
        }
        return aryUserId.join(",");
    },
    closeWindow() {
      Util.closeWindow(this, 'cancel')
    },
    saveOpinion(){
      var self=this;
      BpmOpinionLibApi.save({opText:this.value}).then(res=>{
        if(res.success){
          self.handleBlur();
        }
      });
    },
    closeOpinion(opinion){
      let self_ = this;
      this.$confirm({
        title: '操作提示',
        zIndex:9999,
        content: '确定要删除此条意见吗？',
          okText: '确认',
          cancelText: '取消',
        onOk() {
          BpmOpinionLibApi.del({ids:opinion.opId}).then(res=>{
            self_.fetch('', data => (self_.data = data));
          })
        },
        onCancel() {
        }
      })
    },
    fetch(value,callback){
      BpmOpinionLibApi.getUserText(value).then(res=>{
        callback(res);
      })
    },
    handleSearch(value) {
      this.value=value;
      this.fetch(value, data => (this.data = data));
    },
    handleChange(value) {
      this.value=value;
    },
    handleBlur(){
      if(this.value) {
        this.opinion = this.value;
        this.value=undefined;
      }
    },
    //暂存意见
    temporaryOpinion(){
      var id=this.temporaryOpinionObj.id?this.temporaryOpinionObj.id:"";
      if(this.taskId){
        BpmtaskApi.temporaryOpinion(this.taskId,this.opinion,id);
      }
      Util.closeWindow(this, 'ok');
    },
    //获取暂存意见
    getTemporaryOpinion(){
      if(this.taskId){
        BpmtaskApi.getTemporaryOpinion(this.taskId).then(res=>{
          if(res){
            this.opinion=res.opinion;
            this.temporaryOpinionObj=res;
          }
        });
      }
    }
  }
}
</script>