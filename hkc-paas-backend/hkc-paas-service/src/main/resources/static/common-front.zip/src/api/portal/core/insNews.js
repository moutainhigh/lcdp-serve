import rxAjax from '@/assets/js/ajax.js';
import {Util} from "jpaas-common-lib";

import InsNewsGet from '@/views/modules/portal/core/InsNewsGet';

//信息公告 api接口
export const InsNewsApi = {};

InsNewsApi.baseUrl= '/api-portal/portal/core/insNews';
InsNewsApi.exportUrl= InsNewsApi.baseUrl + '/export';

InsNewsApi.insColumnDefUrl= '/api-portal/portal/core/insColumnDef';
InsNewsApi.sysDicUrl= '/api-system/system/core/sysDic';

InsNewsApi.uploadUrl='/api-system/system/core/sysFile/upload';

//上传文件
InsNewsApi.upload=function(formData,callback) {
  var url= InsNewsApi.uploadUrl;
  return rxAjax.upload(url,formData,callback);
}

//查询列表
InsNewsApi.query=function (parameter) {
  var url= InsNewsApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}
//查询列表
InsNewsApi.getAllIssuedNews=function (parameter) {
  var url= InsNewsApi.baseUrl + '/getAllIssuedNews';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}



InsNewsApi.getInsNews=function(config,callback){
  var baseConf= {
    component:InsNewsGet,
    title:'查看新闻公告'
  };
  let conf = { ...baseConf,...config };
  Util.open(conf,function(action){
    return;
  });
}

//查询新闻类型字典列表
InsNewsApi.getTopDicByKey=function () {
  var url= InsNewsApi.sysDicUrl + '/getTopDicByKey?key=NEWS';
  return rxAjax.get(url);
}


//查询栏目类型列表
InsNewsApi.queryByIsNews=function () {
  var url= InsNewsApi.insColumnDefUrl + '/queryByIsNews?isNews=YES';
  return rxAjax.get(url);
}


/**
* 获取单记录
* @param pkId
* @returns {*}
*/
InsNewsApi.get =function(pkId) {
  var url= InsNewsApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

/**
 * 查看单记录
 * @param pkId
 * @returns {*}
 */
InsNewsApi.readInsNews =function(pkId) {
  var url= InsNewsApi.baseUrl + '/readInsNews?pkId=' + pkId;
  return rxAjax.get(url);
}

//保存数据
InsNewsApi.save =function(parameter) {
  var url= InsNewsApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

//删除数据
InsNewsApi.del =function(parameter) {
  var url= InsNewsApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

export  default InsNewsApi;

