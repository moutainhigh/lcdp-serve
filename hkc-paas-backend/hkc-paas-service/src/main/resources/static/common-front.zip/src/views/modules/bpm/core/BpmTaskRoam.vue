<template>
  <rx-dialog @cancel="cancel" :showok="false" oktext="撤销沟通" order="buttom" btnalign="center">
    <a-table :columns="columns" :data-source="dataSource" :pagination="false">
      <span slot="serial" slot-scope="text, record,index">{{index+1}}</span>
      <span slot="assignee" slot-scope="text, record,index">
        <rx-user-info :userId="text"></rx-user-info>
      </span>
      <span slot="status" slot-scope="text, record,index">
        <a-tag :color="statusMap[text].color">
              <span>{{statusMap[text].text}}</span>
            </a-tag>
      </span>
      <span slot="updateTime" slot-scope="text, record,index">
          <template v-if="record.status=='COMPLETED'">{{text}}</template>
      </span>
      <span slot="remark" slot-scope="text, record,index">
          <template v-if="record.status=='COMPLETED'">{{record.bpmCheckHistory.remark}}</template>
      </span>
    </a-table>

  </rx-dialog>
</template>

<script>
    import {Util} from 'jpaas-common-lib';
    import BpmtaskApi from "@/api/bpm/core/bpmTask";



    export default {
        name: "bpm-task-roam",
        props:{
            taskId:"",

            layerid: String,
            lydata: Object,
            destroy:Function
        },

        data (){
            return {
                columns:[
                    {
                        title: '序号',
                        dataIndex:'serial',
                        scopedSlots: { customRender: 'serial' },
                        width: 80
                    },
                    {
                        title: '流转人',
                        dataIndex: 'assignee',
                        width:180,
                        ellipsis:false,
                        scopedSlots: { customRender: 'assignee' },
                    },
                    {
                        title: '流转时间',
                        dataIndex: 'createTime',
                        width:100
                    },
                    {
                        title: '状态',
                        dataIndex: 'status',
                        width:120,
                        scopedSlots: { customRender: 'status' },
                    },
                    {
                      title: '流转意见',
                      dataIndex: 'remark',
                      width:100
                    }
                ],
                dataSource:[],
                statusMap: {
                    "UNHANDLE": { color: 'red', text: '未处理' },
                    "COMPLETED": { color: 'green', text: '已处理' },
                    "HANDLE": { color: 'red', text: '正在流转' }
                }
            }
        },
        created(){
          this.init();
        },
        methods:{
          init(){
              BpmtaskApi.getRoamTasks(this.taskId).then(res=>{
                  this.dataSource=res.data;
              })
          },
          cancel(){
            Util.closeWindow(this,"cancel");
          }
        }
    }
</script>

<style scoped>

</style>