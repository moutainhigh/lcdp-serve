<template>
    <rx-dialog @handOk="submitForm" @cancel="cancel" order="buttom" btnalign="center">
        <rx-layout>
            <div slot="center">
                <rx-fit>
                    <a-form :label-col="{ span: 4 }" :wrapper-col="{ span: 20 }">
                        <div v-if="assignFlowUsers">
                            <div class="divider" v-if="startReqNodes.length>0">
                                <span>指定人员</span>
                            </div>
                            <a-form-item v-for="reqNode in startReqNodes" :key="reqNode.nodeId"
                                         :label="reqNode.nodeName">
                                <rx-text-list v-model="reqNode.users" textfield="name" valuefield="id"
                                              @click="selectUsers(reqNode.users)" style="margin-top: 6px">
                                    <a-icon type="user"></a-icon>
                                </rx-text-list>
                            </a-form-item>
                        </div>
                        <a-form-item label="关联流程" v-if="showRelInsts">
                            <rx-text-list v-model="relInsts"
                                          :showclose="true"
                                          :readonly="false"
                                          valuefield="id" textfield="name"
                                          @click="selectBpmInst()"
                            >
                                <a-icon type="ellipsis"/>
                            </rx-text-list>

                        </a-form-item>
                        <a-form-item label="即将流向" v-if="processConfig.allowSelectPath">
                            <bpm-task-executors ref="taskExecutors"
                                                :nodeExecutors="nodeExecutors"
                                                :allow-select-executor="true"></bpm-task-executors>
                        </a-form-item>
                        <a-form-item label="提交说明" v-if="fillOpinion==true">
                            <a-textarea v-model="opinion" :rows="4"></a-textarea>
                        </a-form-item>
                        <a-form-item label="附件" v-if="fillOpinion==true">
                            <rx-attach-component v-model="fileList"></rx-attach-component>
                        </a-form-item>
                    </a-form>
                    <rx-spin v-if="spinShow" :text="'正在提交...,请稍等。'"></rx-spin>
                </rx-fit>
            </div>
        </rx-layout>
    </rx-dialog>
</template>
<script>
import {Util, RxSpin, Dialog, RxTextList, RxAttachComponent, RxDialog} from "jpaas-common-lib";
import BpmInstApi from "@/api/bpm/core/bpmInst";
import BpmDefApi from '@/api/bpm/core/bpmDef';
import formbase from "@/api/formbase";
import BpmTaskExecutors from "./BpmTaskExecutors";
import BpmMyEvents from "./BpmMyEvents";


export default {
    name: 'BpmInstStartConfirm',
    mixins: [formbase],
    props: {
        formSolutionAlias: {type: String},
        processConfig: {type: Object, required: true},
        defId: {type: String},
        instId: {type: String},
        layerid: String,
        lydata: Object,
        destroy: Function
    },
    components: {
        RxSpin,
        RxTextList,
        RxAttachComponent,
        BpmTaskExecutors,
        BpmMyEvents,
        RxDialog
    },
    data() {
        return {
            //填写意见
            fillOpinion: false,
            //配置后续用户
            assignFlowUsers: false,
            //计算后续执行用户
            startCalFlowusers: false,
            //是否显示指定关联流程
            showRelInsts: false,
            //填写意见
            opinion: '',
            startReqNodes: [],//必填节点项
            nodeUsers: [],//后续节点人员Id列表,
            spinShow: false,
            nodeExecutors: [],
            fileList: [],
            relInsts: []
        }
    },
    created() {

    },
    methods: {
        //选择对话框
        selectUsers(rtUsers) {
            let self = this;
            let conf = {curVm: this, data: {single: false}, widthHeight: ['1024px', '600px']};
            Dialog.openUserDialog(conf, function (self, users) {
                for (let i = 0; i < users.length; i++) {
                    let obj = users[i];
                    let o = {name: obj.fullName, id: obj.userId};
                    rtUsers.push(o);
                }
            });
        },
        getNodeUsers() {
            let nodeUserIds = {};
            //节点人员是否设置了
            let isNodeUserSet = true;
            //检查是否有存在的节点人员必须需要
            if (this.assignFlowUsers) {
                for (let i = 0; i < this.startReqNodes.length; i++) {
                    var node = this.startReqNodes[i];
                    if (node.users.length == 0) {
                        isNodeUserSet = false;
                        break;
                    }
                    let userIds = [];
                    node.users.forEach(item => {
                        userIds.push(item.id);
                    });
                    nodeUserIds[node.nodeId] = userIds.join(',');
                }

            }
            return {nodeUserIds: nodeUserIds, isNodeUserSet: isNodeUserSet};
        },
        getFormData() {
            let rxForms = this.$parent.rxForms;
            var formData = {};
            if (rxForms) {
                formData = rxForms.getData();
            } else {
                rxForms = this.$parent.$refs.rxForm.formVm;
                formData[rxForms.alias] = rxForms.data;
            }
            let formJson = JSON.stringify(formData);
            let data = {defId: this.defId, formJson: formJson};
            if (this.instId) {
                data.instId = this.instId;
            }
            data.formSolutionAlias = this.formSolutionAlias;
            return data;
        },
        getSubmitData(objNodeUsers) {
            let data = this.getFormData();
            data.checkType = "AGREE";
            data.opinion = this.opinion;
            data.opFiles = JSON.stringify(this.fileList);
            data.relInsts = JSON.stringify(this.relInsts);

            //是否已有主键。
            var hasPk = this.processConfig.hasPk;
            if (hasPk) {
                data.systemHand = true;
                data.hasPk = true;
            }

            data.nodeUserIds = JSON.stringify(objNodeUsers.nodeUserIds);
            //选择执行路径
            if (this.processConfig.allowSelectPath) {
                var ctlUsers = this.$refs.taskExecutors;
                var destNodeId = ctlUsers.getDestNodeId();
                var userMap = ctlUsers.getNodeUserMap();
                data.nodeExecutors = userMap;
                data.destNodeId = destNodeId;
            }
            if (this.instId) {
                data.instId = this.instId;
            }
            return data;
        },
        async submitForm(e) {
            let self = this;
            var objNodeUsers = this.getNodeUsers();
            if (!objNodeUsers.isNodeUserSet) {
                this.$message.error('必填节点没有选择人员！');
                e.loading = false;
                return;
            }
            self.spinShow = true;
            //获取当前需要提交的数据。
            var data = this.getSubmitData(objNodeUsers);

            BpmInstApi.startProcess(data).then(data => {
                self.spinShow = false;
                if (data.success) {
                    Util.closeWindow(self, 'ok', data);
                    e.loading = false;
                }
            }).catch((error) => {
                self.spinShow = false;
                e.loading = false;
            }).finally(() => {
                e.loading = false;
            });
        },

        cancel() {
            Util.closeWindow(this, 'cancel');
        },
        getStartUserNodes() {
            let self = this;
            //传入 defId 则可
            var formData = this.getFormData().formJson;

            BpmDefApi.getStartUserNodes(this.defId, formData).then(resp => {
                self.startReqNodes = [];
                resp.forEach(item => {
                    self.startReqNodes.push({nodeId: item.nodeId, nodeName: item.name, users: item.users});
                });
            });
        },
        getFlowNodesExecutors(){
            //传入 defId 则可
            var formData=this.getFormData().formJson;
            BpmDefApi.getFlowNodesExecutors(this.defId,formData).then(res=>{
                for(var i=0;i<res.length;i++){
                    var o=res[i];
                    o.selected=i==0;
                }
                this.nodeExecutors=res;
            })
        },
        selectBpmInst() {
            var conf = {
                component: BpmMyEvents,
                title: '关联流程',
                curVm: this, widthHeight: ['1024px', '600px']
            };
            var self_ = this;
            Util.open(conf, function (action, relInsts) {
                if (action != 'ok') return;

                var idAry = [];
                for (var i = 0; i < self_.relInsts.length; i++) {
                    var o = self_.relInsts[i];
                    idAry.push(o.id);
                }

                for (var i = 0; i < relInsts.length; i++) {
                    var o = relInsts[i];
                    if (idAry.includes(o.id)) {
                        continue;
                    }
                    self_.relInsts.push(o);
                }
            });
        }
    },
    watch: {
        processConfig: {
            handler(newVal, oldVal) {
                if (!newVal) {
                    return;
                }
                this.buttons = newVal.buttons;
                if (newVal.startNodeOptions instanceof Array) {
                    this.startConfirm = newVal.startNodeOptions.indexOf('startConfirm') != -1;
                    this.fillOpinion = newVal.startNodeOptions.indexOf('fillOpinion') != -1;
                    //执行下一步用户。
                    this.assignFlowUsers = newVal.startNodeOptions.indexOf('assignFlowUsers') != -1;
                    this.startCalFlowusers = newVal.startNodeOptions.indexOf('startCalFlowusers') != -1;
                    this.showRelInsts = newVal.startNodeOptions.indexOf('relInsts') != -1;

                }
                //是否需要显示弹出的窗口
                if (this.assignFlowUsers) {
                    this.getStartUserNodes();
                }
                if (newVal.allowSelectPath) {
                    this.getFlowNodesExecutors();
                }

            },
            immediate: true
        },
    }
}
</script>
<style scoped>
.divider {
    font-size: 14px;
    position: relative;
    margin: 10px 0;
}

.divider > span {
    display: inline-block;
    position: relative;
    z-index: 10;
    background: #fff;
    padding: 0 10px;
    font-weight: bold;
}

.divider > span:before {
    content: '';
    display: inline-block;
    height: 14px;
    background: #4D9EFF;
    width: 3px;
    position: absolute;
    left: 0;
    top: 50%;
    margin-top: -6px;
}

.divider:after {
    content: '';
    position: absolute;
    top: 50%;
    right: 0;
    width: 100%;
    display: block;
    border-bottom: 1px solid #e8e8e8;
    z-index: 8;
}
</style>