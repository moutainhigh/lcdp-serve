<template>
  <div class="flowHeaderTitles">
    <div class="leftTitle">
      <span>本事项&nbsp;<b>{{bpmInst.subject}}</b></span>
      <span>由&nbsp;<b><rx-user-info :userId="bpmInst.createBy" /></b></span>
      <span>创建于&nbsp;<b>{{bpmInst.createTime}}</b></span>
    </div>
    <div class="rightTitle">
      <span>单号: <b>{{bpmInst.billNo}}</b></span>
    </div>
  </div>
</template>

<script>
    export default {
        name: "bpm-inst-info",
        props:{bpmInst:{type:Object}}
    }
</script>

<style scoped>
.flowHeaderTitles{
  display: flex;
  padding:10px;
}
.leftTitle{
    flex: 1;
}
  .leftTitle >span{
    display: inline-block;
    margin-right: 10px;
  }
  .rightTitle{
      margin-right: 150px;
  }
</style>