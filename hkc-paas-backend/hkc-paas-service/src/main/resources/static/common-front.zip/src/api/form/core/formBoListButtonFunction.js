import FormSolutionApi from "@/api/form/core/formSolution";
import FormBusinessSolutionApi from "@/api/form/core/formBusinessSolution";
/*
*  let _obj = {
        title:this.formBoList.name+'--明细',
        alias:this.formBoList.formDetailAlias?this.formBoList.formDetailAlias:this.formBoList.formAlias,
        pkId:row[this.formBoList.idField],
        readOnly:true,
        parent:parent
      }
* */
import {Util} from 'jpaas-common-lib';
import BpmtaskApi from '@/api/bpm/core/bpmTask';
import FlowUtil from "@/views/modules/bpm/js/FlowUtil";

export default {
	mixins:[FlowUtil],
    data() {
        return {
            dialogBox: {},
        }
    },
    created() {
        var files = require.context('@/assets/js', true, /\.js$/);
        files.keys().forEach(key => {
            if (key.indexOf('/DialogBox.js') != -1) {
                this.dialogBox = files(key).default || files(key)
            }
        })
    },
    methods: {
        showForm(obj) {
            if (!obj.alias) {
                this.$message.error("请绑定表单方案！");
                return;
            }
            if (!obj.readOnly) {
                obj.readOnly = false;
            }
            var self = this;
            let config = {
                title: obj.title,
                curVm: self,
                data: {
                    alias: obj.alias,
                    pkId: obj.pkId,
                    readOnly: obj.readOnly,
                    parent: obj.parent,
                    //将表单映射数据提交到表单数据。
                    setInitData(data) {
                        if (self.formdata) {
                            Object.assign(data, self.formdata);
                        }
                        return data;
                    }
                },
                max: true,
                shade: true,
                urlType: obj.urlType,//用來區分 表單按鈕的打開方式；
            }
            this.dialogBox.showForm(config, function (action) {
                self.onRefresh();
            });
        },
        addTableData(data) {
            if (this.formBoList.dataStyle == 'tree') {
                var parentNode = this.table.getParentNode(data);
                this.table.addNode(data, parentNode);
            } else {
                this.table.addRow(data);
            }
        },
        removeTableData(data) {
            if (this.formBoList.dataStyle == 'tree') {
                this.table.removeNodes(data);
            } else {
                this.table.removeRows(data);
            }
            this.table.$forceUpdate();
        },
        getTableData(single) {
            if (this.formBoList.isTreeDlg == 'YES') {
                if (single) {
                    return this.curRow;
                }
                return [this.curRow];
            }
            if (this.formBoList.dataStyle == 'tree') {
                if (single) {
                    return this.table.getSelectedNode();
                }
                return this.table.getSelectedNodes();
            } else {
                if (single) {
                    return this.table.getSelectedRow();
                }
                return this.table.getSelectedRows();
            }
        },
        editRow(record) {
            if (record.isNew) {
                return;
            }
            //业务方案方式
            if(this.formBoList.busSolution){
                var busSolution= JSON.parse(this.formBoList.busSolution);
                this.showBusSolutionForm(busSolution,record,false);
                return;
            }
            if(!this.canDelete(record)){
                this.$message.info('流程审批中或审批完成的记录不能被编辑！');
                return;
            }
            let _obj = {
                title: this.formBoList.name + '--编辑',
                alias: this.formBoList.formAlias,
                pkId: record[this.formBoList.idField],
                urlType: 'EditRow'
            }
            this.showForm(_obj);
        },
        delRowById(record) {
            if (record.isNew) {
                if (this.formBoList.dataStyle == 'tree') {
                    this.removeTableData([record]);
                } else {
                    this.removeTableData([record[this.formBoList.idField]]);
                }
                return;
            }
            if(!this.canDelete(record)){
                this.$message.info('流程审批中或审批完成的记录不能被删除！');
                return;
            }
            let self_ = this;
            this.$confirm({
                title: '操作提示',
                zIndex: 20000,
                content: '您确定需要删除选中的记录吗？',
                okText: '确认',
                cancelText: '取消',
                onOk() {
                    //业务方案方式
                    if(self_.formBoList.busSolution){
                        var busSolution= JSON.parse(self_.formBoList.busSolution);
                        FormBusinessSolutionApi.removeById({busSolId:busSolution.value, id: record[self_.formBoList.idField],rows:[record]}).then(res => {
                            self_.onRefresh();
                        });
                        return;
                    }
                    FormSolutionApi.removeById({
                        alias: self_.formBoList.formAlias,
                        id: record[self_.formBoList.idField]
                    }).then(res => {
                        self_.onRefresh();
                    });
                },
                onCancel() {
                }
            })

        },
        onAdd() {//增加
            //业务方案方式
            if(this.formBoList.busSolution){
                var busSolution= JSON.parse(this.formBoList.busSolution);
                this.showBusSolutionForm(busSolution,"",false);
                return;
            }
            if (this.formBoList.rowEdit == 'YES') {
                var data = {isNew: true};
                data[this.formBoList.idField] = Util.randomId();
                this.addTableData(data);
            } else {
                let _obj = {
                    title: this.formBoList.name + '--添加',
                    alias: this.formBoList.formAddAlias ? this.formBoList.formAddAlias : this.formBoList.formAlias,
                    urlType: 'Add'
                }
                this.showForm(_obj);
            }
        },
        onEdit() {//編輯
            var row = this.getTableData(true);
            var rows = this.getTableData(false);
            if (!rows || rows.length == 0) {
                this.$message.warning("请选择一行数据！");
                return;
            }
            if (rows.length > 1) {
                for(let i = 1; i < rows.length; i++){
                    if(rows[i][this.formBoList.idField] != rows[i-1][this.formBoList.idField]){
                        this.$message.warning("选中多条记录时不能编辑！");
                        return;
                    }
                }
            }
            if (row && row.isNew) {
                return;
            }
            if(!this.canDelete(row)){
                this.$message.info('流程审批中或审批完成的记录不能被编辑！');
                return;
            }
            //业务方案方式
            if(this.formBoList.busSolution){
                var busSolution= JSON.parse(this.formBoList.busSolution);
                this.showBusSolutionForm(busSolution,row,false);
                return;
            }else {
                let _obj = {
                    title: this.formBoList.name + '--编辑',
                    alias: this.formBoList.formAlias,
                    pkId: row[this.formBoList.idField],
                    urlType: 'Edit'
                }
                this.showForm(_obj);
            }
        },
        onAddSub() {
            var row = this.getTableData(true);
            if (!row) {
                this.$message.warning("请选择一行数据！");
                return;
            }
            if (this.formBoList.rowEdit == 'YES') {
                var data = {isNew: true};
                data[this.formBoList.idField] = Util.randomId();
                data[this.formBoList.parentField] = row[this.formBoList.idField];
                this.addTableData(data);
                this.onExpand();
            } else {
                var parent = {field: this.formBoList.parentField, value: row[this.formBoList.idField]};
                let _obj = {
                    title: this.formBoList.name + '--添加',
                    alias: this.formBoList.formAddAlias ? this.formBoList.formAddAlias : this.formBoList.formAlias,
                    pkId: "",
                    readOnly: false,
                    parent: parent,
                    urlType: 'AddSub'
                }
                this.showForm(_obj);
            }
        },
        canDelete(row){
            if(row.INST_STATUS_==undefined){
                return  true;
            }
            let instStatus=row.INST_STATUS_;
            if(!instStatus){
                return true;
            }
            if(instStatus=='CANCEL' || instStatus=='DRAFTED'){
                return true;
            }
            return false;
        },
        onRemove() {
            var rows = this.getTableData();
            if (!rows || rows.length == 0) {
                this.$message.warning("请选择一行数据！");
                return;
            }
            var ids = "";
            for (var i = 0; i < rows.length; i++) {
                if (rows[i].isNew) {
                    continue;
                }
                if(!this.canDelete(rows[i])){
                    continue;
                }

                ids += rows[i][this.formBoList.idField] + ",";
            }
            ids = ids.substring(0, ids.lastIndexOf(","));
            if (!ids) {
                this.$message.info('流程审批中或审批完成的记录不能被删除！');
                //this.removeTableData();
                return;
            }
            if (!this.formBoList.formAlias && !this.formBoList.busSolution) {
                this.$message.error("请绑定表单方案！");
                return;
            }
            let self_ = this;
            this.$confirm({
                title: '操作提示',
                zIndex: 20000,
                content: '您确定需要删除选中的记录吗？注意流程审批中或审批完成的记录不能被删除！',
                okText: '确认',
                cancelText: '取消',
                onOk() {
                    //业务方案方式
                    if(self_.formBoList.busSolution){
                        var busSolution= JSON.parse(self_.formBoList.busSolution);
                        FormBusinessSolutionApi.removeById({busSolId:busSolution.value, id: ids,rows:rows}).then(res => {
                            self_.onRefresh();
                        });
                        return;
                    }
                    FormSolutionApi.removeById({alias: self_.formBoList.formAlias, id: ids}).then(res => {
                        self_.onRefresh();
                    });
                },
                onCancel() {
                }
            })
        },
        onExpand() {
            this.table.expand();
        },
        onCollapse() {
            this.table.collapse();
        },
        onDetail() {
            var row = this.getTableData(true);
            var rows = this.getTableData(false);
            if (!rows || rows.length == 0) {
                this.$message.warning("请选择一行数据！");
                return;
            }
            if (rows.length > 1) {
                for(let i = 1; i < rows.length; i++){
                    if(rows[i][this.formBoList.idField] != rows[i-1][this.formBoList.idField]){
                        this.$message.warning("选中多条记录时不能查看明细！");
                        return;
                    }
                }
            }
            if (row.isNew) {
                return;
            }
            //业务方案方式
            if(this.formBoList.busSolution){
                var busSolution= JSON.parse(this.formBoList.busSolution);
                this.showBusSolutionForm(busSolution,row,true);
                return;
            }
            //如果有流程实例，则显示流程明细
            if(row.INST_ID_){
                this.bpmDetail(row);
                return ;
            }
            let _obj = {
                title: this.formBoList.name + '--明细',
                alias: this.formBoList.formDetailAlias ? this.formBoList.formDetailAlias : this.formBoList.formAlias,
                pkId: row[this.formBoList.idField],
                readOnly: true,
                urlType: 'Details'
            }
            this.showForm(_obj);
        },
        rowDblClick(record,index){
            if(record.isNew){
                return;
            }
            if(this.handRowDblClick){
                this.handRowDblClick(record,index);
            }
            else{
                //业务方案方式
                if(this.formBoList.busSolution){
                    var busSolution= JSON.parse(this.formBoList.busSolution);
                    this.showBusSolutionForm(busSolution,record,true);
                    return;
                }
                //如果有流程实例，则显示流程明细
                if(record.INST_ID_){
                    this.bpmDetail(record);
                    return ;
                }
                let _obj = {
                    title:this.formBoList.name+'--明细',
                    alias:this.formBoList.formDetailAlias?this.formBoList.formDetailAlias:this.formBoList.formAlias,
                    pkId:record[this.formBoList.idField],
                    readOnly:true,
                    urlType:'Details'
                }
                this.showForm(_obj);
            }

        },
        onClose() {
            Util.closeWindow(this.$parent);
        },
        onRefresh() {
            this.table.loadData();
        },
        onRowsSave() {
            var rows = this.getTableData();
            FormSolutionApi.rowsSave({alias: this.formBoList.formAlias, rows: rows}).then(res => {
                this.onRefresh();
                //回调表格数据。
                if (this.onBatSave) {
                    this.onBatSave();
                }
            });
        },
        onXLSExport() {
            if (this.formBoList.isConfig == 'NO') {
                var self = this;
                this.dialogBox.openExportExcelDialog({
                    curVm: self,
                    data: {name: this.formBoList.name, boListKey: this.formBoList.key, queryParam: this.queryParam},
                    widthHeight: ['1400px', '700px']
                });
            }
        },
        onImport() {
            var self = this;
            this.dialogBox.openImportExcelDialog({
                curVm: self,
                data: {name: this.formBoList.name, boListKey: this.formBoList.key},
                widthHeight: ['800px', '600px']
            }, function () {
                self.onRefresh();
            })
        },
        //办理任务
        async handleTask(record) {
            this.openInst(record.instId ? record.instId : record.INST_ID_);
        },
        //流程明细
        bpmDetail(record) {
			this.openDetail(record.instId ? record.instId : record.INST_ID_);
        },
        //打开自定义页面
        openComponent(config, callBack) {
            this.dialogBox.openComponent(config, callBack);
        },

        /**
         * 打开表单
         * @param formAlias 表单方案 “{\"text\":\"测试0703\",\"value\":\"cs0703\"}”
         * @param pkField 主键字段
         * @param readOnly 只读 ‘true’ or 'false'
         * @param row   当前行数据
         * @param fieldMap  字段映射配置 destField(目标字段)  srcField(列表字段)
         * "[{"destField":"xlk","srcField":"F_XLK","idx_":1}]"
         * @returns {*}
         */
        openForm(formAlias, pkField, readOnly, row, fieldMap, callback) {
            if (!formAlias) {
                this.$message.error("请绑定表单方案！");
                return;
            }
            var obj = JSON.parse(formAlias);
            var fieldMap_ = JSON.parse(fieldMap);
            var readOnly_ = readOnly == 'true' ? true : false;
            var urlType = readOnly_ ? "Details" : "EditRow";
            var pkId = "";
            if (pkField) {
                pkId = row[pkField];
            }
            var self = this;
            let config = {
                title: obj.text,
                curVm: self,
                data: {
                    alias: obj.value,
                    pkId: pkId,
                    readOnly: readOnly_,
                    //将表单映射数据提交到表单数据。
                    setInitData(data) {
                        if (row) {
                            for (var i = 0; i < fieldMap_.length; i++) {
                                data[fieldMap_[i].destField] = row[fieldMap_[i].srcField];
                            }
                        }
                        return data;
                    }
                },
                max: true,
                shade: true,
                urlType: urlType,
            }
            this.dialogBox.showForm(config, function (action) {
                if (callback) {
                    var call = "self." + callback + "(row,self)";
                    eval(call);
                }
                self.onRefresh();
            });
        },
        /**
         * @param obj
         *  {text: "业务方案"value: "业务方案ID" }
         * @param rowData 当前行数据
         * @param readOnly
         * @param callback
         * @returns {*}
         */
        showBusSolutionForm(obj,rowData,readOnly,callback){
            var self=this;
            if (obj.readOnly) {
                readOnly=obj.readOnly ;
            }
            let config = {
                title: this.formBoList.name + '--添加',
                curVm: self,
                data: {
                    alias: obj.text,
                    rowData: rowData,
                    busSolId: obj.value,
                    readOnly: readOnly,
                    //将表单映射数据提交到表单数据。
                    setInitData(data) {
                        if (self.formdata) {
                            Object.assign(data, self.formdata);
                        }
                        return data;
                    }
                },
                max: true
            }
            this.dialogBox.showBusSolutionForm(config, function (action) {
                if (callback) {
                    var call = "self." + callback + "(row,self)";
                    eval(call);
                }
                self.onRefresh();
            });
        }
    }
}