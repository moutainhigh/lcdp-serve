import rxAjax from '@/assets/js/ajax.js';

//门户定义 api接口
export const InsPortalDefApi = {};

InsPortalDefApi.baseUrl= '/api-portal/portal/core/insPortalDef';
InsPortalDefApi.exportUrl= InsPortalDefApi.baseUrl + '/export';




//根据月份日程数据
InsPortalDefApi.getCalendarMonthData =function(calendarValue) {
  var url= InsPortalDefApi.baseUrl + '/getCalendarMonthData?calendarValue='+calendarValue;
  return rxAjax.get(url);
}

//根据月份/日期查询日程数据
InsPortalDefApi.getDataByQueryTypeAndVal =function(parameter) {
  var url= InsPortalDefApi.baseUrl + '/getMonthOrDayData';
  return rxAjax.postJson(url,parameter);
}

//查询列表
InsPortalDefApi.query=function (parameter) {
  var url= InsPortalDefApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

//根据门户Id查询列表
InsPortalDefApi.getListByPortalId=function (portId) {
  var url= InsPortalDefApi.baseUrl + '/getListByPortalId?portId=' + portId;
  return rxAjax.get(url).then (res => {
    return res.data
  });
}

//保存门户布局列表数据
InsPortalDefApi.saveAll =function(parameter) {
  var url= InsPortalDefApi.baseUrl + '/saveAll';
  return rxAjax.postJson(url,parameter);
}

/**
 *根据栏目ID获取栏目数据
 * @param baseConf
 * @param config
 * @param callback
 */

InsPortalDefApi.getDataByColId=function (colId) {
  var url= InsPortalDefApi.baseUrl + '/getDataByColId?colId=' + colId;
  return rxAjax.get(url).then (res => {
    return res.data
  });
}

//根据门户Id查询列表
InsPortalDefApi.getLayoutListByPortalId=function (portalId) {
  var url= InsPortalDefApi.baseUrl + '/getLayoutListByPortalId?portalId='+portalId;
  return rxAjax.get(url).then (res => {
    return res.data
  });
}

//根据门户Key查询列表
InsPortalDefApi.getLayoutListByPortalKey=function (portalKey) {
  var url= InsPortalDefApi.baseUrl + '/getLayoutListByPortalKey?portalKey='+portalKey;
  return rxAjax.get(url).then (res => {
    return res.data
  });
}

//根据当前登录用户获取门户数据
InsPortalDefApi.getLayoutListByLoginUser=function () {
  var url= InsPortalDefApi.baseUrl + '/getLayoutListByLoginUser';
  return rxAjax.get(url).then (res => {
    return res.data
  });
}



//------------------insPortalLayout.js  搬迁过来------

/**
* 获取单记录
* @param pkId
* @returns {*}
*/
InsPortalDefApi.get =function(pkId) {
  var url= InsPortalDefApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

//保存数据
InsPortalDefApi.save =function(parameter) {
  var url= InsPortalDefApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

//删除数据
InsPortalDefApi.del =function(parameter) {
  var url= InsPortalDefApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

//根据应用ID获取当前人的门户
InsPortalDefApi.getCurUserPortalByAppId=function(appId) {
    var url= InsPortalDefApi.baseUrl + '/getCurUserPortalByAppId?appId=' + appId;
    return rxAjax.get(url);
}

export  default InsPortalDefApi;

