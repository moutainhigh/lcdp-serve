<template>
    <div id="rx-form-container">
        <div v-if="localData.length==1">
            <k-form-build
                v-if="localData[0].type=='EASY-DESIGN'"
                :javascript="javascript"
                :value="jsonData"
                :alias="localData[0].alias"
                :formDesigner="true"
                :ref="'rxForm_'+localData[0].alias"
                :readOnly="readonly"
            />

            <rx-form v-else :ref="'rxForm_'+localData[0].alias"></rx-form>
        </div>
        <div v-else-if="localData.length>1">
            <!--        <a-tabs  class="rxTabs">-->
            <a-tabs>
                <template v-for="(item,index) in localData">
                    <a-tab-pane :tab="item.title" :forceRender="true" :key="item.alias">
                        <div class="rxContent">
                            <k-form-build v-if="item.type=='EASY-DESIGN'"
                                          :javascript="javascript"
                                          :value="jsonData"
                                          :alias="item.alias"
                                          :formDesigner="true"
                                          :ref="'rxForm_'+item.alias"
                                          :readOnly="readonly"
                            />
                            <rx-form v-else :ref="'rxForm_'+item.alias" style="box-sizing: border-box;"></rx-form>

                        </div>

                    </a-tab-pane>
                </template>
            </a-tabs>

        </div>
        <div v-else>
            <div v-if="!formloaded" class="loadInfo">
                <div class="loadInfolist">
                    <a-spin size="large"/>
                </div>

                亲，系统正在加载单据，请稍侯...
            </div>
            <div v-else class="loadInfo">
                <a-empty :description="false"/>
                加载表单失败...,请联系管理员。
            </div>
        </div>
    </div>


</template>

<script>
import {rxForm} from "jpaas-form-component";
import rxAjax from '@/assets/js/ajax.js';
import FormUtil from "../../form/core/FormUtil";

export default {
    name: "rx-forms",
    data() {
        return {
            localData: [],
            formloaded: false,
            contextData: {},
            jsonData: {},
            javascript: "",
            //表单实例
        }
    },
    components: {
        rxForm
    },
    created() {
    },
    methods: {
        /*
        数据结构。
        [{
          name:"表单名称",
          alias:"别名",
          data:{

          }
        }]

        contextData:{
          curUserId:"",
          curUserName:"",
          nodeId:"",
          instId:"",
          defId:"",
          taskId:"",
          opinionHistorys:""  //审批意见历史
        }
         */
        setData(aryData, readonly, contextData) {
            if (!aryData) {
                return;
            }
            this.localData = aryData;
            this.contextData = contextData;
            this.formloaded = true;
            this.readonly = readonly;
            this.loadForms();
        },
        async loadForms() {
            for (var i = 0, j = this.localData.length; i < j; i++) {
                if (this.localData[i].type == 'EASY-DESIGN') {
                    await this.changeEasyTab(this.localData[i]);
                } else {
                    var alias = this.localData[i].alias;
                    await this.changeTab(alias);
                }
            }
        },
        getFormRef(key) {
            var ref = (this.localData.length == 1) ? this.$refs[key] : this.$refs[key][0]
            return ref;
        },

         getData() {
           let rtn ={};
            for (var i = 0; i < this.localData.length; i++) {
                let formData = this.localData[i];
                let _type = formData.type
                let alias = formData.alias;
                if (_type == 'EASY-DESIGN') {
                    rtn[alias] = this.$refs['rxForm_' + formData.alias].getData() ;
                }else {
                    rtn[alias] = formData.data;
                }
            }
            return rtn;
        },
        getMetadata() {
            let rtn ={};
            for (var i = 0; i < this.localData.length; i++) {
                let formData = this.localData[i];
                let _type = formData.type
                let alias = formData.alias;
                if (_type == 'EASY-DESIGN') {
                    rtn[alias] = this.$refs['rxForm_' + formData.alias].metadata ;
                }else {
                    rtn[alias] = JSON.parse(formData.metadata);
                }
            }
            return rtn;
        },
        getOpinionData() {
            var opinionObj = {
                name: "",
                value: ""
            };
            for (var i = 0; i < this.localData.length; i++) {
                var formData = this.localData[i];
                var alias = formData.alias;
                if (formData.opinionSetting) {
                    var name = "";
                    for (var j = 0; j < formData.opinionSetting.length; j++) {
                        if (formData.opinionSetting[j].setOpinion) {
                            name = formData.opinionSetting[j].name;
                        }
                    }
                    var key = this.getFormKey(alias);
                    var opinionData = this.$refs[key].getOpinionData();
                    opinionObj.name = name;
                    opinionObj.value = opinionData[name];
                }
            }
            return opinionObj;
        },
        getDataByKey(key) {
            for (var i = 0; i < this.localData.length; i++) {
                var formData = this.localData[i];
                var alias = formData.alias;
                if (key == alias) {
                    return formData;
                }
            }
            return {};
        },
        getFormKey(alias) {
            var key = "rxForm_" + alias;
            return key;
        },
        changeEasyTab(tabJson) {
            this.$nextTick(function () {
                var key = this.getFormKey(tabJson.alias);
                var ref = this.getFormRef(key);
                var formData = this.getDataByKey(tabJson.alias);
                ref.setData(formData);
            })
            this.jsonData = JSON.parse(tabJson.metadata);
            this.javascript = tabJson.script;
        },
        changeTab(tab) {
            this.$nextTick(() => {
                var key = this.getFormKey(tab);
                var ref = this.getFormRef(key);
                var formData = this.getDataByKey(tab);
                var tmp = FormUtil.getTemplate(formData);
                formData.template = `<div class="previewBox">${tmp}</div>`;
                //if (!ref.loaded) {
                //    ref.loaded = true;
                    ref.loadForm(formData, this.readonly, this.contextData);
                //} else {
                //    ref.reloadData(formData);
                //}
            })
        },
        /**
         * 设置表单只读。
         * @param readonly
         */
        setReadonly(readonly) {
            for (var i = 0; i < this.localData.length; i++) {
                var formData = this.localData[i];
                var alias = formData.alias;
                var key = this.getFormKey(alias);
                var ref = this.getFormRef(key);
                ref.setReadonly(readonly);
            }
        },
        afterSubmit(result, formJson) {
            var rxForms = this.$refs;
            for (var formKey in rxForms) {
                let form = rxForms[formKey];
                if (form instanceof Array) {
                    form = form[0]
                }
                if (formKey.startsWith("rxForm_") && form && form.formVm) {
                    if (form.formVm._afterSubmit) {
                        form.formVm._afterSubmit(result, formJson);
                    }
                }
            }
        },
        //validRequired:必填校验  validType类型校验
        async valid(validRequired, validType) {
            var rxForms = this.$refs;
            for (var formKey in rxForms) {
                let form = rxForms[formKey];
                if (form instanceof Array) {
                    form = form[0]
                }
                if (formKey.startsWith("rxForm_") && form && form.formVm) {
                    if (form.formVm._beforeSubmit) {
                        var rtn = await form.formVm._beforeSubmit();
                        if (!rtn.success) {
                            return rtn;
                        }
                    }
                    var res = form.formVm.valid(validRequired, validType);
                    if (!res.success) {
                        return res;
                    }
                    //表单唯一性校验
                    let validMainUnique = await form.formVm.validMainUnique();

                    if (!validMainUnique.success) {
                        return validMainUnique;
                    }
                }

            }
            return {success: true}
        },
    }
}
</script>

<style scoped>
.loadInfo {
    padding: 5px;
    text-align: center;
    margin: auto;
    width: 350px;
}

#rx-form-container >>> .table-form {
    width: calc(100% - 2px) !important;
}

</style>