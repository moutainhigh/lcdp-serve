<template>
  <div class="rxEmptyBoxs">
    <div class="rxEmpty">
      <a-empty />
    </div>
  </div>
</template>

<script>
export default {
  name: "rxEmpty"
}
</script>

<style scoped>
.rxEmptyBoxs{
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>