import Vue from 'vue'
import {mapState} from "vuex";


export  default {
	computed: {
		...mapState({
			menus: state => state.appSetting.menus,
			selectMenu: state => state.appSetting.selectMenu,
		}),
	},
	data(){
		return {}
	},
	methods:{
		loadView(view) { // 路由懒加载
			debugger;
			return () => import(`@/views/${view}`)
		},
		getSelectMenus (menus,menuId) {
			var selectMenus=[];
			for (var i = 0; i < menus.length; i++) {
				if(menus[i].id==menuId){
					selectMenus.push(menus[i]);
					break;
				}else {
					if(menus[i].children&&menus[i].children.length>0){
						var res=this.getSelectMenus(menus[i].children,menuId);
						if(res&&res.length>0){
							selectMenus= res;
							break;
						}
					}
				}
			}
			return selectMenus;
		}
	}
}
