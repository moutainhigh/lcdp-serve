import FormSolutionApi from "@/api/form/core/formSolution";
import DialogBox from "@/assets/js/DialogBox";
import FormPdfHtml from "@/views/modules/form/core/FormPdfHtml";
import {Util} from "jpaas-common-lib";
import getLodop from "@/utils/LodopFuncs";
import FormPrintLodopApi from "@/api/form/core/formPrintLodop";

export default {

    methods:{
        async handMethod(btn) {

            let rxForm=this.$refs.rxForm;
            var res=await FormSolutionApi.validPreByButton(btn.preCondConfig,JSON.stringify(rxForm.getData()));
            if(!res.success){
                this.$message.error(res.message);
                return;
            }
            //表单方法
            if(btn.type=="formMethod"){
                var method = "func_" + btn.method;
                var formVm = rxForm.formVm;
                if (formVm && formVm[method]) {
                    formVm[method](this,btn);
                }
                return;
            }
            //自定义方法
            if(btn.type=="custom"){
                this["func_" + btn.method] = function () {
                    let formJson = rxForm.getData();
                    let rxAjax = this.rxAjax;
                    let config=btn.config;
                    eval(config.action);
                };
                this["func_" + btn.method](btn);
                return;
            }
            //调用预定义方法。
            this[btn.method](btn);

        },
        /**
         * 打开自定义表单。
         * @param btn
         */
        openCustomForm(btn) {
            let self_ = this;
            let formJson = {};
            let config=btn.config;
            let formVm=this.$refs.rxForm;
            formJson[formVm.formVm.alias] = formVm.getData();
            FormSolutionApi.getValueByCustomFormConfig({
                formJson: formJson,
                formConfig: config.formConfig || []
            }).then(res => {
                DialogBox.showForm({
                    title: config.formName,
                    curVm: self_,
                    data: {
                        alias: config.formAlias, setInitData: function (data) {
                            return Object.assign(data, res);
                        }
                    },
                    max: true
                }, function (action) {
                });
            })
        },
        /**
         * pdf打印
         * @param btn
         */
        pdfPrint(btn) {
            let rxForm=this.$refs.rxForm;
            var dataJson = rxForm.getData();
            //打开pdf模板
            var self = this;
            var conf = {
                component: FormPdfHtml,
                title: name + 'pdf模板',
                widthHeight: [`100%`, `100%`]
            }
            let btnConfig=btn.config;
            var baseConf = {
                curVm: self,
                data: {   //传递参数
                    pkId: btnConfig.defId,
                    dataJson: dataJson,
                    metadata:rxForm.metadata
                }
            }
            let config = Object.assign(baseConf, conf)
            Util.open(config, function (action) {
            })
        },
        print() {
            let formVm=this.$refs.rxForm;
            var dataJson = formVm.getData();
            var url ="/formprint/" + this.formSolutionAlias;
            var portalUrl = window.localStorage.getItem('portalUrl');
            if (portalUrl) {
                url = portalUrl + url;
            } else {
                url = "/jpaas" + url;
            }
            if (this.pkId) {
                url += "/" + this.pkId;
            }
            window['_getFormData_'+this.formSolutionAlias]=function(){
                return dataJson;
            }
            window.open(url);
        },
        /**
         * ureport打印
         * @param btn
         */
        ureportPrint(btn) {
            let rxForm=this.$refs.rxForm;
            var json = rxForm.getData();
            if (!json.ID_) {
                this.$message.warning('编辑状态才能打印!');
                return;
            }
            let btnConfig=btn.config;
            //获得当前编辑数据的ID
            var url = "/ureport/preview?_u=qiaolin-" + btnConfig.name + "&Id=" + json.ID_;
            window.open(url);
        },
        /**
         * 套打。
         * @param btn
         */
        printLodop(btn) {
            let defId=btn.config.defId;
            if (!defId) {
                this.$message.warning("未绑定套打模板!");
                return;
            }
            var lodop = getLodop(this);
            if (!lodop) {
                return;
            }
            //初始化任务名称
            lodop.PRINT_INIT(btn.config.name);
            FormPrintLodopApi.printHtml({
                pkId: defId,
                formData: JSON.stringify(this.$refs.rxForm.getData())
            }).then(res => {
                eval(res.data);
                //打印预览
                lodop.PREVIEW();
            })
        },

        removeSpaces(data) {
            //清除字段前后空格；
            let _data = JSON.parse(JSON.stringify(data));
            for (var key in _data) {
                var item = _data[key];
                if (typeof item == "string" && item != "") {
                    _data[key] = item.trim();
                } else if (item && Object.prototype.toString.call(item) == "[object Array]") {
                    var _self = this;
                    item.forEach((itm, idx) => {
                        _data[key][idx] = _self.removeSpaces(itm);
                    })
                } else if (item && Object.prototype.toString.call(item) == "[object Object]") {
                    _data[key] = this.removeSpaces(item);
                }
            }
            return _data;
        },
        parseButtons(res){

            let instStatus=res.data.INST_STATUS_;
            var temp=[];
            var btns = res.buttons ? JSON.parse(res.buttons) : [];
            for (var i = 0; i < btns.length; i++) {
                var btn = btns[i];
                if(!this.rxReadOnly){
                    //编辑
                    if(btn.mode && btn.mode.indexOf("edit")==-1){
                        continue;
                    }
                }else{
                    //明细
                    if(btn.mode && btn.mode.indexOf("detail")==-1){
                        continue;
                    }
                }

                if (btn.type=="flowImage" && !this.flowInstId) {
                    continue;
                }
                if(btn.method=="startFlow" && !this.canStartFlow){
                    continue;
                }
                if(btn.method=="submit" && instStatus && instStatus!='CANCEL' && instStatus!='DRAFTED'){
                    this.canStartFlow = false;
                }
                btn.loading = false;
                temp.push(btn);
            }
            return temp;
        },
        dataChange(data){
            var self_=this;
            FormSolutionApi.getButtonsByFormJson(this.formSolution.alias,data).then(res=>{
                self_.buttons = self_.parseButtons(res);
            })
        }
    }
}