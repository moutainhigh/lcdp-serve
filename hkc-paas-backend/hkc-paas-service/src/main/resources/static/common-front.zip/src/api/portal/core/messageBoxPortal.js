/**
 * 消息盒子扩展
 */
export default {
    data(){
        return {
            listCount: 6,
            listWidth: 0,
        }
    },
    computed: {
        listWidthFn: function () {
            let _coun = this.listCount ;
            return "calc( 100% / "+ _coun +" )";
        }
    },
    methods:{
        //初始化方法。
        init_MessageBel(){
            if (this.insColumnDef.setTing) {
                var setTingObj = JSON.parse(this.insColumnDef.setTing);
                if (setTingObj && setTingObj.listCount) {
                    this.listCount = setTingObj.listCount;
                }
            }

            this.loadData();
        }

    }
}