export const ACCESS_TOKEN = 'Access-Token';
//根租户的ID
export const ROOT_TENANT="1";
//跳转的登录页面url
export const LOGIN_URL="/sso/login";