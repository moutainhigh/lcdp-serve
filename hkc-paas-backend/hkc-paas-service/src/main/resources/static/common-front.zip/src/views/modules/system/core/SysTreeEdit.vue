<template>
  <rx-dialog @handOk="handleSubmit" @cancel="cancel">
    <rx-layout>
      <div slot="center">
        <a-form :form="form">
          <a-form-item style="display: none;">
            <a-input v-decorator="['treeId']"/>
            <a-input v-decorator="['parentId',{initialValue:mdl.parentId}]"/>
              <a-input v-decorator="['appId',{initialValue:mdl.appId?mdl.appId:curApp.appId}]"/>
          </a-form-item>
          <a-form-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="上级名称"
                       v-if="mdl.parentName && mdl.parentName!=''">
            <a-input :disabled="true" v-model="mdl.parentName"/>
          </a-form-item>
          <a-form-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="名称">
            <a-input placeholder="名称" v-decorator="['name', {rules: [{required: true, message: '请输入名称'}]}]"/>
          </a-form-item>
          <a-form-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="节点别名">
            <a-input placeholder="节点别名" v-decorator="['alias', {rules: [{required: true, message: '请输入节点别名'}]}]"/>
          </a-form-item>
          <a-form-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="分类">
            <a-select placeholder="分类"
                      :getPopupContainer="p=>p.parentNode"
                      v-decorator="['catKey', {initialValue:mdl.catKey, rules: [{required: true, message: '请输入树分类'}]}]">
              <a-select-option v-for="cat in catList" :value="cat.key" :key="cat.key">{{cat.name}}</a-select-option>
            </a-select>
          </a-form-item>
          <a-form-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="序号">
            <a-input-number :min="1" :max="10000" placeholder="序号"
                            v-decorator="['sn', {
                          initialValue:1,
                          rules: [{required: true, message: '请输入序号'}]}]"/>
          </a-form-item>
        <a-form-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="所属应用"
                     v-if="curApp.appName && curApp.appName !=''" v-show="false">
            <a-input :disabled="true" v-model="curApp.appName"/>
        </a-form-item>
          <a-form-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="展示类型" v-if="displayDataShowType">
            <a-radio-group buttonStyle="solid"  v-decorator="['dataShowType', {initialValue:'FLAT',rules: [{required: false, message: '请输入展示类型'}]}]">
              <a-radio-button value="FLAT">平铺</a-radio-button>
              <a-radio-button value="TREE">树型</a-radio-button>
            </a-radio-group>
          </a-form-item>

        </a-form>
      </div>
    </rx-layout>

  </rx-dialog>
</template>
<script>
  import SysTreeApi from '@/api/system/core/sysTree';
  import SysTreeCatApi from '@/api/system/core/sysTreeCat'
  import {BaseForm,RxDialog,RxLayout } from 'jpaas-common-lib';
  export default {
    name: 'SysTreeEdit',
    mixins:[BaseForm],
    props: {
      data:Object,
      layerid: String,
      lydata: Object,
      destroy: Function,
      displayDataShowType:{
        type:Boolean,
        default:false
      }
    },
    components: {
      RxDialog,
      RxLayout
    },
    data() {
      return {
        catList:[],
      }
    },
    created() {
      SysTreeCatApi.getCatList().then(res => {
        console.log(res)
        this.catList=res;
      })
    },
    methods: {
      onload_(vals){
        if(!this.pkId){
          Object.assign(this.mdl,this.data);
        }
      },
      get(id){
        return SysTreeApi.get(id);
      },
      save(values){
        return SysTreeApi.save(values);
      },

    }
  }


</script>
<style scoped>
  *>>>.ant-row.ant-form-item:last-child{
      margin-bottom: 0;
  }
</style>