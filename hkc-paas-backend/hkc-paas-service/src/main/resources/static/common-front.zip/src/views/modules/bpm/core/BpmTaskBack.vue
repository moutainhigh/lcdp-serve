<template>
  <rx-dialog @handOk="handleCompleteCheck" @cancel="closeWindow" :oktext="'提交'" order="buttom" btnalign="center">
    <rx-fit>
      <div style="height:100%;width:100%;padding:20px;">
        <a-form>
          <a-form-item label="驳回方式" :label-col="labelCol" :wrapper-col="wrapperCol">
            <a-radio-group v-model="checkType" :options="backs">
            </a-radio-group>
          </a-form-item>
          <a-form-item v-if="checkType=='BACK_TO_STARTOR'" label="回退任务完成后" :label-col="labelCol" :wrapper-col="wrapperCol">
            <a-radio-group v-model="nextJumpType">
              <a-radio value="normal">正常执行</a-radio>
              <a-radio value="source">原路返回</a-radio>
            </a-radio-group>
          </a-form-item>


          <a-form-item label="意见" :label-col="labelCol" :wrapper-col="wrapperCol">
            <a-textarea placeholder="请填写意见" v-model="opinion"></a-textarea>
          </a-form-item>

          <a-form-item label="附件" :label-col="labelCol" :wrapper-col="wrapperCol">
              <rx-attach-component v-model="fileList" ></rx-attach-component>
          </a-form-item>

          <a-form-item label="抄送" :label-col="labelCol" :wrapper-col="wrapperCol">
              <rx-user-component v-model="copyUsers" :isAccount="true" :single="false"></rx-user-component>
          </a-form-item>
          <a-form-item label="通知方式" :label-col="labelCol" :wrapper-col="wrapperCol">
            <a-checkbox-group :options="msgOptions" v-model="msgTypes"></a-checkbox-group>
          </a-form-item>
        </a-form>
      </div>
    </rx-fit>
  </rx-dialog>
</template>
<script>
  import { Dialog, RxDialog,RxAttachComponent,RxUserComponent, Util, RxFit, RxTextBoxList } from 'jpaas-common-lib'
  import BpmtaskApi from '@/api/bpm/core/bpmTask'
  import BpmPublicApi from '@/api/bpm/core/BpmPublicApi'


  export default {
    name: 'bpm-task-back',
    components: {
        RxFit,
        RxTextBoxList,
        RxDialog,
        RxUserComponent,
        RxAttachComponent
    },
    props: {
      taskId: {
        type: String,
        required: true
      },
      formJson: String,
      layerid: String,
      lydata: Object,
      destroy: Function,
      backOptions:Array,
      opinionObj:{
        type:Object,
        default:{
          name:"",
          value:""
        }
      }
    },
    data() {
      return {
        labelCol: { span: 4 },
        wrapperCol: { span: 8 },
        msgOptions:[],
        checkType: '',
        nextJumpType:'normal',
        destNodeId: '',
        opinion: '',
        msgTypes: [],
        fileList:[],
        copyUsers: [],
        opinionName:"",
        backs:[
          {label: '驳回上一步', value: 'BACK'},
          {label: '驳回到发起人', value: 'BACK_TO_STARTOR'},
        ],
        backNodes:[]
      }
    },
    created(){
      if(this.backOptions.length==0){
          this.backOptions.push(...['BACK','BACK_TO_STARTOR']);
      }
      var tmp=[];
      for(var i=0;i<this.backs.length;i++){
          if(this.backOptions.contains(this.backs[i].value)){
              tmp.push(this.backs[i]);
          }
      }
      this.checkType=tmp[0].value;
      this.backs=tmp;
      this.opinion=this.opinionObj.value;
      this.opinionName=this.opinionObj.name;
      this.initMessageHandler();
      this.initBackNodes();
    },
    methods: {
      initBackNodes(){
        BpmtaskApi.getBackNodes(this.taskId).then(res=>{
          this.backNodes=res.map(item=>{
            return {label:item.nodeName,value:item.nodeId};
          })
        });
      },
      initMessageHandler(){
        BpmPublicApi.getMessageHandler().then(res=>{
          for(var i=0;i<res.length;i++){
            var o=res[i];
            var obj={ label: o.name, value: o.type };
            this.msgOptions.push(obj);
          }
        })
      },
      handleCompleteCheck() {
        let self = this;
        //抄送用户
        let copyUserIds=this.getCopyUserAccounts();
        let noticeTypes=this.msgTypes.join(",");
        let cmd = {
          taskId: this.taskId,
          checkType: this.checkType,
          nextJumpType: this.nextJumpType,
          opinion: this.opinion,
          msgTypes: noticeTypes,
          copyUserAccounts: copyUserIds,
          formJson:  self.formJson,
          opinionName:self.opinionName,
          opFiles:JSON.stringify(self.fileList)
        }
        if(this.checkType=='BACK_SPEC') {
          if(!this.destNodeId){
            alert("请指定节点！");
            return;
          }
          cmd.destNodeId = this.destNodeId;
        }

        BpmtaskApi.checkComplete(cmd).then(resp => {
          if (resp.success) {
            Util.closeWindow(self,'ok');
          }
        })
      },
        /**
         * 获取抄送用户。
         * @returns {string}
         */
        getCopyUserAccounts(){
            var accounts=[];
            if(this.copyUsers && this.copyUsers.length>0){
                this.copyUsers.forEach(item=>{
                    accounts.push(item.account);
                })
            }
            return accounts.join(",");
        },
      closeWindow() {
        Util.closeWindow(this, 'cancel')
      }
    }
  }
</script>