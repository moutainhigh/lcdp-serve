import rxAjax from '@/assets/js/ajax.js';
//表单公共 api接口
const PublicApi = {};

PublicApi.baseUrl= '/api-form/form/core/public';

PublicApi.getAppServices=function () {
  var url= PublicApi.baseUrl + '/getAppServices';
  return rxAjax.get(url);
}

PublicApi.getParams=function (setting) {
  var url= PublicApi.baseUrl + '/getParams';
  return rxAjax.postJson(url,setting);
}

export  default PublicApi;