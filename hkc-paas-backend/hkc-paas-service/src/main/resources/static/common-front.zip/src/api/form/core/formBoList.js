import rxAjax from '@/assets/js/ajax.js';
import FormUtil from "@/assets/js/FormUtil";


//系统自定义业务管理列表 api接口
export const FormBoListApi = {};

FormBoListApi.baseUrl= '/api-form/form/core/formBoList';
FormBoListApi.exportUrl= FormBoListApi.baseUrl + '/export';

FormBoListApi.doImport=function(formData,callback) {
  var url= FormBoListApi.baseUrl+"/doImport";
  return rxAjax.upload(url,formData,callback);
}


FormBoListApi.doExport = function(solutionIds) {
  window.location.href='/api/api-form/form/core/formBoList/doExport?solutionIds=' + solutionIds;
}

//查询列表
FormBoListApi.query=function (parameter) {
  var url= FormBoListApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

 FormBoListApi.export=async function (parameter) {
    var canExportUrl= FormBoListApi.baseUrl + '/canExportExcel';
    var result=await rxAjax.postForm(canExportUrl,parameter);
    if(result.success){
        var url= FormBoListApi.baseUrl + '/exportExcel';
        var config={responseType:'arraybuffer'}
        return rxAjax.download(url,parameter, config);
    }

}


//查找所查询的数据并导出
FormBoListApi.listExport= function (parameter){
    var url= FormBoListApi.baseUrl + '/listExport';
    FormUtil.doExport(url,parameter);
}



/**
* 获取单记录
* @param pkId
* @returns {*}
*/
FormBoListApi.get =function(pkId) {
  var url= FormBoListApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

FormBoListApi.getByKey =function(listKey){
  var url= FormBoListApi.baseUrl + '/getByKey?listKey=' + listKey;
  return rxAjax.get(url);
}

FormBoListApi.dialog=function(conf){
  var url= FormBoListApi.baseUrl + '/' + conf.key +'/dialog';
  if(conf.params){
    url+="?" + conf.params;
  }
  if(conf.menuId){
      if(url.indexOf("?")==-1){
          url+="?menuId=" +conf.menuId;
      } else{
          url+="&menuId=" +conf.menuId;
      }
  }
  if(conf.pmtAlias){
      if(url.indexOf("?")==-1){
          url+="?pmtAlias=" +conf.pmtAlias;
      } else{
          url+="&pmtAlias=" +conf.pmtAlias;
      }
  }
  if(conf.single){
    if(url.indexOf("?")==-1){
      url+="?single=" +conf.single;
    } else{
      url+="&single=" +conf.single;
    }
  }
  return rxAjax.get(url);
}

//保存数据
FormBoListApi.save =function(parameter) {
  var url= FormBoListApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

FormBoListApi.saveConfigJson =function(parameter){
  var url= FormBoListApi.baseUrl + '/saveConfigJson';
  return rxAjax.postJson(url,parameter);
}

//删除数据
FormBoListApi.del =function(parameter) {
  var url= FormBoListApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

//edit2页面数据
FormBoListApi.getEdit2 =function(id){
  var url= FormBoListApi.baseUrl + '/getEdit2?id='+id;
  return rxAjax.get(url);
}

FormBoListApi.reloadColumns =function (id) {
  var url= FormBoListApi.baseUrl + '/reloadColumns?id='+id;
  return rxAjax.get(url);
}

FormBoListApi.reloadColumnsExcel =function (id) {
    var url= FormBoListApi.baseUrl + '/reloadColumnsExcel?id='+id;
    return rxAjax.get(url);
}

FormBoListApi.reloadColumnsByKey =function (key) {
  var url= FormBoListApi.baseUrl + '/reloadColumnsByKey?key='+key;
  return rxAjax.get(url);
}

FormBoListApi.genHtml =function (id,remark) {
  var url= FormBoListApi.baseUrl + '/genHtml?id='+id+"&remark="+remark;
  return rxAjax.get(url);
}

FormBoListApi.genTreeHtml =function(id,remark){
    var url= FormBoListApi.baseUrl + '/genTreeHtml?id='+id+"&remark="+remark;
    return rxAjax.get(url);
}

FormBoListApi.saveHtml = function (parameter) {
  var url = FormBoListApi.baseUrl + '/saveHtml';
  return rxAjax.postJson(url, parameter);
}

FormBoListApi.onRun = function (parameter) {
  var url = FormBoListApi.baseUrl + '/onRun';
  return rxAjax.postJson(url, parameter);
}

FormBoListApi.setConf = function (parameter) {
  var url = FormBoListApi.baseUrl + '/' + parameter.key + '/config';
  return rxAjax.get(url);
}

FormBoListApi.importExcel = function (parameter) {
  var url = FormBoListApi.baseUrl + '/importExcel';
  return rxAjax.upload(url,parameter);
}

FormBoListApi.getListHistory =function(pkId) {
  var url= FormBoListApi.baseUrl + '/getListHistory?pkId=' + pkId;
  return rxAjax.get(url);
}


/**
 * 调用脚本。
 * @param alias
 * @param params
 * @returns {*}
 */
FormBoListApi.invoke= function(alias,params){
  var url="/api-system/system/core/sysInvokeScript/invoke/"+alias;
  return  rxAjax.postJson(url,params)
}
/**
 * 调用第三方接口
 * @param apiId
 * @param params
 * @returns {AxiosPromise|*}
 */
FormBoListApi.executeInterfaceApi=function(apiId,params){
    var url = "/api-system/system/core/sysInterfaceApi/executeApi?apiId="+apiId;
    return rxAjax.postJson(url,params);
}
/**
 * 给指定的URL提交JSON对象。
 * @param  url
 * @param  params json对象
 */
FormBoListApi.postJson= function(url,params){
  return  rxAjax.postJson(url,params)
}

/**
 * 发送post请求。
 * @param url
 * @param params
 * @returns {AxiosPromise | *}
 */
FormBoListApi.postJson= function(url,params){
  return  rxAjax.postJson(url,params)
}

/**
 * 发送get 请求。
 * @param url
 * @param params
 * @returns {*}
 */
FormBoListApi.getRequest=function(url,params){
  return  rxAjax.get(url,params)
}

/**
 * 调用自定义查询
 * @param sqlKey
 * @param params
 * @returns {AxiosPromise}
 */
FormBoListApi.queryForJson=function(sqlKey,params) {
  var url= "/api-form/form/core/formCustomQuery/queryForJson_"+sqlKey;
  return rxAjax.postForm(url,params);
}


/**
 * 获取表单数据导入处理器
 * @returns {*}
 */
FormBoListApi.getImportDataHandlers=function(){
    let url = '/api-form/form/core/public/getImportDataHandlers';
    return rxAjax.get(url);
}
/**
 * 获取表单方案所有字段
 * @param formAlias
 * @returns {*}
 */
FormBoListApi.getListFields =function(formAlias) {
    var url= 'api-form/form/core/formSolution/getListFields?formAlias=' + formAlias;
    return rxAjax.get(url);
}

//删除数据
FormBoListApi.delListHistory =function(parameter) {
  var url= '/api-form/form/core/listHistory/del';
  return rxAjax.postUrl(url,parameter);
}

export default FormBoListApi;

