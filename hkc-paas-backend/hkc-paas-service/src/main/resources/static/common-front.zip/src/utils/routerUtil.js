import SysMenuApi from "@/api/system/core/sysMenu";
import DialogView from "@/layouts/DialogView";
import MenuViewFun from "@/layouts/menuView/MenuViewFun";
import MenuViewFuns from "@/layouts/menuView/MenuViewFuns";
import MenuViewFunsBlock from "@/layouts/menuView/MenuViewFunsBlock";

/**
 * 动态构造路由。
 * @returns {Promise<any>}
 */
export const getRouters = (appKey) => {
	return new Promise((resolve, reject) => {
		getAppMenus(appKey,function (res) {
			var routers = [];
			let allMenus=res.allMenus;
			for (var i = 0; i < allMenus.length; i++) {
				var ary = [];
				var menu = allMenus[i];
				if (menu.settingType) {
					var rootPath = "/" + menu.key;
					var component =() => import( '@/layouts/MainLayout');
					var parentRouter = {
						id: menu.id,
						name: menu.key + "Home",
						path: rootPath + '/home',
						component: component
					};
					buildRouters(menu, ary);
					parentRouter.children = ary;
					routers.push(parentRouter);
				}
			}
			res.routers=routers;
			resolve(res);
		});

	})
}

/**
 * 根据appKey获取菜单和按钮信息。
 * @param appKey
 * @param callback
 */
function  getAppMenus(appKey,callback) {
	//获取菜单与当前用户
	SysMenuApi.getMenusByAppKey(appKey).then(res => {
		if (res && res.success) {
			var data=res.data.menus;
			var menuMap={};
			for(var i=0;i<data.length;i++){
				menuMap[data[i].id]=data[i];
			}
			var menus = buildMenu(res.data.menus);
			var btns=getButtons(res.data.menus);
			var obj={
				menus:menus.length>0?menus[0].children:[],
				buttons:btns,
				user:res.data.user,
				appId:res.data.app.appId,
				appName:res.data.app.appName,
				allButtons:res.data.allMenuButtons,
				menuMap:menuMap,
				allMenus:menus
			};
			callback(obj);
		}
	});
}

/**
 * 构建菜单
 * @param rows
 * @returns {*[]}
 */
function buildMenu(rows) {
	var newRows = [];
	rows.forEach(item => {
		if (item.menuType != "F") {
			newRows.push(item);
		}
	});
	const menus = [];
	buildTree(newRows, menus, '0');
	for (var i = 0; i < menus.length; i++) {
		if (menus[i].children) {
			menus[i].children.sort(compareSn('sn'));
		}
	}
	return menus;
}

/**
 * 排序
 * @param property
 * @returns {function(*, *)}
 */
function compareSn(property) {
	return function (obj, obj2) {
		return obj[property] - obj2[property]
	}
}

/**
 * 将菜单构建成树状
 * @param list
 * @param arr
 * @param parentId
 */
function buildTree(list, arr, parentId) {
	list.forEach(item => {
		if (item.parentId === parentId) {
			var child = {
				title: item.name,
				key: item.menuKey,
				id: item.id,
				sn: item.sn,
				icon: item.iconPc,
				showType: item.showType,
				menuType: item.menuType,
				settingType: item.settingType,
				component: item.component,
				layout: item.layout,
				parentModule: item.parentModule,
				params: item.params,
				children: [],
				appType:item.appType
			}
			buildTree(list, child.children, item.id)
			if (child.children.length === 0) {
				delete child.children
			}
			arr.push(child)
		}
	})
}

/**
 * 获取按钮
 * @param data
 * @returns {{}}
 */
function getButtons(data) {
	//[{id:"",key:""}]
	let apps= getAppList(data);
	if(!data || data.length==0){
		return {};
	}
	let appButtons={};
	data.forEach(item => {
		if(item.menuType ==="F"){
			var appId =  item.appId;
			var appKey = getAppKey(appId,apps);
			let menus=appButtons[appKey];
			if(menus){
				menus.push(item.menuKey);
			}else {
				menus=[item.menuKey];
				appButtons[appKey]=menus;
			}
		}
	});
	return appButtons;
}

/**
 * 获取应用Key
 * @param appId
 * @param apps
 * @returns
 */
function getAppKey(appId,apps) {
	let ary=apps.filter(item=>{
		return appId==item.id;
	})
	if(ary.length>0){
		return ary[0].key;
	}
	return "";

}

/**
 * 获取应用，返回 [{id:appId,key:appKey}]
 * @param data
 * @returns {appkey1:[]}
 */
function getAppList(data) {
	let apps = [];
	if(!data || data.length==0){
		return apps;
	}
	data.forEach(item => {
		//appId和应用id相同
		if(item.menuType ==="C" && item.appId===item.id){
			let obj={id:item.appId,key:item.menuKey};
			apps.push(obj);
		}
	});
	return apps;
}

/**
 * 构建路由
 * @param parent
 * @param routers
 */
function buildRouters(parent,routers) {
	if (!parent.children) {
		return;
	}
	for (var i = 0; i < parent.children.length; i++) {
		var menu = parent.children[i];
		var path=(parent.path || "")  + (parent.path ? "/": "") + menu.key;
		menu.path = path;
		if(menu.menuType != 'C'){
			continue;
		}


		var component = getComponent(menu);
		//判断是否需要拼接token url最后为&accessToken结尾则拼接token
		if (menu.params && typeof (menu.params) == 'string') {
			var str = menu.params.substring(menu.params.indexOf("&"));
			if (str == "&accessToken") {
				var accessToken = window.localStorage.getItem("pro__Access-Token") ? JSON.parse(window.localStorage.getItem("pro__Access-Token")).value : "";
				if (accessToken) {
					menu.params = menu.params + "=" + accessToken;
				}
			}
		}
		var router = {
			name: menu.key,
			path: path,
			component: component,
			meta: {
				params: menu.params,
				id: menu.id
			}
		};
		routers.push(router);

		buildRouters(menu, routers)
	}
}

function loadView(view){ // 路由懒加载
	return () => import(`@/views/${view}`)
}

export function getComponent(menu) {
	var component=null;
	if (menu.settingType == "iframe") {
		component = DialogView
	}
	//功能面板集(标签)
	else if(menu.showType == 'FUNS'){
		component = MenuViewFuns
	}
	//功能面板集
	else if(menu.showType == 'FUN'){
		component = MenuViewFun
	}
	//功能面板集(单页)
	else if(menu.showType == 'FUNS_BLOCK'){
		component = MenuViewFunsBlock
	}
	//VUE组件
	else if (menu.settingType == "custom") {
		component = loadView(menu.component);
	}
	return component;
}

export const getParentNode = (obj,id) =>{
	let getParent = (list,id) => {
		for (let i in list) {
			if (list[i].id == id) {
				return [list[i]]
			}
			if (list[i].children) {
				let node = getParent(list[i].children, id);
				if (node !== undefined) {
					return node.concat(list[i])
				}
			}
		}
	}
	return getParent(obj, id)
}
