<template>
    <rx-dialog @handOk="handleSubmit" @cancel="cancel">
        <a-form :form="form">
            <a-form-item style="display:none">
                <a-input v-decorator="['id']"/>
            </a-form-item>
            <a-row class="hearlist">
                <a-col :span="12">
                    <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="应用名称">
                        <a-input placeholder="应用名称"
                                 v-decorator="['name', {rules: [{required: true, message: '请输入应用名称'}]}]"/>
                    </a-form-item>
                </a-col>
                <a-col :span="12">
                    <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="图标">
                        <rx-input-icon v-decorator="['icon',{rules: [{ required: true, message: '请选择图标' }]}]" @change="iconChange"></rx-input-icon>
                    </a-form-item>
                </a-col>
            </a-row>
            <a-row>
                <a-col :span="12">
                    <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="类型">
                        <a-radio-group v-model="type">
                            <a-radio value="interior">内部</a-radio>
                            <a-radio value="outside">外部</a-radio>
                        </a-radio-group>
                    </a-form-item>
                </a-col>
                <a-col :span="12">
                    <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="序号">
                        <div >
                            <a-input-number :min="0" :max="1000000" placeholder="序号"
                                            v-decorator="['sn', {rules: [{required: true, message: '请输入序号'}]}]"/>
                        </div>
                    </a-form-item>
                </a-col>
            </a-row>
            <a-row>
                <a-col :span="12" v-show="type=='outside'">
                    <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="应用">
                        <a-input  placeholder="应用链接"
                                 v-decorator="['url', {rules: [{required: type=='outside', message: '请输入应用链接地址'}]}]"/>
                    </a-form-item>
                </a-col>
                <a-col :span="12" v-show="type=='interior'">
                    <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="应用">
                        <rx-input-button v-decorator="['app', {rules: [{required: type=='interior', message: '请选择应用'}]}]"  @click="openSystemAppDialog" ></rx-input-button>
                    </a-form-item>
                </a-col>
                <a-col :span="12">
                    <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="背景色">
                        <div >
                            <input type="color" class="onchange" v-model="bgColor" />
                        </div>
                    </a-form-item>
                </a-col>
            </a-row>

            <a-row>
                <a-col :span="24">
                    <a-form-item :labelCol="labelCol1" :wrapperCol="wrapperCol" label="描述">
                        <a-textarea class="urlWidthClass" placeholder="描述"
                                    v-decorator="['description', {rules: [{required: false, message: '请输入描述'}]}]"
                                    :rows="4"/>
                    </a-form-item>
                </a-col>
            </a-row>
        </a-form>
    </rx-dialog>
</template>
<script>
import InsAppCollectApi from '@/api/portal/core/insAppCollect'
import rxInputIcon from '@/components/rxComponent/rx-input-icon';
import {BaseForm, Dialog, RxDialog,Util } from 'jpaas-common-lib';
import AppDialog from "@/views/modules/portal/core/AppDialog";

export default {
    name: 'InsAppCollectEdit',
    mixins: [BaseForm],
    components: {
        RxDialog,rxInputIcon
    },
    props:["appType"],
    data() {
        return {
            icon: "",
            ownerId: "",
            bgColor:'#458bff',
            type:"interior"
        }
    },
    methods: {
        onload_(data) {
            if(data){
                if(data.ownerId){
                    this.ownerId = data.ownerId;
                }
                if(data.icon){
                    var iconfont =  JSON.parse(data.icon)
                    if(iconfont.bgColor){
                        this.bgColor =  iconfont.bgColor
                    }
                }
                if(data.type){
                    this.type = data.type;
                }
            }
        },
        iconChange(icon){
            this.form.setFieldsValue({'icon':icon});
        },
        get(id) {
            return InsAppCollectApi.get(id);
        },
        save(values) {
            if (this.ownerId) {
                values.ownerId = this.ownerId;
            }
            if(values.icon){
                var iconfont =  JSON.parse(values.icon)
                this.$set(iconfont,'bgColor',this.bgColor);
                values.icon = JSON.stringify(iconfont)
            }
            if (this.type) {
                values.type = this.type;
            }
            //custom default
            values.appType=this.appType?this.appType:'default';
            return InsAppCollectApi.save(values);
        },
        openSystemAppDialog(vm){
            let self = this;
            var conf = {
                component: AppDialog,
                data: {},
                curVm: this,
                widthHeight: ['800px', '600px'],
                title: '选择应用'
            }
            Util.open(conf, function (action,data) {
                if (action != 'ok') return;
                vm.setVal(data.key,data.name);
            });
        }

    }
}
</script>
<style scoped>
.onchange{
    border:none;
}
.hearlist {
    margin-top: 20px;
}

.widthClass {
    width: 80%;
}

.urlWidthClass {
    width: 91%;
}
</style>