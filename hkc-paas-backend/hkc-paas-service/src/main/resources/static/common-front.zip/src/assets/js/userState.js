import { mapState} from 'vuex';
import { ROOT_TENANT} from '@/store/mutation-types';
import OsGroupApi from '@/api/user/org/osGroup'

/**
 * 导出用户状态。
 */
export default {
  computed:{
    ...mapState({
      //用户对象
      user: state => state.appSetting.user,
      //是否根租户
      isRootTenant: state => state.appSetting.user.tenantId==ROOT_TENANT,
      //当前租户ID
      curentTenantId:state => state.appSetting.user.tenantId,
      //是否管理员
      isAdmin:state => state.appSetting.user.admin,
      //是否根租户管理员
      isRootAdmin:state => state.appSetting.user.admin && state.appSetting.user.tenantId==ROOT_TENANT,
      //当前分公司ID
      companyId:state=> state.appSetting.user.companyId

    })
  },
  data(){
        return {
            //组织分级管理开关
            supportGrade: false,
        }
  },
  created() {
        //获取组织分级管理开关配置
        this.getSupportGradeConfig();
  },
  methods:{
    /*
    记录是否能编辑
    1.租户私有的记录可以编辑。
    2.当前是根租户，并且记录租户ID为 0。
    */
    canEdit(record){
      if(this.isAdmin){
          return true;
      }
      //私有的数据可以删除
      if(!record.isPublic){
          return true;
      }
      if(this.curentTenantId==record.tenantId && this.companyId==record.companyId){
        return true;
      }
      return false;
    },

    canDel(record){
        if(this.isAdmin){
            return true;
        }
        //私有的数据可以删除
        if(!record.isPublic){
            return true;
        }
        if(this.curentTenantId==record.tenantId && this.companyId==record.companyId){
            return true;
        }
        return false;
    },

    getCheckboxProps(record){
      var canEdit=!this.canEdit(record);
      return {
        props: {
          disabled: canEdit
        }
      }
    },
    /**
    * 获取公司是否支持分公司管理。
    */
    getSupportGradeConfig() {
      OsGroupApi.getSupportGradeConfig().then(res => {
          this.supportGrade = res;
      })
    },

  }
}