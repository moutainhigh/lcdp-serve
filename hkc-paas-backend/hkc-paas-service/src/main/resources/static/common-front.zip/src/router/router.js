
export const constantRouterMap = [
	/*{
		path: '/:appKey',
		name: 'index',
		props: true,
		component: () => import( '@/layouts/MainLayout')
	},*/
	{
		path: '/',
		name: 'home',
		props: true,
		component: () => import( '@/layouts/MainLayout')
	}
]
