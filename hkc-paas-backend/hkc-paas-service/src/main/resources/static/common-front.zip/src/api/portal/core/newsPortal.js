import InsNewsApi from "@/api/portal/core/insNews";
/**
 * 新闻扩展。
 */
export default {
    data(){
        return {
            newType: '',
        }
    },
    methods:{
        init_NewsBel(){
            this.getNewType();
            //调用父类的加载数据的方法。
            this.loadData();
        },
        //阅读新闻公告
        getInsNews(pkId) {
            var self_ = this;
            InsNewsApi.getInsNews({
                curVm: this, data: { pkId: pkId, single: true,readonly:true }, widthHeight: ['1000px', '700px']
            }, function (self_, data) {
            });
        },
        //获取新闻类型
        getNewType() {
            var setting = JSON.parse(this.insColumnDef.setTing);
            if (setting && setting.newType) {
                this.newType = setting.newType;
            }
        },
        hasImage(data){
            if(!data){
                return false;
            }
            for(var i=0;i<data.length;i++){
                var o=data[i];
                if(o.imgFileId){
                    return true;
                }
            }
            return false;
        }

    }
}