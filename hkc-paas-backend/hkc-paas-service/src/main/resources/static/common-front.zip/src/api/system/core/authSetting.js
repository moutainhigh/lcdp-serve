var authSettings = {
  //流程分类相关权限
  "BPM":[{id:'1',type:'task',typeName:'待办任务权限',children:[
      {id:'5',parentId:'1',type:'read',typeName:'阅读权限',setting:'everyone',settingName:'所有人'}
    ]},
    {id:'2',type:'def',typeName:'流程定义权限',children:[
        {id:'6',parentId:'2',type:'read',typeName:'阅读权限',setting:'everyone',settingName:'所有人'},
        {id:'7',parentId:'2',type:'start',typeName:'启动',setting:'everyone',settingName:'所有人'},
        {id:'8',parentId:'2',type:'add',typeName:'添加',setting:'everyone',settingName:'所有人'},
        {id:'9',parentId:'2',type:'design',typeName:'设计',setting:'everyone',settingName:'所有人'},
        {id:'10',parentId:'2',type:'delete',typeName:'删除',setting:'everyone',settingName:'所有人'},
    ]},
    {id:'3',type:'inst',typeName:'流程实例权限',children:[
        {id:'11',parentId:'3',type:'read',typeName:'阅读权限',setting:'everyone',settingName:'所有人'},
        {id:'12',parentId:'3',type:'intervene',typeName:'干预',setting:'everyone',settingName:'所有人'},
        {id:'13',parentId:'3',type:'delete',typeName:'删除',setting:'everyone',settingName:'所有人'}
    ]},
    {id:'4',type:'start',typeName:'流程发起权限',children:[
        {id:'14',parentId:'4',type:'read',typeName:'阅读权限',setting:'everyone',settingName:'所有人'}
    ]}]
}

authSettings.getByType=function(type){
  var ary=authSettings[type];
  if(!ary){
    //默认权限
    ary=[{id:'1',type:'read',typeName:'阅读权限',setting:'everyone',settingName:'所有人'},
      {id:'2',type:'add',typeName:'添加权限',setting:'everyone',settingName:'所有人'},
      {id:'3',type:'edit',typeName:'编辑权限',setting:'everyone',settingName:'所有人'},
      {id:'4',type:'delete',typeName:'删除权限',setting:'everyone',settingName:'所有人'}];
  }
  return ary;
}


export default authSettings;