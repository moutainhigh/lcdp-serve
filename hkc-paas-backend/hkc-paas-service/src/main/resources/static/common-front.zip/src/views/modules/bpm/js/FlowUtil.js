import BpmInstApi from "@/api/bpm/core/bpmInst";
import { mapState} from 'vuex';

export default {


    computed:{
        ...mapState({
            nav: state => state.flowHome.nav}
        )
    },
    methods:{
        encryptInstId(instId,callback){
            BpmInstApi.getBpmInstEncrypt(instId).then(res=>{
                if(!res.success){
                    this.$message.warn(res.message);
                    return;
                }
                callback(res.data);
            })
        },
        encryptInstIds(instIds,relType,callback){
            BpmInstApi.getBpmInstEncryptList(instIds,relType).then(resultList=>{
                callback(resultList);
            })
        },
        /**
         * 启动流程页面
         * @param defKey
         */
        startFlow(defKey,entCode){
            let obj=this.$router.resolve({
                name:'newDoc',
                params:{
                    defKey:defKey
                }
            });
            let href=obj.href ;
            if(entCode){
                href+="?entCode="+entCode
            }
            window.open(href,"_blank" );
        },
        /**
         * 打开流程实例页面
         * <pre>
         *     1.审批页面
         *     2.流程实例
         * </pre>
         * @param instId
         * @param taskType
         */
        openInst(instId){
            var self=this;
            this.encryptInstId(instId,function(encryptInstId){
                let obj=self.$router.resolve({
                    name:'openDoc',
                    params:{instId:encryptInstId}
                });
                window.open(obj.href,"_blank" );
            })
        },
        /**
         * 打开明细
         * @param instId
         */
        openDetail(instId){
            var self=this;
            this.encryptInstId(instId,function(encryptInstId){
                let obj=self.$router.resolve({
                    name:'openDoc',
                    params:{instId:encryptInstId},
                    query:{action:"detail"}
                });
                window.open(obj.href,"_blank" );
            })
        },
        hrefInst(name,instId){
            var self=this;
            this.encryptInstId(instId,function(encryptInstId) {
                let obj = self.$router.resolve({
                    name: name,
                    params: {instId: encryptInstId}
                });
                location.href = obj.href;
            });
        },
        pushInst(instId){
            var self=this;
            this.encryptInstId(instId,function(encryptInstId) {
                let time = new Date().getTime();
                self.$router.push({path: '/bpm/workbench/openDoc/' + encryptInstId + '?time=' + time});
            });
        },
        copyInst(instId){
            let obj=this.$router.resolve({
                name:'openDoc',
                params:{instId:instId}
            });
            let url=obj.href +"?action=copy";
            window.open(url,"_blank" );
        },

    }
}