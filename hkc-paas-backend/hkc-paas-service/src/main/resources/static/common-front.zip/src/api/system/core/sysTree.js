import rxAjax from '@/assets/js/ajax.js';
const SysTreeApi = {};

SysTreeApi.baseUrl= '/api-system/system/core/sysTree';
SysTreeApi.exportUrl= SysTreeApi.baseUrl + '/export';


SysTreeApi.doImport=function(formData,callback) {
  var url= SysTreeApi.baseUrl+"/doImport";
  return rxAjax.upload(url,formData,callback);
}


SysTreeApi.doExport = function(solutionIds) {
  window.location.href='/api/api-system/system/core/sysTree/doExport?solutionIds=' + solutionIds;
}

SysTreeApi.query=function (parameter) {
  var url= SysTreeApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
 * 获取单记录
 * @param pkId
 * @returns {*}
 */
SysTreeApi.get =function(pkId) {
  var url= SysTreeApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

SysTreeApi.save =function(parameter) {
  var url= SysTreeApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

SysTreeApi.del =function(parameter) {
  var url= SysTreeApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

SysTreeApi.getByCatKey=function (catKey,appId) {
  var url =  SysTreeApi.baseUrl + '/getByCatKey';
  return rxAjax.get(url,{catKey:catKey,readKey:'read',isAdmin:true,isGrant:false,appId:appId});
}

SysTreeApi.getByCatKeyAndParentId=function (catKey,appId) {

  var url =  SysTreeApi.baseUrl + '/getByCatKeyAndParentId?catKey=' + catKey + "&appId=" +appId;
  return rxAjax.get(url);
}


SysTreeApi.delByTreeId =function(parameter) {
  var url = SysTreeApi.baseUrl + '/delByTreeId';
  return rxAjax.postUrl(url, parameter);
}


SysTreeApi.getById = function (pkId) {
  var url = SysTreeApi.baseUrl + '/getById?pkId=' + pkId;
  return rxAjax.get(url);
}

SysTreeApi.getByAliasCatKey = function (alias, catKey) {
  var url = SysTreeApi.baseUrl + '/getByAliasCatKey?alias=' + alias + '&catKey=' + catKey;
  return rxAjax.get(url);
}

SysTreeApi.listDicTree = function (appId){
  var url = SysTreeApi.baseUrl + '/listDicTree?appId=' + appId;
  return rxAjax.get(url);
}

export default SysTreeApi;