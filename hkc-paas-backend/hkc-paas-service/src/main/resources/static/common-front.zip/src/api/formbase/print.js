import  getLodop  from '@/utils/LodopFuncs';
import FormPrintLodopApi from "@/api/form/core/formPrintLodop";
import FormPdfHtml from "@/views/modules/form/core/FormPdfHtml";
import {Util} from "jpaas-common-lib";

export default {
  data(){
    return {
      btnPrint:"",
      printArea:""
    }
  },
  methods:{
    initPrint(btnPrintId,printArea){
      this.btnPrint=btnPrintId;
      this.printArea=printArea;
      var self_=this;
      document.getElementById(this.btnPrint).addEventListener("click",function () {
        self_.print();
      })
    },
    print() {
      var self_=this;
      var bodyHtml=window.document.body.innerHTML;
      var printHtml=this.$refs[this.printArea].innerHTML;
      window.document.body.innerHTML=printHtml;


      setTimeout(function () {
         window.print();
         window.document.body.innerHTML=bodyHtml;
             document.getElementById(self_.btnPrint).addEventListener("click",function () {
              self_.print();
          })
      },2000);
    },
    printLodop(pkId,boAlias,name){
      if(!pkId){
        alert("未绑定套打模板!");
        return;
      }
        var LODOP=getLodop(this);
        if(!LODOP){
            return;
        }
        //初始化任务名称
        LODOP.PRINT_INIT(name);
        FormPrintLodopApi.printHtml({pkId:pkId,formData:JSON.stringify(this.rxForms.getData()[boAlias])}).then(res=>{
            eval(res.data);
            //打印预览
            LODOP.PREVIEW();
        })
    },
    pdfPrint(pkId,boAlias,name){
        var dataJson = this.rxForms.getData()[boAlias];
        var metadata =  this.rxForms.getMetadata()[boAlias];
        //打开pdf模板
        var self = this;
        var conf = {
            component: FormPdfHtml,
            title: name + 'pdf模板',
            widthHeight: [`100%`, `100%`]
        }
        var baseConf = {
            curVm: self,
            data: {   //传递参数
                pkId: pkId,
                dataJson: dataJson,
                metadata: metadata
            }
        }
        let config = Object.assign(baseConf, conf)
        Util.open(config, function (action) {
        })
    }

  }
}