import {Dialog, Util,GridMixin} from "jpaas-common-lib";

/**
 * 发布与接收事件
 */
export default {
    mixins:[GridMixin],
    computed: {
        receiveRowSelection() {
            return {
                selectedRowKeys: this.selectedRowKeys,
                onChange: this.onSelectChange,
            }
        },
    },
    data() {
        return {
            selectedRowKeys:[],
            componentParamsDef: [],
            publishComponent: [],
            paramsDef: [],
            valueSourceDef: [
                { value: 'param', label: '参数传入' },
                { value: 'fixedVar', label: '固定值' },
                { value: 'script', label: '脚本' },
                { value: 'constantVar', label: '常量' },
            ],
            sourceAry: [
                { value: 'url', label: '来自传入参数' },
                { value: 'event', label: '来自事件' },
            ],
        }
    },
    created() {
        if(this.portalLayout){
            this.sourceAry=[{ value: 'event', label: '来自事件' }]
        }
    },
    methods: {
        addParams() {
            if (this.config.receive.type == 'event' && this.config.receive.mapping.length >= this.componentParamsDef.length) {
                this.$notification.warning({
                    message: '提示信息',
                    description: '该组件未配置传入参数，请去配置!',
                })
                return;
            }
            this.config.receive.mapping.push({ idx_: Util.randomId(), name: '', valueSource: '', valueDef: '' })
        },
        removeSelect() {
            this.removeRows(this.config.receive.mapping, this.selectedRowKeys)
        },
        onSelectChange(selectedRowKeys) {
            this.selectedRowKeys = selectedRowKeys
        },
        openScriptQuery(record) {
            Dialog.openScripttextDialog(
                {
                    curVm: this,
                    widthHeight: ['800px', '600px'],
                    data: { script: record.valueDef },
                    zIndex:99999
                },
                function (self, data) {
                    record.valueDef = data
                }
            )
        },
        changeComponent(val) {
            if(!val){
                return;
            }
            if (this.config.alias == val) {
                this.config.receive.publishComponent = ''
                this.$notification.warning({ message: '提示信息', description: '发布事件组件不能选择自己!' })
                return
            }
            this.componentParamsDef = this.getPubParams(val);
        },
    }
}