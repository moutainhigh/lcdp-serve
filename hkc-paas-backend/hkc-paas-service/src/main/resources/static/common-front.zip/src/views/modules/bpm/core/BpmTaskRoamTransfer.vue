<template>
    <rx-dialog @handOk="handTrans" @cancel="cancel" order="bottom">
        <rx-layout>
            <div slot="center">
                <a-form-model ref="form" :model="form" :rules="rules">
                    <a-row>
                        <a-col :span="24">
                            <a-form-model-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="任务名称">
                                {{ form.subject }}
                            </a-form-model-item>
                        </a-col>
                    </a-row>
                    <a-row>
                        <a-col :span="24">
                            <a-form-model-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="流转类型"
                                               prop="transferType">
                                <a-radio-group :options="transferOptions" v-model="form.transferType">
                                </a-radio-group>
                            </a-form-model-item>
                        </a-col>
                    </a-row>

                    <a-row>
                        <a-col :span="24">
                            <a-form-model-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="流转人"
                                               prop="toUser">
                                <rx-input-button width="100%" v-model="form.toUser"
                                                 @click="selectUsers"></rx-input-button>
                            </a-form-model-item>
                        </a-col>
                    </a-row>
                    <a-row>
                        <a-col :span="24">
                            <a-form-model-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="审批类型"
                                               prop="approveType">
                                <a-radio-group :options="approveOptions" v-model="form.approveType">
                                </a-radio-group>
                            </a-form-model-item>
                        </a-col>
                    </a-row>
                    <a-row>
                        <a-col :span="24">
                            <a-form-model-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="备注"
                                               prop="opinion">
                                <a-textarea v-model="form.opinion" style="width: 100%"/>
                            </a-form-model-item>
                        </a-col>
                    </a-row>

                    <a-row>
                        <a-col :span="24">
                            <a-form-model-item label="通知方式" :labelCol="labelCol1" :wrapperCol="wrapperCol1"
                                               prop="msgTypes">
                                <a-checkbox-group :options="msgOptions" v-model="form.msgTypes">
                                </a-checkbox-group>
                            </a-form-model-item>
                        </a-col>
                    </a-row>
                    <a-row v-show="form.approveType=='parallel'">
                        <a-col :span="24">
                            <a-form-model-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="完成配置"
                                               prop="completeType">
                                <a-radio-group :options="completeOptions" v-model="form.completeType">
                                </a-radio-group>
                            </a-form-model-item>
                        </a-col>
                    </a-row>
                    <a-row v-show="form.completeType==1 && form.approveType=='parallel'">
                        <a-col :span="24">
                            <a-form-model-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="计算类型"
                                               prop="completeJudgeType">
                                <a-radio-group :options="completeJudgeOptions" v-model="form.completeJudgeType">
                                </a-radio-group>
                            </a-form-model-item>
                        </a-col>
                    </a-row>
                    <a-row v-show="form.completeType==1 && form.approveType=='parallel'">
                        <a-col :span="24">
                            <a-form-model-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="投票数"
                                               prop="completeSetting">
                    <span style="width:80px;display: inline-block;margin-right: 6px;">
                        <a-input-number v-model="form.completeSetting" :min="1" style="width:100px;"/>
                    </span>
                                <span v-if="form.completeJudgeType=='voteCount'">票</span>
                                <span v-else>%</span>


                            </a-form-model-item>
                        </a-col>
                    </a-row>
                </a-form-model>
            </div>
        </rx-layout>

    </rx-dialog>
</template>
<script>

import BpmPublicApi from '@/api/bpm/core/BpmPublicApi'
import {BaseFormModel, RxDialog, Dialog, Util} from 'jpaas-common-lib';
import BpmtaskApi from "@/api/bpm/core/bpmTask";

export default {
    name: 'BpmTaskRoamTransfer',
    props: {
        subject: String,
        taskId: String,
        layerid: String,
        lydata: Object,
        destroy: Function
    },
    mixins: [BaseFormModel],
    components: {
        RxDialog,
    },
    data() {
        return {
            rules: {
                toUser: [{required: true, message: '请选择流转人', trigger: 'change'}]
            },
            msgOptions: [],
            transferOptions: [
                {label: '返回', value: 'waitAllVoted'},
                {label: '审批下一步', value: 'jumpNext'}
            ],
            approveOptions: [
                {label: '串行', value: 'sequential'},
                {label: '并行', value: 'parallel'}
            ],
            completeOptions: [
                {label: '默认', value: 0},
                {label: '高级配置', value: 1}
            ],
            completeJudgeOptions: [
                {label: '票数', value: 'voteCount'},
                {label: '百分比', value: 'votePercent'}
            ],
            form: {
                transferType: "waitAllVoted",
                approveType: "parallel",
                completeType: 0,
                completeJudgeType: "voteCount",
                completeSetting: 1,
                opinion: "",
                toUser: "",
                msgTypes: []
            },
            aryNames: [],
            aryIds: []
        }
    },
    created() {
        this.init();
    },
    methods: {
        init() {
            this.form.subject = this.subject;
            this.form.taskId = this.taskId;

            BpmPublicApi.getMessageHandler().then(res => {
                res.forEach((val) => {
                    this.msgOptions.push({label: val.name, value: val.type})
                })
            })
        },
        selectUsers(vm) {
            if (this.form.toUser == '') {
                this.aryIds = [];
                this.aryNames = [];
            }
            var self_ = this;
            Dialog.openUserDialog({
                curVm: this, data: {single: false}, widthHeight: ['1200px', '600px']
            }, function (self, users) {
                for (var i = 0; i < users.length; i++) {
                    var user = users[i];
                    if (self.aryNames.indexOf(user.fullName) === -1) {
                        self.aryNames.push(user.fullName);
                        self.aryIds.push(user.userId);
                    }
                }

                var json = {text: self.aryNames.join(","), value: self.aryIds.join(",")};
                self_.form.toUser = JSON.stringify(json);
                vm.setVal(self.aryIds.join(","), self.aryNames.join(","));
            });

        },
        handTrans(e) {
            this.$refs.form.validate(valid => {
                if (!valid) {
                    e.loading = false;
                    return;
                }
                var self_ = this;
                this.form.msgType = this.form.msgTypes.join(",");
                this.$confirm({
                    title: '确认流转任务吗?',
                    cancelText:'取消',
                    okText:'确定',
                    zIndex:9999,
                    onOk() {
                        console.log(self_.form)
                        BpmtaskApi.transRoamTask(self_.form).then(res => {
                            e.loading = false;
                            if (res.success) {
                                Util.closeWindow(self_, "ok")
                            }
                        })
                    },
                    onCancel() {
                        e.loading = false;
                        return;
                    },
                });

            });
        }
    }
}
</script>
