import Vue from 'vue'

import {RxFit,RxGrid,RxTree,RxLayout,RxTreeTable,RxButton}  from 'jpaas-common-lib';
Vue.component(RxFit.name, RxFit);
Vue.component(RxGrid.name, RxGrid);
Vue.component(RxTree.name, RxTree);
Vue.component(RxLayout.name, RxLayout);
Vue.component(RxTreeTable.name, RxTreeTable);
Vue.component(RxButton.name, RxButton);
