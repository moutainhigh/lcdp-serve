import rxAjax from '@/assets/js/ajax.js';

//图表数据模型 api接口
export const ChartDataModelApi = {};

ChartDataModelApi.baseUrl= '/api-form/form/core/chartDataModel';
ChartDataModelApi.exportUrl= ChartDataModelApi.baseUrl + '/export';

//查询列表
ChartDataModelApi.query=function (parameter) {
    var url= ChartDataModelApi.baseUrl + '/query';
    return rxAjax.postJson(url,parameter).then (res => {
        return res.result
    })
}

//查询列表
ChartDataModelApi.getAll=function () {
    var url= ChartDataModelApi.baseUrl + '/getAll';
    return rxAjax.get(url).then (res => {
        return res
    })
}

/**
 * 获取单记录
 * @param pkId
 * @returns {*}
 */
ChartDataModelApi.get =function(pkId) {
    var url= ChartDataModelApi.baseUrl + '/get?pkId=' + pkId;
    return rxAjax.get(url);
}

//保存数据
ChartDataModelApi.save =function(parameter) {
    var url= ChartDataModelApi.baseUrl + '/save';
    return rxAjax.postJson(url,parameter);
}

//删除数据
ChartDataModelApi.del =function(parameter) {
    var url= ChartDataModelApi.baseUrl + '/del';
    return rxAjax.postUrl(url,parameter);
}

//获取数据源表 {tableName:"", ds:""}
ChartDataModelApi.getTables =function(parameter) {
    var url='/api-form/form/core/sysDb/findTableList';
    return rxAjax.postForm(url,parameter);
}


//获取表的字段 {sql:""}
ChartDataModelApi.getFields =function(parameter) {
    var url='/api-form/form/core/sysDb/getFields';
    return rxAjax.postForm(url,parameter);
}

//获取表的字段
ChartDataModelApi.getData =function(config) {
    var url='/api-form/form/core/chartDataModel/getData';
    return rxAjax.postJson(url,config);
}

//根据数据字典获取选项
ChartDataModelApi.getByDic =function(dicKey,parentId) {
    var url= "/api-system/system/core/sysDic/getByPidAndDicId";
    var params={dicKey:dicKey,parentId:parentId};
    return rxAjax.get(url,params);
}

//根据自定义sql获取选项
ChartDataModelApi.getBySql =function(sqlKey,params) {
    var url= "/api-form/form/core/formCustomQuery/queryForJson_"+sqlKey;
    return rxAjax.postForm(url,params);
}


//根据AppName获取数据源
ChartDataModelApi.getAllByAppName =function() {
    var url="/api-form/form/core/formDataSourceDef/getAllByAppName?appName=jpaas-form";
    return rxAjax.get(url);
}



export  default ChartDataModelApi;

