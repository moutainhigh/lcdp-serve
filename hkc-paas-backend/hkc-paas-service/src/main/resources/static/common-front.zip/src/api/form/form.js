
import rxAjax from '@/assets/js/ajax.js';

export const FormApi = {};

//获取首页
FormApi.getHomePageByAppId= function(appId) {
	var url= '/api-form/form/core/formCustom/getHomePageByAppId?appId=' + appId;
	return rxAjax.get(url);
}

FormApi.setConf = function (parameter) {
	var url =  '/api-form/form/core/formBoList/' + parameter.key + '/config';
	return rxAjax.get(url);
}

FormApi.dialog=function(conf){
	var url= '/api-form/form/core/formBoList/' + conf.key +'/dialog';
	if(conf.params){
		url+="?" + conf.params;
	}
	if(conf.single){
		if(url.indexOf("?")==-1){
			url+="?single=" +conf.single;
		} else{
			url+="&single=" +conf.single;
		}
	}
	return rxAjax.get(url);
}

export  default FormApi;
