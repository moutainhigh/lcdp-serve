<template>
    <rx-dialog @handOk="okFun" @cancel="cancelFun">
        <rx-layout>
            <div slot="center">
                <div v-if="mdl.status=='Draft'" slot="toolbar">
                    <a-button type="primary" @click="saveNews">发布</a-button>
                </div>
                <a-form :form="form">
                    <a-form-item style="display:none">
                        <a-input v-decorator="['newId']"/>
                    </a-form-item>
                    <a-row>
                        <a-col :span="12">
                            <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="标题">
                                <span>{{ mdl.subject }}</span>
                            </a-form-item>
                        </a-col>
                        <a-col :span="12">
                            <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="摘　　要">
                                <span>{{ mdl.keywords }}</span>
                            </a-form-item>
                        </a-col>
                    </a-row>
                    <a-row>
                        <a-col :span="12">
                            <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="阅读次数">
                                <span style="color: red">{{ mdl.readTimes }}</span>
                            </a-form-item>
                        </a-col>
                        <a-col :span="12">
                            <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="作　　者">
                                <span>{{ mdl.author }}</span>
                            </a-form-item>
                        </a-col>
                    </a-row>

                    <a-row>
                        <a-col :span="12">
                            <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="创建时间">
                                <span style="color: red">{{ mdl.createTime }}</span>
                            </a-form-item>
                        </a-col>
                    </a-row>

                    <a-row>
                        <a-col :span="24">
                            <a-form-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="图  片">
                                <rx-attach-component v-model="imageUrl" :readonly="lydata.readonly"  :fileType="'image'"></rx-attach-component>
                            </a-form-item>
                        </a-col>
                    </a-row>
                    <a-row>
                        <a-col :span="24">
                            <a-form-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="附件">
                                <rx-attach-component v-model="fileList" :readonly="lydata.readonly"></rx-attach-component>
                            </a-form-item>
                        </a-col>
                    </a-row>

                    <a-row>
                        <a-col :span="24">
                            <a-form-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="内　　容">
                                <div   v-html="mdl.content">
                                </div>
                            </a-form-item>
                        </a-col>
                    </a-row>
                </a-form>
            </div>
        </rx-layout>
    </rx-dialog>
</template>
<script>
import InsNewsApi from '@/api/portal/core/insNews';
import {BaseForm, RxDialog, Util} from 'jpaas-common-lib';


export default {
    name: 'InsNewsEdit',
    mixins: [BaseForm],
    components: {
        Util, RxDialog
    },
    props: {

        value: {
            type: String
        },
        lydata: {},
        layerid: {},
        destroy: {}
    },
    data() {
        return {
            fileList: [],
            imageUrl: [],
            columnName: "",
            columnShow: false,
            columnDefList: [],
            editorOption: {}
        }
    },
    methods: {
        okFun() {
            Util.closeWindow(this, "ok");
        },
        cancelFun() {
            Util.closeWindow(this, "cancel");
        },
        getInsColumnDefList() {
            InsNewsApi.queryByIsNews().then(data => {
                var result = data.data;
                for (var i = 0; i < result.length; i++) {
                    if (this.mdl.columnId == result[i].colId) {
                        this.columnName = result[i].name;
                    }
                }
            });
        },
        onload_(data) {
            if (typeof (data) == 'undefined') {
                this.mdl = Object.assign({
                    status: "Draft",
                    content: "",
                    readTimes: 0
                });
                this.form.setFieldsValue(this.mdl)
                return;
            }
            if (data.imgFileId) {
                this.imageUrl.push({
                    fileId:data.imgFileId
                });
            }
            if (data.files) {
                this.fileList = JSON.parse(data.files);
            }
            this.getInsColumnDefList();
        },
        getPath(fileId) {
            var accessToken = this.$ls.get("Access-Token");
            var url = `/api/api-system/system/core/sysFile/downloadScale/${fileId}?accessToken=` + accessToken;
            return url;
        },
        getDownLoadPath(file) {
            var accessToken = this.$ls.get("Access-Token");
            var url = `/api/api-system/system/core/sysFile/download/${file.fileId}?accessToken=` + accessToken;
            return url;
        },
        get(id) {
            return InsNewsApi.readInsNews(id);
        },
    }
}
</script>
