<template>
  <div>
    <rx-category-tree ref="categoryTree" :cat-key="catKey" :async="async" @select="handSelect"
                      :readKey="readKey" :isAdmin="isAdmin" :isGrant="isGrant"
                      @rightClick="rightClick"></rx-category-tree>
    <v-contextmenu ref="contextmenu">
      <v-contextmenu-item @click="addNode">新增子节点</v-contextmenu-item>
      <v-contextmenu-item @click="grantNode">控制权限</v-contextmenu-item>
      <v-contextmenu-item v-if="isTreeCat" @click="addSibling">添加同级</v-contextmenu-item>
      <v-contextmenu-item v-if="isTreeCat" @click="editNode">编辑节点</v-contextmenu-item>
      <v-contextmenu-item v-if="isTreeCat" @click="deleteNode">删除节点</v-contextmenu-item>
    </v-contextmenu>
  </div>
</template>

<script>
  import SysTreeEdit from "../../views/modules/system/core/SysTreeEdit";
  import SysAuthSettingTreeEdit from "../../views/modules/system/core/SysAuthSettingTreeEdit";
  import SysTreeApi from '@/api/system/core/sysTree'
  import {Util} from "jpaas-common-lib";

  export default {
    name: "rx-category-treeeditor",
    props: {
      /**
      * 分类KEY
      */
      catKey: {
        type: String
      },
      /**
      * 权限KEY
      */
      readKey:{
        type:String,
        default:'read'
      },
      /**
      * 是否管理员,默认管理
      */
      isAdmin:{
        type:Boolean,
        default:true
      },
      /**
      * 默认需要授权。
      */
      isGrant:{
        type:Boolean,
        default:true
      },
      /**
      *  异步属性，默认为true
      */
      async: {
        type: Boolean,
        default: true
      },
      /**
      * 是否允许编辑，默认为true。
      */
      edit: {
        type: Boolean,
        default: true
      }

    },
    data() {
      return {
        isTreeCat:true
      }
    },
    computed: {
      categoryTree() {
        return this.$refs.categoryTree;
      },
      curRow() {
        return this.$refs.categoryTree.curRow;
      },
    },
    methods: {
      handSelect(selKeys, e) {
        this.$emit("handSelect", this.curRow);
      },
      rightClick({event, node}) {
        if (this.edit) {
          const postition = {top: event.clientY, left: event.clientX};
          if (this.curRow.key=="0"){
            this.isTreeCat=false;
          }else {
            this.isTreeCat=true;
          }
          this.$refs.contextmenu.show(postition);
        }
      },
      addNode() {
        var data = {parentName: this.curRow.name, parentId: this.curRow.treeId, catKey: this.curRow.catKey};
        this.handClick(data, "添加分类", "addchild");
      },
      grantNode(){
        var self_=this;
        var conf={
          component:SysAuthSettingTreeEdit,
          title:"添加权限配置",
          widthHeight:['800px','600px'],
          "curVm":self_,
          "data":{"curRow":this.curRow}
        };
        Util.open(conf,function(action){
        });
      },
      addSibling() {
        var row = this.curRow;
        var title = '添加同级'
        if (row.parentId && row.parentId != '0') {
          //取得上级的数据
          SysTreeApi.get(row.parentId).then(response => {
            var data = response.data;
            var rs = Object.assign({parentName: data.name, parentId: data.treeId, catKey: data.catKey});
            this.handClick(rs, title, "addSibling")
          });
        } else {
          var catKey = row.catKey;
          if (!catKey) {
            catKey = this.selCatKey;
          }
          var rs = Object.assign({parentName: '', parentId: '0', catKey: catKey});
          this.handClick(rs, title, "addSibling")
        }
      },
      editNode() {
        this.handClick(this.curRow, "编辑分类", "edit");
      },
      deleteNode() {
        var treeId = this.curRow.treeId;
        let self_ = this;
        this.$confirm({
          title: '操作提示',
          content: '您确定需要删除选中的记录吗？',
            okText: '确认',
            cancelText: '取消',
          onOk() {
            SysTreeApi.delByTreeId({treeId: treeId}).then(res => {
              if (res.success && res.code == 200) {
                self_.categoryTree.remove();
              }
            })
          },
          onCancel() {
          }
        })
      },
      handClick(data, title, operator) {
        var conf = {
          curVm: this,
          data: {data: data, displayDataShowType: true},
          widthHeight: ['800px', '450px'],
          component: SysTreeEdit,
          title: title
        };
        //编辑
        if (data.treeId) {
          conf.data.pkId = data.treeId;
        }
        var self_ = this;
        Util.open(conf, function (action) {
          if (action != "ok") {
            return;
          }
          var pkId = this.resultData.treeId;

          SysTreeApi.getById(pkId).then(res => {
            var row = res.data;
            switch (operator) {
              case "add":
                self_.categoryTree.addRoot(row, "name", "treeId");
                break
              case "edit":
                self_.categoryTree.merge(row, "name", "treeId");
                break;
              case "addchild":
                self_.categoryTree.addChild(row, "name", "treeId");
                break;
              case "addSibling":
                self_.categoryTree.addRow(row, "name", "treeId");
                break;
            }
          })
        });
      },
    }
  }
</script>

<style scoped>

</style>