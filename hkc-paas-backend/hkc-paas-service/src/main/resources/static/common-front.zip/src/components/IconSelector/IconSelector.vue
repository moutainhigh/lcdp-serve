<template>
  <div style="height:500px">
    <rx-fit>
      <a-tabs v-model="currentTab" @change="handleTabChange">
        <a-tab-pane v-for="v in icons" :tab="v.title" :key="v.key">
          <ul>
            <li v-for="(icon, key) in v.icons" :key="`${v.key}-${key}`" :class="{ 'active': selectedIcon==icon }"
                @click="handleSelectedIcon(v.key,icon)"
            >
              <my-icon :type="icon" v-if="customArr.includes(v.key)" :style="{ fontSize: '36px' }" ></my-icon>
              <a-icon :type="icon" v-else :style="{ fontSize: '36px' }" />
            </li>
          </ul>
        </a-tab-pane>
      </a-tabs>
    </rx-fit>
  </div>
</template>

<script>
import icons from './icons'
import {RxFit} from 'jpaas-common-lib'
export default {
  name: 'IconSelect',
  components: {
		RxFit,
	},
  props: {
    prefixCls: {
      type: String,
      default: 'ant-pro-icon-selector'
    },
    // eslint-disable-next-line
    value: {
      type: String
    }
  },
  data () {
    return {
      selectedIcon: this.value || '',
      currentTab: 'customIcon',
      customArr:['customIcon','userCustomIcon'],
      icons,
      iconArr:[],
      userIconArr:[]
    }
  },
  watch: {
    value (val) {
      this.selectedIcon = val
      this.autoSwitchTab()
    }
  },
  created () {
    this.init();
    if (this.value) {
      this.autoSwitchTab()
    }
  },
  methods: {
    init(){
      var baseURL = process.env.VUE_APP_API_CTX_PATH;
      var _url1,_url2 ;
      if(baseURL != "/"){
          _url1 = `${baseURL}/iconfont/iconfont.css`
          _url2 = `${baseURL}/customIcon/iconfont.css`
      }else {
          _url1 = `/iconfont/iconfont.css`
          _url2 = `/customIcon/iconfont.css`
      }

      this.getIconfont('iconArr',_url1);
      this.getIconfont('userIconArr',_url2);
      for(let i = 0 ;i<this.icons.length ;i++){
        if(this.icons[i].key == 'customIcon'){
          this.icons[i].icons = this.iconArr ;
        }
        if(this.icons[i].key == 'userCustomIcon'){
          this.icons[i].icons = this.userIconArr ;
        }
      }
  },
    getIconfont(arr,url){
      let xhr = new XMLHttpRequest();
      var _self = this ;
      xhr.open('GET',url);
      xhr.onreadystatechange = function () {
        if(xhr.readyState === 4 && xhr.status === 200){
          var data=xhr.responseText;
          var myregexp = /\.(.+):before/mg;
          var match = myregexp.exec(data);
          while (match != null) {
            _self[arr].push(match[1]);
            match = myregexp.exec(data);
          }
        }
      }
      xhr.send();
    },
    handleSelectedIcon (key,icon) {
      this.selectedIcon = icon
      this.$emit('change', {type:key,icon:icon})
    },
    handleTabChange (activeKey) {
      this.currentTab = activeKey
    },
    autoSwitchTab () {
      icons.some(item => item.icons.some(icon => icon === this.value) && (this.currentTab = item.key))
    }
  }
}
</script>

<style lang="less" scoped>
  @import "../index.less";

  ul{
    list-style: none;
    padding: 0;
    margin-bottom: 50px;
    overflow-y: scroll;

    li{
      display: inline-block;
      padding: @padding-sm;
      margin: 3px 0;
      border-radius: @border-radius-base;

      &:hover, &.active{
        // box-shadow: 0px 0px 5px 2px @primary-color;
        cursor: pointer;
        color: @white;
        background-color: @primary-color;
      }
    }
  }
</style>
