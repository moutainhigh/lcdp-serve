import rxAjax from '@/assets/js/ajax.js';

//form_save_export api接口
export const SaveExportApi = {};

SaveExportApi.baseUrl= '/api-form/form/core/saveExport';
SaveExportApi.exportUrl= SaveExportApi.baseUrl + '/export';


SaveExportApi.saveConfigJson =function(parameter){
  var url= SaveExportApi.baseUrl + '/saveConfigJson';
  return rxAjax.postJson(url,parameter);
}


//查询列表
SaveExportApi.query=function (parameter) {
  var url= SaveExportApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
* 获取单记录
* @param pkId
* @returns {*}
*/
SaveExportApi.get =function(pkId) {
  var url= SaveExportApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

SaveExportApi.getByList =function(dataList) {
  var url= SaveExportApi.baseUrl + '/getByList?dataList=' + dataList ;
  return rxAjax.get(url);
}

SaveExportApi.removeByName =function(name, dataList) {
  var url= SaveExportApi.baseUrl + '/removeConfig?name=' + name + '&dataList=' + dataList;
  return rxAjax.postUrl(url);
}

SaveExportApi.getByName =function(name, dataList) {
  var url= SaveExportApi.baseUrl + '/getByName?name=' + name + '&dataList=' + dataList;
  return rxAjax.get(url);
}


//保存数据
SaveExportApi.save =function(parameter) {
  var url= SaveExportApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

//删除数据
SaveExportApi.del =function(parameter) {
  var url= SaveExportApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

export  default SaveExportApi;

