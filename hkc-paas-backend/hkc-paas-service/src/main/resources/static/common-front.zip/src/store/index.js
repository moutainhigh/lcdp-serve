import Vue from 'vue'
import Vuex from 'vuex'

import appSetting from './modules/appSetting'
import editable from './modules/editable'
Vue.use(Vuex)

export default new Vuex.Store({
  modules: {
	  appSetting,
	  editable
  },
  state: {

  },
  mutations: {

  },
  actions: {

  }
})
