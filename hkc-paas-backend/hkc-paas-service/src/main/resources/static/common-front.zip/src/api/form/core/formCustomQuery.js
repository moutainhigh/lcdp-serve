import rxAjax from '@/assets/js/ajax.js';

//自定查询 api接口
export const FormCustomQueryApi = {};

FormCustomQueryApi.baseUrl= '/api-form/form/core/formCustomQuery';
FormCustomQueryApi.exportUrl= FormCustomQueryApi.baseUrl + '/export';


FormCustomQueryApi.doImport=function(formData,callback) {
  var url= FormCustomQueryApi.baseUrl+"/doImport";
  return rxAjax.upload(url,formData,callback);
}


FormCustomQueryApi.doExport = function(solutionIds) {
  window.location.href='/api/api-form/form/core/formCustomQuery/doExport?solutionIds=' + solutionIds;

}



//查询列表
FormCustomQueryApi.query=function (parameter) {
  var url= FormCustomQueryApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
* 获取单记录
* @param pkId
* @returns {*}
*/
FormCustomQueryApi.get =function(pkId) {
  var url= FormCustomQueryApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

FormCustomQueryApi.preview =function(pkId) {
  var url= FormCustomQueryApi.baseUrl + '/preview?pkId=' + pkId;
  return rxAjax.get(url);
}

//保存数据
FormCustomQueryApi.save =function(parameter) {
  var url= FormCustomQueryApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

//删除数据
FormCustomQueryApi.del =function(parameter) {
  var url= FormCustomQueryApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

//系统常量
FormCustomQueryApi.getConstants =function () {
  var url= FormCustomQueryApi.baseUrl + '/getConstantItem';
  return rxAjax.get(url);
}

/**
 * 加载自定义查询。
 */
FormCustomQueryApi.getByKey=function(params) {
    var url= "/api-form/form/core/formCustomQuery/getByKey";
    return rxAjax.get(url,params);
}

//执行自定义SQL
FormCustomQueryApi.doQuery=function(alias,parameter){
    var url = FormCustomQueryApi.baseUrl + '/queryForJson_'+alias;
    return rxAjax.postForm(url,parameter);
}


export  default FormCustomQueryApi;

