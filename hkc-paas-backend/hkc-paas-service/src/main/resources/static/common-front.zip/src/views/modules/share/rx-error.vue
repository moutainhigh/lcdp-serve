<template>
  <div class="masg"
       style="text-align:center;height: 100%;width: 100%;display: flex;justify-content: center;">
    <div style="margin-top:40px;">
      <a-icon style="font-size: 40px;color:red" type="exclamation-circle" />
      <div style="margin-top:10px;">{{message}}</div>
    </div>
  </div>
</template>

<script>
    export default {
        name: "rx-error",
        props:{
            message:""
        }
    }
</script>

<style scoped>

</style>
