export  default {

    methods:{
        onFileRender(text){
            if(!text){
                return "";
            }
            var files="";

            var fileType = [
                {name: "media", type: ['.mp3', '.mp4', '.avi', '.rmvb']},
                {name: "ppt", type: ['.ppt', '.pptx']},
                {name: "pdf", type: ['.pdf']},
                {name: "excel", type: ['.xls', '.xlsx']},
                {name: "word", type: ['.doc', '.docx']},
                {name: "image", type: ['.img', '.png', '.jpg']},
                {name: "txt", type: ['.txt']},
                {name: "rar", type: ['.rar']},
                {name: "zip", type: ['.zip']}
            ];
            var ary=JSON.parse(text);
            for(var i=0;i<ary.length;i++){
                var fileId=ary[i].fileId;
                var fileName=ary[i].fileName;
                var fileClass="iconBox otherBox";
                if (fileName) {
                    let indexS = fileName.lastIndexOf(".");
                    let extName = fileName.substr(indexS, fileName.length);
                    for (var j = 0; j < fileType.length; j++) {
                        let type = fileType[j].type;
                        if (type.contains(extName)) {
                            let classText = "iconBox ";
                            fileClass = classText + fileType[j].name + "Box";
                            break;
                        }
                    }
                }
                var accessToken = this.$ls.get("Access-Token");
                var downUrl="/api/api-system/system/core/sysFile/download/"+fileId+'?accessToken='+accessToken;
                files += "<i class='"+fileClass+"'></i><a href='"+downUrl+"'>"+fileName+"</a>";
            }

            return files;
        },
        onAddressRender(genMode,record,key,num){
            if("form"==genMode|| "create"==genMode){
                if(num==3){
                    return record[key+"Province"]+record[key+"City"]+record[key+"County"]+record[key+"Address"];
                }else if(num==2){
                    return record[key+"Province"]+record[key+"City"]+record[key+"County"];
                }else if(num==1){
                    return record[key+"Province"]+record[key+"City"];
                }else {
                    return record[key+"Province"];
                }
            }
            return record[key];
        },
    }

}