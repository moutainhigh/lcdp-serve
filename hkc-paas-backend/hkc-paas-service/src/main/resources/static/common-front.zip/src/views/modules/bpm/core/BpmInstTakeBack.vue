<template>
    <rx-dialog @handOk="handOk" @cancel="closeWindow" :oktext="'提交'" order="buttom" btnalign="center">
        <rx-fit>
            <div style="height:100%;width:100%;padding:20px;">
                <a-form>

                    <a-form-item  label="撤回后" :label-col="labelCol" :wrapper-col="wrapperCol">
                        <a-radio-group v-model="nextJumpType">
                            <a-radio value="normal">正常执行</a-radio>
                            <a-radio value="source">原路返回</a-radio>
                        </a-radio-group>
                    </a-form-item>


                    <a-form-item label="意见" :label-col="labelCol" :wrapper-col="wrapperCol">
                        <a-textarea placeholder="请填写意见" v-model="opinion"></a-textarea>
                    </a-form-item>


                </a-form>
            </div>
        </rx-fit>
    </rx-dialog>
</template>
<script>
import { Dialog, RxDialog,RxAttachComponent,RxUserComponent, Util, RxFit, RxTextBoxList } from 'jpaas-common-lib'
import BpmtaskApi from '@/api/bpm/core/bpmTask'
import BpmPublicApi from '@/api/bpm/core/BpmPublicApi'


export default {
    name: 'bpm-task-back',
    components: {
        RxFit,
        RxDialog,
    },
    props: {
        layerid: String,
        lydata: Object,
        destroy: Function,
        instId:{
            type: String
        },
        backNodeId:{
            type: String
        }

    },
    data() {
        return {
            labelCol: { span: 4 },
            wrapperCol: { span: 8 },
            nextJumpType:'normal',
            opinion:""
        }
    },
    created(){

    },
    methods: {
        handOk(){
            let self_=this;
            let conf={
                instId:this.instId,
                backNodeId:this.backNodeId,
                nextJumpType:this.nextJumpType,
                opinion: this.opinion
            }
            BpmtaskApi.takeBackTask(conf).then(resp=>{
                Util.closeWindow(self_, 'ok')
            });
        },
        closeWindow() {
            Util.closeWindow(this, 'cancel')
        }
    }
}
</script>