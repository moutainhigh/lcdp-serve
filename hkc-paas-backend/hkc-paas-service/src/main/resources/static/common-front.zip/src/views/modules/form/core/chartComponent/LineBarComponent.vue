<template>
    <div class="wrap">
        <div><filter-params @paramsChange="paramsChange" :config="config" :filterParams="config.filterParams" ></filter-params></div>
        <div style="height: 100%" :ref="config.alias"></div>
    </div>
</template>

<script>
import ChartPublic from '../formComponent/ChartPublic'
export default {
    /**
     * 线柱混搭
     */
    name: "line-bar-component",
    mixins: [ChartPublic],
    data() {
        return {
        }
    },
    methods: {
        setOption(){
            //图例组件
            var legend = [];
            //直角坐标系 grid 中的 x 轴
            var xAxis = {};
            //yAxis直角坐标系 grid 中的 y 轴
            var yAxis = [];
            /**
             *系列列表
             [{name: 名称,
             type: 类型,
             data: 数据 []
             }]
             */
            var series = [];

            //获取维度
            xAxis=this.getDimensions();

            //获取度量
            for (var i = 0; i < this.config.measureList.length; i++) {
                var measures=this.config.measureList[i];
                for (var j = 0; j < measures.length; j++) {
                    var array=[];
                    var measure = measures[j];
                    //默认折线
                    var chartType="line";
                    if(measure.chartType){
                        chartType=measure.chartType
                    }
                    //默认左边
                    var position="left";
                    if(measure.position){
                        position=measure.position
                    }
                    //格式
                    var formatter="{value}";
                    if(measure.formatter){
                        formatter+=measure.formatter;
                    }
                    legend.push(measure.fieldLabel);
                    var color="";
                    if(this.config.colour.content.length>0){
                        color=this.config.colour.content[(i%this.config.colour.content.length)];
                    }
                    yAxis.push({
                        type: 'value',
                        name: measure.fieldLabel,
                        min: measure.min?measure.min:0,
                        max: measure.max?measure.max:100,
                        position: position,
                        offset: measure.offset?measure.offset:0,
                        axisLine: {
                            show: true,
                            lineStyle: {
                                color:color
                            }
                        },
                        axisLabel: {
                            formatter: formatter
                        }
                    })
                    for (var k = 0; k < this.data.length; k++) {
                        var value= this.data[k][measure.tableName+'_'+measure.fieldName];
                        if(value){
                            array.push(value);
                        }else {
                            array.push(0);
                        }
                    }
                    var obj={
                        name: measure.fieldLabel,
                        type:chartType,
                        data:array
                    }
                    //柱形宽度
                    if(this.config.advConfig && this.config.advConfig.barWidth ){
                        obj.barWidth=this.config.advConfig.barWidth;
                    }
                    series.push(obj);
                }
            }
            this.option={

                tooltip: {
                    trigger: 'axis'
                },
                toolbox: {
                    feature: {
                        saveAsImage: {show:this.config.advConfig.saveAsImage},
                        magicType:this.config.advConfig.magicType? {type: ['line', 'bar']}:{} ,
                        restore: {show: this.config.advConfig.restore}
                    }
                },
                color:this.getColors(),
                legend: {
                    data: legend,
                    show:this.config.advConfig.legendShow,
                    left:this.config.advConfig.legendLeft,
                    top:this.config.advConfig.legendTop
                },
                xAxis: xAxis,
                yAxis: yAxis,
                series: series
            };
        }
    }
}
</script>