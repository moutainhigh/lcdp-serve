import {GetAjax} from 'jpaas-common-lib';
var config={timeout:30000};
var rxAjax=GetAjax(config);
export default rxAjax;