import Vue from 'vue'
import result from './Result'
export default {
  install(){
    Vue.component("result",result)
  }
}