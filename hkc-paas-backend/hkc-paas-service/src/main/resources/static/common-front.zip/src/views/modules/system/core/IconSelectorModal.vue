<template>
  <a-modal
    title="图标选择"
    style="top: 20px;"
    :width="800"
    :height="580"
    :footer="null"
    v-model="visible"
    :zIndex="99999"
  >
    <icon-selector @change="handleIconChange"/>
  </a-modal>
</template>

<script>
import IconSelector from '@/components/IconSelector'

export default {
  name: 'IconSelectorView',
  components: {
    IconSelector
  },
  data () {
    return {
      visible: false,
      sj:false,
      params:{}
    }
  },
  methods: {
    show (params) {
      this.visible = true;
      this.params=params;
    },
    handleIconChange (icon) {
      this.visible = false;
      if(this.sj == false){
      this.$emit('ok', icon,this.params)
      }else{
       this.$parent.fatherMethod(icon);
      }
      // this.$message.info(<span>选中图标 <code>{icon}</code></span>)
    }
  }
}
</script>
<style>

</style>
