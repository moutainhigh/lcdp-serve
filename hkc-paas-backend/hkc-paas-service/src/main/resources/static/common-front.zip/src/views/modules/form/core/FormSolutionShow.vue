<template>
    <a-layout class="layersty" ref="layersty" style="height:100%;" >
        <a-layout-content style="order:1" class="defaultContent">
            <div id="rx-form-container" :class="type=='EASY-DESIGN'? 'kforms':''" :style="`background-color:${ formAllConfig.bg }`">
                <div v-if="type=='EASY-DESIGN'" style="margin: auto;max-width: 1300px;">
                    <k-form-build :javascript="javascript"
                                  :value="metadata"
                                  :alias="formSolutionAlias"
                                  :formDesigner="true"
                                  ref="rxForm"
                                  :readOnly="rxReadOnly"
                    />
                </div>
                <div v-else :style="`max-width:${formAllConfig.allWidth};;margin:auto;`">
                    <rx-form  ref="rxForm" @dataChange="dataChange" :layerid="layerid" :destroy="destroy"></rx-form>
                </div>
            </div>
        </a-layout-content>

        <a-layout-footer style="order:0;">
            <a-form class="buttongmodle" >
                <a-button-group>
                    <a-button :type="btn.style"
                              :ref="btn.value"
                              v-for="btn in buttons"
                              @click="handMethod(btn)" :loading="btn.loading"
                              :key="btn.name">{{ btn.name }}
                    </a-button>
                </a-button-group>
            </a-form>
        </a-layout-footer>
    </a-layout>

</template>

<script>
import FormSolutionApi from '@/api/form/core/formSolution'
import BpmInstApi from "@/api/bpm/core/bpmInst";
import {rxForm} from "jpaas-form-component";
import {Util} from 'jpaas-common-lib';
import FormUtil from "./FormUtil";
import formbase from '@/api/formbase';
import BpmInstStartConfirm from "@/views/modules/bpm/core/BpmInstStartConfirm";
import {mapState} from "vuex";
import userState from "@/assets/js/userState";
import FormSolutionFunc from "@/views/modules/form/core/formsolution/FormSolutionFunc";
import BpmImageView from "@/views/modules/bpm/comps/BpmImageView";


export default {
    name: "form-solution-show",
    props: {
        alias: {
            type: String
        },
        pkId:{
            type: [String,Number]
        },
        //这个是从DialogView打开时需要用到的。
        menuParams:{
            type:String
        },
        /**
         * 不使用主键打开表单数据。
         * {
         *     param1:"",
         *     param2:""
         * }
         */
        params:{
          type:Object
        },
        parent: {
            type: Object
        },
        readOnly: {
            type: Boolean, default: false
        },
        setInitData: {
            type: Function
        },
        /**
         * 在保存时关闭窗口默认为false。
         */
        closeOnSave:{
            type: Boolean, default: false
        },
        layerid: {
            type: String,
            default: ""
        },
        destroy: {
            type: Function
        }
    },
    mixins: [formbase,userState,FormSolutionFunc],
    components: {
        rxForm
    },
    data() {
        return {
            canStartFlow: false,
            type: "",
            buttons: [],
            formSolutionAlias: "",

            metadata: {},
            javascript: "",
            processConfig: {
                buttons: [],
                startConfirm: false,
                fillOpinion: false,
                assignFlowUsers: false,
                startCalFlowusers: false,
                //是否允许选择路径。
                allowSelectPath: false,

                formType: "online"
            },
            needConfirmDlg: false,
            //根实例
            rootVm: true,
            fromRoute: false,
            rxReadOnly: this.readOnly,
            rxParent: this.parent,
            formAllConfig:{
                allWidth: "1300px",
                bg: "#fff"
            },
            /**
             * 表单别名
             */
            formAlias:"",
            flowInstId:null,
        }
    },
    computed: {
        ...mapState({
            showType: (state) => state.appSetting.showType
        }),
        //是否打开窗口。
        isOpenWindow(){
            if( this.layerid){
                return true;
            }
            return false;
        }
    },
    created() {
        this.init();
    },
    methods: {
        /**
         * 初始化参数,获取表单方案别名和主键信息。
         */
        initParams() {
            //使用Util.open的方法打开
            if (this.alias) {
                this.formSolutionAlias = this.alias;
            }
            //从弹框打开,使用DialogView 打开
            else if (this.menuParams) {
                var json = JSON.parse(this.menuParams);
                this.formSolutionAlias = json.formAlias;
            } else {
                var params;
                if (this.$route.meta.params) {
                    params = JSON.parse(this.$route.meta.params);
                } else {
                    params = this.$route.params;
                }
                if (params.formAlias) {
                    this.formSolutionAlias = params.formAlias;
                }
                if (params.pkId) {
                    this.pkId = params.pkId;
                }
                //从路由打开
                this.fromRoute = true;
            }
        },
        init() {
            //初始化参数
            this.initParams();
            let _self = this;
            FormSolutionApi.getByAlias(this.formSolutionAlias, this.pkId, this.params).then(res => {
                if (res.metadata) {
                    res.metadata = JSON.parse(res.metadata);
                    if (res.metadata.formAllConfig) {
                        _self.formAllConfig = res.metadata.formAllConfig
                    }
                }

                this.type = res.type;
                this.formSolution = res.formSolution;

                if (_self.setInitData) {
                    let _data = res.data;
                    res.data = Object.assign(res.data, _self.setInitData(_data));
                }
                if (this.type == 'EASY-DESIGN') {
                    _self.initEasyForm(res);
                } else {
                    var tmp = FormUtil.getTemplate(res);
                    res.template = `<div class="previewBox">${tmp}</div>`;
                    _self.initForm(res);
                }
                _self.canStartFlow = res.canStartFlow;
                this.flowInstId=res.data.INST_ID_;


                // 按钮定义。
                _self.buttons = this.parseButtons(res);


                //设置表单别名。
                this.formAlias=res.alias;
            })
        },
        initEasyForm(res) {
            this.$nextTick(function () {
                this.$refs.rxForm.setData(res);
            })
            this.javascript = res.script;
            this.metadata = res.metadata;
        },
        initForm(res) {
            var curUser = this.user;
            var contextData = {
                type: "form",
                curUserId: curUser.userId,
                curUserName: curUser.fullName,
                account: curUser.account,
                deptId: curUser.deptId,
                tenantId: curUser.tenantId,
                tenantLabel:curUser.tenantLabel
            };
            this.rxReadOnly = this.readOnly;
            if (res.data.INST_ID_ && "DELETE" != res.data.INST_STATUS_) {
                var contextDetail = {
                    type: "detail",
                    instId: res.data.INST_ID_,
                    opinionHistorys: res.instDetail.bpmCheckHistories
                };
                Object.assign(contextData, contextDetail);
            }
            this.$refs.rxForm.loadForm(res, this.rxReadOnly, contextData);
        },
        async validForm(required) {
            var formVm = this.$refs.rxForm.formVm;
            //提交前校验
            if (formVm._beforeSubmit) {
                var rtn = await formVm._beforeSubmit(formVm);
                if (!rtn.success) {
                    return rtn;
                }
            }
            //数据必填，类型校验
            var res = formVm.valid(required, true);
            if (!res.success) {
                return res;
            }
            //表单唯一性校验
            let validMainUnique = await formVm.validMainUnique();
            if (!validMainUnique.success) {
                return validMainUnique;
            }
            return {success: true, msg: "验证通过"};
        },
        //流程图查看
        async flowImage(btn){
            Util.open({
                component:BpmImageView,
                curVm:this,
                widthHeight:['1024px','600px'],
                title:'流程图',
                data:{
                    instId:this.flowInstId,
                    formData:this.getFormData()
                }
            },function (action){
            });
        },
        async startFlow(btn) {
            var self_ = this;
            btn.loading = true;
            var validResult = await this.validForm(true);
            if (!validResult.success) {
                this.$message.warning(validResult.msg);
                return;
            }
            var formData = self_.$refs.rxForm.getData();
            var params = {
                flowDefMapping: self_.formSolution.flowDefMapping,
                formJson: formData
            }
            var flowDefRes = await FormSolutionApi.getFlowDefId(params);
            var flowDefId = flowDefRes.data;
            if(!flowDefId){
                this.$message.warning("无满足条件的流程定义！");
                return;
            }
            var processConfigRes = await BpmInstApi.getProcessConfig(flowDefId);
            if (!processConfigRes.success) {
                this.$message.warning(processConfigRes.message);
                return;
            }
            if (processConfigRes.data) {
                var config = Util.deepClone(self_.processConfig);
                self_.processConfig = Object.assign(config, processConfigRes.data);
                self_.handleProcessConfig(self_.processConfig);
            }
            if (self_.processConfig.startConfirm && !self_.needConfirmDlg) { //启动流程确认
                self_.$confirm({
                    title: '提示信息',
                    content: '确认启动流程吗？',
                    okText: '确认',
                    cancelText: '取消',
                    zIndex: 20000,
                    onOk() {
                        btn.loading = false;
                        self_.doSubmit('start', btn);
                    },
                    onCancel() {
                        btn.loading = false;
                    },
                });
            } else if (self_.needConfirmDlg) { //是否确认
                let conf = {
                    curVm: self_,
                    title: '流程启动确认',
                    component: BpmInstStartConfirm,
                    data: {
                        formSolutionAlias: self_.formSolutionAlias,
                        processConfig: self_.processConfig,
                        defId: flowDefId,
                        instId: self_.instId  || formData.instId || formData.INST_ID_
                    },
                    widthHeight: ['800px', '520px']
                };
                btn.loading = false;
                Util.open(conf, function (action, data) {
                    if (action != 'ok') return;
                    self_.handSuccess("start",data,formData)
                });
            } else {
                this.doSubmit('start', btn);
            }
        },
        closeWindow(json) {
            if (this.fromRoute) {
                this.$bus.emit("closeTab", {action: "current"})
            } else {
                Util.closeWindow(this, 'ok', json);
            }
        },
        async submit(btn) {
            if (this.type == 'EASY-DESIGN') {
                this.doEasySubmit("save", btn);
                return;
            }
            var validRequired = this.canStartFlow ? false : true;
            var validResult = await this.validForm(validRequired);
            if (!validResult.success) {
                this.$message.warning(validResult.msg);
                return;
            }
            this.doSubmit("save", btn)
        },
        doEasySubmit(action, btn) {
            var self = this;
            //拖拽表单，验证;
            this.$refs.rxForm.valid().then(res=>{
                //获取数据；
                let _data =  self.$refs.rxForm.getData() ;
                if (self.rxParent && self.rxParent.field) {
                    _data[self.rxParent.field] = self.rxParent.value;
                }
                btn.loading = true;
                let data = {setting: {action: action, alias: self.formSolutionAlias}, data: _data};
                FormSolutionApi.saveForm(data).then(res => {
                    btn.loading = false;
                    if (self.$refs.rxForm._afterSubmit) {
                        self.$refs.rxForm._afterSubmit(res, data);
                    }
                    if (res.success) {
                        var result = {formJson: data, result: res.data};
                        this.closeWindow(result);
                    }
                })
            })
        },
        doSubmit(action, btn) {
            var json = this.$refs.rxForm.getData();
            //清除字段前后空格；
            json = this.removeSpaces(json);
            if (this.rxParent && this.rxParent.field) {
                json[this.rxParent.field] = this.rxParent.value;
            }
            btn.loading = true;

            let self_=this;

            var data = {setting: {action: action, alias: this.formSolutionAlias}, data: json};
            FormSolutionApi.saveForm(data).then(async res => {
                btn.loading = false;
                if (self_.$refs.rxForm.formVm._afterSubmit) {
                    //如果_afterSubmit有返回结果并且rtn为success则返回。
                    let rtn= await self_.$refs.rxForm.formVm._afterSubmit(res, json);
                    if(rtn && rtn.success){
                        return;
                    }
                }
                if (res.success) {
                    this.handSuccess(action,res,json);
                }
            })
        },
        /**
         * 数据保存成功的处理。
         * 1.当action为数据保存的时候
         *   1.保存刷新页面。
         * 2.当启动流程的时候
         *   1.当打开窗口的时候，则关闭窗口。
         *   2.当不是打开窗口时，则跳转到流程实例页面。
         * @param action
         * @param res
         */
        handSuccess(action,res,json){
            if(action=="save"){
                //如果外部指定了需要关闭，并且是弹窗模式则关闭窗口。
                if(this.closeOnSave && this.isOpenWindow){
                    var result = {formJson: json, result: res.data};
                    this.closeWindow(result);
                }
                else{
                    //刷新页面。
                    this.pkId=res.data.pk;
                    //重新初始化。
                    this.init();
                }
            }
            //启动流程。
            else{
                //打开新窗口。
                if(this.isOpenWindow){
                    var result = {formJson: json, result: res.data};
                    this.closeWindow(result);
                }
                else{
                    let instId=res.data.instId;
                    this.$router.push({name:"openDoc",params:{instId:instId}});
                }
            }


        },
        handleProcessConfig(newVal) {
            let fillOpinion = false;
            let assignFlowUsers = false;
            let startCalFlowusers = false;
            //允许选择路径
            let allowSelectPath = newVal.allowSelectPath;

            var startOptions = newVal.startNodeOptions;

            if (startOptions instanceof Array) {
                this.processConfig.startConfirm = startOptions.indexOf('startConfirm') != -1;
                fillOpinion = startOptions.indexOf('fillOpinion') != -1;
                assignFlowUsers = startOptions.indexOf('assignFlowUsers') != -1;
                startCalFlowusers = startOptions.indexOf('startCalFlowusers') != -1;
            }
            if (fillOpinion || assignFlowUsers || startCalFlowusers || allowSelectPath) {//需要显示弹出对话框
                this.needConfirmDlg = true;
            }
        },
        //流程预演
        async bpmPreview(){
            var params = {
                flowDefMapping: this.formSolution.flowDefMapping,
                formJson: this.getFormData()
            }
            var flowDefRes = await FormSolutionApi.getFlowDefId(params);
            var flowDefId = flowDefRes.data;
            if(!flowDefId){
                this.$message.warning("无满足条件的流程定义！");
                return;
            }
            Util.open({
                component:BpmImageView,
                curVm:this,
                title:'流程预演',
                widthHeight:['1024px','600px'],
                data:{
                    defId:flowDefId,
                    formData:this.getFormData(),
                    preview:true
                }
            },function (action){
            });
        }
    },
    watch: {
        '$route': {
            handler: function (val) {
                this.init();
            },
            deep: true
        }
    }
}
</script>

<style scoped>
.layersty{
    overflow: hidden;
}
.layersty >>> .eidtFormContainer{
    overflow: initial;
    height: auto;
}
.buttongmodle {
    text-align: right;
}

.footerToolBar button {
    margin-right: 4px;
}

.footerToolBar button:last-child {
    margin-right: 0;
}

.footerToolBar {
    display: inline-block;
}

.ant-layout-footer {
    padding: 8px 20px;
    background: #fff;
    box-shadow: 0px 0px 3px #d2d2d2;
    z-index: 99;
}

.defaultContent {
    position: relative;
}

.content-div {
    position: absolute;
    top: 10px;
    right: 10px;
    left: 10px;
    bottom: 10px;
    border-radius: 6px;
    overflow-y: auto;
    background: #fff;
    overflow: auto;
}

.beLayout {
    top: 0px;
    right: 0px;
    left: 0px;
    bottom: 0px;
    background: #f0f2f5;
}

#formContainer {
    background-color: #fff;
}

#rx-form-container {
    position: absolute;
    top: 10px;
    bottom: 0;
    left: 0;
    right: 0;
    overflow: auto;
}
.kforms{
    background-color: #fff;
}
</style>