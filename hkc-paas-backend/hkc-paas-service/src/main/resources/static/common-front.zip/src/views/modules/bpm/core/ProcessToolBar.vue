<template>
  <div>
      <a-button-group v-if="!buttons || buttons.length==0">
        <a-button key="btnStart" :loading="startProcessStatus" @click="startProcess" type="primary" >启动流程</a-button>
        <a-button key="btnSave" :loading="saveDraftStatus" @click="saveDraft">保存</a-button>
        <a-button key="btnPrint" @click="formPrint">打印</a-button>
        <a-button key="btnFlowimg" @click="openFlowImg">流程图</a-button>
      </a-button-group>
      <a-button-group v-else>
        <template v-for="btn in buttons">
          <a-button v-if="btn.id=='btnStart'" :type="btn.style" :loading="startProcessStatus" :key="btn.id" @click="handMethod(btn)">{{btn.name}}</a-button>
          <a-button v-else-if="btn.id=='btnSave'" :type="btn.style" :loading="saveDraftStatus" :key="btn.id" @click="handMethod(btn)">{{btn.name}}</a-button>
          <a-button v-else :key="btn.id" :type="btn.style" @click="handMethod(btn)">{{btn.name}}</a-button>
        </template>
      </a-button-group>
      <rx-spin v-if="spinShow" :text="'正在提交...,请稍等。'"></rx-spin>
  </div>
</template>

<script>

    import {Util,RxSpin,RxTexList} from "jpaas-common-lib";
    import BpmInstApi from "@/api/bpm/core/bpmInst";
    import formbase from '@/api/formbase';
    import BpmInstStartConfirm from './BpmInstStartConfirm';
    import BpmInstStart from "./BpmInstStart";
    import {notification} from "ant-design-vue";

    export default {
      name: "ProcessToolBar",
      props: {
          processConfig:{type:Object},
          defId:{type:String},
          instId:{type:String},
          mainDefId:{type:String},
          mainTaskId:{type:String},
          vars:{type:Object,default:()=>{}}
      },
      mixins:[formbase],
      components:{
        RxSpin,
        RxTexList
      },
      data(){
        return {
          saveDraftStatus:false,
          startProcessStatus:false,
          buttons:[],
          startConfirm:false,
          spinShow:false,
          submited:false,
          saveed:false,
          needConfirmDlg:false,//是否需要弹出确认的对话框
        }
      },

      methods:{
        startSubProcess(alias){
          var self_=this;
          var formType=this.processConfig.formType;
          var formData={};
          if(formType=="online"){
            formData=this.rxForms.getData();
          }else{
            formData=this.customForm.getData();
          }
          BpmInstApi.getSubProcessFormData({
            defKey:alias,mainDefId:this.defId,instId:this.instId,formData:formData
          }).then(res=>{
            if(!res.success) {
              return;
            }
            self_.startFlowPage(res.data);
          })
        },
        startFlowPage(data){
          Util.open({
            component: BpmInstStart,
            curVm:this,
            max:true,
            title: data.defName + '流程启动',
            data:{
              defId:data.defId,
              mainDefId:this.defId,
              formData:data.formData,
              vars:data.vars
            }
          },function (action){
          });
        },
        async startProcess(){
            if(this.submited){
                this.$message.error("请勿重复提交流程！");
                return;
            }
            var validResult=await this.valid(true);
            if(!validResult.success){
                this.$message.error(validResult.msg);
                return ;
            }

            let self_=this;
            if(self_.startConfirm && !self_.needConfirmDlg){ //启动流程确认
              self_.$confirm({
                    title: '提示信息',
                    content: '确认启动流程吗？',
                    cancelText: '取消',
                    okText: '确认',
                    zIndex:20000,
                    onOk() {
                      self_.startFlow();
                    },
                    onCancel() {},
                });
            }else if(self_.needConfirmDlg){ //是否确认
                let conf = {
                  curVm: self_,
                  title:'流程启动确认',
                  component:BpmInstStartConfirm,
                  data: {processConfig: self_.processConfig,defId:self_.defId,instId:self_.instId},
                  widthHeight: ['800px', '520px']
                };
                Util.open(conf,function (action,data) {
                  if(action!='ok') return;
                    self_.closeWindow(data);
                });
            } else {
              self_.startFlow();
            }
        },
        async valid(validRquired){
            var res={success:true};
            //表单保存校验
            if(this.processConfig.formType =="custom"){
                res=await this.customForm.valid();
                return res;
            }else {
                res=await this.rxForms.valid(validRquired,true);
                return  res;
            }
        },
        afterSubmit(result,formJson){
          if(this.processConfig.formType !="custom"){
            this.rxForms.afterSubmit(result,formJson);
          }
        },
        async startFlow(){
          let self=this;
          self.spinShow = true ;
          this.startProcessStatus=true;
          let data={};
          if(this.processConfig.formType =="custom"){
            var jsonData=this.customForm.getData();
            var formJson=JSON.stringify(jsonData);
            data.formJson=formJson;
            data.defId=this.defId;
            if(this.instId){
              data.instId=this.instId;
            }
            data.systemHand=false;
          }else {
            data=this.getData();
          }

          var varData={mainDefId:this.mainDefId,mainTaskId:this.mainTaskId};
          if(this.vars){
            varData=Object.assign(varData,this.vars);
          }
          data.vars=JSON.stringify(varData);
          BpmInstApi.startProcess(data).then(res=>{
            self.afterSubmit(res,data);
            self.startProcessStatus=false;
            self.spinShow = false ;

            if(res.success){
                //启动流程成功
                let eventObj = {action: "start", data: res.data};
                this.$bus.emit("flowEvent", eventObj);
            }


          }).catch((error)=>{
            self.startProcessStatus=false;
            self.spinShow = false ;
          });
        },
        async saveDraft(){
            if((this.parentVm.fromRoute || !this.parentVm.instId) && this.saveed){
                this.$message.error("请勿重复保存！");
                return;
            }
          this.saveDraftStatus=true;
          var validResult=await this.valid(false);
          if(!validResult.success){
              this.$message.error(validResult.msg);
              this.saveDraftStatus=false;
              return ;
          }

          var data={};
          if(this.processConfig.formType =="custom"){
            var jsonData=this.customForm.getData();
            var formJson=JSON.stringify(jsonData);
            data.formJson=formJson;
            data.defId=this.defId;
            if(this.instId){
              data.instId=this.instId;
            }
            data.systemHand=false;
          }else {
            data=this.getData();
          }
          var varData={mainDefId:this.mainDefId,mainTaskId:this.mainTaskId};
          if(this.vars){
            varData=Object.assign(varData,this.vars);
          }
          data.vars=JSON.stringify(varData);
          BpmInstApi.saveDraft(data).then(res=>{
              if(res.success){
                  notification.success({
                      message: '操作提示',
                      description: res.message
                  });
                  //重新加载表单数据。
				  let eventObj = {action: "start", data: res.data};
				  this.$bus.emit("flowEvent", eventObj);
              }
              else{
                  notification.warning({
                      message: '操作提示',
                      description: res.message
                  })
              }

              this.saveDraftStatus=false;
              this.saveed=true;
              this.afterSubmit(res,data);

          });
        },
        formPrint(){
            var baseUrl=process.env.VUE_APP_API_CTX_PATH;
            var url=baseUrl +"/flowprint/" + this.defId ;
            if(this.instId){
                url+= "/" + this.instId;
            }
            else {
                url+= "/-1" ;
            }

            window.open(url);
        },
        closeWindow(data){
          this.submited=true;
          if(this.parentVm.fromRoute){
            this.parentVm.$bus.emit("closeTab",{action:"current"})
          }
          else{
            Util.closeWindow(this.parentVm, 'ok',data);
          }
        }
      },
      watch: {
          processConfig: {
              handler(newVal, oldVal) {
                  if (!newVal) {
                      return;
                  }
                  this.buttons = newVal.buttonConfigs;

                  let fillOpinion=false;
                  let assignFlowUsers=false;
                  let startCalFlowusers=false;
                  let relInsts=false;
                  //允许选择路径
                  let allowSelectPath= newVal.allowSelectPath;

                  var startOptions=newVal.startNodeOptions;

                  if (startOptions instanceof Array) {
                      this.startConfirm = startOptions.indexOf('startConfirm') != -1;
                      fillOpinion = startOptions.indexOf('fillOpinion') != -1;
                      assignFlowUsers = startOptions.indexOf('assignFlowUsers') != -1;
                      startCalFlowusers = startOptions.indexOf('startCalFlowusers') != -1;
                      relInsts  = startOptions.indexOf('relInsts') != -1;
                  }
                  if(fillOpinion || assignFlowUsers || startCalFlowusers || allowSelectPath || relInsts){//需要显示弹出对话框
                      this.needConfirmDlg=true;
                  }
              }
          }
      }
    }
</script>

<style scoped>
  .spinContainer{
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 999;
    padding-top: 40px;
    text-align: center;
  }
  .spinCenter{
    text-align: left;
    display: inline-block;
    padding: 10px;
    border-radius: 3px;
    background: #fff;
    position: absolute;
    box-shadow: 0px 0px 5px #ddd;
    top: 40%;
  }
</style>