<template>
    <rx-dialog @handOk="submitForm" @cancel="closeWindow" :canceltext="'关闭'">
      <a-form style="padding: 10px;">
<!--    a-form这个属性注释掉了 :form="form" 报错 而且我也不知道有什么用 yangxin 2020-12-10-->
        <a-form-item label="加签人员" :label-col="labelCol" :wrapper-col="wrapperCol">
          <rx-text-list
            v-model="signUsers"
            :textfield="'fullName'"
            :valfield="'userId'"
            @click="selectUsers"
            style="margin-top: 5px;"
          >
            <a-icon type="user"></a-icon>
          </rx-text-list>

        </a-form-item>
        <a-form-item label="消息" :label-col="labelCol" :wrapper-col="wrapperCol">
          <a-textarea v-model="opinion" style="width: 100%"/>
        </a-form-item>
        <a-form-item label="通知方式" :label-col="labelCol" :wrapper-col="wrapperCol">
          <a-checkbox-group :options="msgOptions" v-model="msgTypes">
        </a-checkbox-group>
        </a-form-item>
<!--        <a-form-item :label-col="labelCol" :wrapper-col="wrapperCol" style="text-align: center">
          <a-button type="primary" @click="submitForm()">确定</a-button>
          &nbsp;
          <a-button type="link" @click="closeWindow()">关闭</a-button>
        </a-form-item>-->
      </a-form>

    </rx-dialog>
</template>

<script>
    import {Dialog,Util,RxTextList,RxDialog} from 'jpaas-common-lib';
    import BpmtaskApi from "@/api/bpm/core/bpmTask";
    const msgOptions = [
        {label: '消息', value: 'InnerMsg'},
        {label: '短信', value: 'ShortMsg'},
        {label: '邮件', value: 'Email'},
        {label: '企业微信', value: 'EntWX'},
        {label: '钉钉', value: 'DingDing'}
    ];

    export default {
        name: "BpmTaskAddSign",
        props:{
            taskId:{//流程任务Id
                type:String,
                required:true
            },
            layerid: String,
            lydata: Object,
            destroy:Function
        },
        comments:{
          RxTextList,
            RxDialog
        },
        data (){
            return {
                labelCol: { span: 4 },
                wrapperCol: { span: 8 },
                opinion:'',
                msgOptions,
                msgTypes:[],
                signUsers:[],
                rxtext:[
                  {value:'aaa',text:'A'},
                  {value:'bbb',text:'b'}
                ]
            }
        },
        methods:{
            selectUsers(){
                let self=this;
                Dialog.openUserDialog({
                    curVm: this,data:{single:false}, widthHeight: ['800px', '600px']
                },function(self,data){
                    for(let i=0;i<data.length;i++){
                        self.signUsers.push({userId:data[i].userId,fullName:data[i].fullName});
                    }
                })
            },
            closeUser(userId){
                for(let i=0;i<this.signUsers.length;i++){
                    if(this.signUsers[i].userId==userId){
                        this.signUsers.splice(i,1);
                        return;
                    }
                }
            },
            closeWindow(){
                Util.closeWindow(this,'cancel');
            },
            submitForm(e){
                if(this.signUsers.length == 0 || this.opinion==''){
                    e.loading=false;
                    this.$message.error('请选择用户与填写意见！');
                    return ;
                }
                var userIds=[];
                this.signUsers.forEach(item=>{
                    userIds.push(item.userId);
                });

                BpmtaskApi.addSignUser({
                    taskId:this.taskId,
                    toUserIds:userIds.join(','),
                    opinion: this.opinion,
                    msgTypes:this.msgTypes.join(',')
                }).then(resp=>{
                    Util.closeWindow(this,'ok');
                });
            }
        }
    }
</script>

<style scoped>

</style>