import rxAjax from '@/assets/js/ajax.js';

export const SysTreeCatApi = {};

SysTreeCatApi.baseUrl= '/api-system/system/core/sysTreeCat';
SysTreeCatApi.exportUrl= SysTreeCatApi.baseUrl + '/export';

SysTreeCatApi.query=function (parameter) {
  var url= SysTreeCatApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

SysTreeCatApi.getCatList=function (parameter) {
  var url= SysTreeCatApi.baseUrl + '/getCatList';
  return rxAjax.get(url,parameter);
}

/**
 * 获取单记录
 * @param pkId
 * @returns {*}
 */
SysTreeCatApi.get =function(pkId) {
  var url= SysTreeCatApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

SysTreeCatApi.save =function(parameter) {
  var url= SysTreeCatApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

SysTreeCatApi.del =function(parameter) {
  var url= SysTreeCatApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

export  default SysTreeCatApi;
