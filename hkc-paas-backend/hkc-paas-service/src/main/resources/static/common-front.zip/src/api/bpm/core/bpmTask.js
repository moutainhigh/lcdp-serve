import rxAjax from '@/assets/js/ajax.js';
import BpmInstApi from "@/api/bpm/core/bpmInst";
export const BpmtaskApi = {};

BpmtaskApi.baseUrl= '/api-bpm/bpm/core/bpmTask';
BpmtaskApi.exportUrl= BpmtaskApi.baseUrl + '/export';

BpmtaskApi.query=function (parameter) {
  var url= BpmtaskApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter);
  /* return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })*/
}

/**
 * 获取当前用户后续的任务节点及执行人员
 */
BpmtaskApi.getTaskFlowNodesExecutors=function(taskId,checkType,formData){
  var url= BpmtaskApi.baseUrl + '/getTaskFlowNodesExecutors';
  return rxAjax.postJson(url,{taskId:taskId,checkType:checkType,formData:formData});
}

/**
 * 获取单记录
 * @param pkId
 * @returns {*}
 */
BpmtaskApi.get =function(pkId) {
  var url= BpmtaskApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}
BpmtaskApi.save =function(parameter) {
  var url= BpmtaskApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

BpmtaskApi.del =function(parameter) {
  let url= BpmtaskApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}
/**
 * 获取流程任务所有明细
 * @param taskId
 * @returns {*}
 */
BpmtaskApi.getAllDetail =function(taskId) {
  let url= BpmtaskApi.baseUrl + '/getTaskInfo?taskId='+taskId;
  return rxAjax.get(url);
}

/**
 * 完成审批
 * @param cmd
 * @returns {AxiosPromise}
 */
BpmtaskApi.checkComplete =function(cmd) {
  let url= BpmtaskApi.baseUrl + '/completeTask';
  return rxAjax.postJson(url,cmd);
}

/**
 * 取回任务
 * params:{
 *     instId:"",
 *     backNodeId:"",
 *     nextJumpType:"",
 *     opinion:""
 *
 * }
 */
BpmtaskApi.takeBackTask = function(params){
  let url= BpmtaskApi.baseUrl + '/takeBackTask';
  return rxAjax.postJson(url, params);
}

/**
 * 保存单据的数据
 * @param formData
 * @returns {AxiosPromise}
 */
BpmtaskApi.saveFormData = function (formData) {
  let url= BpmtaskApi.baseUrl + '/saveFormData';
  return rxAjax.postJson(url,formData);
}

/**
 * 更改任务的状态
 * @param status
 * @returns {AxiosPromise}
 */
BpmtaskApi.updateLocked = function (params) {
  let url= BpmtaskApi.baseUrl + '/updateLocked';
  return rxAjax.postForm(url,params);
}

/**
 * 任务沟通
 */
BpmtaskApi.submitTasklinkup = function(params){
  let url= BpmtaskApi.baseUrl + '/linkup';
  return rxAjax.postJson(url,params);
}

/**
 * 任务加会签用户
 */
BpmtaskApi.addSignUser = function(params){
  let url= BpmtaskApi.baseUrl + '/addSignUser';
  return rxAjax.postJson(url,params);
}

/**
 * 回复沟通任务
 */
BpmtaskApi.replyLinkupTask = function (parameters){
  let url= BpmtaskApi.baseUrl + '/replyLinkupTask';
  return rxAjax.postJson(url,parameters);
}

/**
 * 任务干预跳转
 * parameters {
 *  taskId  //任务Id
 *  destNodeId,//目标节点id
 *  toUserIds, // 最终用户Id,格式如1,2
 *  opinion, //跳转的原因
 *  msgTypes //通知的消息类型
 * }
 */
BpmtaskApi.jumpToNode = function (parameters){
  let url= BpmtaskApi.baseUrl + '/jumpToNode';
  return rxAjax.postJson(url,parameters);
}

/**
 * 取消流转
 * @param taskId
 */
BpmtaskApi.cancelTransRoamTask = function(taskId){
  let url= BpmtaskApi.baseUrl + '/cancelTransRoamTask?taskId='+taskId;
  return rxAjax.get(url);
}

/**
 * 流转
 */
BpmtaskApi.transRoamTask = function(params){
  let url= BpmtaskApi.baseUrl + '/transRoamTask';
  return rxAjax.postJson(url,params);
}

/**
 * 转办
 */
BpmtaskApi.transTask = function(params){
  let url= BpmtaskApi.baseUrl + '/transTask';
  return rxAjax.postJson(url,params);
}


BpmtaskApi.getCommuTasks = function(taskId){
  let params={taskId:taskId};
  let url= BpmtaskApi.baseUrl + '/getCommuTasks';
  return rxAjax.postForm(url,params);
}

BpmtaskApi.getRoamTasks = function(taskId){
  let params={taskId:taskId};
  let url= BpmtaskApi.baseUrl + '/getRoamTasks';
  return rxAjax.postForm(url,params);
}


BpmtaskApi.revokeCmTask = function(taskId,delOpinion){
  let params={taskId:taskId,delOpinion:delOpinion};
  let url= BpmtaskApi.baseUrl + '/revokeCmTask';
  return rxAjax.postForm(url,params);
}

BpmtaskApi.canReplyCommu = function(taskId){
  let params={taskId:taskId};
  let url= BpmtaskApi.baseUrl + '/canReplyCommu';
  return rxAjax.postForm(url,params);
}

BpmtaskApi.getBackNodes=function(taskId){
  let url = BpmtaskApi.baseUrl + '/getBackNodes/'+taskId;
  return rxAjax.get(url);
}

BpmtaskApi.setAssignee=function(bpmTask,userIds){
  let params={bpmTask:bpmTask,userIds:userIds};
  let url ='/api-bpm/bpm/core/bpmTaskUser/setAssignee';
  return rxAjax.postJson(url,params);
}

BpmtaskApi.temporaryOpinion=function(taskId,opinion,id){
  var params={taskId:taskId,opinion:opinion,id:id};
  var url = '/api-bpm/bpm/core/bpmTemporaryOpinion/saveOpinion';
  return rxAjax.postForm(url,params);
}

BpmtaskApi.getTemporaryOpinion=function(taskId){
  var url = '/api-bpm/bpm/core/bpmTemporaryOpinion/getTemporaryOpinion?taskId='+taskId;
  return rxAjax.get(url);
}


BpmtaskApi.batApprove=function(json){
  var url = '/api-bpm/bpm/core/bpmTask/batCompleteTask';
  return rxAjax.postJson(url,json);
}


//获取审批类型
BpmtaskApi.getCheckTypes=function (){
    let url ="/api-system/system/core/sysProperties/getCheckTypes";
    return rxAjax.get(url);
}

export  default BpmtaskApi;
