<template>
    <a-layout class="layersty" style="height:100%;">
        <a-layout-content style="order:1" class="defaultContent">
            <rx-layout>
                <div slot="center" :span="24" id="html">
                    <div v-html="pdfHtml">
                    </div>
                </div>
            </rx-layout>

        </a-layout-content>

        <a-layout-footer style="order:0;">
            <a-form class="buttongmodle">
                <a-button-group>
                    <a-button @click="print()">打印</a-button>
                </a-button-group>
            </a-form>
        </a-layout-footer>

    </a-layout>
</template>

<script>
    import FormPdfTemplateApi from "@/api/form/core/formPdfTemplate";
    import print from 'print-js';
    import {Util, RxDialog, RxLayout} from 'jpaas-common-lib';

    export default {
        name: "FormPdfHtml",
        props: ["pkId", "layerid","lydata", "destroy", "dataJson","metadata"],
        components: {
            RxDialog,
            RxLayout,
        },

        data() {
            return {
                pdfHtml: '',
            }
        },
        created() {
            this.loadData();
        },
        methods: {
            print() {
                var self_ = this;
                console.log('打印')
                printJS({
                    printable: 'html',
                    scanStyles: false,
                    style: '#html .firstRow th {text-align:left}', //传入自定义时的样式
                    type: 'html',
                    targetStyles: ['*'],
                    ignoreElements: ['no-print', 'bc', 'gb']
                })
            },
            loadData() {
                let self_ = this;
                if (!self_.pkId) {
                    return;
                }
                let data = JSON.parse(JSON.stringify(self_.dataJson||self_.lydata.dataJson));
                delete data.initData;
                var values = Object.values(self_.metadata||self_.lydata.metadata);
                FormPdfTemplateApi.getTemplate({pkId: this.pkId, data: JSON.stringify(data),metadata: JSON.stringify(values)}).then(res => {
                    var html = res.data;
                    this.pdfHtml = html;
                })
            },
        }

    }
</script>

<style scoped>
    .buttongmodle {
        text-align: right;
    }

    .ant-layout-footer {
        padding: 8px 20px !important;
    }
</style>