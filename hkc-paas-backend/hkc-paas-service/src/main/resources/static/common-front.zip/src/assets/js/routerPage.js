
const routerPage = function (config){
    let _self = config.self ;
    let _name = config.name;
    let _component = config.component;
    let _urlType = config.urlType ? config.urlType :'Add'
    let obj = {//里面的字符串拼接-请务必用双引号
      path: _name + _urlType + "/:pkId",
      name: _name+ _urlType,
      component: _component,
      props:true,
      meta: {
        title: config.title //传入当前页面的名字；
      }
    }
    let pathArr = [];
    pathArr.push(obj);
    var _options = _self.$router.options.routes;
    _options.forEach(item => {
      if (item.path == '/editPage') {
        let childrenArr = item.children;
        pathArr.forEach((p,index) => {
            let _path = p.path;
            let _names = p.name;
            if (childrenArr.length > 0) {
                let isContain = false;
                let idx = null;
                for (let i = 0; i < childrenArr.length; i++) {
                    let _name2 = childrenArr[i].name;
                    if (_names == _name2) {
                        isContain = true;
                        idx = i;
                        break;
                    }
                }
                if (isContain) {
                    childrenArr[idx] = p;
                } else {
                    childrenArr.push(p);
                }
            } else {
                childrenArr.push(p);
            }
        })
      }
    })
  _self.$router.addRoutes(_self.$router.options.routes);
}
export default routerPage ;
