<template>
  <rx-dialog @handOk="handleSubmit" @cancel="cancel">
    <a-form :form="form">
      <a-form-item style="display:none">
        <a-input v-decorator="['dicId']"/>
        <a-input v-decorator="['parentId',{initialValue:mdl.parentId}]"/>
        <a-input v-decorator="['treeId',{initialValue:mdl.treeId}]"/>
      </a-form-item>

      <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="项名">
        <a-input placeholder="项名" v-decorator="['name', {rules: [{required: true, message: '请输入项名'}]}]"/>
      </a-form-item>
      <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="项值">
        <a-input placeholder="项值" v-decorator="['value', {rules: [{required: true, message: '请输入项值'}]}]"/>
      </a-form-item>
      <a-form-item :labelCol="labelCol" :wrapperCol="wrapperCol" label="序号">
        <a-input-number :min="0" :max="1000000" placeholder="序号" v-decorator="['sn', {rules: [{required: true, message: '请输入序号'}]}]"/>
      </a-form-item>
    </a-form>
  </rx-dialog>
</template>
<script>
  import SysDicApi from '@/api/system/core/sysDic'
  import {BaseForm, RxDialog} from "jpaas-common-lib";
  export default {
    name: 'SysDicEdit',
    mixins:[BaseForm],
    props: {
      data:Object,
      layerid: String,
      lydata: Object,
      destroy: Function,
    },
    data() {
      return {

      }
    },
    components: {
      RxDialog,
    },
    methods: {
      onload_(vals){
        if(!this.pkId){
          Object.assign(this.mdl,this.data);
          console.info(this.mdl);
        }
      },
      get(id){
        return SysDicApi.get(id);
      },
      save(values){
        return SysDicApi.save(values);
      },

    }
  }
</script>
