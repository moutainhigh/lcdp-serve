import rxAjax from '@/assets/js/ajax.js';

//表单权限配置 api接口
export const LoginApi = {};

LoginApi.authUrl= '/api-uaa';
LoginApi.userUrl= '/api-user';



//获取用户信息
LoginApi.getUserInfo = () => rxAjax.get(
  LoginApi.userUrl+'/user/org/osUser/current'
)

//退出登录
LoginApi.logout = (token) => rxAjax.postUrl(
  LoginApi.authUrl+'/oauth/remove/token',
  {"token": token}
)

export  default LoginApi;
