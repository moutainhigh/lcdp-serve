<template>
    <div class="formBox" style="width: 100%;height:100%;">
        <component :is="currentView" v-bind="props" :key="viewKey"></component>
    </div>
</template>

<script>
import userState from "@/assets/js/userState";
import {RxFit, Util} from "jpaas-common-lib";
import BpmInstApi from "@/api/bpm/core/bpmInst";
import BpmInstStart from "@/views/modules/bpm/core/BpmInstStart";
import BpmTaskStart from "@/views/modules/bpm/core/BpmTaskStart";
import BpmInstDetail from "@/views/modules/bpm/core/BpmInstDetail";
import RxLoading from "@/views/modules/bpm/workbench/RxLoading";
import FlowUtil from "@/views/modules/bpm/workbench/js/FlowUtil";

//打开文档的窗口
export default {
    name: "OpenDoc",
    mixins: [userState,FlowUtil],
    components:{
        RxFit
    },
    data(){
        return {
            props:{},
            currentView:RxLoading,
            actionMap:{
                start:BpmInstStart,
                startDraft:BpmInstStart,
                task:BpmTaskStart,
                detail:BpmInstDetail,
            },
            viewKey:"",
        }
    },
    created() {
        this.init();
        this.$bus.on("flowEvent",(e=>{
            this.handEvent(e);
        }))

    },
    beforeDestroy(){
        this.$bus.off("flowEvent");
    },

    methods:{
        init(){
            let type=this.$route.name;
            let params=this.$route.params;
            let action=this.$route.query.action;

            let id=this.$route.name=="newDoc"?params.defKey:params.instId;

            BpmInstApi.getInfoByDefKeyInstId(type,id,action).then(res=>{
                if(!res.success){
                    this.$message.warn(res.message);
                    return;
                }
                this.viewKey=Util.randomId();
                this.currentView=this.actionMap[res.action];

                if(res.action=="start") {
                    let conf={defKey: id};
                    this.props.config = conf;
                }
                if(res.action=="startDraft" ){
                    this.props.instId= res.instId;
                    this.props.config={defKey:res.defKey};
                }
                if(res.action=="task" ){
                    this.props.taskId= res.taskId;
                    this.props.instId= res.instId;
                }
                if(res.action=="detail" ){
                    this.props.instId= res.instId;
                }

            })
        },
        handEvent(event){
            if(event.action=="start"){
                let instId=event.data.instId;
                this.pushInst(instId);
            }
            if(event.action=="task"){
                let instId=event.data;
                this.pushInst(instId);
            }
            if(event.action=="inst"){
                let instId=event.data;
                this.pushInst(instId);
            }

        }
    },
    watch:{
        "$route":function (val,oldVal){
            this.init();
        }
    }
}
</script>

<style scoped>
.formBox{
    display: flex;
    flex-direction: column;
}

.formContainer{
    flex: 1;
    position: relative;
}
.formContainerRoll .formCenter{
    max-width: 1300px;
    margin: auto;
}
.formContainerRoll{
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    overflow: auto;
}
.formFooter{
    text-align: right;
    padding: 10px;
    border-top: 1px solid #ddd;
}
.formFooter button{
    margin-left: 6px;
}
.header{
    background-color: #4285f4;
    display: flex;
    justify-content: space-between;
    height: 50px;
    align-items: center;
    padding: 0 10px;
    color: #fff;
}
.logoText{
    display: inline-block;
    padding: 2px 8px;
    line-height: normal;
    border:1px solid #fff;
    border-radius: 4px;
    font-weight: bold;
    margin-right: 6px;
}
.rightToolBar{
    display: flex;
}
.current{
    margin-left: 16px;
    position: relative;
}
.treeBox .text .icon{
    padding-right: 6px;
}
.treeBox .text{
    margin-right: 6px;
}
</style>