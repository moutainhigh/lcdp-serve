<template>
  <rx-dialog @handOk="transfer" @cancel="closeWindow" :oktext="'提交'" order="buttom" btnalign="center">
    <rx-fit>
      <div style="height:100%;width:100%;padding:20px;">
      <a-form-model :model="form">
        <a-form-model-item label="抄送人" :label-col="labelCol" :wrapper-col="wrapperCol" v-if="send" >
          <rx-user-component v-model="copyUsers" :isAccount="false" :single="false"></rx-user-component>
        </a-form-model-item>

        <a-form-model-item label="意见" :label-col="labelCol" :wrapper-col="wrapperCol" >
          <a-textarea v-model="form.opinion"></a-textarea>
        </a-form-model-item>

        <a-form-model-item label="附件" :label-col="labelCol" :wrapper-col="wrapperCol">
          <rx-attach-component v-model="files" ></rx-attach-component>
        </a-form-model-item>

        <a-form-model-item label="通知方式" :label-col="labelCol" :wrapper-col="wrapperCol" v-if="send">
          <a-checkbox-group :options="msgOptions" v-model="msgTypes"></a-checkbox-group>
        </a-form-model-item>
      </a-form-model>
    </div>
  </rx-fit>
  </rx-dialog>
</template>
<script>

import { Dialog, RxDialog, Util, RxFit, RxUserComponent,RxAttachComponent,RxTextList} from 'jpaas-common-lib';
import BpmPublicApi from '@/api/bpm/core/BpmPublicApi';
import BpmInstCcApi from '@/api/bpm/core/bpmInstCc';

export default {
  name: 'bpm-task-transfer',
  components: {
      RxUserComponent,
      RxAttachComponent,
      RxFit,
      RxDialog,
      RxTextList
  },
  props: {
    layerid: String,
    lydata: Object,
    destroy: Function,
    instId:String,
    send:{
        type: Boolean,
        default:true
    }

  },
  data() {
    return {

      labelCol: { span: 4 },
      wrapperCol: { span: 8 },
      msgOptions:[],

      copyUsers:[],
      files:[],
      msgTypes:[],
      form:{
          copyUsers:"",
          files:"[]",
          msgTypes:"",
          opinion:"",
          send:this.send,
          instId:this.instId
      }
    }
  },
  created(){
      this.initMessageHandler();
  },
  methods: {
    initMessageHandler(){
        BpmPublicApi.getMessageHandler().then(res=>{
            for(var i=0;i<res.length;i++){
                var o=res[i];
                var obj={ label: o.name, value: o.type };
                this.msgOptions.push(obj);
            }
        })
    },
    transfer(){
        if(this.form.send){
            if(this.copyUsers.length==0){
                this.$message.warning("请选择执行人!");
                return;
            }
        }



        this.form.copyUsers=JSON.stringify(this.copyUsers);
        this.form.files=JSON.stringify(this.files);
        this.form.msgTypes=JSON.stringify(this.msgTypes);

        BpmInstCcApi.transfer(this.form).then(res=>{
          if(res.success){
              Util.closeWindow(this, 'ok');
          }
        });
    },
    closeWindow() {
        Util.closeWindow(this, 'cancel')
    },

  }
}
</script>