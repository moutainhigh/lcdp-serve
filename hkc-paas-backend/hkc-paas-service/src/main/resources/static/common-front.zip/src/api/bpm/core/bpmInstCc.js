import rxAjax from '@/assets/js/ajax.js';
import BpmInstApi from "@/api/bpm/core/bpmInst";

const BpmInstCcApi = {
  baseUrl: '/api-bpm/bpm/core/bpmInstCc'
}

//通过定义获取视图
BpmInstCcApi.updRead=function (cpId) {
  var url= BpmInstCcApi.baseUrl + '/updRead';
  var obj={cpId:cpId};
  return rxAjax.postForm(url,obj);
}


BpmInstCcApi.getByInstId=function (instId) {
  var url= BpmInstCcApi.baseUrl + '/getByInstId';
  var obj={instId:instId};
  return rxAjax.postForm(url,obj);
}

BpmInstCcApi.transfer=function(json){
  let url = BpmInstCcApi.baseUrl + '/transfer';
  return rxAjax.postJson(url,json);
}


export default BpmInstCcApi;