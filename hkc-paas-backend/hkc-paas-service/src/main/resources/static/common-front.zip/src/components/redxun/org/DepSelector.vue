<template>
  <a-cascader
    :loadData="loadData"
    :name="name"
    :options="orgData"
    :placeholder="placeholder"
    :v-decorator="v-decorator"
    @change="onChange"
    v-model="value"
    changeOnSelect
  />
</template>

<script>
    import {getAdminOrg,getParentGroup} from '@/api/user/org/osGroup'
    export default {
      name: "部门选择组件",
      props: ["name", "placeholder", "v-decorator"],
      data() {
        return {
          orgData: [],
          value:''
        }
      },
      created() {
        let scopeThis = this;
        getAdminOrg().then(resp => {
          let data = resp.data;
          for (let i = 0; i < data.length; i++) {
            let rs = data[i];
            let isLeaf = rs.isLeaf == '1' ? true : false;
            scopeThis.orgData.push({label: rs.name, value: rs.groupId, key: rs.key, isLeaf: isLeaf})
          }
        });
      },
      methods: {
        //加载第一级组织架构
        loadTopDeps() {

        },
        loadData(selectItems) {

          const targetOption = selectItems[selectItems.length - 1];

          let scopeThis = this;
          if (targetOption.children) {
            return;
          }
          targetOption.loading = true;
          return getParentGroup(targetOption.value).then(data => {
            targetOption.loading = false;
            let treeData = [];
            for (let i = 0; i < data.length; i++) {
              let rs = data[i];
              let isLeaf = rs.isLeaf == '1' ? true : false;
              treeData.push({label: data[0].name, value: data[0].groupId, key: data[0].key, isLeaf: isLeaf})
            }
            targetOption.children = treeData;
            scopeThis.orgData = [...scopeThis.orgData];
          });
        }
      },
      watch:{
        value(val,oldVal){
          this.$emit("input",val);
        }
      }
    }
</script>

<style scoped>

</style>