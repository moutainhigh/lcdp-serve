import { getRouters } from '@/utils/routerUtil'


const appSetting = {
	namespaced: true,
	state: {
		user:{}, //当前用户
		appKey:"",//应用标识
		menus: [],//所有菜单
		selectMenu: {},//选中的菜单
		buttons:{}, //当前用户权限 应用按钮
		navigations:[],//面包屑导航
		navigation:[{key:'home-index',title:'首页',collapsed:false}],//导航栏 默认首页 {key:'home-index',title:'首页',collapsed:false};
		selectedKeys:[],//左边树选中的key
		activeKey:'',//导航栏当 前选中相 ;
		showHome:true,//展示方式
		appId:"",//应用ID
		appName:"",//应用名称
		showType:'window',//列表按钮窗口类型 window弹窗，newPage新页面；
		routers:[], //路由
		allButtons:{},//所有菜单按钮
		idKey:'',//权限的key
		menuMap:[],
		menuPath:[],
		pmzturl:'',
    	appmenuId:'',
		newPageMenu:"", //保存新窗口打开的页面 防止死循环
		openAppType:'window',//微前端打开方式window新窗口，inner内置
	},
	mutations: {
		setSelecteKeys: (state, defaultKeys) => {
			state.selectedKeys = defaultKeys;
		  },
		setAppMenuId:(state,appmenuId) =>{
			state.appmenuId = appmenuId;
		  },
		setpmzturl:(state,pmzturl)=>{
			state.pmzturl = pmzturl
		  },
		setUser: (state, user) => {
			state.user = user;
		},
		setAppKey: (state, appKey) => {
			state.appKey = appKey;
		},
		setMenus: (state, menus) => {
			state.menus = menus;
		},
		setSelectMenu: (state, selectMenu) => {
			state.selectMenu = selectMenu;
		},
		setButtons: (state, buttons) => {
			state.buttons = buttons;
		},
		setNavigations:(state,navigations)=>{
			state.navigations = navigations
		},
		setNavigation:(state,navigation)=>{
			state.navigation = navigation;
		},
		setActiveKey:(state,activeKey)=>{
		state.activeKey = activeKey;
		},
		setShowHome:(state,showHome)=>{
			state.showHome = showHome
		},
		setAppId:(state,appId)=>{
			state.appId = appId
		},
		setAppName:(state,appName)=>{
			state.appName = appName
		},
		setShowType:(state,showType)=>{
			state.showType = showType
		},
		setRouters: (state, routers) => {
			state.routers = routers;
		},
		setAllButtons: (state, allButtons) => {
			state.allButtons = allButtons;
		},
		setIdKey: (state, idKey) => {
			state.idKey = idKey;
		},
		setMenuMap: (state, menuMap) => {
			state.menuMap = menuMap;
		},
		setMenuPath:(state,menuPath)=>{
			state.menuPath = menuPath
		},
		setNewPageMenu:(state,newPageMenu)=>{
			state.newPageMenu = newPageMenu
		},
		setOpenAppType :(state,type) => {
			state.openAppType = type
		}
	},
	actions: {
		/**
		 * 构建路由
		 * @param commit
		 * @param data
		 * @returns {Promise<any>}
		 * @constructor
		 */
		buildRoutes({ commit }) {
			var appKey=this.state.appSetting.appKey;
			return new Promise(resolve => {
				getRouters(appKey).then(res => {
					var routers=res.routers;
					commit('setMenuMap', res.menuMap);
					commit('setButtons', res.buttons);
					commit('setMenus', res.menus);
					commit('setUser', res.user);
					commit('setAppId', res.appId);
					commit('setAppName',res.appName);
					commit('setRouters',routers);
					commit('setAllButtons',res.allButtons);
					resolve(routers)
				})
			})
		},
	}
}
export default appSetting;
