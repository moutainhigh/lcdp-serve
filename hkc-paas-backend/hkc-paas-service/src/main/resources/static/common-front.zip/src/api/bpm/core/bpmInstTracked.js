import rxAjax from '@/assets/js/ajax.js';

//流程实例跟踪 api接口
export const BpmInstTrackedApi = {};

BpmInstTrackedApi.baseUrl= '/api-bpm/bpm/core/bpmInstTracked';
BpmInstTrackedApi.exportUrl= BpmInstTrackedApi.baseUrl + '/export';

//查询列表
BpmInstTrackedApi.query=function (parameter) {
  var url= BpmInstTrackedApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
* 获取单记录
* @param pkId
* @returns {*}
*/
BpmInstTrackedApi.get =function(pkId) {
  var url= BpmInstTrackedApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

//保存数据
BpmInstTrackedApi.save =function(parameter) {
  var url= BpmInstTrackedApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

//删除数据
BpmInstTrackedApi.del =function(parameter) {
  var url= BpmInstTrackedApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

// 获取流程实例
BpmInstTrackedApi.doTracked =function(instId) {
    let params={instId:instId};
    let url= BpmInstTrackedApi.baseUrl + '/doTracked';
    return rxAjax.postForm(url,params);
}

BpmInstTrackedApi.removeTracked =function(instId) {
    let params={instId:instId};
    let url= BpmInstTrackedApi.baseUrl + '/removeTracked';
    return rxAjax.postForm(url,params);
}

export  default BpmInstTrackedApi;

