<template>
    <div>
        正在加载中
    </div>
</template>

<script>
export default {
    name: "rx-loading"
}
</script>

<style scoped>

</style>