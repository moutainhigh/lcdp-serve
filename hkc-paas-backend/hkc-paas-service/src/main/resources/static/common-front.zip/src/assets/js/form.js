import {Util} from 'jpaas-common-lib'

export default {
  props:["pkId","layerid","destroy"],
  data () {
    return {
      visible: false,
      labelCol: { span:6 },
      wrapperCol: { span:18 },
      labelCol1: { span:3 },
      wrapperCol1: { span:19 },
      confirmLoading: false,
      mdl: {},
      form: this.$form.createForm(this,{
        onValuesChange: (_, values) => {
          var self_=this;
          if(this.handFieldChange){
            Util.delay(function(){
              self_.handFieldChange(values);
            },200);
          }
        }
      }),
      resultData:{},

    }
  },
  created(){
    this.loadData();
  },
  methods: {
    loadData(){
      if(!this.pkId){
        if(this.onload_){
          this.onload_()
        }
        return;
      }
      this.confirmLoading = true;
      this.get(this.pkId).then (res => {
        this.confirmLoading = false;
        if(res.success && res.code==200) {
          var data=res.data;
          this.initJson(data);
          if(this.onload_){
            this.onload_(data)
          }
          this.mdl = Object.assign(data);
          this.form.setFieldsValue(this.mdl)
        }
      })
    },
    cancel(){
      Util.closeWindow(this,"cancel");
    },
    /**
     * 在提交时将json 数据分解为两个字段。
     * @param row         行数据
     * @param field       字段名称
     * @param textField   文本字段
     * @param valField    值字段
     */
    parseJson(row,field,textField,valField){
      var val=row[field];
      if(!val){
        return ;
      }
      var json=JSON.parse(val);
      delete  row[field];
      if(textField){
        row[textField]=json.text;
      }
      if(valField){
        row[valField]=json.value;
      }
    },
    /**
     * 在加载数据时将记录促成 json 数据。
     * @param row           一行数据
     * @param form          需要构建的目标数据
     * @param textField     文本字段
     * @param valField      值字段
     */
    toJson(row,form,textField,valField){
      var text=row[textField];
      var val=row[valField];
      var json={text:text,value:val};
      row[form]=JSON.stringify(json);
    },
    initJson(json){
      if(!this.complexJson){
        return;
      }
      var main=this.complexJson.main;
      for(var key in main){
        var obj=main[key];
        this.toJson(json,key,obj.text,obj.value);
      }

      //处理子表。
      for(var table in this.complexJson){
        if(table!="main"){
          continue;
        }
        var tableKey="sub__" + table;
        var tableData=json[tableKey];
        if(!tableData){
          if(!sub){
            continue;
          }
        }
        var sub=this.complexJson[table];
        if(!sub){
          continue;
        }
        for(var i=0;i<tableData.length;i++){
          var row=tableData[i];
          for(var key in sub){
            var obj=sub[key];
            this.toJson(row,key,obj.text,obj.value);
          }
        }
      }
    },
    onSubmit(json){
      /*
      {value:aa,text:""}
      * main:{user:{text:"",value:""}},
      * table:{user:{text:"",value:""}}
      * */
      if(!this.complexJson){
        return;
      }
      var main=this.complexJson.main;
      for(var key in main){
        var obj=main[key];
        this.parseJson(json,key,obj.text,obj.value);
      }
      //处理子表。
      for(var table in this.complexJson){
        if(table!="main"){
          continue;
        }
        var tableKey="sub__" + table;
        var tableData=json[tableKey];
        if(!tableData){
          continue;
        }
        var sub=this.complexJson[table];
        if(!sub){
          continue;
        }
        for(var i=0;i<tableData.length;i++){
          var row=tableData[i];
          for(var key in sub){
            var obj=sub[key];
            this.parseJson(row,key,obj.text,obj.value);
          }
        }
      }
    },
    handleSubmit (e) {
      this.form.validateFields((err, values) => {
        if(err) {
          return;
        }
        values.pkId=this.pkId;
        this.confirmLoading = true;
        if(this.validForm){
          var flag=this.validForm(values);
          if(!flag){
            return;
          }
        }
        this.onSubmit(values);
        this.save(values).then(res => {
          if(res.success && res.code==200){
            //返回结果数据。
            this.resultData=res.data;
            Util.closeWindow(this,"ok");
          }
        }).catch(() => {
          this.$message.error('系统错误，请稍后再试!')
        }).finally(() => {
          this.confirmLoading = false
        })
      })
    }
  },
  watch:{
    mdl:{
      handler:function(val,oldval){
        this.form.setFieldsValue(this.mdl);
      },
      deep:true
    }
  }

}