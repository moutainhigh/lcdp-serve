import Vue from 'vue'
import VueRouter from 'vue-router'
import {constantRouterMap} from "@/router/router";
Vue.use(VueRouter);
var path =process.env.BASE_URL;
export default new VueRouter({
	mode: 'history',
	base: path,
	scrollBehavior: () => ({ y: 0 }),
	routes: constantRouterMap
})
