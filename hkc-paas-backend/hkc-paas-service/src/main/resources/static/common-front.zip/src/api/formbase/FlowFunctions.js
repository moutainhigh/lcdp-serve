import rxAjax from "@/assets/js/ajax";
import BpmImageView from "@/views/modules/bpm/comps/BpmImageView";
import {Util} from "jpaas-common-lib";


export default {
    methods:{
        /**
         * 打开表单组件。
         * @param conf
         *
         * this.open({
         *   component:'modules/form/customform/DemoOpen.vue',
         *   curVm:this.parentVm,
         *   max:true,
         *   widthHeight: ['800px', '600px'],
         *   title: '测试',
         *   data:{name:"ray",age:20}
         *   },function (action,data){
         *       console.info(data);
         *       debugger
         *   });
         *
         * @param destroy
         */
        open(conf,destroy){
            var data= conf.data;
            var component=conf.component;

            let dataObj={};

            for (let key in data) {
                let value=data[key];
                if(!value){
                    continue;
                }
                dataObj[key]=value;
            }
            if(component) {
                conf.component = this.getOpenDialogComponet(data);
                var obj=require(`@/views/${component}`).default;
                conf.data={currentView:obj,...dataObj};
                Util.open(conf,destroy);
            }else{
                alert("请填写相应组件路径！");
            }
        },

        openUrl(conf,destroy){
            var url=conf.url;
            if(url) {
                conf.component = this.getOpenDialogComponet();
                conf.data={url:url};
                Util.open(conf,destroy);
            }else{
                alert("请填写相应URL路径！");
            }
        },

        /**
         * 返回rxAjax
         * @returns {*}
         */
        getRxAjax(){
            return rxAjax;
        },
        /**
         * 打开流程图。
         */
        openFlowImg(){
            var defId=this.parentVm.localDefId;
            let obj = {
                widthHeight:['1024px','600px'],
            }
            if(this.isMobile){
                obj.max=true;
                delete obj.widthHeight
            }
            Util.open({
                component:BpmImageView,
                curVm:this.parentVm,
                ...obj,
                title:'流程图',
                data:{
                    defId:defId,
                    formData:this.getFormData()
                }
            },function (action){
            });
        },
        //流程预演
        bpmPreview(){
            var defId=this.parentVm.localDefId;
            Util.open({
                component:BpmImageView,
                curVm:this.parentVm,
                title:'流程预演',
                widthHeight:['1024px','600px'],
                data:{
                    defId:defId,
                    formData:this.getFormData(),
                    preview:true
                }
            },function (action){
            });
        }
    }
}