<template>
    <div class="wrap">
        <div><filter-params @paramsChange="paramsChange" :config="config" :filterParams="config.filterParams" ></filter-params></div>
        <div style="height: 100%" :ref="config.alias"></div>
    </div>
</template>

<script>
import ChartPublic from '../formComponent/ChartPublic'

export default {
    /**
     * 折线图
     */
    name: "line-component",
    mixins: [ChartPublic],
    data() {
        return {
        }
    },
    methods: {
        setOption(){
            //图例组件
            var legend = [];
            //图例组件配置
            var legendArr = [];
            //直角坐标系 grid 中的 x 轴
            var xAxis = {};
            //x轴维度配置
            var xAxisArr = [];
            //yAxis直角坐标系 grid 中的 y 轴
            var yAxis =  {type: 'value'};
            /**
             *系列列表
             [{name: 名称,
             type: 类型,
             data: 数据 []
             }]
             */
            var series = [];

            //获取维度
            xAxis=this.getDimensions(xAxisArr);

            //未配置颜色图例
            if(this.config.colorLegends.length==0){
                //获取度量
                for (var i = 0; i < this.config.measures.length; i++) {
                    var array=[];
                    var measure = this.config.measures[i];
                    legend.push(measure.fieldLabel);
                    for (var j = 0; j < this.data.length; j++) {
                        var value= this.data[j][measure.tableName+'_'+measure.fieldName];
                        if(value){
                            array.push(value);
                        }else {
                            array.push(0);
                        }
                    }
                    var obj={
                        name: measure.fieldLabel,
                        type:this.config.reportType,
                        data:array,
                        smooth: this.config.advConfig.smooth
                    }
                    series.push(obj);
                }
            }else {
                //根据颜色图例与度量获取图例组件
                for (var i = 0; i < this.config.colorLegends.length; i++) {
                    var colorLegend = this.config.colorLegends[i];
                    for (var j = 0; j < this.config.measures.length; j++) {
                        var measure = this.config.measures[j];
                        for (var k = 0; k < this.data.length; k++) {
                            var colorValue =this.getColorValue(this.data[k],colorLegend,measure);
                            var number = legend.indexOf(colorValue);
                            if(number==-1){
                                legend.push(colorValue);
                                legendArr.push({
                                    key:measure.tableName+"_"+measure.fieldName,
                                    fieldName:colorLegend.tableName+'_'+colorLegend.fieldName,
                                    value:this.data[k][colorLegend.tableName+'_'+colorLegend.fieldName]
                                })
                            }
                        }
                    }
                }
                for (var i = 0; i < legendArr.length; i++) {
                    var legendObj=legendArr[i];
                    var array=[];
                    for (var j = 0; j < xAxisArr.length; j++) {
                        var val=0;
                        for (var k = 0; k < this.data.length; k++) {
                            var xAxisObj=xAxisArr[j];
                            if(this.config.dimensions.length>1){
                                var xAxisKeys = xAxisObj.key.split("-");
                                var xAxisVal="";
                                for (var l = 0; l < xAxisKeys.length; l++) {
                                    if(l!=0){
                                        xAxisVal+="-";
                                    }
                                    var xVal = this.data[k][xAxisKeys[l]];
                                    //维度配置了字段渲染
                                    if(typeof(xVal)!='string'){
                                        xVal=xVal.oldValue;
                                    }
                                }
                                if(xAxisVal==xAxisObj.value && this.data[k][legendObj.fieldName]==legendObj.value ){
                                    val=this.data[k][legendObj.key];
                                    break;
                                }
                            }else {
                                var xVal = this.data[k][xAxisObj.key];
                                //维度配置了字段渲染
                                if(typeof(xVal)!='string'){
                                    xVal=xVal.oldValue;
                                }
                                if(xVal==xAxisObj.value && this.data[k][legendObj.fieldName]==legendObj.value ){
                                    val=this.data[k][legendObj.key];
                                    break;
                                }
                            }

                        }
                        array.push(val)
                    }

                    var obj={
                        name: legend[i],
                        type:this.config.reportType,
                        data:array,
                        smooth: this.config.advConfig.smooth
                    }
                    series.push(obj);
                }
            }

            this.option={
                tooltip: {
                    trigger: 'axis'
                },
                toolbox: {
                    feature: {
                        saveAsImage: {show:this.config.advConfig.saveAsImage},
                        magicType:this.config.advConfig.magicType? {type: ['line', 'bar']}:{} ,
                        restore: {show: this.config.advConfig.restore}
                    }
                },
                color:this.getColors(),
                legend: {
                    data: legend,
                    show:this.config.advConfig.legendShow,
                    left:this.config.advConfig.legendLeft,
                    top:this.config.advConfig.legendTop
                },
                xAxis:xAxis,
                yAxis: yAxis,
                series: series
            };

        }
    }
}
</script>

<style>

</style>