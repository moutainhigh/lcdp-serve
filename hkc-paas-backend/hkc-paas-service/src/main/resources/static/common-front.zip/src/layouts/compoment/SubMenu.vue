<template>
	<a-sub-menu :key="menuItem.key" v-bind="$props" v-on="$listeners">
    <span slot="title">
        <a-icon v-if="!menuItem.icon.includes('type')" :type="menuItem.icon"/>
        <my-icon v-else-if="customArr.includes(JSON.parse(menuItem.icon).type)"
				 :type="JSON.parse(menuItem.icon).icon"></my-icon>
        <a-icon v-else :type="JSON.parse(menuItem.icon).icon"></a-icon>
      <span>{{ menuItem.title }}</span>
    </span>
		<template v-for="(subItem,index) in menuItem.children">
			<template v-if="showSubMenu(subItem)">
				<!--  vue组件自己调用自己  -->
				<sub-Menu :key="subItem.key" :subindex="index" :subpath="subpath2+index+'.'" :menu-item="subItem"
						  :hand-click="handClick"></sub-Menu>
			</template>
			<template v-else>
				<a-menu-item :key="subItem.key" @click="ganclick(subItem,index)">
					<a-icon v-if="!subItem.icon.includes('type')" :type="subItem.icon"/>
					<my-icon v-else-if="customArr.includes(JSON.parse(subItem.icon).type)"
							 :type="JSON.parse(subItem.icon).icon"></my-icon>
					<a-icon v-else :type="JSON.parse(subItem.icon).icon"></a-icon>
					<span>{{ subItem.title }}</span>
				</a-menu-item>
			</template>
		</template>
	</a-sub-menu>
</template>

<script>
import {Menu} from 'ant-design-vue';

export default {
	name: 'SubMenu',
	components: {},
	isSubMenu: true,
	props: {
		...Menu.SubMenu.props,
		menuItem: {},
		subindex: '',
		subpath: '',
		handClick: {
			type: Function
		}
	},
	data() {
		return {
			customArr: ['customIcon', 'userCustomIcon'],
			subpath2: ""
		}
	},
	created() {
		this.subpath2 = this.subpath;
	},
	methods: {
		ganclick(subItem, index) {
			this.handClick(subItem)
		},
		showSubMenu(item) {
			var showType = item.showType;
			if (!item.children || showType == 'FUNS' || showType == 'FUN' || showType == 'FUNS_BLOCK') {
				return false;
			}
			return true;
		}
	}
}
</script>
