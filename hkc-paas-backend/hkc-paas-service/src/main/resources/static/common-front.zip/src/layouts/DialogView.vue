<template>
    <div style="width:100%;height:100%;">
      <component v-if="!url  && !show" ref="current" :is="currentView"
                 :menuId="menu.id" :menuParams="menu.params"
                 :destroy="destroy" :layerid="layerid"></component>
      <iframe v-else-if="url && show" style="height:700px;width:100%;"
              id="iframeId" :src="url" frameborder="0" scrolling="auto">
      </iframe>
    </div>
</template>

<script>
    import {mapState} from "vuex";
    import {Util} from 'jpaas-common-lib';
	import Vue from 'vue'

	export default {
        name: "DialogView",
        props:["currentView","layerid","destroy"],
		computed: {
			...mapState({
				selectMenu: state => state.appSetting.selectMenu,
			}),
		},
		data() {
			return {
				menu:{},
				url:"",
				show: false
			}
		},
		created() {
			if(this.selectMenu && this.selectMenu.settingType=="iframe"){
				this.show=true;
				this.url=this.selectMenu.params;
				let jsonToken = Vue.ls.storage['pro__Access-Token'];
				var token = "";
				if (jsonToken) {
					jsonToken = JSON.parse(jsonToken);
					token = jsonToken.value;
					if(!Util.getKey('loginUser')) {
						Util.setKeyVal('TOKEN', jsonToken.value);
						Util.setKeyVal('TOKEN_EXPIRE', jsonToken.expire);
					}
				}
				if (this.url.indexOf("?") == -1) {
					this.url += "?authorization=" + token;
				} else {
					this.url += "&authorization=" + token;
				}
			}else {
				this.menu=this.selectMenu;
			}
		},
		watch: {
			'selectMenu': {
				handler: function (val, old) {
					this.show = false;
					this.$nextTick(() => {
						if(this.selectMenu && this.selectMenu.settingType=="iframe"){
							this.show=true;
							this.url=this.selectMenu.params;
							let jsonToken = Vue.ls.storage['pro__Access-Token'];
							var token = "";
							if (jsonToken) {
								jsonToken = JSON.parse(jsonToken);
								token = jsonToken.value;
								if(!Util.getKey('loginUser')) {
									Util.setKeyVal('TOKEN', jsonToken.value);
									Util.setKeyVal('TOKEN_EXPIRE', jsonToken.expire);
								}
							}
							if (this.url.indexOf("?") == -1) {
								this.url += "?authorization=" + token;
							} else {
								this.url += "&authorization=" + token;
							}
						}else {
							this.menu=this.selectMenu;
						}
					})
				}
			},
			deep: true
		}
	}
</script>

<style scoped>

</style>