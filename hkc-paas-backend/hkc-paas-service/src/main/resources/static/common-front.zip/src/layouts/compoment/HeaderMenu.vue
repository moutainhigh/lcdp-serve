<template>
	<div class="header" style="justify-content: flex-end;line-height: 50px;">
		<!-- <div class="reuse-tab ad-rt fixed" :class="collapsed ==false? 'collapsednam_a':'collapsednam'"
             @click="showBox =false"
             v-if="switching =='navigation'">
            <a-tabs :activeKey="activeKey" type="line" @contextmenu.prevent="show">
                <a-tab-pane v-for="pane in navigation" :key="pane.key">
                    <div slot="tab">
                        <span @click="callback(pane.key,pane)" class="name">{{ pane.title }}</span>
                        <a-icon :class="[pane.collapsed == false? 'op ':'op op1']" @click="onEdit(pane.key,pane)" type="close"/>
                    </div>
                </a-tab-pane>
            </a-tabs>
            <div v-if="showBox">
                <div class="show-parent" :style="{left: tranLeft, top: tranTop}">
                    <ul>
                        <li @click="closeCurrent()">关闭当前页签</li>
                        <li @click="other">关闭其它页签</li>
                        <li @click="whole">关闭全部页签</li>
                    </ul>
                </div>
            </div>
            <div class="beijing" @click="showBox =false" v-if="showBox== true"></div>
        </div>
		<div class="aBreadcrumb" v-else>
			<a-breadcrumb>
				<a-breadcrumb-item v-if="hearts.length<1"  :key="defHeart.key">
					<a @click="handleToHome">{{defHeart.title}}</a>
				</a-breadcrumb-item>
				<a-breadcrumb-item v-else v-for="(item,index) in hearts" :key="item.key">
					<a v-if="item.key=='home-index'" @click="handleToHome">{{item.title}}</a>
					<span v-else>{{ item.title }}</span>
				</a-breadcrumb-item>
			</a-breadcrumb>
		</div> -->
		<div class="message">
			<a-dropdown>
				<div>
					<img class="login" :src="imgUrl"/>
					<span class="names">{{ user.fullName }}，您好！</span>
				</div>
				<a-menu slot="overlay">
					<a-menu-item key="1" @click="confirm"><a-icon class="logout" type="logout"/><span class="logout">退出登录</span></a-menu-item>
				</a-menu>

			</a-dropdown>
		</div>
	</div>
</template>
<script>

import {mapState,mapMutations} from 'vuex';
import router from '@/router'
import {ACCESS_TOKEN, LOGIN_URL} from "@/store/mutation-types";
import LoginApi from "@/api/login"
import Vue from "vue";

export default {
	data() {
		return {
			defHeart: {key:'home-index',title:'首页'},
			hearts: [],
			imgUrl: require('@/image/avatar2.jpg'),
			// switching:'navigation', //navigation  or  crumbs
			// tranLeft: 0,
            // tranTop: 0,
			// showBox: false,
			// collapsed:false,
			// targetKeyObj:{
            //     FUNS:'funs', //功能面板集（标签）
            //     FUNS_BLOCK:'funsBlock',//功能面板集（单页）
            //     FUN:'FUN'//功能面板
            // },
            // homeArr:[ {
            //     key: 'home-index',
            //     title: '首页',
            //     collapsed: false
            // }]
		}
	},
	computed: {
		...mapState({
			navigations: (state) => state.appSetting.navigations,
			appKey: (state) => state.appSetting.appKey,
			user: (state) => state.appSetting.user,

			// navigation: state => state.appSetting.navigation,
            // activeKey: state => state.appSetting.activeKey,
            // // switching: (state) => state.appSetting.switching,
            // breadlist: state => state.appSetting.breadlist,
            // appmenuId: state => state.appSetting.appmenuId,
            // showType: state => state.appSetting.showType,
		}),
	},
	components: {},
	created() {
		this.getFilePath(this.user.photo)
	},
	filters: {},
	mounted() {
	},
	methods: {
		 ...mapMutations('appSetting', ['setShowHome','setSelectMenu']),
		//...mapMutations('appSetting', ['setActiveKey', 'setNavigation', 'setidKey', 'setpmzturl', 'setAppMenuId', 'setSelecteKeys', 'setOpenKeys']),
		confirm() {
			var self=this;
			this.$confirm({
				title: '提示',
				content: '真的要注销登录吗 ?',
				okText: '确认',
				cancelText: '取消',
				onOk: () => {
					self.logout();
				},
				onCancel() {
				},
			})
		},
		handleToHome(){
			this.hearts=[this.defHeart];
			this.setShowHome(true);
			this.setSelectMenu({});
			router.push({name: "index",params: { appKey: this.appKey }});
		},
		getFilePath(fileId) {
			if (fileId && fileId != '') {
				this.imgUrl = '/api/api-system/system/core/sysFile/previewFile?fileId=' + fileId
			}
		},
		logout(){
			var self=this;
			let token=Vue.ls.get(ACCESS_TOKEN);
			LoginApi.logout(token).then(res=>{
				Vue.ls.remove(ACCESS_TOKEN)
				setTimeout(() => {
					var redirect=window.location.href;
					window.open(LOGIN_URL+'?redirect='+redirect,'_self');
				}, 16)
			});
		},
		// // 删除
        // onEdit(targetKey) {
		// 	debugger
        //     if (targetKey == 'home-index') {
        //         return
        //     }
        //     for (var i = 0; i <= this.navigation.length; i++) {
        //         if (this.navigation[i].key == targetKey) {
        //             this.navigation.splice(i, 1)
        //         }
        //     }
        //     var pane = this.navigation[i - 2];
        //     var url = this.navigation[i - 2].key

        //     targetKey = targetKey = this.targetKeyObj[pane.showType] ? this.targetKeyObj[pane.showType] : targetKey;
		// 	if (['funs','funsBlock','fun'].includes(targetKey)) {
        //         var pathParams = {name: targetKey}
        //         pathParams.params = {menuId: pane.id};
        //         if (pane.params) {
        //             pathParams.params.params = pane.params;
        //         }
        //         this.setAppMenuId(pathParams.params.menuId);
        //         this.setActiveKey(url)
        //         if (this.showType && this.showType == 'window') {
        //             router.push(pathParams);
        //         }
        //     } else {
        //         this.setActiveKey(url);
        //         this.setSelecteKeys([pane.key]);
        //         if (this.showType && this.showType == 'window') {
        //             router.push({
        //                 name: url
        //             })
        //         }
        //     }
        // },
        // //点击首页
        // homePage(){
        //     var pathParams = {name: 'home-index'}
        //     router.push(pathParams);
        // },
        // //选中
        // callback(targetKey, pane) {
        //     if(pane.params){
        //         this.setpmzturl(pane.params)
        //     }
        //     if(pane.idKey){
        //         this.setidKey(pane.idKey)
        //     }
        //     this.setActiveKey(targetKey)
        //     if(pane.showType){
        //         targetKey = this.targetKeyObj[pane.showType] ? this.targetKeyObj[pane.showType] : targetKey;
        //     }
        //     var pathParams = {name: targetKey}
        //     if(pane.id){
        //         pathParams.params = {menuId: pane.id};
        //     }
        //     if (pane.params) {
        //         if(pane.params.toString.call(pane.params).indexOf('Object') < 0 && pane.params.indexOf('{')>-1){
        //             pathParams.params = JSON.parse(pane.params)
        //         }else{
        //             pathParams.params=pane.params;
        //         }
        //     }
		// 	console.log(pathParams.params,targetKey);
        //     if(pathParams.params && pathParams.params.menuId){
        //         this.setAppMenuId(pathParams.params.menuId);
        //     }
        //     this.setSelecteKeys([targetKey]);
        //     if (this.showType && this.showType == 'window'){
        //         router.push(pathParams);
        //     }
        //     if(pane.id){
        //         this.$emit('navClick', pane);
        //     }

		// 	// this.$set(item, 'idKey', this.appKey);
        //     // for (var nav of this.navigation) {
        //     //     if (nav.key == item.key) {
        //     //         this.setActiveKey(item.key)
        //     //         return
        //     //     }
        //     // }
        //     // this.setActiveKey(pane.key);
        //     // this.setSelecteKeys([pane.key]);
        //     //this.navigation.push(pane)
        //     //this.setNavigation(this.navigation);

        // },
        // show(e) {
        //     this.tranLeft = e.pageX - 230 + 'px'
        //     this.tranTop = e.pageY - 60 + 'px'
        //     // 点击的时候显示模态框
        //     this.showBox = true
        // },
        // // 关闭当前标签
        // closeCurrent() {
        //     if (this.activeKey != 'home-index') {
        //         for (var i = 0; i <= this.navigation.length; i++) {
        //             if (this.navigation[i].key == this.activeKey) {
        //                 var key = this.navigation[i - 1].key;
        //                 this.setActiveKey(key);
        //                 if (this.showType && this.showType == 'window') {
        //                     router.push({
        //                         name: key
        //                     })
        //                 }
        //                 this.navigation.splice(i, 1)
        //             }
        //         }
        //     }
        // },
        // // 关闭全部
        // whole() {
        //     let _hom = {
        //         key: 'home-index',
        //         title: '首页',
        //         collapsed: false
        //     }
        //     this.setNavigation([_hom]);
        //     this.setActiveKey('home-index');
        //     if (this.showType && this.showType == 'window') {
        //         router.push({
        //             name: 'home-index'
        //         })
        //     }
        // },
        // //关闭其他
        // other() {
        //     if (this.activeKey != 'home-index') {
        //         let _activeTab = ''
        //         let _navData = this.navigation ;
        //         this.setNavigation([]);
        //         for (var i = 0; i < _navData.length; i++) {
        //             if (_navData[i].key == this.activeKey) {
        //                 _activeTab = _navData[i] ;
        //                 break;
        //             }
        //         }
        //         let _hom = {
        //             key: 'home-index',
        //             title: '首页',
        //             collapsed: false
        //         }
        //         var cont = [_hom,_activeTab];
        //         this.setNavigation(cont);
        //     } else {
        //         this.setNavigation(this.homeArr);
        //     }
        // }
	},
	watch:{
		"navigations":function (val,oldVal){
			if(val){
				this.hearts=[];
				//先加默认菜单
				this.hearts.push(this.defHeart);
				this.hearts.push(...val);
			}
		}
	}
}
</script>
<style scoped lang="less">
.quit:hover {
	color: #1890ff;
	cursor: pointer;
}
.logout{
	vertical-align: middle;
}
.login {
	width: 30px;
	height: 30px;
	border-radius: 50%;
}

.header {
	display: flex;
}

.aBreadcrumb {
	margin-top: 18px;
	flex: 1;
}

.message {

}
.names{
	padding-left: 6px;
}
.message i {
	font-size: 18px;
	margin-right: 20px;
}

.message i:hover {
	cursor: pointer;
}

.login:hover {
	cursor: pointer;
}

</style>