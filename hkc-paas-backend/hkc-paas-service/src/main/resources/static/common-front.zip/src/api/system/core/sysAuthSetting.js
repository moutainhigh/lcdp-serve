import rxAjax from '@/assets/js/ajax.js';

//权限配置表 api接口
export const SysAuthSettingApi = {};

SysAuthSettingApi.baseUrl= '/api-system/system/core/sysAuthSetting';
SysAuthSettingApi.exportUrl= SysAuthSettingApi.baseUrl + '/export';


SysAuthSettingApi.doImport=function(formData,callback) {
  var url= SysAuthSettingApi.baseUrl+"/doImport";
  return rxAjax.upload(url,formData,callback);
}


SysAuthSettingApi.doExport = function(solutionIds) {
  window.location.href='/api/api-system/system/core/sysAuthSetting/doExport?solutionIds=' + solutionIds;
}


//查询列表
SysAuthSettingApi.query=function (parameter) {
  var url= SysAuthSettingApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
* 获取单记录
* @param pkId
* @returns {*}
*/
SysAuthSettingApi.get =function(pkId) {
  var url= SysAuthSettingApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

SysAuthSettingApi.getAuthSetting=function(pkId){
  var url= SysAuthSettingApi.baseUrl + '/getAuthSetting?pkId=' + pkId;
  return rxAjax.get(url);
}

//保存数据
SysAuthSettingApi.save =function(parameter) {
  var url= SysAuthSettingApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

//删除数据
SysAuthSettingApi.del =function(parameter) {
  var url= SysAuthSettingApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

SysAuthSettingApi.saveConfigJson=function(parameter){
  var url= SysAuthSettingApi.baseUrl + '/saveConfigJson';
  return rxAjax.postJson(url,parameter);
}

export  default SysAuthSettingApi;

