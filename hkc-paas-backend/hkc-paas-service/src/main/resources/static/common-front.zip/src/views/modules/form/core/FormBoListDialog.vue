<template>
  <rx-dialog style="height: 100%;" @handOk="onOk" @cancel="cancel">
    <div slot="toolbar" v-if="isTreeDialog=='YES'">
      <a-button @click="expand">展开</a-button>
      <a-button @click="collapse">收起</a-button>
      <a-checkbox :checked="!checkStrictly" @change="changeCheckStrictly(checkStrictly)">
        级联选择
      </a-checkbox>
    </div>
    <div id="dialogContainer" style="height:100%;">
      <component ref="current"
                 :is="currentView"
                 :onload="onload"
                 :formdata="formdata"
                 :dialogVm="this"></component>
    </div>
  </rx-dialog>
</template>

<script>
    import Vue from 'vue'
  import {RxDialog, Util,FormBoListPreview,PublicFunction} from 'jpaas-common-lib';
    import FormBoListExt from "./FormBoListExt";
  export default {
    name:"FormBoListDialog",
    props:["isTreeDialog","html","layerid","onload","destroy","formdata"],
    data(){
      return {
        checkStrictly:true,
        currentView: {
          template: "<div>正在加载...</div>"
        }
      }
    },
    components:{
      RxDialog
    },
    created() {
      this.load();
    },
    methods:{
      load(){
        var template="无数据",script={};
        var templateMath = this.html.match(/<template>([\s\S]*)<\/template>/);
        if (templateMath != null) {
          template=templateMath[1];
        }
        var scriptMath = this.html.match(/<script>([\s\S]*)<\/script>/);
        if (scriptMath != null) {
          script=scriptMath[1];
            let vueJs=script.substring(script.indexOf("export default")+14);
            vueJs=`let sc=${vueJs};return sc;`;
            script=new Function(vueJs)();
        }
        var customDialogComponet= Vue.component('custom-dialog', {
          mixins: [FormBoListPreview,PublicFunction,FormBoListExt],
          template: template,
          ...script
        })
        this.loadLink();
        this.loadStyle();
        this.currentView=customDialogComponet;
      },
      loadLink(){
        var linkMath = this.html.match(/<link id=".*" href=".*" \/>/g);
        if(linkMath==null){
          return;
        }
        for(var i=0;i<linkMath.length;i++){
          var link = linkMath[i].match(/<link id="([\s\S]*)" href="([\s\S]*)" \/>/);
          if(link){
            var id=link[1];
            var newLink=document.getElementById(id);
            if(!newLink){
              newLink=document.createElement('link');
              document.getElementsByTagName('head')[0].appendChild(newLink)
            }
            newLink.id=id;
            newLink.rel="stylesheet";
            newLink.type="text/css";
            newLink.href=link[2];
          }
        }
      },
      loadStyle(){
        var style="";
        var styleMath = this.html.match(/<style scoped>([\s\S]*)<\/style>/) || this.html.match(/<style>([\s\S]*)<\/style>/);
        if (styleMath != null) {
          style=styleMath[1];
        }

        var newStyle=document.getElementById("previewStyle");
        if(!newStyle){
          newStyle = document.createElement('style');
          document.getElementsByTagName('head')[0].appendChild(newStyle)
        }
        /*for(var key in this.$refs.current.$el.dataset){
          style=style.replace("{","[data-"+key+"]{")
          break;
        }*/
        newStyle.id="previewStyle";
        newStyle.innerHTML = style;
      },
      changeCheckStrictly(value){
        this.checkStrictly=!value;
      },
      getData(){
        return this.currentView.options.methods.getData(this,this.$refs.current);
      },
      onOk(){
        Util.closeWindow(this,"ok",this.getData());
      },
      cancel(){
        Util.closeWindow(this,"cancel");
      },
      collapse(){
          this.$refs.current.onCollapse();
      },
      expand(){
          this.$refs.current.onExpand();
      }
    }
  }
</script>

<style scoped>

</style>
