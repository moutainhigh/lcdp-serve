<template>
  <rx-dialog @handOk="handTrans" @cancel="cancel" order="bottom" >
    <rx-layout>
      <div slot="center">
        <a-form-model ref="form" :model="form" :rules="rules">
          <a-row>
            <a-col :span="24">
              <a-form-model-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="任务名称">
                {{form.subject}}
              </a-form-model-item>
            </a-col>
          </a-row>

          <a-row>
            <a-col :span="24">
              <a-form-model-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="转办人"  prop="toUser">
                <rx-input-button width="40%" v-model="form.toUser" @click="selectUsers"></rx-input-button>
              </a-form-model-item>
            </a-col>
          </a-row>

          <a-row>
            <a-col :span="24">
              <a-form-model-item :labelCol="labelCol1" :wrapperCol="wrapperCol1" label="意见" prop="opinion">
                <a-textarea v-model="form.opinion" style="width: 100%"/>
              </a-form-model-item>
            </a-col>
          </a-row>

          <a-row>
            <a-col :span="24">
              <a-form-model-item label="通知方式" :labelCol="labelCol1" :wrapperCol="wrapperCol1"  prop="msgTypes">
                <a-checkbox-group :options="msgOptions" v-model="form.msgTypes">
                </a-checkbox-group>
              </a-form-model-item>
            </a-col>
          </a-row>

        </a-form-model>
      </div>
    </rx-layout>

  </rx-dialog>
</template>
<script>

  import BpmPublicApi from '@/api/bpm/core/BpmPublicApi'
  import {BaseFormModel, RxDialog,Dialog,Util} from 'jpaas-common-lib';
  import BpmtaskApi from "@/api/bpm/core/bpmTask";

  export default {
    name: 'BpmTaskTransferEdit',
    props:{
        subject:String,
        taskId:String,
        layerid: String,
        lydata: Object,
        destroy:Function
    },
    mixins:[BaseFormModel],
    components: {
      RxDialog,
    },
    data(){
      return {
        rules: {
            toUser:[{ required: true, message: '请选择转办人', trigger: 'change' }]
        },
        msgOptions:[],
        form:{
            opinion:"",
            toUser:"",
            msgTypes:[]
        }
      }
    },
    created(){
      this.init();
    },
    methods: {
      init(){
          this.form.subject=this.subject;
          this.form.taskId=this.taskId;

          BpmPublicApi.getMessageHandler().then(res=>{
              res.forEach((val)=> {
                  this.msgOptions.push({label:val.name,value:val.type})
              })
          })
      },
      selectUsers(vm) {
          var self_=this;
          Dialog.openUserDialog({
              curVm: this, data: {single: true}, widthHeight: ['1200px', '600px']
          }, function (self, user) {
              var json={text: user.fullName, value: user.userId};
              self_.form.toUser=JSON.stringify(json);
              vm.setVal(user.userId, user.fullName);

          });
      },
      handTrans(e){
          this.$refs.form.validate(valid=>{
              if(!valid){
                  e.loading=false;
                  return;
              }
              this.form.msgType=this.form.msgTypes.join(",");
              var _set = this;
              this.$confirm({
                  title: '确认转办任务吗?',
                  okText: '确认',
                  cancelText: '取消',
                  zIndex:9999,
                  onOk() {
                      BpmtaskApi.transTask(_set.form).then(res=>{
                          Util.closeWindow(_set,"ok")
                      })
                  },
                  onCancel() {
                      e.loading=false;
                  }
              },);
          });
      }
    }
  }
</script>
