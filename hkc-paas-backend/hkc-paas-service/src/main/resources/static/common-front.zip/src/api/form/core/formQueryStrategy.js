import rxAjax from '@/assets/js/ajax.js';

//查询策略表 api接口
export const FormQueryStrategyApi = {};

FormQueryStrategyApi.baseUrl = '/api-form/form/core/formQueryStrategy';
FormQueryStrategyApi.exportUrl = FormQueryStrategyApi.baseUrl + '/export';

//查询列表
FormQueryStrategyApi.query = function (parameter) {
  var url = FormQueryStrategyApi.baseUrl + '/query';
  return rxAjax.postJson(url, parameter).then(res => {
    return res.result
  })
}

/**
 * 获取单记录
 * @param pkId
 * @returns {*}
 */
FormQueryStrategyApi.get = function (pkId) {
  var url = FormQueryStrategyApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

//保存数据
FormQueryStrategyApi.save = function (parameter) {
  var url = FormQueryStrategyApi.baseUrl + '/save2';
  return rxAjax.postJson(url, parameter);
}

//删除数据
FormQueryStrategyApi.del = function (parameter) {
  var url = FormQueryStrategyApi.baseUrl + '/del';
  return rxAjax.postUrl(url, parameter);
}

FormQueryStrategyApi.getByListId = function (listId) {
  var url = FormQueryStrategyApi.baseUrl + '/getByListId?listId=' + listId;
  return rxAjax.get(url);
}

export default FormQueryStrategyApi;

