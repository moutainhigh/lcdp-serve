<template>
  <div style="height: 100%;">
    <iframe class="herlist" v-if="show"
            id="iframeId" :src="url" frameborder="0" scrolling="auto">
    </iframe>
  </div>
</template>

<script>
  import {Util} from 'jpaas-common-lib'
  import {ACCESS_TOKEN} from "@/store/mutation-types";

  export default {
    name: "UrlView",
    props: {
      showUrl: {
          type: String
      },
    },
    data() {
      return {
        url: '',
        show: false
      }
    },
    created() {
      this.initView();
    },
    methods: {
      setUrl(valUrl){
        this.url = valUrl;
        this.initToken();
      },
      initView() {
            this.show=true;
            if (this.$route.meta.params) {
                this.url = this.$route.meta.params;
                this.initToken();
            }else if(this.showUrl){
                this.url=this.showUrl;
                this.initToken();
            }else if(this.url){
                this.initToken();
            }
        },
        initToken() {
            let jsonToken = Vue.ls.storage['pro__Access-Token'];
            var token = "";
            if (jsonToken) {
                jsonToken = JSON.parse(jsonToken);
                token = jsonToken.value;
                if(!Util.getKey('loginUser')) {
                    Util.setKeyVal('TOKEN', jsonToken.value);
                    Util.setKeyVal('TOKEN_EXPIRE', jsonToken.expire);
                }
            }
            if (this.url.indexOf("?") == -1) {
                this.url += "?authorization=" + token;
            } else {
                this.url += "&authorization=" + token;
            }
        }
    },
    watch: {
      '$route': {
        handler: function (val, old) {
            this.show = false;
            this.$nextTick(() => {
                this.initView();
            })
        }
      },
      deep: true
    }
  }
</script>

<style >
.herlist{
  height: calc(100vh - 120px);
  width: 100%;
}
</style>