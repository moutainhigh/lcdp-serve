<template>
  <a-drawer
    title="审批历史"
    placement="right"
    @close="onCheckHistory"
    width="400"
    :visible="historyShow"
    :z-index="20000"
  >
    <div class="drawer-body">
      <div style="padding-bottom: 20px" v-if="bpmTask!=null">
        当前节点：{{ bpmTask.name }}
      </div>
      <div class="drawer-centent">
        <div class="rxContent">
          <a-steps direction="vertical" :current="checkHistorys.length">
            <a-step v-for="his in checkHistorys" :key="his.hisId" :title="his.nodeName">
               <span slot="description">
                      <p><a-icon type="edit"/>&nbsp;<rx-user-info :userId="his.createBy"/>进行了 <b :class="his.jumpType">{{
                          his.jumpTypeName
                        }}</b> 操作。</p>
                      <p v-if="his.jumpType=='TRANSFER'"><a-icon
                        type="user"/> &nbsp;{{ his.jumpTypeName }}给了{{ his.handlerUserName }} </p>
                      <p v-if="his.jumpType=='LINKUP'  ">沟通给:<rx-user-component :readonly="true"
                                                                                v-model="his.linkUpUsers"></rx-user-component></p>
                      <p v-if="his.jumpType=='TRANS'">转发给:<rx-user-component :readonly="true"
                                                                             v-model="his.linkUpUsers"></rx-user-component></p>
                      <p v-if="his.jumpType=='ROAM_TRANSFER'">流转给:<rx-user-component :readonly="true"
                                                                                     v-model="his.linkUpUsers"></rx-user-component></p>
                      <p class="time"><a-icon type="dashboard"/> &nbsp; {{ his.completeTime }} </p>
                      <p><a-icon type="highlight"/>&nbsp;意见：<span v-if="his.remark!=''">{{ his.remark }}</span>
                        <span v-else>无</span>
                      </p>
                      <p>关联流程：
                        <span v-if="getRelInsts(his).length>0">
                            <ul>
                                <li v-for="item in getRelInsts(his)">
                                    <a @click="showInst(item.id,item.name)">{{ item.name }}</a>
                                </li>
                            </ul>
                        </span>
              <span v-else>无</span>
              </p>
              <p>
                <li v-if="his.opFiles && his.opFiles.length>0">
              <div class="headerTitle">
                <p>流程节点：{{ his.nodeName }}</p>
                <p>附件上传人：{{ his.handlerUserName }}</p>
              </div>
              <div v-for="(subItem,index) in his.opFiles">
                <p>附件上传时间：{{ subItem.createTime }}</p>
                <div class="fileContent">
                  <span class="iconBox" :class="rxClass(subItem)"></span>
                  <span class="textName">{{ subItem.fileName }}</span>
                  <span class="handleDown" @click="donwload(subItem)" title="下载查看附件">
                          <a-icon type="download"/>
                        </span>
                </div>
              </div>
              </li>
              </p>
              </span>
            </a-step>
          </a-steps>
        </div>
      </div>
    </div>
  </a-drawer>
</template>

<script>
import {RxUserComponent, Util,RxUserInfo} from "jpaas-common-lib";
import BpmCheckHistoryApi from "@/api/bpm/core/bpmCheckHistory";
import FlowUtil from "../js/FlowUtil";


export default {
  name: "bpm-check-history",
  props: {
    instId: {type: String},
    bpmTask: {type: Object, required: false},
    historyShow: {type: Boolean, default: false},

    layerid: String,
    lydata: Object,
    destroy: {
      type: Function
    }
  },
	mixins:[FlowUtil],
  components: {
    RxUserComponent,
      RxUserInfo
  },
  data() {
    return {
      checkHistorys: [],
      extMapping: {
        ".doc": "wordBox",
        ".docx": "wordBox",
        ".xls": "excelBox",
        ".xlsx": "excelBox",
        ".txt": "txtBox",
        ".pdf": "pdfBox",
        ".rar": "rarBox",
        ".zip": "zipBox",
      }
    }
  },
  methods: {
    rxClass(item) {//根据文件名  添加类名；
      var name = item.fileName;
      for (var key in this.extMapping) {
        if (name.indexOf(key) > -1) {
          return this.extMapping[key];
        }
      }
      return "attachBox";
    },
    getRelInsts(his) {
      if (!his.relInsts) {
        return [];
      }
      return JSON.parse(his.relInsts);
    },
    donwload(file) {//下载附件
      var accessToken = this.$ls.get("Access-Token");
      const url = '/api/api-system/system/core/sysFile/download/' + file.fileId + '?accessToken=' + accessToken;
      window.open(url);
    },
    onCheckHistory() {
      this.$emit('update:historyShow', false)
    },
    loadCheckHistory() {
      BpmCheckHistoryApi.getCheckHistorys(this.instId).then(his => {
        this.checkHistorys = his;
      });
    },
    showInst(id, name) {
		var self=this;
		this.encryptInstIds(id,true,function(resultList){
			let grant=resultList[0].grant;
			if(!grant){
				return;
			}
			let encInstId=resultList[0].encInstId;
			let obj=self.$router.resolve({
				name:'openDoc',
				params:{instId:encInstId}
			});
			window.open(obj.href,"_blank" );
		})
    }
  },
  watch: {
    historyShow: function (val) {
      if (val) {
        this.loadCheckHistory();
      }
    }
  }
}
</script>

<style scoped>
.file-ul > li {
  padding: 10px;
  border-bottom: 1px solid #d2dcf8;
}

.file-ul > li:last-child {
  border-bottom: 0;
}

.iconBox {
  margin-right: 10px;
}

.fileContent {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
  margin-top: 10px;
}

.fileContent .textName {
  flex: 1;
  overflow: hidden;
}

.handleDown {
  padding: 0 10px;
  box-sizing: border-box;
  cursor: pointer;
}

.handleDown:hover {
  color: #4D9EFF;
}

.rxTabs {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.rxTabs >>> .ant-tabs-content {
  flex: 1;
}

.rxTabs >>> .ant-tabs-tabpane-active {
  position: relative;
}

.rxTabs .rxContent {
  position: absolute;
  width: 100%;
  height: 100%;
  overflow: auto;
}

.ant-steps-vertical {
  margin-top: 10px;
}

.ant-steps-item-content .ant-drawer-wrapper-body {

}

.drawer-body {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  box-sizing: border-box;
}

.drawer-centent {
  flex: 1;
  overflow: auto;
}

.opDesp {
  font-size: 12px;
  line-height: 32px;
  color: blue;
  width: 100%;
}

.time {
  font-size: 10px;
  color: darkgray;

  width: 100%;
  line-height: 26px;
}

.AGREE {
  font-weight: bold;
  color: green;
}

.BACK, .BACK_SPEC, .BACK_TO_STARTOR {
  font-weight: bold;
  color: red;
}
</style>