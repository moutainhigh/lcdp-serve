<template>
	<rx-fit>
		<a-tabs class="tabFuns" style="height: 100%">
			<a-tab-pane v-for="(menu_,index) in selectMenus" :tab="menu_.title" :key="menu_.key">
				<component v-if="menu_.settingType !='iframe'" :menu="menu_" :is="menu_.component" :ref="menu_.component" :menuParams="menu_.params"></component>
				<iframe v-else :id="menu_.alias" :src="menu_.params"  frameborder="0" scrolling="auto" style="height:100%;width:100%;"></iframe>
			</a-tab-pane>
		</a-tabs>
	</rx-fit>
</template>

<script>
/**
 * 功能面板集（标签）
 */
import {RxFit} from 'jpaas-common-lib'
import menuView from "@/layouts/js/menuView";
import {
	mapState
} from 'vuex'

export default {
	name: "MenuViewFuns",
	props: {
		menu:[Object]
	},
	mixins: [menuView],
	components: {
		RxFit
	},
	data() {
		return {
			selectMenus: [],
			activeKey: "",
			curMenuId: "",
		}
	},
	created() {
		this.initMenus();
	},
	methods: {
		initMenus() {
			if(this.menu){
				this.curMenuId=this.menu.id;
			}else {
				this.curMenuId=this.selectMenu.id;
			}
			var ary = this.getSelectMenus(this.menus, this.curMenuId);
			this.selectMenus=ary[0].children
			this.buildTree(this.selectMenus);

		},
		buildTree(list) {
			list.map(item => {
				item.component = this.getComp(item);
				if (item.children && item.children.length > 0) {
					this.buildTree(item.children);
				}
			});
		},
		getComp(menu) {
			if (menu.menuType == 'C') {
				if (menu.showType) {
					if (menu.showType == 'FUNS') {
						return () => import('@/layouts/menuView/MenuViewFuns');
					} else if (menu.showType == 'FUNS_BLOCK') {
						return () => import('@/layouts/menuView/MenuViewFunsBlock');
					} else if (menu.showType == 'FUN') {
						return () => import('@/layouts/menuView/MenuViewFun');
					}
				}
			}
			if(menu.settingType == "iframe"){
				return null;
			}else {
				if(typeof menu.component === "function"){
					return menu.component;
				}else {
					return this.loadView( menu.component);
				}
			}
		}
	},
	watch:{
		"selectMenu.id":function (val,oldVal){
			if(val){
				this.initMenus();
			}
		}
	}
}
</script>

<style scoped>

</style>