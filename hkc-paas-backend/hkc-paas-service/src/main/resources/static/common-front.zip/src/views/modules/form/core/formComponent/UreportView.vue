<template>
    <div style="width: 100%;height: 100%;">
        <iframe v-if="config.ureport" ref="ureport" style="width: 100%;height: 100%;border: none" :src="url"></iframe>
        <span v-else>未配置报表!</span>
    </div>
</template>

<script>
import BusEvent from "@/views/modules/form/core/formComponent/BusEvent";

export default {
    name: "ureport-view",
    props: {
        config: {
            type: Object
        },
        layoutItem:{
            type:Object
        }
    },
    mixins:[BusEvent],
    data() {
        return {
            url:"/ureport/preview?_u=qiaolin-",
            //初始化时的url 用于参数拼接时刷新url
            initUrtl:""
        }
    },
    created() {
        this.init();
    },
    methods: {
        init(){
            if(this.config.ureport){
                var token = this.$ls.get("Access-Token");
                var ureportName=JSON.parse(this.config.ureport).text;
                this.url+=ureportName+"&accessToken="+token;
                this.initUrtl=this.url
            }
        },
        handReceive(args){
            var receive=this.config.receive;
            if(this.config.receive.type=='event' && receive.publishComponent==args.component){
                var inputParams=args.params;
                var param="";
                //读取配置的参数
                for(var i=0;i<receive.mapping.length;i++){
                    var obj=receive.mapping[i];
                    if(obj.valueSource=='param' && inputParams[obj.valueDef]){
                        param+="&"+obj.name+"="+inputParams[obj.valueDef]
                    }
                }
                this.url=this.initUrtl;
                this.url+=param;
            }
        },
    },
    watch:{
        config:{
            handler: function (val, oldVal) {
                if(val){
                    this.init();
                }
            },
            deep: true
        }
    }
}
</script>

<style scoped>

</style>