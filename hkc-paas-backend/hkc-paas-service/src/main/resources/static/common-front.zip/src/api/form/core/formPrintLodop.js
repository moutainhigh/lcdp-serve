import rxAjax from '@/assets/js/ajax.js';

//表单套打模板 api接口
export const FormPrintLodopApi = {};

FormPrintLodopApi.baseUrl= '/api-form/form/core/formPrintLodop';
FormPrintLodopApi.exportUrl= FormPrintLodopApi.baseUrl + '/export';

//查询列表
FormPrintLodopApi.query=function (parameter) {
  var url= FormPrintLodopApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
* 获取单记录
* @param pkId
* @returns {*}
*/
FormPrintLodopApi.get =function(pkId) {
  var url= FormPrintLodopApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

//保存数据
FormPrintLodopApi.save =function(parameter) {
  var url= FormPrintLodopApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

//删除数据
FormPrintLodopApi.del =function(parameter) {
  var url= FormPrintLodopApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

FormPrintLodopApi.printHtml = function (parameter) {
  var url = FormPrintLodopApi.baseUrl + '/printHtml';
  return rxAjax.postJson(url,parameter);
}

export  default FormPrintLodopApi;

