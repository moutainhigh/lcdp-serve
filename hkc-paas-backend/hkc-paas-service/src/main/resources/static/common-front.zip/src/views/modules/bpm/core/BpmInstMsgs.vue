<template>
  <a-drawer
    title="留言"
    placement="right"
    @close="onLeaveMsgClose"
    width="400"
    :visible="msgShow"
    :z-index="20000"
    >

  <div>
    <a-empty v-if="leaveMsges.length==0" />
    <a-comment v-for="msg in leaveMsges" :key="msg.id">
      <a slot="author"><a-icon type="user"/> &nbsp;{{msg.author}}</a>
      <p slot="content">
        <a-icon type="message"/> &nbsp;{{msg.content}}
      </p>
      <a-tooltip slot="datetime" :title="msg.createTime">
        <span>{{msg.createTime}}</span>
      </a-tooltip>
    </a-comment>
    <a-comment>

      <div slot="content">
        <a-form-item>
          <a-textarea :rows="4"  v-model="leaveMsg" @pressEnter="enterLeaveMsg"></a-textarea>
        </a-form-item>
        <a-form-item>
          <a-button htmlType="submit" :loading="msgSubmitting" @click="enterLeaveMsg" type="primary">
            添加留言
          </a-button>
        </a-form-item>
      </div>
    </a-comment>
  </div>
  </a-drawer>
</template>

<script>
    import BpmInstMsgApi from "@/api/bpm/core/bpmInstMsg";
    export default {
        name: "BpmInstMsgs",
        props:{
          instId:{//流程实例Id
            type:String,
            required:true
          },
            msgShow:{
                type:Boolean,
                default:false
            }
        },
        data(){
          return {
            leaveMsges:[],
            leaveMsg:'',
            msgSubmitting:false,
          }
        },
      methods:{
          enterLeaveMsg(){
            this.msgSubmitting=true;
            //发送至后台实现数据保存
            BpmInstMsgApi.addMsg(this.instId,this.leaveMsg).then(resp=>{
              this.leaveMsges.push(resp.data);
              this.leaveMsg='';
              this.msgSubmitting=false;
            });
          },
          //加载内部消息
          loadInstMsg(){
            let _self=this;
            BpmInstMsgApi.getByInstId(this.instId).then(data=>{
              _self.leaveMsges=data;
            });
          },
          onLeaveMsgClose(){
              this.$emit('update:msgShow', false)
          }
      },
        watch:{
            msgShow:function (val) {
                if(val){
                    this.loadInstMsg();
                }
            }
        }

    }
</script>

<style scoped>

.ant-comment-inner{
  padding:5px;
}

</style>