/**
 * 页面定制公共事件
 */
export default {
    data() {
        return {
        }
    },
    created() {
        var self_=this;
        this.$bus.on('formEvent',  (args)=> {
            self_.handReceive(args,self_)
        });
        this.$bus.on('chartEvent',  (args)=> {
            self_.handReceive(args,self_)
        });
        this.$bus.on('customViewEvent',  (args)=> {
            self_.handReceive(args,self_)
        });
        this.$bus.on('calendarViewEvent',  (args)=> {
            self_.handReceive(args,self_)
        });
    },
}