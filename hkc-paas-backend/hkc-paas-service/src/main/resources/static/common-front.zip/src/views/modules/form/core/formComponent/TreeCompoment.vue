<template>
    <div style="overflow-y:hidden;" class="layersty">
        <div class="tite_btn">
            <div class="font_btn" v-if="config.showName">{{ config.name }}</div>
        </div>
        <FormBoListPreviewList ref="boList" :html="html" :customVm="getCurVm"></FormBoListPreviewList>
    </div>
</template>

<script>
import FormBoListPreviewList from "../FormBoListPreviewList";
import FormBoListApi from "@/api/form/core/formBoList";
import PublicApi from "@/api/form/core/public";
import BusEvent from "@/views/modules/form/core/formComponent/BusEvent";

export default {
    name: "tree-component",
    components: {FormBoListPreviewList},
    mixins:[BusEvent],
    props: {
        config: {
            type: Object,
            default: () => {
                return {}
            }
        }
    },
    data() {
        return {
            currentView: {
                template: "<div>正在加载...</div>"
            },
            html: ""
        }
    },
    created() {
        var self_ = this;
        this.$bus.on('refreshEvent', (args) => {
            self_.$refs.boList.loadData();
        })
    },
    mounted() {
        this.loadList();
    },
    methods: {
        getCurVm() {
            return this;
        },
        getData(hasParent) {
            return this.$refs.boList.$refs.current.$refs.rxTree.getCheckedNodes(hasParent);
        },
        getParent(name) {
            var vmObj=this;
            while(!vmObj.isFormCustom){
                vmObj=vmObj.$parent;
            }
            var ctlObj=vmObj.$refs[name];
            if(!ctlObj){
                var layAry=vmObj.$refs;
                for(var lay in layAry){
                    for(var i=0;i<layAry[lay].length;i++){
                        var layObj=layAry[lay][i].$refs[name];
                        if(layObj){
                            return layObj;
                        }
                    }
                }
            }
            return ctlObj;
        },
        loadList() {
            if (!this.config.alias) {
                return;
            }
            var parameter = {key: this.config.alias, params: ''};
            var params = {};
            if (this.$route.meta.query) {
                params = JSON.parse(this.$route.meta.query);
            }else {
                params=this.$route.query;
            }
            //读取配置的参数
            for (var i = 0; i < this.config.receive.mapping.length; i++) {
                var o = this.config.receive.mapping[i];
                if(o.valueSource == 'param'){
                    if(this.config.receive.type== "url"){
                        if (params[o.valueDef]) {
                            parameter.params += o.name + '=' + params[o.valueDef] + '&';
                        }
                    }else {
                        if (params[o.name]) {
                            parameter.params += o.name + '=' + params[o.name] + '&';
                        }
                    }
                }
            }
            var self = this;
            this.getParams(function (params) {
                for (var key in params) {
                    parameter.params = key + '=' + params[key] + '&';
                }
                parameter.params = parameter.params.substring(0, parameter.params.length - 1);
                FormBoListApi.dialog(parameter).then(res => {
                    if(!res.success){
                        return;
                    }
                    var record = res.data;
                    self.html = record.listHtml;
                });
            });
        },
        handReceive(args) {
            var receive = this.config.receive;
            //
            if (this.config.receive.type == 'event' && receive.publishComponent == args.component) {
                var inputParams = args.params;
                var params = {};
                //读取配置的参数
                for (var i = 0; i < receive.mapping.length; i++) {
                    var o = receive.mapping[i];
                    if (o.valueSource == 'param' && inputParams[o.valueDef]) {
                        params[o.name] = inputParams[o.valueDef];
                    }
                }
                var self = this;
                this.getParams(function (data) {
                    for (var key in data) {
                        params[key] = data[key];
                    }
                    self.$refs.boList.loadByParams(params);
                })
            }
        },
        getParams(callback) {
            PublicApi.getParams(JSON.stringify(this.config.receive.mapping)).then(res => {
                callback(res);
            }).catch(err => {
                callback({});
            })
        }
    },
    watch: {
        config: {
            handler: function (val, oldVal) {
                if (val) {
                    this.loadList();
                }
            },
            deep: true
        }
    }
}
</script>

<style scoped>
.tite_btn {
    /*position: absolute;*/
    /*z-index: 99;*/
    /*width: 100%;*/
    /*top: 10px;*/
}

.font_btn {
    background: #fafafa;
    padding: 5px 10px;
    border-bottom: 1px solid #dadde0;
    font-size: 14px;
}

.hr_btn {
    /*position: relative;*/
    bottom: -34px;
    z-index: 99;
    margin: 0;
    opacity: .4;

}

.ant-tree {
    margin-bottom: 2vw !important;
}

.layersty {
    height: 100%;
    background: #fff;
    border: 1px solid #dadde0;
}
</style>