<template>
    <div id="dialogContainer" style="width:100%;height:100%;">
        <component
            ref="current"
            :is="currentView"
            :onload="onload"
            :formdata="formdata"
            :layerid="layerid"
            :destroy="destroy"
            :lydata="lydata"
            :dialogVm="customVm?customVm:this"></component>
    </div>
</template>

<script>
import Vue from 'vue';
import {FormBoListPreview,PublicFunction} from 'jpaas-common-lib';
import FormBoListExt from "./FormBoListExt";
export default {
    name:"FormBoListPreviewList",
    props:{
        "html":{
            type:String
        },
        "onload":{
            type:Function
        },
        "customVm":{
            type:Object
        },
        //表单数据映射
        "formdata":{
            type:Object
        },
        "layerid": {
            type: String
        },
        "destroy": {
            type: Function
        },
        "lydata":{
            type: Object
        }
    },
    data(){
        return {
            currentView: {
                template: "<div>正在加载...</div>"
            }
        }
    },
    created() {
        this.load();
    },
    watch:{
        "html":function(val){
            this.html=val;
            this.load();
        }
    },
    methods:{
        load(){

            var template="无数据",script={};
            var templateMath = this.html.match(/<template>([\s\S]*)<\/template>/);
            if (templateMath != null) {
                template=templateMath[1];
            }
            var scriptMath = this.html.match(/<script>([\s\S]*)<\/script>/);
            if (scriptMath != null) {
                script=scriptMath[1];
                let vueJs=script.substring(script.indexOf("export default")+14);
                vueJs=`let sc=${vueJs};return sc;`;
                script=new Function(vueJs)();
            }
            var listComponet= Vue.component('custom-list', {
                mixins: [FormBoListPreview,PublicFunction,FormBoListExt],
                template: template,
                ...script,
                watch:{
                    'lydata.layerResize':{
                        handler:function (o,ol){
                            this.table.initDom();
                        },
                        deep:true
                    }
                }
            })
            this.loadLink();
            this.loadStyle();
            this.currentView=listComponet;
        },
        loadLink(){
            var linkMath = this.html.match(/<link id=".*" href=".*" \/>/g);
            if(linkMath==null){
                return;
            }
            for(var i=0;i<linkMath.length;i++){
                var link = linkMath[i].match(/<link id="([\s\S]*)" href="([\s\S]*)" \/>/);
                if(link){
                    var id=link[1];
                    var newLink=document.getElementById(id);
                    if(!newLink){
                        newLink=document.createElement('link');
                        document.getElementsByTagName('head')[0].appendChild(newLink)
                    }
                    newLink.id=id;
                    newLink.rel="stylesheet";
                    newLink.type="text/css";
                    newLink.href=link[2];
                }
            }
        },
        loadStyle(){
            var style="";
            var styleMath = this.html.match(/<style scoped>([\s\S]*)<\/style>/) || this.html.match(/<style>([\s\S]*)<\/style>/);
            if (styleMath != null) {
                style=styleMath[1];
            }

            var newStyle=document.getElementById("previewStyle");
            if(!newStyle){
                newStyle = document.createElement('style');
                document.getElementsByTagName('head')[0].appendChild(newStyle)
            }
            newStyle.id="previewStyle";
            newStyle.innerHTML = style;
        },
        loadByParams(params){
            var ctl=this.$refs.current;
            ctl.loadByParams(params);
        },
        loadData(){
            var ctl=this.$refs.current;
            ctl.loadData();
        }
    }

}
</script>

<style scoped>
.rx-table .blockLi .blockLiBox {
    min-height: 24px !important;
}
</style>