import DialogBox from "@/assets/js/DialogBox";

export default {
    methods: {
        getDialogBox() {
            return DialogBox;
        }
    }
}