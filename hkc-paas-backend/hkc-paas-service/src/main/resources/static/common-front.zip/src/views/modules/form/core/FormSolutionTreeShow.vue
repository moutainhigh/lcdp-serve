<template>
	<a-layout class="layersty"   ref="layersty" style="height:100%;">
		<a-layout-content  style="order:1" class="defaultContent">
			<rx-layout>
				<div slot="left">
					<a-directory-tree
						:loadData="loadByParent"
						:multiple="false"
						:showIcon="true"
						:treeData="treeData"
						:selectedKeys="checkedKeys"
						@select="selectNode"
						@rightClick="rightClick"
						@expand="onExpand"
						:expandedKeys="expandedKeys"
						:autoExpandParent="autoExpandParent"
					>
					</a-directory-tree>
					<v-contextmenu ref="contextmenu">
						<v-contextmenu-item @click="addData">添加</v-contextmenu-item>
						<v-contextmenu-item v-if="isTreeCat" @click="editData">编辑</v-contextmenu-item>
						<v-contextmenu-item v-if="isTreeCat" @click="delData">删除</v-contextmenu-item>
					</v-contextmenu>
				</div>
				<div slot="center">
					<div id="rx-form-container" v-show="loading" :class="type=='EASY-DESIGN'? 'kforms':''" :style="`background-color:${ formAllConfig.bg }`">
						<div v-if="type=='EASY-DESIGN'" style="margin: auto;max-width: 1300px;">
							<k-form-build :javascript="javascript" :value="jsonData" ref="rxForm" :alias="alias" :formDesigner="true" :readOnly="rxReadOnly" />
						</div>
						<div v-else :style="`max-width:${formAllConfig.allWidth};;margin:auto;`">
							<rx-form ref="rxForm"> </rx-form>
						</div>
					</div>
				</div>
			</rx-layout>
		</a-layout-content>

		<a-layout-footer style="order:0;">
			<a-form class="buttongmodle"  >
				<a-button-group>
					<a-button :type="btn.style"
							  :ref="btn.method"
							  v-for="btn in buttons"
							  @click="handMethod(btn)" :loading="btn.loading"
							  :key="btn.name">{{btn.name}}</a-button>
				</a-button-group>
			</a-form>
		</a-layout-footer>
	</a-layout>

</template>

<script>
	import FormSolutionApi from '@/api/form/core/formSolution'
	import BpmInstApi from "@/api/bpm/core/bpmInst";
	import {rxForm} from "jpaas-form-component";
	import {Util} from 'jpaas-common-lib';
	import formbase from '@/api/formbase';
	import BpmInstStartConfirm from "@/views/modules/bpm/core/BpmInstStartConfirm";
	import FormUtil from "./FormUtil";
	import {mapState} from "vuex";
	import userState from "@/assets/js/userState";
	import FormSolutionFunc from "@/views/modules/form/core/formsolution/FormSolutionFunc";
	import BpmImageView from "@/views/modules/bpm/comps/BpmImageView";

	export default {
		name: "form-solution-tree-show",
		props:{
			alias: {
				type: String,
				default: ""
			},
			readOnly: {
				type: Boolean,
				default: false
			},
			//这个是从DialogView打开时需要用到的。
			menuParams:{
				type:String
			},
			layerid: {
				type: String,
				default: ""
			},
			destroy: {
				type: Function
			}
		},
		mixins:[formbase,userState,FormSolutionFunc],
		components: {
			rxForm
		},
		data(){
			return {
				canStartFlow:false,
				buttons:[],
				formSolutionAlias:"",
				treeData:[],
				type:"",
				jsonData:{},
				javascript:"",
				curRow:{},
				parent:{},
				checkedKeys:[],
				expandedKeys:[],
				autoExpandParent:true,
				pkField:'ID_',
				parentField:'PARENT_ID_',
				loading:true,
				processConfig: {
					buttons: [],
					startConfirm: false,
					fillOpinion: false,
					assignFlowUsers: false,
					startCalFlowusers: false,
					//是否允许选择路径。
					allowSelectPath: false,
					formType: "online"
				},
				needConfirmDlg: false,
				//根实例
				rootVm: true,
				fromRoute:false,
				isTreeCat:false,
				rxReadOnly:this.readOnly,
				formAllConfig:{
					allWidth: "1300px",
					bg: "#fff"
				},
				/**
				 * 表单别名
				 */
				formAlias:"",
				flowInstId:null
			}
		},
		computed:{
			...mapState({
				showType: (state) => state.appSetting.showType,
			})
		},
		created() {
			this.loading=false;

			this.initParams();

			this.initData();
		},
		methods:{
			/**
			 * 初始化表单的参数。
			 */
			initParams(){
				//使用Util.open的方法打开
				if(this.alias){
					this.formSolutionAlias=this.alias;
				}
				//从弹框打开,使用DialogView 打开
				else if(this.menuParams ){
					var json=JSON.parse(this.menuParams);
					this.formSolutionAlias=json.formAlias;
				}
				else{
					//从菜单打开 或从地址栏直接打开。
					var params=JSON.parse(this.$route.meta.params);
					if(params.formAlias){
						this.formSolutionAlias=params.formAlias;
					}
					//从路由打开
					this.fromRoute=true;
				}
			},
			initData(){
				FormSolutionApi.getTreeByAlias(this.formSolutionAlias).then(res=>{
					var data=res.data;
					this.pkField=res.pkField;
					this.parentField=res.parentField;
					var ary=Util.listToTree(data,this.pkField,this.parentField);
					Util.genTreeData(ary,"text",this.pkField,this.pkField);
					this.treeData=ary;
				})
			},
			init(){
				if(this.curRow[this.pkField]==0){
					return;
				}

				FormSolutionApi.getByAlias(this.formSolutionAlias,this.curRow[this.pkField]).then(res=> {
					if (res.metadata) {
						res.metadata = JSON.parse(res.metadata);
						if (res.metadata.formAllConfig) {
							this.formAllConfig = res.metadata.formAllConfig
						}
					}
					this.type=res.type;
					this.formSolution=res.formSolution;
					if(this.type=='EASY-DESIGN'){
						this.initEasyForm(res);
					}else{
						var tmp = FormUtil.getTemplate(res);
						res.template = `<div class="previewBox">${tmp}</div>`;
						this.initForm(res);
					}

					this.canStartFlow=res.canStartFlow;
					this.flowInstId=res.data.INST_ID_;
					// 按钮定义。
					this.buttons = this.parseButtons(res);
					//设置表单别名。
					this.formAlias=res.alias;
					this.loading = true;
				})
			},
			initForm(res){
				var curUser = this.user;
				var contextData = {
					type: "form",
					curUserId: curUser.userId,
					curUserName: curUser.fullName,
					account: curUser.account,
					deptId: curUser.deptId,
					tenantId: curUser.tenantId,
					tenantLabel:curUser.tenantLabel
				};
				if (res.data.INST_ID_ && "DELETE" != res.data.INST_STATUS_) {
					var contextDetail = {
						type: "detail",
						instId: res.data.INST_ID_,
						opinionHistorys: res.instDetail.bpmCheckHistories
					};
					Object.assign(contextData, contextDetail);
				}
				this.$refs.rxForm.loadForm(res, this.rxReadOnly, contextData);
			},
			initEasyForm(res){
				this.$nextTick(function() {
					this.$refs.rxForm.setData(res);
				})
				this.javascript=res.script;
				this.jsonData=res.metadata;
			},
			async validForm(required) {
				var formVm = this.$refs.rxForm.formVm;
				//提交前校验
				if (formVm._beforeSubmit) {
					var rtn = await formVm._beforeSubmit(formVm);
					if (!rtn.success) {
						return rtn;
					}
				}
				//数据必填，类型校验
				var res = formVm.valid(required, true);
				if (!res.success) {
					return res;
				}
				//表单唯一性校验
				let validMainUnique = await formVm.validMainUnique();
				if (!validMainUnique.success) {
					return validMainUnique;
				}
				return {success: true, msg: "验证通过"};
			},
			//流程图查看
			async flowImage(btn){
				Util.open({
					component:BpmImageView,
					curVm:this,
					widthHeight:['1024px','600px'],
					title:'流程图',
					data:{
						instId:this.flowInstId,
						formData:this.getFormData()
					}
				},function (action){
				});
			},
			async startFlow(btn){
				var self_ = this;
				btn.loading = true;
				var validResult = await this.validForm(true);
				if (!validResult.success) {
					this.$message.warning(validResult.msg);
					return;
				}
				var formData = self_.$refs.rxForm.getData();
				var params = {
					flowDefMapping: self_.formSolution.flowDefMapping,
					formJson: formData
				}
				var flowDefRes = await FormSolutionApi.getFlowDefId(params);
				var flowDefId = flowDefRes.data;
				if(!flowDefId){
					this.$message.warning("无满足条件的流程定义！");
					return;
				}
				var processConfigRes = await BpmInstApi.getProcessConfig(flowDefId);
				if (!processConfigRes.success) {
					this.$message.warning(processConfigRes.message);
					return;
				}
				if (processConfigRes.data) {
					var config = Util.deepClone(self_.processConfig);
					self_.processConfig = Object.assign(config, processConfigRes.data);
					self_.handleProcessConfig(self_.processConfig);
				}
				if (self_.processConfig.startConfirm && !self_.needConfirmDlg) { //启动流程确认
					self_.$confirm({
						title: '提示信息',
						content: '确认启动流程吗？',
						okText: '确认',
						cancelText: '取消',
						zIndex: 20000,
						onOk() {
							btn.loading = false;
							self_.doSubmit('start', btn);
						},
						onCancel() {
							btn.loading = false;
						},
					});
				} else if (self_.needConfirmDlg) { //是否确认
					let conf = {
						curVm: self_,
						title: '流程启动确认',
						component: BpmInstStartConfirm,
						data: {
							formSolutionAlias: self_.formSolutionAlias,
							processConfig: self_.processConfig,
							defId: flowDefId,
							instId: self_.instId  || formData.instId || formData.INST_ID_
						},
						widthHeight: ['800px', '520px']
					};
					btn.loading = false;
					Util.open(conf, function (action, data) {
						if (action != 'ok') return;
						self_.closeWindow(data);
					});
				} else {
					this.doSubmit('start', btn);
				}
			},
			closeWindow(json){
				if(this.fromRoute){
					this.$bus.emit("closeTab",{action:"current"})
				}
				else{
					Util.closeWindow(this, 'ok',json);
				}
			},
			async submit(btn) {
				if (this.type == 'EASY-DESIGN') {
					this.doEasySubmit("save", btn);
					return;
				}
				var validRequired = this.canStartFlow ? false : true;
				var validResult = await this.validForm(validRequired);
				if (!validResult.success) {
					this.$message.warning(validResult.msg);
					return;
				}
				this.doSubmit("save", btn);
			},
			doEasySubmit(action,btn) {
				var self = this;
				//拖拽表单，验证;
				this.$refs.rxForm.valid().then(res=> {
					var json = self.$refs.rxForm.getData();
					if (self.parent && self.parent.field) {
						json[self.parent.field] = self.parent.value;
					}
					btn.loading = true;
					var data = {setting: {action: action, alias: self.formSolutionAlias}, data: json};
					FormSolutionApi.saveForm(data).then(res => {
						btn.loading = false;
						if (self.$refs.rxForm._afterSubmit) {
							self.$refs.rxForm._afterSubmit(res, data);
						}
						if (res.success) {
							var result = {formJson: data, result: res.data};
							this.closeWindow(result);
						}
					})
				})
			},
			doSubmit(action,btn) {
				var json = this.$refs.rxForm.getData();
				//清除字段前后空格；
				json = this.removeSpaces(json);
				if (this.parent&&this.parent.field) {
					json[this.parent.field] = this.parent.value;
				}
				btn.loading = true;

				var data = {setting: {action: action, alias: this.formSolutionAlias}, data: json};
				FormSolutionApi.saveForm(data).then(res => {
					if (this.$refs.rxForm.formVm._afterSubmit) {
						this.$refs.rxForm.formVm._afterSubmit(res, json);
					}
					if (res.success) {
						var result = {formJson: json, result: res.data};
						btn.loading = false;
						this.closeWindow(result);
					} else {
						btn.loading = false;
					}
				})
			},
			handleProcessConfig(newVal) {
				let fillOpinion = false;
				let assignFlowUsers = false;
				let startCalFlowusers = false;
				//允许选择路径
				let allowSelectPath = newVal.allowSelectPath;

				var startOptions = newVal.startNodeOptions;

				if (startOptions instanceof Array) {
					this.processConfig.startConfirm = startOptions.indexOf('startConfirm') != -1;
					fillOpinion = startOptions.indexOf('fillOpinion') != -1;
					assignFlowUsers = startOptions.indexOf('assignFlowUsers') != -1;
					startCalFlowusers = startOptions.indexOf('startCalFlowusers') != -1;
				}
				if (fillOpinion || assignFlowUsers || startCalFlowusers || allowSelectPath) {//需要显示弹出对话框
					this.needConfirmDlg = true;
				}
			},
			selectNode(selKeys, e){
				this.curRow=e.node._props.dataRef;
				this.rxReadOnly=true;
				this.checkedKeys=selKeys;
				this.init();
			},
			rightClick({event, node}){
				this.curRow = node._props.dataRef;
				const postition = {top: event.clientY, left: event.clientX};
				if (this.curRow.key=="0"){
					this.isTreeCat=false;
				}else {
					this.isTreeCat=true;
				}
				this.checkedKeys=[this.curRow[this.pkField]];
				this.$refs.contextmenu.show(postition);
			},
			addData(){
				this.parent={field:this.parentField,value:this.curRow[this.pkField]};
				this.curRow={};
				this.rxReadOnly=false;
				this.init();
			},
			editData(){
				this.parent={};
				this.rxReadOnly=false;
				this.init();
			},
			delData(){
				let self_=this;
				this.$confirm({
					title: '操作提示',
					content: '您确定需要删除选中的记录吗？',
					okText: '确认',
					cancelText: '取消',
					zIndex:20000,
					onOk() {
						FormSolutionApi.removeById({alias: self_.formSolutionAlias, id: self_.curRow[self_.pkField]}).then(res => {
							self_.initData();
						});
					},
					onCancel() {
					}
				})
			},
			onExpand(expandedKeys) {
				this.expandedKeys = expandedKeys;
				this.autoExpandParent = false;
			},
			transData(data,name,key){
				for (let i = 0; i < data.length; i++) {
					var row = data[i];
					this.handRow(row,name,key);
				}
			},
			handRow(row,name,key){
				var obj={ title: row[name],  key: row[key]};
				Object.assign(row,obj)
			},
			loadByParent(treeNode){
				if (treeNode.dataRef[this.pkField]=="0" || (treeNode.dataRef.children && treeNode.dataRef.children.length>0)) {
					return;
				}
				return FormSolutionApi.getTreeByAlias(this.formSolutionAlias,treeNode.dataRef[this.pkField]).then(res=>{
					var ary=res.data;
					this.transData(ary,"text",this.pkField);
					treeNode.dataRef.children = ary;
				})
			}
		}
	}
</script>

<style scoped>
	.layersty{
		overflow: hidden;
	}
	.layersty >>> .eidtFormContainer{
		overflow: initial;
		height: auto;
	}
	.buttongmodle{
		text-align: right;
	}
	.footerToolBar button{
		margin-right: 4px;
	}
	.footerToolBar button:last-child{
		margin-right: 0;
	}
	.footerToolBar{
		display: inline-block;
	}
	.ant-layout-footer{
		padding: 8px 20px;
		background: #fff;
		box-shadow: 0px 0px 3px #d2d2d2;
		z-index: 99;
	}
	.defaultContent{
		position: relative;
		height: 100%;
	}
	.content-div{
		position: absolute;
		top: 10px;
		right: 10px;
		left: 10px;
		bottom: 10px;
		border-radius: 6px;
		overflow-y: auto;
		background: #fff;
		overflow: auto;
	}
	.beLayout{
		top: 0px;
		right: 0px;
		left: 0px;
		bottom: 0px;
		background: #f0f2f5;
	}

	#formContainer{
		background-color: #fff;
	}
	#rx-form-container {
		position: absolute;
		top: 10px;
		bottom: 0;
		left: 0;
		right: 0;
		overflow: auto;
	}
	.kforms{
		background-color: #fff;
	}
</style>