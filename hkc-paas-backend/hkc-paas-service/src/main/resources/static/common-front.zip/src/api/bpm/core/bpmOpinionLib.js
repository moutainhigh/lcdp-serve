import rxAjax from '@/assets/js/ajax.js';

//意见收藏表 api接口
export const BpmOpinionLibApi = {};

BpmOpinionLibApi.baseUrl= '/api-bpm/bpm/core/bpmOpinionLib';
BpmOpinionLibApi.exportUrl= BpmOpinionLibApi.baseUrl + '/export';

//查询列表
BpmOpinionLibApi.query=function (parameter) {
  var url= BpmOpinionLibApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
* 获取单记录
* @param pkId
* @returns {*}
*/
BpmOpinionLibApi.get =function(pkId) {
  var url= BpmOpinionLibApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

//保存数据
BpmOpinionLibApi.save =function(parameter) {
  var url= BpmOpinionLibApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

//删除数据
BpmOpinionLibApi.del =function(parameter) {
  var url= BpmOpinionLibApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

//获取当前用户常用审批意见
BpmOpinionLibApi.getUserText=function(){
  var url=BpmOpinionLibApi.baseUrl + '/getUserText';
  return rxAjax.get(url);
}

export  default BpmOpinionLibApi;

