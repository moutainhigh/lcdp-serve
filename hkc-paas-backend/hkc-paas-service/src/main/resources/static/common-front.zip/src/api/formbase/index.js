
import Vue from 'vue';
import print from '@/api/formbase/print';
import rxAjax from '@/assets/js/ajax.js';
import {Util} from 'jpaas-common-lib';
import BpmImageView from "@/views/modules/bpm/comps/BpmImageView";
import FormFunctions from "@/views/modules/form/core/js-comps/FormFunctions";
import FormSolutionApi from "@/api/form/core/formSolution";
import DialogBox from "@/assets/js/DialogBox";
import FlowFunctions from "@/api/formbase/FlowFunctions";

export default {
    mixins:[print,FlowFunctions],
    computed:{
        parentVm(){
            var vm=this;
            while (vm && !vm.rootVm){
                vm=vm.$parent;
            }
            return vm;
        },
        rxForms(){
            return this.parentVm.$refs.rxForms;
        },
        rxForm(){
            return this.parentVm.$refs.rxForm;
        },
        customForm(){
            return this.parentVm.$refs.customForm;
        }
    },

    methods:{
        ...FormFunctions,

        getFormData(){
            var formType=this.parentVm.processConfig.formType;
            var formData={};
            if(formType=="online") {
                if(this.rxForms){
                    formData=this.rxForms.getData();
                }else{
                    formData[this.rxForm.formVm.alias]=this.rxForm.getData();
                }
            }else{
                formData=this.customForm.getData();
            }
            return formData;
        },

        getData(){
            var defId=this.parentVm.localDefId;
            var data={defId:defId};
            var formType=this.parentVm.processConfig.formType;
            var hasPk=this.parentVm.processConfig.hasPk;
            var formData={};
            if(formType=="online"){
                if(this.rxForms){
                    formData=this.rxForms.getData();
                }else{
                    formData[this.rxForm.formVm.alias]=this.rxForm.getData();
                }
                data.systemHand=true;
                data.hasPk=hasPk;
            }
            else{
                formData=this.customForm.getData();
                data.systemHand=false;
            }
            var formJson=JSON.stringify(formData);
            data.formJson=formJson;

            let isCopy=this.parentVm.isCopy;
            if(this.parentVm.instId && !isCopy){
                data.instId=this.parentVm.instId;
            }
            data.attachment=JSON.stringify( this.parentVm.attachments);
            data.relateProcess=JSON.stringify(this.parentVm.relateProcess);
            return data;
        },

        /**
         * 执行表单方法。
         * @param 表单名称.自定义方法
         */
        exeCustomBtn(jsMethod){
            var idx=jsMethod.indexOf(".");
            if(idx==-1){
                this.$message.warning("自定义方法名称必须使用表单名称.方法的格式定义!");
                return;
            }
            var ary=jsMethod.split(".");
            var formAlias=ary[0];
            var formMethod=ary[1];
            var formDef;
            if(this.rxForms){
                formDef=this.rxForms.$refs["rxForm_" +formAlias];
            }else{
                formDef=this.rxForm;
            }
            var formVm=formDef.formVm;

            if(!formVm){
                this.$message.warning("表单名称【"+formAlias+"】不存在!");
                return;
            }

            if(!formVm['func_'+formMethod]){
                alert("方法【"+formMethod+"】不存在!");
                return;
            }
            //调用自定义方法。
            formVm['func_'+formMethod](formVm);
        },
        getOpenDialogComponet(data){
            var template=`<div style="width:100%;height:100%;"> 
              <component v-if="!url" ref="current" :is="currentView" :layerid="layerid" :destroy="destroy" `;

            let ary=["currentView","url","layerid","destroy"];

            if(data) {

                for (var key in data) {
                    var value=data[key];
                    if(typeof value=='string' && value.constructor==String){
                        template += key + '="' + value + '" ';
                    }else{
                        template += ' :' + key + '="' + key + '" ';
                        ary.push( key );
                    }
                }
            }
            template +=`      ></component>
             <iframe v-else style="height:700px;width:100%;" 
                      id="iframeId" :src="url" frameborder="0" scrolling="auto"> 
              </iframe>
           </div>`;

            let aryProp=[];
            for(let key of ary){
                aryProp.push('"' + key +'"');
            }
            let props=aryProp.join(",");



            var openDialogComponet= Vue.component('open-dialog', {
                template:template,
                ...eval('({\n' +
                    '        name: "DialogView",\n' +
                    '        props:['+props+']\n' +
                    '    })')
            })
            return openDialogComponet;
        },

        /**
         * 执行表单方法。
         * @param btn
         */
        handFormMethod(btn){
            let rxForms=this.rxForms;
            let formVm;
            let method="";
            if(btn.method.indexOf(".")==-1){
                formVm=rxForms.getFormRef().formVm;
                method = "func_" + btn.method;
            }
            else{
                let aryTmp=btn.method.split(".");
                let alias=aryTmp[0];
                method="func_" + aryTmp[1];
                formVm=rxForms.getFormRef(alias).formVm;
            }
            if (formVm && formVm[method]) {
                formVm[method]();
            }
        },
        /**
         * 处理自定义方法。
         * @param btn
         */
        handCustom(btn){

            this.customForm_ = function () {
                let rxAjax = this.rxAjax;
                let formJson=this.rxForms.getData();
                let rxForms=this.rxForms;
                let config=btn.config;
                eval(config.action);
            };
            this.customForm_();
        },
        /**
         * 处理pdf打印方法。
         * @param btn
         */
        handPdfPrint(btn){
            let pkId = btn.config.pkId;
            let boAlias = btn.config.boAlias;
            this.pdfPrint(pkId,boAlias,'');
        },
        /**
         * 执行按钮。
         * @param btn
         */
        handMethod(btn) {
            let rxForms=this.parentVm.$refs.rxForms;
            //表单方法
            if(btn.type=="formMethod" && rxForms){
                //执行表单方法。
                this.handFormMethod(btn);
                return;
            }
            //pdf打印
            if(btn.type=="pdfPrint"){
                //执行pdf打印方法。
                this.handPdfPrint(btn);
                return;
            }
            //自定义方法
            if(btn.type=="custom"){
                this.handCustom(btn);
                return;
            }
            //调用预定义方法。
            this[btn.method](btn);
        },
        /**
         * 打开自定义表单。
         * @param btn
         */
        openCustomForm(btn) {
            let self_ = this;

            let config=btn.config;
            let rxForms=this.parentVm.$refs.rxForms;
            let formJson = rxForms.getData();
            FormSolutionApi.getValueByCustomFormConfig({
                formJson: formJson,
                formConfig: config.formConfig || []
            }).then(res => {
                DialogBox.showForm({
                    title: config.formName,
                    curVm: self_,
                    data: {
                        alias: config.formAlias, setInitData: function (data) {
                            return Object.assign(data, res);
                        }
                    },
                    max: true
                }, function (action,data) {
                    if(config.script){
                        self_.callBack = function (action,data) {
                            let rxAjax = self_.rxAjax;
                            let formJson=self_.rxForms.getData();
                            let rxForms=self_.rxForms;

                            eval(config.script);
                        };
                        self_.callBack(action,data);
                    }
                });
            })
        },



    },
    watch:{
        buttons:{
            handler:function(val,oldval){
                this.btns=val;
            },
            deep:true
        }
    },
}