<template>
    <div class="layoutTabBox">
      <a-tabs
        :tab-position="'top'"
      >
        <a-tab-pane v-for="(item,index) of data" :key="index + 1" :tab="item.name" forceRender>
          <template v-if="item.config">
            <component  :ref="item.config.alias" :is="item.config.component"
                        :config="item.config" :isTab="true">
            </component>
          </template>
        </a-tab-pane>
      </a-tabs>
    </div>
</template>

<script>
    export default {
      name: 'layout-tab',
      props: {
          config: Array
      },
      data() {
        return {
          data: this.config
        }
      },
      methods: {},
      watch: {
        'config': {
          handler: function (val) {
            this.data=val;
          },
          deep: true
        }
      }
    }
</script>

<style scoped="scoped">
.layoutTabBox{
  height: 100%;
  width: 100%;
    background: #fff;
    border: 1px solid #dadde0;
}
.layoutTabBox >>> .ant-tabs-bar{
    background: #fafafa;
    height: 32px;
    border-bottom: 1px solid #dadde0;
}
.layoutTabBox >>> .ant-tabs-nav .ant-tabs-tab{
    padding: 6px 0px;
}
</style>