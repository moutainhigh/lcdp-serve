<template>
	<rx-fit>
		<div class="itmsFont">
			<ul class="ithear" v-if="!menu || !menu.title">
				<li :class="[curMenus_id == index? 'hoverli':'']" v-for="(menu, index) in curMenus"
					@click="hanlick(index,menu)">{{ menu.title }}
				</li>
			</ul>
			<ul class="item-cong">
				<li @click="handMenuClick(list)" v-for="list in curMenus_li" class="item-li">
					<div class="item-icon-box">
						<i class="iconfont " :class="JSON.parse(list.icon).icon"></i>
						<a-icon :type="JSON.parse(list.icon).icon"></a-icon>
					</div>
					<p>
						<span class="spanlist">{{ list.title }}</span>
					</p>
				</li>
			</ul>
		</div>
	</rx-fit>
</template>

<script>
/**
 * 功能面板
 */
import {RxFit} from 'jpaas-common-lib'
import {mapMutations, mapState} from 'vuex'
import menuView from "@/layouts/js/menuView";

export default {
	name: 'MenuViewFun',
	props: {
		menu:[Object]
	},
	components: {
		RxFit,
	},
	mixins: [menuView],
	data() {
		return {
			curMenus: [],
			alert: '',
			curMenuId: '',
			curMenus_li: [],
			curMenus_id: '0'
		}
	},
	created() {
		this.initMenus()
	},
	methods: {
		...mapMutations('appSetting', ['setSelectMenu']),
		initMenus() {
			if(this.menu){
				this.curMenuId=this.menu.id;
			}else {
				this.curMenuId=this.selectMenu.id;
			}
			this.curMenus = this.getSelectMenus(this.menus, this.curMenuId)
			if (this.curMenus.length>0 &&this.curMenus[0].children) {
				this.curMenus_li = this.curMenus[0].children
			}
		},
		hanlick(index, menu) {
			this.curMenus_id = index;
			this.curMenus_li = menu.children;
		},
		handMenuClick(menu) {
			this.setSelectMenu(menu);
		}
	},
	watch:{
		"selectMenu.id":function (val,oldVal){
			if(val){
				this.initMenus();
			}
		}
	}
}
</script>

<style scoped>
.spanlist {
	width: 100%;
	display: block;
	text-align: center;
	text-overflow: ellipsis;
	display: -webkit-box;
	-webkit-line-clamp: 1;
	-webkit-box-orient: vertical;
}

.itmsFont {
	background-color: white;
	width: calc(100% - 20px);
	margin: auto;
	border-radius: 6px;
	margin-top: 10px;
	padding: 10px;
}

.ithear {
	width: 100%;
	overflow: hidden;
	height: 42px;
	border-bottom: 1px solid #eef2f4;
}

.ithear li {
	float: left;
	height: 40px;
	line-height: 40px;
	margin-right: 20px;
	cursor: pointer;
}

.hoverli {
	color: #1890ff;
	border-bottom: 2px solid #1890ff;
}

.item-cong {
	width: 100%;
	overflow: hidden;
	background-color: white;
}

.item-li {
	width: 100px;
	margin-top: 10px;
	border-radius: 6px;
	margin-right: 15px;
	position: relative;
	background: white;
	border: 1px solid white;
	float: left;
}

.item-li:hover {
	border: 1px solid #4D9EFF;
	top: -2px;
	box-shadow: 0 6px 18px 2px #e0e5e7;
}

.item-li:nth-child(6n + 6) {
	margin-right: 0;
}

.item-li p {
	font-size: 14px;
	text-align: center;
	width: 100%;
	box-sizing: border-box;
	white-space: nowrap;
	text-overflow: ellipsis;
	overflow: hidden;
	min-height: 42px;
}

.itmsFont .item-li p > span {
	display: inline-block;
	vertical-align: middle;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;

}

.item-li p:before {
	content: '';
	display: inline-block;
	height: 100%;
	width: 0;
	vertical-align: middle;
}

.item-icon-box {
	width: 60px;
	height: 60px;
	margin: auto;
	text-align: center;
	border-radius: 50%;
	background: #09bcb9;
	color: white;
	margin-top: 15px;
}

.item-icon-box i {
	font-size: 30px;
	line-height: 60px;
}

.item-li:nth-child(1) .item-icon-box {
	background-color: #0595fe;
}

.item-li:nth-child(2) .item-icon-box {
	background-color: #458bff;
}

.item-li:nth-child(3n) .item-icon-box {
	background-color: #09bcb9;
}

.item-li:nth-child(4n) .item-icon-box {
	background-color: #76d32c;
}

.item-li:nth-child(5n) .item-icon-box {
	background-color: #f0cb39;
}
</style>