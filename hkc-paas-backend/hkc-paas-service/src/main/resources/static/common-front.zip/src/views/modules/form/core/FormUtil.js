var FormUtil={};

/**
 * 构建表单模板。
 * @param tmp
 * @returns {string|*}
 */
FormUtil.getTemplate=function (json) {
  var tmp=json.template;
  var wizard=json.wizard;
  var aryTmp= JSON.parse(tmp);
  if(aryTmp.length==1){
    return aryTmp[0].content;
  }
  else{
    var ary = [];
    ;
    var _len = aryTmp.length ;
    if(wizard){
      //fromTabActive ,changeTab，readonly，tabPrev，tabNext在 表单设计代码的rxform.js中;
      ary.push('<a-tabs :activeKey= "fromTabActive" ref="fromTab" @change="changeTab">');
    }else {
      ary.push('<a-tabs defaultActiveKey="tab0" ref="fromTab" @change="changeTab">');
    }
    for (var i = 0; i < _len; i++) {
      var tab = aryTmp[i];
      if(wizard){
        ary.push(`<a-tab-pane tab="${tab.title}" key="tab${i}" :disabled="!readonly" :forceRender="true">
            <div id="fromTab${i}">
                 ${tab.content}
                 <div style="padding:10px;text-align:center;">
                   <a-button type="primary" @click="tabPrev(${i},${_len})"  v-if="${ i == 0 ? false:true } && !readonly" style="margin-right:6px;" >上一步</a-button>				            
                   <a-button type="primary" @click="tabNext(${i},${_len})"  v-if="${ i == _len - 1 ? false:true } && !readonly" >下一步</a-button>			            
                 </div>
           </div>
          </a-tab-pane>`);
      }else{
        ary.push(`<a-tab-pane tab="${tab.title}" key="tab${i}" :forceRender="true">${tab.content}</a-tab-pane>`);
      }
    }
    ary.push("</a-tabs>");
    return ary.join("");
  }
}


export default FormUtil;