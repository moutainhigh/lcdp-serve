<template>
    <div class="wrap">
        <div><filter-params @paramsChange="paramsChange" :config="config" :filterParams="config.filterParams" ></filter-params></div>
        <div style="height: 100%" :ref="config.alias"></div>
    </div>
</template>

<script>
import ChartPublic from '../formComponent/ChartPublic'
export default {
    /**
     * 漏斗图
     */
    name: "funnel-component",
    mixins: [ChartPublic],
    data() {
        return {
        }
    },
    methods: {
        setOption(){
            //图例组件
            var legend = this.dimensionVals;
            var data = [];
            for (let i = 0; i < legend.length; i++) {
                var val=this.measureVals[i]?this.measureVals[i].value:"";
                data.push({value: val, name: legend[i] })
            }
            var formatter=this.config.advConfig.formatter?this.config.advConfig.formatter:''
            this.option  = {
                tooltip: {
                    trigger: 'item',
                    formatter:'{a} <br/>{b} : {c}'+formatter,
                },
                toolbox: {
                    feature: {
                        saveAsImage: {show:this.config.advConfig.saveAsImage},
                        restore: {show: this.config.advConfig.restore}
                    }
                },
                legend: {
                    data:legend
                },
                color:this.getColors(),
                series: [
                    {
                        name: this.config.name,
                        type: 'funnel',
                        left: '10%',
                        label: {
                            show: true,
                            position: 'inside'
                        },
                        emphasis: {
                            label: {
                                fontSize: this.config.advConfig.fontSize
                            }
                        },
                        sort:this.config.advConfig.sort,
                        data: data
                    }
                ]
            };
        }
    }
}
</script>