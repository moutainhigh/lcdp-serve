import rxAjax from '@/assets/js/ajax.js';

//form_pdf_template api接口
export const FormPdfTemplateApi = {};

FormPdfTemplateApi.baseUrl= '/api-form/form/core/formPdfTemplate';
FormPdfTemplateApi.exportUrl= FormPdfTemplateApi.baseUrl + '/export';

//查询列表
FormPdfTemplateApi.query=function (parameter) {
  var url= FormPdfTemplateApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
* 获取单记录
* @param pkId
* @returns {*}
*/
FormPdfTemplateApi.get =function(pkId) {
  var url= FormPdfTemplateApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

/**
 * 获取pdf打印模板
 */
FormPdfTemplateApi.getTemplate = function(parameter){
  var url= FormPdfTemplateApi.baseUrl + '/getPdfTemplate';
  return rxAjax.postJson(url,parameter);
}
/**
 * 获取pdf打印模板优化
 */
FormPdfTemplateApi.getTemplate2 =function(config) {
  var url= FormPdfTemplateApi.baseUrl + '/getPdfTemplate2';
  return rxAjax.postJson(url,config);
}

//保存数据
FormPdfTemplateApi.save =function(parameter) {
  var url= FormPdfTemplateApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

//删除数据
FormPdfTemplateApi.del =function(parameter) {
  var url= FormPdfTemplateApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

export  default FormPdfTemplateApi;

