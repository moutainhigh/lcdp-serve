export { default as ExceptionPage } from '@/components/Exception'

