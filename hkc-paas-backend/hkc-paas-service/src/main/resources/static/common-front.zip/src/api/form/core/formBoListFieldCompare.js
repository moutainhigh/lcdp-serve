
import moment from "moment";

export  default {
    methods:{
        getActionButton(alias){
            //如果没有rowButtons 直接返回true。
            if(!this.rowButtons){
                return null;
            }
            var btn=null;
            for(var i=0;i<this.rowButtons.length;i++){
                var button=this.rowButtons[i];
                if(!button.alias){
                    return null;
                }
                if(button.alias==alias){
                    btn=button;
                    break;
                }
            }
            return btn;
        },
        /**
         * 判断按钮是否有权限。
         * @param record
         * @param config
         */
        canActionShow(alias,record){
            var btn=this.getActionButton(alias);
            if(btn==null || !btn.btnShow){
                return  true;
            }
            var config=JSON.parse(btn.btnShow);


            var user=this.user;

            //  {type:"",setting:[],script:""}
            var rtn=true;
            var type=config.type;
            if(type=="field"){
                rtn=this.handButtonField(config.setting,record);
            }
            else{
                rtn=this.handButtonScript(config.script,record);
            }
            return rtn;

        },
        handButtonScript(script,record){
            if(!script){
                return true;
            }
            var user=this.user;
            var func=`this.hasPermission=()=>{${script}};`;
            eval(func)
            var rtn= this.hasPermission();
            return rtn;
        },
        handButtonField(settings,record){
            var rtn=false;
            for(var i=0;i<settings.length;i++){
                var setting=settings[i];
                if(i==0){
                    rtn=this.handField(setting,record);
                }
                else{
                    var tmp=this.handField(setting,record);
                    if(setting.logic=="and"){
                        rtn=tmp?rtn:false;
                    }
                    else {
                        rtn=tmp?true:rtn;
                    }
                }
            }
            return rtn;
        },
        /**
         * {
            "field": "F_AMOUNT",
            "operator": "between",
            "valType": "fixed",
            "val": "{\"start\":\"10\",\"end\":\"20\"}",
            "datatype": "int",

        }
         * @param setting
         */
        handField(setting,record){
            var datatype=setting.datatype;
            if(datatype=="string"){
                return  this.handString(setting,record);
            }
            else if(datatype=="date"){
                return this.handDate(setting,record);
            }
            else{
                return this.handNumber(setting,record)
            }
        },
        handString(setting,record){
            var srcVal=record[setting.field];
            var targetVal="";
            var valType=setting.valType;
            if(valType=="fixed"){
                targetVal=setting.val;
            }
            else if(valType=="field"){
                targetVal=record[setting.val];
            }
            else if(valType=="group" || valType=="user" ){
                if(!setting.val){
                    targetVal="";
                }
                var ary=[];
                var aryTmp=setting.val;
                for(var i=0;i<aryTmp.length;i++){
                    ary.push(aryTmp[i].id);
                }
                targetVal=ary.join(",");
            }
            else if(valType=="curUserId"){
                targetVal=this.user.userId ;
            }
            else if(valType=="curGroupId"){
                targetVal=this.user.roles.join(",") ;
            }


            var operator=setting.operator;
            if(operator=="="){
                return srcVal==targetVal;
            }
            else if(operator=="!="){
                return srcVal!=targetVal;
            }
            else if(operator=="contains"){
                return  this.isInclude( srcVal, targetVal);
            }
            else if(operator=="includeIn"){
                return this.isInclude( targetVal, srcVal);
                return  targetVal.includes( srcVal);
            }
            else if(operator=="notcontains"){
                return  !this.isInclude( srcVal, targetVal);
            }
        },
        isInclude(src,target){
            var aryTarget=target.split(",");
            var include=true;
            for(var i=0;i<aryTarget.length;i++){
                if(!src.includes(aryTarget[i])){
                    include=false;
                    break;
                }
            }
            return include;
        },


        handDate(setting,record){
            var format="YYYY-MM-DD HH:mm:ss";
            var srcVal=record[setting.field];
            var targetVal="";
            var valType=setting.valType;
            if(valType=="fixed"){
                targetVal=setting.val;
            }
            else if(valType=="field"){
                targetVal=record[setting.val];
            }
            else{
                targetVal=moment().format(format);
            }

            if(!srcVal || !targetVal){
                return true;
            }

            //将日期统一成字符串进行比较。
            var src=moment(srcVal).format(format);
            var target=moment(targetVal).format(format);

            var operator=setting.operator;

            if(operator=="="){
                return src==target;
            }
            else if(operator==">"){
                return src>target;
            }
            else if(operator==">="){
                return src>=target;
            }
            else if(operator=="<"){
                return src<target;
            }
            else if(operator=="<="){
                return src<=target;
            }
            else if(operator=="between"){
                var targetJson=JSON.parse(targetVal);
                var start=moment( targetJson.start).format(format);
                var end=moment(targetJson.end).format(format);
                var rtn=srcVal>=start && srcVal<=end;
                return rtn;
            }
        },
        handNumber(setting,record){
            var srcVal=record[setting.field];
            var targetVal="";
            var valType=setting.valType;
            if(valType=="fixed"){
                targetVal=setting.val;
            }
            else if(valType=="field"){
                targetVal=record[setting.val];
            }
            var operator=setting.operator;

            if(operator=="="){
                return parseInt(srcVal)==parseInt(targetVal);
            }
            else if(operator==">"){
                return parseInt(srcVal)>parseInt(targetVal);
            }
            else if(operator==">="){
                return parseInt(srcVal)>=parseInt(targetVal);
            }
            else if(operator=="<"){
                return parseInt(srcVal)<parseInt(targetVal);
            }
            else if(operator=="<="){
                return parseInt(srcVal)<=parseInt(targetVal);
            }
            else if(operator=="between"){
                var targetJson=JSON.parse(targetVal);
                //{"start":"5","end":"5"}
                var start=parseInt(targetJson.start);
                var end=parseInt(targetJson.end);
                var srcVal=parseInt(srcVal);
                var rtn=srcVal>=start && srcVal<=end;
                return rtn;
            }


        }
    }
}