import rxAjax from '@/assets/js/ajax.js';

//demo api接口
export const DemoApi = {};

DemoApi.baseUrl= '/api-demo/demo/core/demo';
DemoApi.exportUrl= DemoApi.baseUrl + '/export';

//查询列表
DemoApi.query=function (parameter) {
  var url= DemoApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
* 获取单记录
* @param pkId
* @returns {*}
*/
DemoApi.get =function(pkId) {
  var url= DemoApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

//保存数据
DemoApi.save =function(parameter) {
  var url= DemoApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

//删除数据
DemoApi.del =function(parameter) {
  var url= DemoApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

export  default DemoApi;

