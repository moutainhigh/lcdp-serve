<template>
    <div style="width:100%;height:100%" class="flowImg">
        <div style="padding: 10px">温馨提示：按住鼠标<span style="color: red">左键</span>可拖动查看,<span style="color: red">单击节点</span>可查看节点操作详情
        </div>
        <div class="containers" ref="content">
            <div class="canvas" ref="canvas" style="width: 100%;height: 100%">
            </div>
        </div>
    </div>
</template>

<script>
import BpmnViewer from 'bpmn-js/lib/NavigatedViewer'
import {getBpmnXmlFromParam, getBpmnImageNodeInfo} from '@/api/bpm/core/bpmImage'
import SysDicApi from "@/api/system/core/sysDic";
import BaseRenderer from 'diagram-js/lib/draw/BaseRenderer';
import nodeProperties from './flowstate'
import flowNode from './flowNode.js'
import baidu from 'baidutemplate/baiduTemplate'
import {
    append as svgAppend,
    attr as svgAttr,
    create as svgCreate,
    classes as svgClasses,
} from 'tiny-svg';

var propertiesConfig = {}

var isPreview =false

function createFlowNode(parentNode, imgUrl, position, width, height) {
    var image = svgCreate('image');
    var isPosition = position == "bottom" ? true : false;
    var _w = width || 42;
    var _h = height || 20;
    var _width = (100 - Number(_w)) / 2;
    var _height = 0 - Number(_h);
    if (isPosition) {
        //右下角标，暂时只有超时用到；
        svgAttr(image, {
            x: 59,
            y: 59,
            width: 40,
            height: 20,
            href: imgUrl
        });
    } else {
        svgAttr(image, {
            x: _width,
            y: _height,
            width: _w,
            height: _h,
            href: imgUrl
        });
    }
    svgAppend(parentNode, image);
}

class CustomRenderer extends BaseRenderer {
    constructor(eventBus, bpmnRenderer) {
        super(eventBus, 1500);
        this.bpmnRenderer = bpmnRenderer;
    }

    canRender(element) {
        // ignore labels
        const type = element.type // 类型
        return !element.labelTarget;
    }

    drawShape(parentNode, element) {
        let shape = this.bpmnRenderer.drawShape(parentNode, element);
        setShapeProperties(shape, element, parentNode) // 在此修改shape
        return shape
    }
    getShapePath(shape) {
        return this.bpmnRenderer.getShapePath(shape);
    }

}

function setShapeProperties(shape, element, parentNode) {
    const id = element.id;//获取到的节点ID
    const type = element.type // 获取到的类型
    //开始节点和结束节点加上颜色
    if(isPreview &&  (type=="bpmn:StartEvent" || type=="bpmn:EndEvent" || type=="bpmn:ExclusiveGateway") ){
        shape.style.setProperty("stroke", '#83cd6c');
        return;
    }
    if (propertiesConfig[type + ":" + id]) {
        const properties = propertiesConfig[type + ":" + id];
        Object.keys(properties).forEach(prop => {
            const val = properties[prop];
            if (prop == "href") {
                var type = properties['type'];
                if (type && type == "REFUSE") {//不同意
                    createFlowNode(parentNode, val, '', 52);
                } else if (type == "OVERTIME") {//超时
                    createFlowNode(parentNode, val, "bottom")
                } else if (type == "HANDLE" || type == "UNHANDLE") {//当前节点
                    createFlowNode(parentNode, val, "", 62)
                } else {
                    createFlowNode(parentNode, val)
                }
            }
            if (prop == 'fill' || prop == "stroke") {
                shape.style.setProperty(prop, properties[prop]);
            }
        })
    }
}

CustomRenderer.$inject = ['eventBus', 'bpmnRenderer']

export default {
    name: "BpmImageView",
    components: {
        flowNode
    },
    props: {
        instId: String,
        taskId: String,
        defId: String,
        formData: Object,
        preview: {
            tyep:Boolean,
            default:false
        }
    },
    data() {
        return {
            nodeAry: {},
            histories:[]
        }
    },
    created() {
        if (this.instId || this.taskId || this.preview) {
            this.loadDic();
        }
        this.init();

    },
    methods: {
        loadDic() {
            var self = this;
            SysDicApi.getByAlias('LCJD').then(res => {
                res.forEach(item => {
                    self.nodeAry[item.name] = item.value;
                });
            })
        },
        createHtml(json) {
            var _html = baidu.template(flowNode, json);
            return _html;
        },
        getNodeId(nodeId) {
            for (var key in this.nodeAry) {
                if (nodeId.indexOf(key) != -1) {
                    return this.nodeAry[key] + ':' + nodeId;
                }
            }
        },
        init() {
            let self = this;
            isPreview=this.preview;
            this.$nextTick().then(() => {
                this.canvas = this.$refs.canvas;
                if (!this.viewer) {
                    this.viewer = new BpmnViewer({
                        container: this.canvas,
                        keyboard: {
                            bindTo: window
                        },
                        additionalModules: [
                            {
                                __init__: ['customRenderer'],
                                customRenderer: ['type', CustomRenderer]
                            }
                        ]
                    })
                }

                //从后台xml中获取
                getBpmnXmlFromParam({
                    defId: self.defId,
                    instId: self.instId,
                    taskId: self.taskId,
                    showHis: true,
                    preview: this.preview,
                    formData:this.formData
                }).then(result => {
                    if (!result) {
                        return;
                    }
                    propertiesConfig = {};
                    if (result.histories != null) {
                        self.histories=result.histories;
                        for (let i = 0; i < result.histories.length; i++) {
                            var checkStatus = result.histories[i].checkStatus;
                            if (checkStatus == 'TRANSFER' || checkStatus == 'ROAM_TRANSFER' || checkStatus == 'COMPLETED') {
                                //转办历史跳过
                                continue;
                            }
                            propertiesConfig[this.getNodeId(result.histories[i].nodeId)] = nodeProperties[checkStatus];
                        }
                    }
                    this.viewer.importXML(result.bpmnXml, function (err) {

                        if (err) {
                            console.log('error rendering', err);
                        } else {
                            console.log('rendered');
                        }
                        const eventBus = self.viewer.get('eventBus');
                        const overlays = self.viewer.get('overlays');

                        var ishovers = false;
                        var _id = ''
                        eventBus.on('element.click', (e) => {
                            if (e.element.type != 'bpmn:UserTask') {
                                overlays.clear();
                                ishovers = false;
                                return;
                            }
                            if (e.element.id && _id != e.element.id) {
                                if (overlays) {
                                    overlays.clear();
                                }
                                overlays.clear();
                                ishovers = false;
                                _id = e.element.id;
                            }
                            if (ishovers) {
                                return;
                            }
                            if(self.preview){
                                var json={
                                    taskNodeUser:{
                                        "nodeId": e.element.id,
                                        "nodeText": "",
                                        "nodeType": e.element.type,
                                        "multiInstance": "normal",
                                        "actDefId": "",
                                        "configExecutors": [],
                                    },
                                    histories:[]
                                };
                                self.histories.find(item=>{
                                    if(item.nodeId==e.element.id){
                                        json.histories.push(item);
                                        var executor={
                                            "type": "user",
                                            "id": item.handlerId,
                                            "name": item.handlerUserName,
                                            "account": item.handlerUserNo,
                                            "calcType": "none"
                                        };
                                        json.taskNodeUser.nodeText=item.nodeName;
                                        json.taskNodeUser.actDefId=item.actDefId;
                                        json.taskNodeUser.configExecutors.push(executor);
                                    }
                                });
                                if(json.histories.length>0){
                                    const $overlayHtml = self.createHtml(json);
                                    overlays.add(e.element.id, {
                                        position: {top: e.element.height, left: -92},
                                        html: $overlayHtml
                                    });
                                }
                            }else {
                                getBpmnImageNodeInfo({
                                    taskId: self.taskId,
                                    instId: self.instId,
                                    defId: self.defId,
                                    nodeId: e.element.id,
                                    formData: self.formData
                                }).then(json => {
                                    if (!json.taskNodeUser) {
                                        return;
                                    }
                                    const $overlayHtml = self.createHtml(json);
                                    overlays.add(e.element.id, {
                                        position: {top: e.element.height, left: -92},
                                        html: $overlayHtml
                                    });
                                })
                            }
                            self.itemClick(overlays);
                            ishovers = true;
                        });

                    });
                });
            });
        },
        itemClick(overlays) {
            var dom = overlays._overlayRoot;
            dom.removeEventListener('click', this.btnClick);
            dom.addEventListener('click', this.btnClick)
        },
        btnClick(e) {
            var ev = e || window.event;
            var target = ev.target || ev.srcElement;
            if (target.className.includes('flow-item-btn')) {
                var li = target.parentNode.parentNode.parentNode;
                var lichiren = li.parentNode.getElementsByClassName('flow-item-li');
                for (let i = 0; i < lichiren.length; i++) {
                    if (lichiren[i] != li) {
                        lichiren[i].className = "flow-item-li";
                        lichiren[i].getElementsByClassName('flow-item-btn')[0].innerText = "展开";
                    }
                }
                if (li.className.includes("flow-item-li")) {
                    if (li.className.includes('active')) {
                        target.innerText = "展开";
                        li.className = "flow-item-li"
                    } else {
                        target.innerText = "收起";
                        li.className = "flow-item-li active"
                    }
                }

            }
        }
    }
}
</script>

<style scoped>
.containers {
    height: calc(100% - 44px);
    width: 100%;
}

.djs-container > svg {
    overflow: auto !important;
}

.djs-connection path {
    stroke: blue !important;
    marker-end: url(#sequenceflow-arrow-normal) !important;
}
</style>