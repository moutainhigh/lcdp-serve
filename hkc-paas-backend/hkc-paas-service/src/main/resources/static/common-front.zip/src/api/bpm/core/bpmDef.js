import rxAjax from '@/assets/js/ajax.js';
import BpmInstApi from "@/api/bpm/core/bpmInst";

const BpmDefApi = {
  baseUrl: '/api-bpm/bpm/core/bpmDef',
  designBaseUrl:'/bpm-designer'  ,
  export:  '/api-bpm/bpm/core/bpmDef/export'
}

BpmDefApi.getBpmnXmlFromDefId=function (defId) {
  let url = BpmDefApi.baseUrl + '/getBpmnXmlFromDefId?defId='+defId;
  return rxAjax.get(url);
}
/**
 * 流程定义作废
 * @param defId
 */
BpmDefApi.discard= function (defId){
  let url = BpmDefApi.baseUrl + '/discard';
  return rxAjax.postForm(url,{"defId":defId});
}

/**
 * 流程定义恢复
 * @param defId
 */
BpmDefApi.recover= function (defId){
  let url = BpmDefApi.baseUrl + '/recover';
  return rxAjax.postForm(url,{"defId":defId});
}

// 流程设计导入
BpmDefApi.doImport=function(formData,callback) {
  let url= BpmDefApi.baseUrl+"/doImport";
  return rxAjax.upload(url,formData,callback);
}

/**
 * 流程设计导出
 * @param defIds
 * @returns {*}
 */
BpmDefApi.doExport = function(defIds) {
  window.location.href='/api/api-bpm/bpm/core/bpmDef/doExport?defIds=' + defIds;
}

/**
 * 获取单记录
 * @param pkId
 * @returns {*}
 */
BpmDefApi.get = function(pkId) {
  let url =  BpmDefApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

BpmDefApi.save =function(parameter) {
  let url=BpmDefApi.baseUrl+ '/save';
  return rxAjax.postJson(url,parameter);
}

BpmDefApi.copyDef=function(parameter){
  let url=BpmDefApi.baseUrl+ '/copyDef';
  return rxAjax.postJson(url,parameter);
}
/**
 * 传入defIds进行流程定义删除
 * @param ids
 */
BpmDefApi.del=function (defIds) {
  let url=BpmDefApi.baseUrl + '/del';
  return rxAjax.postForm(url,{ids:defIds});
}

/**
 * 清除流程运行数据。
 * @param defId
 */
BpmDefApi.clearInstByDefId=function (defId) {
  let url=BpmDefApi.baseUrl + '/clearInstByDefId';
  return rxAjax.postForm(url,{defId:defId});
}

/**
 * 获取流程的开始节点的必填节点与可选节点
 * @param defId
 * @returns {AxiosPromise}
 */
BpmDefApi.getStartUserNodes = function(defId,formData){
  let url=BpmDefApi.baseUrl + '/getStartUserNodes?defId='+ defId;
  return rxAjax.postJson(url,formData);
}


/**
 * 获取流程的开始节点的必填节点与可选节点
 * @param defId
 * @returns {AxiosPromise}
 */
BpmDefApi.getFlowNodesExecutors = function(defId,formData){
  let url=BpmDefApi.baseUrl + '/getFlowNodesExecutors?defId='+ defId;
  return rxAjax.postJson(url,formData);
}





export default  BpmDefApi;


