import chaoshi from "./img/chaoshi.png"
import agree from "./img/agree.png"
import back from "./img/back.png"
import recover from "./img/recover.png"
import interpose from "./img/interpose.png"
import refuse from "./img/refuse.png"
import skip from "./img/skip.png"
import handle from "./img/handle.png"

const nodeProperties = {
  SKIP:{//跳过
    stroke:'#2e9eef',
    href:skip
  },
  REFUSE:{//不同意
    type:'REFUSE',
    stroke:'#ff8484',
    href:refuse
  },
  AGREE:{//同意
    stroke:'#83cd6c',
    href:agree
  },
  BACK:{//驳回
    stroke:'#b095f5',
    href:back
  },
  UNHANDLE:{//未处理
    stroke:'#ff3737',
    href:handle
  },
  HANDLE:{//正在处理（当前节点）；
    type:'HANDLE',
    stroke:'#ff3737',
    href:handle
  },
  OVERTIME_AUTO_AGREE:{//超时审批
    type:"OVERTIME",
    href:chaoshi
  },
  RECOVER:{//撤回
    stroke:"#fcbc0d",
    href:recover
  },
  ABSTAIN:{//弃权

  },
  INTERPOSE:{//干预
    stroke:"#fa894b",
    href:interpose
  }
}
//fill:填充颜色 stroke:边框颜色 strokeWidth:边框长度
/*
* AGREE:通过，
* SKIP：跳过，
* REFUSE：不同意，
* ABSTAIN：弃权；
* TRANSFER：转办；
* INTERPOSE：干预；
* UNHANDLE:未处理
*
*OVERTIME_AUTO_AGREE：超时审批，TIMEOUT_SKIP：超时跳过，
*
* RECOVER：撤回，RECOVER_CANCEL撤回撤销
*
* BACK：驳回；BACK_TO_STARTOR：驳回发起人；BACK_SPEC：驳回节点；BACK_CANCEL：驳回撤销；BACK_GATEWAY：驳回网关；
*
* COMMUNICATE：沟通；REPLY_COMMUNICATE：回复沟通；CANCEL_COMMUNICATE：取消沟通，
* */
export default nodeProperties ;
