<template>
	<a-menu theme="dark" mode="inline" :selectedKeys="selectedKeys">
		<template v-for="(menu,index) in leftMenus">
			<a-menu-item v-if="showSubMenu(menu)" :key="menu.key" @click="handMenuClick(menu)" >
				<a-icon v-if="!menu.icon.includes('type')" :type="menu.icon"/>
				<my-icon v-else-if="customArr.includes(JSON.parse(menu.icon).type)"
						 :type="JSON.parse(menu.icon).icon"></my-icon>
				<a-icon v-else :type="JSON.parse(menu.icon).icon"></a-icon>
				<span>{{ menu.title }}</span>
			</a-menu-item>
			<sub-menu v-else :key="menu.key" :menu-item="menu" :subindex="index" :subpath="index+'.'"
					  :hand-click="handMenuClick"/>
		</template>
	</a-menu>
</template>

<script>
import SubMenu from './SubMenu'
import {mapMutations, mapState} from 'vuex'
import menuPortal from "@/api/portal/core/menuPortal";

export default {
	components: {
		'sub-menu': SubMenu,
	},
	mixins:[menuPortal],
	// props: {
    //     menu: {type: Object},
    //   collapsed:''
    // },
	data() {
		return {
			leftMenus: [],
			customArr: ['customIcon', 'userCustomIcon']
		}
	},
	mounted() {
		this.leftMenus=this.menus;
		if (this.leftMenus && this.leftMenus.length>0) {
			this.setNavigation([{key:this.leftMenus[0].key,title:'首页',collapsed:false}])
			this.setSelecteKeys([this.leftMenus[0].key])
		}

	},
	computed: {
		...mapState({
			menus: state => state.appSetting.menus,
			navigations: state => state.appSetting.navigations,
			appKey: state => state.appSetting.appKey
		})
	},
	methods: {
		...mapMutations('appSetting', ['setSelectMenu','setNavigations','setIdKey']),
		rootlist() {
            this.rootSubmenuKeys = [];
            for (var listyp of this.menu.children) {
                this.rootSubmenuKeys.push(listyp.key)
            }
        },
		showSubMenu(item) {
			var showType = item.showType;
			if (!item.children || showType == 'FUNS' || showType == 'FUN' || showType == 'FUNS_BLOCK') {
				return true;
			}
			return false;
		},
		// handMenuClick(selectMenu) {
		// 	this.setSelectMenu({});
		// 	this.setSelectMenu(selectMenu);
		// 	this.setIdKey(this.appKey);
		// }
	},
	watch:{
		"menus":function (val,oldVal){
			if (val){
				this.leftMenus=val;
			}else {
				this.leftMenus=[];
			}
		}
		// menu: function (val) {
        //     this.rootlist();
        //     if (val && val.key) {
        //         this.appKey = val.key;
        //     }
        // },
	}
}
</script>
