import {mapMutations, mapState} from "vuex";
import DialogView from "@/layouts/DialogView";
import {getComponent, getParentNode} from "@/utils/routerUtil";
import {Util} from "jpaas-common-lib";

/**
 * 导航菜单扩展。
 */
export default {
	computed: {
		...mapState({
			menus: state => state.appSetting.menus,
			menuStyle: state => state.appSetting.menuStyle,
			menuMap: state => state.appSetting.menuMap,
			selectedKeys: state => state.appSetting.selectedKeys,
			openKeys: state => state.appSetting.openKeys,
			navigation: state => state.appSetting.navigation,
			activeKey: state => state.appSetting.activeKey,
			switching: state => state.appSetting.switching,//栏目类型 : 导航栏 navigation 与 面包屑 crumbs

		})
	},
	methods: {
		...mapMutations('appSetting', ['setMenuPath', "setSelecteKeys", 'setOpenKeys', 'setNavigation', 'setActiveKey', 'sebreadlist', 'setidKey', 'setpmzturl', 'setAppMenuId']),
		handUrlClick(url){
			if(url) {
				var self_=this;
				var urlAry=url.split("\/");
				var flag=false;
				for (var i = 0; i < this.menus.length; i++) {
					if(this.menus[i].key==urlAry[1]){
						this.menu=this.menus[i];
						this.getItemByUrl(this.menus[i].children,urlAry,3,function(item){
							flag=true;
							self_.$bus.emit('handUrlClick', self_.menu);
							var path=item.path;
							if(path){
								var pathAry=path.split("\/");
								for(var i=0;i<pathAry.length-1;i++){
									self_.openKeys.push(pathAry[i]);
								}
							}
							self_.handMenuClick(item);
						})
					}
				}
				if(!flag){
					this.$router.push({
						path: url
					});
				}
			}
		},
		getItemByUrl(menus,urlAry,index,callback){
			for(var i=0;i<menus.length;i++){
				if(menus[i].key==urlAry[index]){
					if(urlAry.length==index+1){
						if(callback){
							callback(menus[i]);
						}
					}else{
						if(menus[i].children){
							this.getItemByUrl(menus[i].children,urlAry,index+1,callback);
						}
					}
				}
			}
		},
		handMenuClick(item, index, typename) {
			this.pmzt(item);
			var showType = item.showType;
			//组件路径为空 默认为目录
			if (showType == 'URL' && item.settingType == 'custom' && !item.component) {
				return;
			}
			//添加权限的key
			//this.setidKey(this.menu.key)
			if (showType != 'POP_WIN' && showType != 'NEW_WIN') {
				//添加tab導航
				this.bread(item);
				//添加第二种面包屑
				this.switching == "crumbs" ? this.columnlist(item) : '';
			}
			if (!showType) {
				//URL访问
				this.openUrl(item);
			}

			let _objFun = {
				"URL": {fn: 'openUrl'},  //URL访问
				"POP_WIN": {fn: 'openPopWin'},   //弹窗
				"NEW_WIN": {fn: 'openNewWin'},        //新窗口
				"FUNS": {fn: 'openFuns', parames: 'funs'},    //功能面板集（标签）
				"FUNS_BLOCK": {fn: 'openFuns', parames: 'funsBlock'},   //功能面板集（单页）
				"FUN": {fn: 'openFuns', parames: 'fun'},   //功能面板
			}
			let _fn = _objFun[showType].fn;

			let _parames = _objFun[showType].parames;
			this[_fn](item, _parames);

			this.setSelectMenu({});
			this.setSelectMenu(item);
			//this.$emit('leftMenuClick', item.id)
		},
		pmzt(item) {
			this.setpmzturl(item.params)
		},
		//面包屑
		bread(item) {
			this.$set(item, 'idKey', this.appKey);
			for (var nav of this.navigation) {
				if (nav.key == item.key) {
					this.setActiveKey(item.key)
					return
				}
			}
			this.setActiveKey(item.key);
			this.setSelecteKeys([item.key]);
			this.navigation.push(item)
			this.setNavigation(this.navigation);
		},
		columnlist(item) {
			let parentArr = getParentNode(this.menus, item.id).reverse();
			this.sebreadlist(parentArr);
		},
		openFuns(item, name) {
			var menuId = item.id;
			var pathParams = {name: name};
			this.setSelecteKeys([item.key]);
			this.setAppMenuId(menuId)
			this.generatePath(menuId);
			pathParams.params = {}
			if (item.params) {
				pathParams.params = JSON.parse(item.params);
			}
			pathParams.params.menuId = menuId;

			this.$router.push(pathParams);
		},
		handMenuPath(menu) {
			var pathParams = {name: menu.key};
			return pathParams;
		},
		//在弹窗中打开菜单
		openPopWin(item) {
			var data = {};
			if (item.settingType == 'iframe') {
				data.url = item.params;
			} else {
				data.menu = item;
				data.currentView = getComponent(item);
			}
			var conf = {
				component: DialogView,
				curVm: this,
				max: true,
				title: item.title,
				data: data
			};
			Util.open(conf);
		},
		//在新窗口打开菜单
		openNewWin(item) {
			var path = process.env.VUE_APP_API_CTX_PATH;
			var aryMenuPath = this.getMenuPath(item.id);
			var url = path;
			for (var i = 0; i < aryMenuPath.length; i++) {
				url += "/" + aryMenuPath[i].menuKey;
				if (i == 0) {
					url += "/home";
				}
			}
			url=location.protocol +"//" + location.host +url.replace("//","/");
			//如果菜单参数为外网地址，则直接取该地址  2022-1-25
			let params=item.params;
			if(params){
				params=params.toLowerCase();
				if(params.startWith('http://') || params.startWith('https://')){
					url=params;
				}
			}
			window.open(url, '_blank');
		},
		openUrl(item) {
			var name = item.key;
			var menuId = item.id;
			this.setSelecteKeys([name]);
			var path = this.handMenuPath(item);
			/*     if (item.params) {
					 path.params = item.params;
				 }*/
			this.setAppMenuId(menuId);
			this.generatePath(menuId);
			/**
			 *  {
			 *     name:"路由名称",
			 *    params: {"formAlias":"custom001",query:{name1:value1}}
			 *  }
			 */
			this.$router.push(path);

		},
		generatePath(id) {
			var aryMenuPath = this.getMenuPath(id);
			//将菜单路径发布到VUEX
			this.setMenuPath(aryMenuPath)
		},
		getMenuPath(id) {
			var aryMenuPath = [];
			var obj = this.menuMap[id];
			aryMenuPath.push(obj)
			while (obj.parentId != '0') {
				obj = this.menuMap[obj.parentId];
				//往数组开头增加元素。
				aryMenuPath.unshift(obj);
			}
			return aryMenuPath;
		},
	}
}
