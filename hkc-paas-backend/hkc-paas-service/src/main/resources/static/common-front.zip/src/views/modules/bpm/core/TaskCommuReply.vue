<template>
  <rx-dialog @handOk="handleReplyLinkup()" @cancel="cancel" oktext="确定" order="top" btnalign="right">
    <a-form-model ref="form" :model="form" :rules="rules" class="container-a-form">
      <a-row>
        <a-col :span="24">
          <a-form-model-item label="意见" :labelCol="labelCol1" :wrapperCol="wrapperCol1"  prop="opinion">
            <a-textarea placeholder="请填写意见" v-model="form.opinion"></a-textarea>
          </a-form-model-item>
        </a-col>
      </a-row>
      <a-row>
        <a-col :span="24">
          <a-form-model-item label="附件" :labelCol="labelCol1" :wrapperCol="wrapperCol1">
            <rx-attach-component v-model="form.files" ></rx-attach-component>
          </a-form-model-item>
        </a-col>
      </a-row>
      <a-row>
        <a-col :span="24">
          <a-form-model-item label="通知方式" :labelCol="labelCol1" :wrapperCol="wrapperCol1"   >
            <a-checkbox-group :options="msgOptions" v-model="form.msgType">
            </a-checkbox-group>
          </a-form-model-item>
        </a-col>
      </a-row>
    </a-form-model>
  </rx-dialog>
</template>

<script>
    import BpmPublicApi from '@/api/bpm/core/BpmPublicApi';
    import {BaseFormModel, RxDialog,Dialog,Util,RxAttachComponent} from 'jpaas-common-lib';
    import BpmtaskApi from "@/api/bpm/core/bpmTask";

    export default {
        name: "task-commu-reply",
        components: {
            RxAttachComponent
        },
        mixins:[BaseFormModel],
        props:{
            taskId:{
                type:String
            }
        },
        data(){
            return {
                rules: {
                    opinion:[{ required: true, message: '请填写意见', trigger: 'change' }]
                },
                msgOptions:[],
                form:{
                    opFiles:"",
                    opinion:"",
                    msgType:[],
                    files:[]
                }


            }
        },
        created(){
            this.init();
        },
        methods:{

            init(){
                this.form.taskId=this.taskId;
                BpmPublicApi.getMessageHandler().then(res=>{
                    res.forEach((val)=> {
                        this.msgOptions.push({label:val.name,value:val.type})
                    })
                })
            },
            cancel(){
                Util.closeWindow(this,'cancel');
            },
            //回复沟通
            handleReplyLinkup() {
              this.form.opFiles = JSON.stringify(this.form.files);
              this.$refs.form.validate(valid => {
                if (!valid) {
                  return;
                }
                this.form.msgTypes = this.form.msgType.join(',');
                BpmtaskApi.replyLinkupTask(this.form).then(resp => {
                  if (resp.success) {
                    Util.closeWindow(this, 'ok');
                  }
                });
              })
            }
        }
    }
</script>

<style scoped>
.container-a-form{
    padding:10px 10px 0 0 ;
}
</style>