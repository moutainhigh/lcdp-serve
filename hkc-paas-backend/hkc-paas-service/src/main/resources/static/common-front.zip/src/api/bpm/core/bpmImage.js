import rxAjax from '@/assets/js/ajax.js';

export const BpmImageApi = {
  bpmImage: '/api-bpm/bpm/core/bpmImage'
}

/**
 * 获得流程定义配置
 * @param bpmParams
 * @returns {AxiosPromise}
 */
export function getBpmnXmlFromParam (bpmParams) {
  let url = BpmImageApi.bpmImage + '/getBpmnXmlFromParam';
  return rxAjax.postJson(url,bpmParams);
}

export function getBpmnImageNodeInfo (bpmParams) {
  let url = BpmImageApi.bpmImage + '/getBpmnImageNodeInfo';
  return rxAjax.postJson(url,bpmParams);
}