var FormMethods={};

import { Formula } from './FormulaUtil.js';
import FormPcApi from './api/FormApi.js';
import {Util} from "jpaas-common-lib";

/*
 * 日期计算 例如日期+天数=日期
 *
 * CALC_DATE({开始时间},{时间数},[单位],[方式]),
 * 单位可以是'Y(years)'、Q(quarters)'、'M(months)'、
	'w(weeks)'、'd(days)、'h(hours)'、
	'm(minutes)'、's(seconds)',
	方式可以是 ‘+’、‘-’
	日期格式: ‘YYYY-MM-DD HH:mm:ss’
 */
FormMethods.CALC_DATE=function(date,time,unit,mode,formatStr){
	return Formula.CALC_DATE(date,time,unit,mode,formatStr)
}


/**
 * 两个时间计算。比如计算两个时间的时间差。
 *
 * @param   date1	开始时间
 * @param   date2	结束时间
 * @param   unit	单位可以是'Y(years)'、Q(quarters)'、'M(months)'、	'w(weeks)'、'd(days)、'h(hours)'、	'm(minutes)'、's(seconds)',
 * @param   fixed	精度 默认 为0
 * @param   amend	修正值
 */
FormMethods.DATEDIF=function(date1,date2,unit,fixed,amend){
	return Formula.CALC_DATE(date,time,unit,mode,formatStr)
}


/**
 * 四舍五入函数。
 * @param  numberRound
 * @param  roundDigit
 */
FormMethods.NUM_ROUND=function(numberRound,roundDigit){
	return Formula.ROUND(numberRound,roundDigit);
}


/**
 * 调用服务端脚本。
 */
FormMethods.invokeScript=function(alias, params, callback) {
	FormPcApi.invoke(alias, params).then(res => {
		if(callback) {
			callback(res);
		}
	})
}

/**
 * 调用服务端脚本。
 */
FormMethods.invokeScriptPromise=function(alias,params){
	return FormPcApi.invoke(alias, params);
}

/**
 * 调用自定义查询
 */
FormMethods.invokeCustomQueryPromise=function(alias,params){
	return FormPcApi.queryForJson(alias, {params: JSON.stringify(params)});
}
/**
 * 调用自定义查询。
 */
FormMethods.invokeCustomQuery=function(alias,params,callback){
	FormPcApi.queryForJson(alias, {params: JSON.stringify(params)})
		.then(res=>{
			if(res.success && callback) {
				callback(res.data);
			}
		})
}

/**
 * 调用第三方接口
 */
FormMethods.invokeInterfacePromise=function(apiId,params){
    return FormPcApi.executeInterfaceApi(apiId,params);
}
/**
 * 调用第三方接口
 * @param apiId
 * @param params
 * @param callback
 */
FormMethods.invokeInterface=function(apiId,params,callback){
    FormPcApi.executeInterfaceApi(apiId,params).then(res=>{
        if(res.success && callback){
            callback(res.data);
        }
    })
}

/**
 * 发送post请求。
 */
FormMethods.postJson=function(url, params) {
			return FormPcApi.postJson(url, params);
}

/**
 * 发送get请求。
 */
FormMethods.get=function(url, params) {
  return FormPcApi.get(url, params);
}

/**
 * 发送 post 请求。
 *  两种方式 ： 对象 {name:"RAY"} 传键值对 name=ray
 * @param url
 * @param params
 */
FormMethods.postForm=function(url, params) {
  return FormPcApi.postForm(url, params);
}

/**
 * 取双值的value.
 * @param json
 * @returns {*}
 */
FormMethods.getJsonValue=function(json) {
  if(!json){
    return "";
  }
  return JSON.parse(json).value;
}


/**
 * 打开表单方案
 * @param alias     表单方案名称
 * @param title     标题
 * @param readonly  是否只读
 * @param pk        主键
 * @param params    将数据映射到表单 {}
 * @param destroy   回调函数 function(action){
 *
 * }
 */
FormMethods.openForm=function(alias, title, readonly,pk, params, destroy) {
    var params={
        alias:alias,
        pk:pk,
        readOnly:readonly,
        params:params
    }
    this.openDialog('form', "", title, params, destroy);
}

/**
 * 打开列表。
 * @param alias     列表名称
 * @param params    传入参数，使用对象类型 参数键值数据例如 {user:"ray","Q_USER_S_EQ":"red"}
 * @param config    对象类型 {max:true,widthHeight:[data.width + 'px', data.height + 'px']}
 * @param destroy   回调函数 function(data){}
 */
FormMethods.openList=function(alias, params,config, destroy) {
    var parameter="";
    if(params){
        var aryParams=[];
        for(var key in params){
            aryParams.push(key + "=" + params[key]);
        }
        parameter=aryParams.join("&");
    }

    var paramJson={key:alias};
    if(parameter){
        paramJson.params=parameter;
    }
    var obj={
        params:paramJson,
        config:config
    }
    this.openDialog("list", "", "", obj, destroy)
}
/**
 * 打开一个自定义组件
 * @param url       这个组件路径是相对于 views目录的路径
 * @param title     标题
 * @param params    可以传递的参数
 * @param destroy   回调函数
 */
FormMethods.openDialogComponet=function(url, title, params, destroy) {
    this.openDialog('custom', url, title, params, destroy);
}
/**
 * 打开一个IFRAME 页面
 * @param url   URL地址
 * @param title 标题
 */
FormMethods.openDialogUrl=function(url, title) {
    this.openDialog('iframe', url, title);
}

/**
 * 打开对话框
 * @param settingType
 * @param url
 * @param title
 * @param params
 * @param destroy
 */
FormMethods.openDialog=function(settingType, url, title, params, destroy) {
    var params = {
        settingType: settingType,
        url: url,
        params: params,
        title: title,
        destroy: destroy
    }
    this.$bus.emit("formOpenEvent", params);
}

/**
 * 延迟处理函数。
 * @param callBack  需要执行的函数
 * @param timeout   延迟时间
 */
FormMethods.delay=function(callBack,timeout){
    if(this.timer){
        window.clearTimeout(this.timer);
        this.timer=0;
    }
    this.timer=window.setTimeout(callBack,timeout);
}

/**
 * 获取Util工具。
 * @return
 */
FormMethods.getUtil=function(){
   return Util;
}

export default FormMethods;
