import rxAjax from '@/assets/js/ajax.js';

//表单日历视图 api接口
export const FormCalendarViewApi = {};

FormCalendarViewApi.baseUrl= '/api-form/form/core/formCalendarView';
FormCalendarViewApi.exportUrl= FormCalendarViewApi.baseUrl + '/export';

//查询列表
FormCalendarViewApi.query=function (parameter) {
  var url= FormCalendarViewApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
* 获取单记录
* @param pkId
* @returns {*}
*/
FormCalendarViewApi.get =function(pkId) {
  var url= FormCalendarViewApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

//保存数据
FormCalendarViewApi.save =function(parameter) {
  var url= FormCalendarViewApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

//删除数据
FormCalendarViewApi.del =function(parameter) {
  var url= FormCalendarViewApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

/**
 *
 * @param pkId
 * @param getFields 获取字段
 * @returns {*}
 */
FormCalendarViewApi.getById =function(pkId,getFields) {
    var url= FormCalendarViewApi.baseUrl + '/getById?pkId=' + pkId+"&getFields="+getFields;
    return rxAjax.get(url);
}

FormCalendarViewApi.getDataByKey =function(key,menuId,parameter) {
    parameter.key=key;
    if(menuId){
        parameter.menuId=menuId;
    }
    var url= FormCalendarViewApi.baseUrl + '/getDataByKey';
    return rxAjax.postForm(url,parameter);
}

export  default FormCalendarViewApi;

