<template>
    <div class="formBox" style="width: 100%;height:100%;">
        <rx-fit class="rxfits">
            <div slot="toolheader" border="true" foldheader="true" foldbtn="false" align="right">
                <div style="padding-bottom: 16px;">
                    <process-tool-bar :processConfig="processConfig"
                                      :def-id="localDefId"
                                      :instId="instId"
                                      :mainDefId="mainDefId"
                                      :mainTaskId="mainTaskId"
                                      :vars="vars"/>
                </div>
            </div>
            <div class="fitContainer">
                <div class="contents">
                    <div class="fitContentBox">
                        <rx-forms ref="rxForms" v-if="processConfig.formType=='online'"></rx-forms>
                        <component ref="customForm" :is="formComponent" :pk="pk" v-else></component>
                    </div>
                </div>
            </div>
        </rx-fit>
    </div>
</template>
<script>
import {RxFit, Util} from 'jpaas-common-lib';
import ProcessToolBar from "./ProcessToolBar";
import BpmInstApi from "@/api/bpm/core/bpmInst";
import RxForms from "./RxForms";
import userState from "@/assets/js/userState";

export default {
    name: "bpm-inst-start",
    mixins: [userState],
    props: {
        //流程定义ID
        defId: String,
        //流程实例ID
        instId: String,
        //通过主键直接启动流程
        pkId: String,
        //这个是从DialogView打开时需要用到的。
        menuParams: {
            type: String
        },

        mainDefId: String,
        mainTaskId: String,
        formData: Object,
        vars: Object,

        layerid: String,
        lydata: Object,
        destroy: Function,
        config: Object
    },
    components: {
        ProcessToolBar,
        RxFit,
        RxForms
    },
    data() {
        var hasPk = false;
        if (this.pkId) {
            hasPk = true;
        }

        return {
            startProcess: false,
            saveDraft: false,
            closed: false,
            title: '流程发起',
            processConfig: {
                buttons: [],
                startConfirm: false,
                fillOpinion: false,
                assignFlowUsers: false,
                startCalFlowusers: false,
                //是否允许选择路径。
                allowSelectPath: false,
                formType: "online",
                hasPk: hasPk
            },

            formComponent: "",
            pk: "",
            //流程定义KEY
            defKey: "",
            //流程定义ID
            localDefId: "",
            //是否从路由过来
            fromRoute: false,
            //根实例
            rootVm: true

        }
    },
    created() {
        this.initParams();

        this.initProcessConfig();
    },
    methods: {
        initParams() {
            //从属性传入，这个一般用于 Util.open的方式打开。
            if (this.defId) {
                this.localDefId = this.defId;
            }
            //从弹框打开,使用DialogView 打开
            else if (this.menuParams) {
                this.handParams(JSON.parse(this.menuParams));
            } else if (this.config) {
                if (this.config.defId) {
                    this.localDefId = this.config.defId;
                }
                if (this.config.defKey) {
                    this.defKey = this.config.defKey;
                }
            }
            //通过路由获取参数
            else {
                var params;
                if (this.$route.meta.params) {
                    params = JSON.parse(this.$route.meta.params);
                } else {
                    params = this.$route.params;
                }
                this.fromRoute = true;
                this.handParams(params);
            }
        },
        handParams(params) {
            if (params.defId) {
                this.localDefId = params.defId;
            }
            if (params.defKey) {
                this.defKey = params.defKey;
            }

        },
        initProcessConfig() {

            var self_ = this;
            BpmInstApi.getProcessConfig(this.localDefId, this.defKey).then(res => {
                if (!res.success) {
                    this.$message.warning(res.message);
                    return;
                }
                self_.localDefId = res.data.defId;

                if (res.data) {
                    var config = Util.deepClone(self_.processConfig);
                    self_.processConfig = Object.assign(config, res.data);
                }
                //处理表单配置。
                self_.handFormConfig(res.data);
                //加载表单。
                if (self_.processConfig.formType == "online") {
                    self_.initForm();
                } else {
                    self_.initCustomForm();
                }
            })
        },
        initCustomForm() {
            this.instId = this.instId ? this.instId : this.$route.params.instId;
            if (!this.instId) {
                if(this.config.instId){
                    this.instId=this.config.instId;
                }else {
                    return;
                }
            }
            BpmInstApi.getPkByInstId(this.instId).then(res => {
                if (!res.success) {
                    return;
                }
                this.pk = res.data;
            })
        },
        //处理表单配置。
        handFormConfig(conf){
            //startForm
            if( conf.startForm.formpc && conf.startForm.formpc.length>0){
                var form= conf.startForm.formpc[0];
                if(form && form.type=="custom"){
                    this.processConfig.formType="custom";
                    this.formComponent=this.loadView(form.component) ;
                    return;
                }
            }
            //获取全局。
            if( conf.globalForm.formpc && conf.globalForm.formpc.length>0){
                var form= conf.globalForm.formpc[0];
                if(form && form.type=="custom"){
                    this.processConfig.formType="custom";
                    this.formComponent=this.loadView(form.component);
                    return;
                }
            }
        },
        loadView(view)  { // 路由懒加载
            return require(`@/views/${view}`).defaul;
        },
        async initForm(){

            var params={defId:this.localDefId};
            var instId=this.instId?this.instId:this.$route.params.instId;
            if(instId){
                params.instId=this.instId;
            }

            //如果从外部传入主键
            if(this.pkId){
                params.pkId=this.pkId;
            }

            let res =await BpmInstApi.getViewByDefId(params);
            if(!res.success){
                this.$message.warning(res.message);
                return;
            }
            var data=res.data;
            var formData=data.formData;


            var curUser=this.user;
            var contextData={
                type:"start",
                curUserId:curUser.userId,
                curUserName:curUser.fullName,
                account:curUser.account,
                deptId:curUser.deptId,
                curNodeId:"start",
                curNodeName:"开始节点",
                instId:this.instId,
                defId:this.localDefId,
                tenantId: curUser.tenantId,
                tenantLabel:curUser.tenantLabel
            };
            formData[0].data=Object.assign(formData[0].data,this.formData);

            this.$refs.rxForms.setData(formData,false,contextData);
        },
        closeWindow(){
            if(this.fromRoute){
                this.$bus.emit("closeTab",{action:"current"})
            }
            else{
                Util.closeWindow(this, 'ok');
            }
        }
    },
    watch: {
        closed:function (val) {
            if(val){
                this.closeWindow();
            }
        }
    }
}
</script>
<style scoped>
.formBox >>> .fit-header.showBorder{
    box-shadow: none;
}
.formBox >>> .divdefault{
    overflow: hidden;
}
.fitContainer{
    background: #f0f2f5;
    padding-right: 0;
    box-sizing: border-box;
    height: 100%;
    width: 100%;
    overflow: auto;
}
.contents{
    background: #fff;
    padding: 6px;
    padding-right: 16px;
    margin-right: 0 !important;
    min-height: 100%;
    box-sizing: border-box;
}

.fitContentBox{
    margin: auto;
    width: 100%;
    max-width: 1300px;
}
</style>

