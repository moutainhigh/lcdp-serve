<template>
    <a-layout class="layersty"  ref="layersty">
        <div class="formlist">
            <div>
                <div class="font_btn" v-if="config.showName">{{config.name}}</div>
                <a-layout-footer style="order:0;" v-if="isRead!='YES'">
                    <a-form class="buttongmodle"  >
                        <a-button-group>
                            <a-button :type="btn.style"
                                      :ref="btn.method"
                                      v-for="btn in buttons"
                                      @click="handMedhod(btn)"
                                      :key="btn.name">{{btn.name}}</a-button>
                        </a-button-group>
                    </a-form>
                </a-layout-footer>
            </div>
            <div>
                <a-layout-content  style="order:1" class="defaultContent">
                    <div id="rx-form-container">
                        <div v-if="type=='EASY-DESIGN'">
                            <!--                    <k-form-build :javascript="javascript" :value="jsonData" ref="rxForm" :alias="config.alias" :formDesigner="true" :readOnly="config.receive.isRead=='YES'" />
                                           -->
                        </div>
                        <rx-form v-else ref="rxForm"> </rx-form>
                    </div>
                </a-layout-content>
            </div>
        </div>
    </a-layout>
</template>

<script>

import FormUtil from "../FormUtil";
import FormSolutionApi from '@/api/form/core/formSolution'
import FormPrintLodopApi from "@/api/form/core/formPrintLodop";
import {rxForm} from "jpaas-form-component";
import {Util} from 'jpaas-common-lib';
import  getLodop  from '@/utils/LodopFuncs';
import formbase from '@/api/formbase';
import PublicApi from "@/api/form/core/public";
import BusEvent from "@/views/modules/form/core/formComponent/BusEvent";

export default {
    name: "form-component",
    props:{
        config:{
            type:Object,
            default:()=>{
                return {}
            }
        },
        layerid:{
            type:String
        },
        lydata:{
            type:Object
        },
        destroy:Function
    },
    mixins:[formbase,BusEvent],
    components: {
        rxForm
    },
    created() {
        this.loadForm();
    },
    data(){
        return {
            canStartFlow: false,
            buttons: [],
            type:"",
            jsonData:{},
            javascript:"",
            isRead:"NO",
            formData:{},
            pkId:""
        }
    },
    methods: {
        /*
          * args:{
          *   component:"",
          *   params:{
          *     'sqr':record.sqr
          *    }};
          *
          * }
          */
        handEvent(args) {
            var receive = this.config.receive;
            //当发布组件和配置的组件一致的时候
            if (receive && receive.type == 'event' && receive.component == args.component) {
                this.loadForm(args);
            }
        },
        loadForm(args) {
            if(!this.config.alias){
                if(this.lydata.alias){
                    this.config=this.lydata;
                    this.isRead= this.lydata.readOnly?"YES":"NO";
                    if(this.lydata.pkId){
                        this.pkId=this.lydata.pkId;
                        this.getByAlias(this.lydata.pkId,this.lydata,{});
                    }else {
                        this.getByAlias(null,this.lydata,{});
                    }
                }
                return ;
            }
            if(this.config.receive){
                if(this.config && this.config.receive){
                    this.isRead= this.config.receive.isRead?this.config.receive.isRead:this.isRead;
                }
                var pkMapping = Util.deepClone(this.config.receive.pkMapping);
                var mapping = Util.deepClone(this.config.receive.mapping);
                var formData = {};
                var params = {};
                if (this.$route.meta.query) {
                    params = JSON.parse(this.$route.meta.query);
                }else {
                  params=this.$route.query;
                }
                if (this.config.receive.type == 'url') {
                    if (this.config.receive.isPk == 'YES') {
                        if (pkMapping[0].valueSource == 'param'){
                            if (params[pkMapping[0].valueDef]) {
                                pkMapping[0].valueSource = 'fixedVar';
                                pkMapping[0].valueDef = params[pkMapping[0].valueDef];
                            } else if ( params[pkMapping[0].name]) {
                                pkMapping[0].valueSource = 'fixedVar';
                                pkMapping[0].valueDef = params[pkMapping[0].name];
                            }
                        }
                    } else {
                        for (var i = 0; i < mapping.length; i++) {
                            var o = mapping[i];
                            if (o.valueSource == 'param' && params[o.name]) {
                                if(this.config.receive.isData=='YES'){
                                    formData[o.name]=params[o.name];
                                }
                                o.valueSource = 'fixedVar';
                                o.valueDef = params[o.name];
                            }
                        }
                    }
                } else {
                    if (!args) {
                        return;
                    }
                    if (this.config.receive.isPk == 'YES') {
                        if (pkMapping[0].valueSource == 'param' && args.params[pkMapping[0].valueDef]) {
                            pkMapping[0].valueSource = 'fixedVar';
                            pkMapping[0].valueDef = args.params[pkMapping[0].valueDef];
                        }
                    } else {
                        for (var i = 0; i < mapping.length; i++) {
                            var o = mapping[i];
                            if (o.valueSource == 'param' && args.params[o.valueDef]) {
                                if(this.config.receive.isData=='YES'){
                                    formData[o.name]=args.params[o.valueDef];
                                }
                                o.valueSource = 'fixedVar';
                                o.valueDef = args.params[o.valueDef];
                            }
                        }
                    }
                }
                var self = this;
                if (this.config.receive.isPk == 'YES') {
                    this.getParams(pkMapping,function(json){
                        self.getByAlias(json.pk,{},formData);
                    })
                } else {
                    this.getParams(mapping,function(json){
                        self.getByAlias(null,json,formData);
                    })
                }
            }
        },
        getByAlias(pkId,json,formData){
            var self = this;
            FormSolutionApi.getByAlias(this.config.alias, pkId, JSON.stringify(json)).then(res => {
                if(res.metadata){
                    res.metadata = JSON.parse(res.metadata);
                }
                this.type=res.type;
                this.formSolution = res.formSolution;
                res.data=Object.assign(res.data,formData);
                self.formData=res.data;
                if(this.type=='EASY-DESIGN'){
                    this.initEasyForm(res);
                }else{
                    var tmp = FormUtil.getTemplate(res);
                    res.template = `<div class="previewBox">${tmp}</div>`;
                    self.$refs.rxForm.loadForm(res, self.isRead=='YES');
                }
                this.canStartFlow = res.canStartFlow;

                var btns = res.buttons ? JSON.parse(res.buttons) : [];
                for (var i = 0; i < btns.length; i++) {
                    var btn = btns[i];
                    if (btn.method == "startFlow" && !this.canStartFlow) {
                        btns.splice(i, 1);
                    }
                }
                // 按钮定义。
                this.buttons = btns;
            })
        },
        getParams(mapping,callback){
            PublicApi.getParams(JSON.stringify(mapping)).then(res=>{
                callback(res);
            }).catch(err=>{
                callback({});
            })
        },
        initEasyForm(res){
            this.$nextTick(function() {
                this.$refs.rxForm.setData(res);
            })
            this.javascript=res.script;
            this.jsonData=res.metadata;
        },
        startFlow() {
            this.doSubmit("start");
        },
        submit() {
            if(this.type=='EASY-DESIGN') {
                this.doEasySubmit("save");
                return;
            }
            this.doSubmit("save")
        },
        doEasySubmit(action){
            var self=this;
            this.$refs.rxForm.getData().then(json=>{
                if (self.parent&&self.parent.field) {
                    json[self.parent.field] = self.parent.value;
                }

                var data = {setting: {action: action, alias: self.config.alias}, data: json};
                FormSolutionApi.saveForm(data).then(res => {
                    if(self.$refs.rxForm._afterSubmit) {
                        self.$refs.rxForm._afterSubmit(res,data);
                    }
                    if (res.success){
                        Util.closeWindow(self, "ok");
                    }
                })
            });
        },
        async doSubmit(action) {
            var formVm = this.$refs.rxForm.formVm;
            //提交前校验
            if (formVm._beforeSubmit) {
                var rtn = await formVm._beforeSubmit(formVm);
                if (!rtn.success) {
                    this.$message.warning(rtn.msg);
                    return;
                }
            }
            //数据必填，类型校验
            var res = formVm.valid(true, true);
            if (!res.success) {
                this.$message.warning(res.msg);
                return;
            }

            var json = this.$refs.rxForm.getData();
            if (this.parent && this.parent.field) {
                json[this.parent.field] = this.parent.value;
            }
            var data = {setting: {action: action, alias: this.config.alias}, data: json};
            FormSolutionApi.saveForm(data).then(res => {
                if (formVm._afterSubmit) {
                    formVm._afterSubmit(res,json);
                }
                if (res.success) {
                    this.$bus.emit('refreshEvent', {});
                    Util.closeWindow(this, "ok");
                }
            })
        },
        print() {
            var url ="/formprint/" + this.config.alias;
            var portalUrl = window.localStorage.getItem('portalUrl');
            if (portalUrl) {
                url = portalUrl + url;
            } else {
                url = "/jpaas" + url;
            }
            if (this.pkId) {
                url += "/" + this.pkId;
            }
            window.open(url);
        },
        printLodop(pkId, name) {
            if (!pkId) {
                this.$message.warning("未绑定套打模板!");
                return;
            }
            var lodop = getLodop(this);
            if (!lodop) {
                return;
            }
            //初始化任务名称
            lodop.PRINT_INIT(name);
            FormPrintLodopApi.printHtml({
                pkId: pkId,
                formData: JSON.stringify(this.$refs.rxForm.getData())
            }).then(res => {
                eval(res.data);
                //打印预览
                lodop.PREVIEW();
            })
        },
        handMedhod(btn) {
            if (btn.default) {
                if (btn.method && btn.method.indexOf("(") != -1) {
                    eval("this." + btn.method);
                } else if (btn.isAction) {
                    this["func_" + btn.method] = function () {
                        var formJson = this.$refs.rxForm.getData();
                        var rxAjax = this.$refs.rxForm.rxAjax;
                        eval(btn.action);
                    };
                    this["func_" + btn.method]();
                } else {
                    this[btn.method]();
                }
            } else {
                var method = "func_" + btn.method;
                var formVm = this.$refs.rxForm.formVm;
                if (formVm && formVm[method]) {
                    formVm[method](formVm);
                }
            }
        }
    },
    watch:{
        config:{
            handler: function (val, oldVal) {
                if(val){
                    this.loadForm();
                }
            },
            deep: true
        }
    }
}
</script>

<style scoped>
.buttongmodle{
    text-align: right;
}
.footerToolBar button{
    margin-right: 4px;
}
.footerToolBar button:last-child{
    margin-right: 0;
}
.footerToolBar{
    display: inline-block;
}
.ant-layout-footer{
    padding: 8px 20px;
    background: #fff;
    box-shadow: 0px 0px 3px #d2d2d2;
    z-index: 99;
}
.content-div{
    position: absolute;
    top: 10px;
    right: 10px;
    left: 10px;
    bottom: 10px;
    border-radius: 6px;
    overflow-y: auto;
    background: #fff;
    overflow: auto;
}
.beLayout{
    top: 0px;
    right: 0px;
    left: 0px;
    bottom: 0px;
    background: #f0f2f5;
}

#formContainer{
    background-color: #fff;
}


.hr_btn{
    position: relative;
    bottom: -30px;
    z-index: 99;
    margin: 0;
    /*opacity: .4;*/
    opacity: 1;

}
.layersty{
    height: 100%;
    border: 1px solid #dadde0;
    background: #fff;
    overflow-y: auto;
    position: absolute;
}
/*标题固定，列表部分可以滚动，仅限列表滚动，防止出现双滚动条*/
.font_btn{
    background: #fafafa;
    padding: 5px 10px;
    border-bottom: 1px solid #dadde0;
    font-size: 14px;
    width: calc(100% - 3px);
    z-index: 19;
    text-align: left;
}
.formlist{
    display: flex;
    flex-direction: column;
    height: 100%;
}
.formlist >div:nth-child(2){
    overflow: auto;
    flex: 1;
}
</style>