<template>
    <rx-dialog @handOk="handleSubmit" @cancel="close" oktext="确定" :canceltext="'取消'"   order="bottom">
        <div class="dialog">
            <!--        左边-->
            <div>
                <div class="dialog-all">全部字段</div>
                <div style="margin-top: 10px">
                    <a-checkbox :indeterminate="indeterminate" :checked="checkAll" @change="onCheckAllChange">
                        全选
                    </a-checkbox>
                </div>
                <a-checkbox-group class="dialog-checkedBox" v-model="checkedList" :options="checkedBoxSource"
                                  @change="onChange" />
                <!--            转移按钮-->
                <div class="dialog-circle" @click="moveToExportList"><i style="font-size: 18px;"
                                                                        class="iconfont iconxiangyou"></i></div>
            </div>
            <!--        中边-->
            <div class="formbolist_middle" style="padding-bottom: 0px">
                <div class="dialog-all">要导出的字段</div>
                <div class="table-operator">
                    <a-button size="small" type="primary" @click="addRow">添加</a-button>
                    <a-button size="small" type="danger" @click="removeRow">删除</a-button>
                    <a-button size="small" type="primary" @click="upRow">向上</a-button>
                    <a-button size="small" type="primary" @click="downRow">向下</a-button>
                    <a-button size="small" type="primary" @click="topRow">上升一级</a-button>
                    <a-button size="small" type="primary" @click="subRow">下降一级</a-button>
                </div>
                <div class="formbolist_rxGrid">
                    <rx-grid ref="grid" :dataSource="headerFields" :allowRowSelect="true" :multiSelect="true"
                             :showPage="false" :bordered="true" :columns="headerColumns" id-field="field">
					<span slot="header" slot-scope="{text,record,index,blur}">
						<a-input v-model="record.header" @blur="blur(index,'header',text,record)" />
					</span>
                        <span slot="field" slot-scope="{text,record,index,blur}">
						<a-input v-model="record.field" @blur="blur(index,'field',text,record)" />
					</span>
                        <span v-if="haveRender" slot="showRender" slot-scope="{text,record,index}">
						<a-switch default-checked v-if="(record.renderType && record.renderType!='') "
                                  v-model="record.showRender" />
					</span>
                    </rx-grid>
                </div>
            </div>
        </div>

    </rx-dialog>
</template>

<script>
import {RxDialog,RxFit,Util} from 'jpaas-common-lib';
import FormBoListApi from "@/api/form/core/formBoList";

export default {
    name: "FormBoListExportExcelDialog",
    props: {
        row:{
            type:Object
        },
        boListKey: {
            type: String,
            default: ""
        },
        layerid: {
            type: String,
            default: ""
        },
        destroy: {
            type: Function
        }
    },
    computed: {
        grid() {
            return this.$refs.grid;
        }
    },
    components: {
        RxDialog,
        RxFit
    },
    data() {
        return {
            totalFields:[],
            headerFields: [],
            headerColumns: [{
                title: '字段名称',
                dataIndex: 'header',
                allowCellEdit: true,
                scopedSlots: {
                    customRender: 'header'
                },
                width: 120
            },
                {
                    title: '字段Key',
                    dataIndex: 'field',
                    allowCellEdit: true,
                    scopedSlots: {
                        customRender: 'field'
                    },
                    width: 120
                },
                {
                    title: '是否导出显示值',
                    dataIndex: 'showRender',
                    scopedSlots: {
                        customRender: 'showRender'
                    },
                    width: 100
                }
            ],
            haveRender: false,
            indeterminate: false,
            checkAll: false,
            checkedList: [],
            checkedBoxSource: []
        }
    },
    created() {
        this.reloadColumns();
    },
    methods: {
        handleSubmit(){
            var fields=this.getExportFields();
            if(!fields || fields.length==0){
                this.$notification["warning"]({
                    message: '操作提示',
                    description: "请从左边字段中选择需要导出的字段!",
                });
                return;
            }
            Util.closeWindow(this,"ok",JSON.stringify(fields));
        },
        cancel(){
            Util.closeWindow(this,"cancel");
        },
        getExportFields() {
            var fields = this.$refs.grid.getData();
            var list = [];
            for (var i = 0; i < fields.length; i++) {
                var field = fields[i];
                var tmp = this.handField(field);
                list.push(tmp);
            }
            return list;

        },
        handField(field) {
            var obj = {};
            obj.name = field.header;
            obj.key = field.field;
            obj.showRender = field.showRender;
            obj.renderType = field.renderType;
            var children = field.children;
            if (children && children.length > 0) {
                obj.children = [];
                for (var i = 0; i < children.length; i++) {
                    var tmp = children[i];
                    var cObj = this.handField(tmp);
                    obj.children.push(cObj);
                }
            }
            return obj;
        },
        reloadColumns() {
            var self_ = this;
            FormBoListApi.reloadColumnsByKey(this.boListKey).then(res => {
                if (res.data) {
                    for (var obj of res.data) {
                        if (obj.renderType) {
                            this.haveRender = true;
                            obj.showRender = true;
                        }
                    }
                }
                if (this.haveRender == false) {
                    self_.grid.initColumns(['header','field']);
                }
                //把data存到totalFields里，在后续推到导出列的时候需要从这里拿，再只用header构建多选（因为如果存value,label这种双值格式会导致全选失效）（header相同会有问题）
                self_.totalFields = res.data;
                for (let i = 0; i < self_.totalFields.length; i++) {
                    let value = self_.totalFields[i].header;
                    self_.checkedBoxSource.push(value);
                }
                self_.loadExport();
            });
        },
        loadExport() {
            var json = JSON.parse(this.row.setting);
            var fields = [];
            for (var i = 0; i < json.length; i++) {
                var field = json[i];
                var obj = this.handFieldTrun(field);
                //把导出时的配置从多选来源处删掉
                for (let i = 0; i < this.checkedBoxSource.length; i++) {
                    if (field.name == this.checkedBoxSource[i]) {
                        this.checkedBoxSource.splice(i, 1);
                    }
                }
                fields.push(obj);
            }
            this.headerFields = fields;
        },
        handFieldTrun(field) {
            var obj = {};
            obj.header = field.name;
            obj.field = field.key;
            obj.showRender = field.showRender;
            obj.renderType = field.renderType;
            var children = field.children;
            if (children && children.length > 0) {
                obj.children = [];
                for (var i = 0; i < children.length; i++) {
                    var tmp = children[i];
                    var cObj = this.handFieldTrun(tmp);
                    obj.children.push(cObj);
                }
            }
            return obj;
        },
        addRow() {
            this.grid.addRow();
        },
        removeRow() {
            //删除行同时 多选框来源加回去
            var selectedRows = this.grid.getSelectedRows();
            for (let i = 0; i < selectedRows.length; i++) {
                var exists = false;
                for(let j = 0; j < this.totalFields.length; j++) {
                    if(this.totalFields[j].header == selectedRows[i].header){
                        exists = true;
                        break;
                    }
                }
                if(exists == true) {
                    this.checkedBoxSource.push(selectedRows[i].header);
                }
            }
            this.grid.removeRows();
        },
        upRow() {
            this.grid.moveUp();
        },
        downRow() {
            this.grid.moveDown();
        },
        topRow() {
            this.grid.toMain();
        },
        subRow() {
            this.grid.toSub();
        },
        moveToExportList() {
            //向右到导出框
            while (this.checkedList.length != 0) {
                let item = this.checkedList[0];
                //把左边多选框推到右边，需要从整体totalFields中推(如果他们header相同会有问题，一般不会吧？)
                for (let i = 0; i < this.totalFields.length; i++) {
                    if (this.totalFields[i].header == item) {
                        this.headerFields.push(this.totalFields[i]);
                    }
                }
                this.checkedList.splice(0, 1);
                //把左边多选框删除相应的
                for (let i = 0; i < this.checkedBoxSource.length; i++) {
                    if (this.checkedBoxSource[i] == item) {
                        this.checkedBoxSource.splice(i, 1);
                    }
                }
            }
        },
        onChange(checkedList) {
            //勾选时，做一个全选的按钮状态更新
            this.indeterminate = !!checkedList.length && checkedList.length < this.checkedBoxSource.length;
            this.checkAll = checkedList.length === this.checkedBoxSource.length;
        },
        onCheckAllChange(e) {
            //全选操作
            Object.assign(this, {
                checkedList: e.target.checked ? this.checkedBoxSource : [],
                indeterminate: false,
                checkAll: e.target.checked,
            });
        },
        close(){
            Util.closeWindow(this,"cancel");
        }
    }
}
</script>

<style>
.formbolist_middle{
    display: flex;
    flex-direction: column;
}
.formbolist_rxGrid{
    flex: 1;
    margin-bottom: 15px;
}
.dialog-content-input {
    margin-right: 20px !important;
    width: calc(100% - 330px) !important;
}

.dialog-content-head {
    margin-top: 20px;
}

.dialog-circle {
    position: absolute;
    top: 119px;
    right: -20px;
    width: 40px;
    text-align: center;
    line-height: 40px;
    height: 40px;
    background-color: #ffffff;
    border: solid 1px #dadde0;
    border-radius: 50%;
    color: #46494d;
}

.dialog-circle:hover {
    cursor: pointer;
    background-color: #1890ff;
    color: white;
}

.dialog-checkedBox label {
    width: 40%;
    float: left;
    margin-bottom: 5px;
}
.dialog-checkedBox>label>span:last-of-type{
    display: block;
    width: 125px;
    float: right;
    overflow: hidden;
    height: 20px;
}
.dialog-all {
    border-left: 2px solid #1890ff;
    line-height: 13px;
    padding-left: 6px;
    font-weight: 500;
}
.dialog {
    display: flex;
    width: 100%;
    height:calc(100% - 40px);
}

.dialog>div {
    padding: 20px;
}

.dialog>div:nth-child(1) {
    position: relative;
    width: 400px;
    border-right: 1px solid #e8e8e8;
}

.dialog>div:nth-child(2) {
    flex: 1;
    border-right: 1px solid #e8e8e8;
    overflow: auto;
}

.dialog>div:nth-child(3) {
    width: 500px;
    overflow: auto;
}
</style>
