<template>
    <rx-dialog @handOk="handleSubmit" @cancel="cancel">
        <rx-layout>
            <div slot="center">
                <rx-fit>
                    <div slot="toolheader" foldheader="true" foldbtn="false" border="false">
                        <div class="table-page-search-wrapper">
                            <a-form layout="inline">
                                <a-row :gutter="24">
                                    <a-col :span="8">
                                        <a-form-item label="应用名称">
                                            <a-input placeholder="请输入应用名称" v-model="queryParam.Q_client_name__S_LK"/>
                                        </a-form-item>
                                    </a-col>
                                    <a-col :span="8">
                                        <a-form-item label="应用编码">
                                            <a-input placeholder="请输入应用编码" v-model="queryParam.Q_client_code__S_LK"/>
                                        </a-form-item>
                                    </a-col>
                                    <a-col :md="8" :sm="24">
                                  <span class="table-page-search-submitButtons">
                                    <a-button @click="$refs.table.loadData()" icon="search" type="primary">查询</a-button>
                                    <a-button @click="resetSearchList" style="margin-left: 4px">重置</a-button>
                                  </span>
                                    </a-col>
                                </a-row>
                            </a-form>
                        </div>
                    </div>
                    <rx-grid
                        ref="table"
                        :dataSource="appList"
                        :allowRowSelect="true"
                        :multiSelect="false"
                        :showPage="false"
                        id-field="id"
                        :columns="columns"
                        @selectChange="onSelectChange"
                    >
                    </rx-grid>
                </rx-fit>
            </div>
        </rx-layout>
    </rx-dialog>
</template>

<script>
import {RxDialog, RxLayout, RxGrid, Util, BaseList,RxFit} from 'jpaas-common-lib';
import {mapState} from "vuex";
export default {
    name: "AppDialog",
    mixins: [BaseList],
    components: {
        RxDialog,
        RxGrid,
        RxLayout,
        RxFit
    },
    props: {
        layerid: {
            type: String,
            default: ""
        },
        destroy: {
            type: Function
        }
    },
    computed: {
        ...mapState({
            menus: state => state.appSetting.menus
        })
    },
    data() {
        return {
            // 表头
            columns: [
                {
                    title: '序号',
                    type: 'indexColumn',
                    width: 100,
                    dataIndex: 'serial',
                    scopedSlots: {customRender: 'serial'}
                },
                {
                    title: '应用编码',
                    dataIndex: 'key',
                    width:150
                },
                {
                    title: '应用名称',
                    dataIndex: 'name',
                    width:150
                }
            ],
            appList:[]
        }
    },
    created() {
        this.menus.find(item=>{
            if(item.appType ==1){
                this.appList.push({
                    key:item.key,
                    name:item.title,
                    id:item.id
                });
            }
        })
    },
    methods: {
        handleSubmit(vm) {
            if(this.selectedRows.length==0){
                this.$message.error("请选择至少一个");
                vm.loading=false;
                return;
            }
            Util.closeWindow(this,"ok",this.selectedRows[0])
        },
        cancel() {
            Util.closeWindow(this,"cancel")
        },
    },
    watch: {}
}
</script>

<style scoped>

</style>