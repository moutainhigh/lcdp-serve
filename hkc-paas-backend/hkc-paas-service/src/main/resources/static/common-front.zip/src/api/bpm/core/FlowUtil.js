import BpmInstApi from "@/api/bpm/core/bpmInst";

var FlowUtil={};

/**
 * {
 *   defId:""
 *   instId:"",
 *   //json字符串
 *   formJson:""
 * }
 */
FlowUtil.startFlow=function(data){
    return BpmInstApi.startProcess(data);
}


export  default FlowUtil;