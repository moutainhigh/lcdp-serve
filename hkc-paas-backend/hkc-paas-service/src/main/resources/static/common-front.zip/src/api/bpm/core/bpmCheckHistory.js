import rxAjax from '@/assets/js/ajax.js';

//流程审批流转记录 api接口
export const BpmCheckHistoryApi = {};

BpmCheckHistoryApi.baseUrl= '/api-bpm/bpm/core/bpmCheckHistory';
BpmCheckHistoryApi.exportUrl= BpmCheckHistoryApi.baseUrl + '/export';

//查询列表
BpmCheckHistoryApi.query=function (parameter) {
  var url= BpmCheckHistoryApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
* 获取单记录
* @param pkId
* @returns {*}
*/
BpmCheckHistoryApi.get =function(pkId) {
  var url= BpmCheckHistoryApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

//保存数据
BpmCheckHistoryApi.save =function(parameter) {
  var url= BpmCheckHistoryApi.baseUrl + '/save';
  return rxAjax.postJson(url,parameter);
}

//删除数据
BpmCheckHistoryApi.del =function(parameter) {
  var url= BpmCheckHistoryApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

//获得审批历史
BpmCheckHistoryApi.getCheckHistorys=function(instId){
  var url= BpmCheckHistoryApi.baseUrl + '/getCheckHistorys?instId=' + instId;
  return rxAjax.get(url);
}

export  default BpmCheckHistoryApi;

