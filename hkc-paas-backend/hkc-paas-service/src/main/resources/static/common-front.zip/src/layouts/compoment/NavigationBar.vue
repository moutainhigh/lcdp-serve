<template>
  <div>
    <div
      class="reuse-tab ad-rt fixed"
      :class="collapsed == false ? 'collapsednam_a' : 'collapsednam'"
      @click="showBox = false"
      v-if="switching == 'navigation'"
    >
      <a-tabs :activeKey="activeKey" type="line" @contextmenu.prevent="show">
        <a-tab-pane v-for="pane in navigation" :key="pane.key">
          <div slot="tab">
            <span @click="callback(pane.key, pane)" class="name">{{
              pane.title
            }}</span>
            <a-icon
              :class="[pane.collapsed == false ? 'op ' : 'op op1']"
              @click="onEdit(pane.key, pane)"
              type="close"
            />
          </div>
        </a-tab-pane>
      </a-tabs>
      <div v-if="showBox">
        <div class="show-parent" :style="{ left: tranLeft, top: tranTop }">
          <ul>
            <li @click="closeCurrent()">关闭当前页签</li>
            <li @click="other">关闭其它页签</li>
            <li @click="whole">关闭全部页签</li>
          </ul>
        </div>
      </div>
      <div
        class="beijing"
        @click="showBox = false"
        v-if="showBox == true"
      ></div>
    </div>
    <div class="aBreadcrumb" v-else>
      <a-breadcrumb>
        <a-breadcrumb-item v-if="hearts.length < 1" :key="defHeart.key">
          <a @click="handleToHome">{{ defHeart.title }}</a>
        </a-breadcrumb-item>
        <a-breadcrumb-item v-else v-for="item in hearts" :key="item.key">
          <a v-if="item.key == 'home-index'" @click="handleToHome">{{
            item.title
          }}</a>
          <span v-else>{{ item.title }}</span>
        </a-breadcrumb-item>
      </a-breadcrumb>
    </div>
  </div>
</template>
<script>
import { mapState, mapMutations } from "vuex";
import router from "@/router";

export default {
  name: "navigation-bar",
  data() {
    return {
      hearts: [],
      mode: "top",
      showBox: false,
      tranLeft: 0,
      tranTop: 0,
      customArr: ["customIcon", "userCustomIcon"],
      targetKeyObj: {
        FUNS: "funs", //功能面板集（标签）
        FUNS_BLOCK: "funsBlock", //功能面板集（单页）
        FUN: "FUN", //功能面板
      },
      subscribed: false,
      homeArr: [
        {
          key: "home-index",
          title: "首页",
          collapsed: false,
        },
      ],
      switching: "navigation", //navigation  or  crumbs
      //collapsed:false,
    };
  },
  props: {
    collapsed: "",
  },
  computed: {
    ...mapState({
      navigations: (state) => state.appSetting.navigations,
      navigation: (state) => state.appSetting.navigation,
      activeKey: (state) => state.appSetting.activeKey,
      //switching: (state) => state.appSetting.switching,
      breadlist: (state) => state.appSetting.breadlist,
      appmenuId: (state) => state.appSetting.appmenuId,
      showType: (state) => state.appSetting.showType,
      appKey: (state) => state.appSetting.appKey,
    }),
  },
  created() {
    if (!this.$bus.closeTab) {
      this.$bus.on("closeTab", (obj) => {
        if (obj.action == "current") {
          this.closeCurrent();
        }
      });
      this.$bus.closeTab = true;
    }
  },
  methods: {
    ...mapMutations("appSetting", [
      "setActiveKey",
      "setShowHome",
      "setNavigation",
      "setidKey",
      "setpmzturl",
      "setAppMenuId",
      "setSelecteKeys",
      "setOpenKeys",
    ]),
    handleToHome() {
      this.hearts = [this.defHeart];
      this.setShowHome(true);
      this.setSelectMenu({});
      router.push({ name: "index", params: { appKey: this.appKey } });
    },
    // 删除
    onEdit(targetKey) {
      if (targetKey == "home-index") {
        return;
      }
      for (var i = 0; i <= this.navigation.length; i++) {
        if (this.navigation[i].key == targetKey) {
          this.navigation.splice(i, 1);
        }
      }
      var pane = this.navigation[i - 2];
      var url = this.navigation[i - 2].key;

      targetKey = targetKey = this.targetKeyObj[pane.showType]
        ? this.targetKeyObj[pane.showType]
        : targetKey;
      if (["funs", "funsBlock", "fun"].includes(targetKey)) {
        var pathParams = { name: targetKey };
        pathParams.params = { menuId: pane.id };
        if (pane.params) {
          pathParams.params.params = pane.params;
        }
        this.setAppMenuId(pathParams.params.menuId);
        this.setActiveKey(url);
        if (this.showType && this.showType == "window") {
          router.push(pathParams);
        }
      } else {
        this.setActiveKey(url);
        this.setSelecteKeys([pane.key]);
        if (this.showType && this.showType == "window") {
            if (url == "home-index") {
                this.setShowHome(true);
                router.push({ path: "/" + this.appKey });
                } else {
                router.push({
                    name: url,
                });
            }
        }
      }
    },
    //点击首页
    homePage() {
      var pathParams = { path: "home-index" };
      router.push(pathParams);
    },
    //选中
    callback(targetKey, pane) {
      if (pane.params) {
        this.setpmzturl(pane.params);
      }
      if (pane.idKey) {
        this.setidKey(pane.idKey);
      }
      this.setActiveKey(targetKey);
      if (pane.showType) {
        targetKey = this.targetKeyObj[pane.showType]
          ? this.targetKeyObj[pane.showType]
          : targetKey;
      }
      var pathParams = { name: targetKey };
      if (pane.id) {
        pathParams.params = { menuId: pane.id };
      }
      if (pane.params) {
        if (
          pane.params.toString.call(pane.params).indexOf("Object") < 0 &&
          pane.params.indexOf("{") > -1
        ) {
          pathParams.params = JSON.parse(pane.params);
        } else {
          pathParams.params = pane.params;
        }
      }
      if (pathParams.params && pathParams.params.menuId) {
        this.setAppMenuId(pathParams.params.menuId);
      }
      this.setSelecteKeys([targetKey]);
      if (this.showType && this.showType == "window") {
        if (targetKey == "home-index") {
          this.setShowHome(true);
          router.push({ path: "/" + this.appKey });
        } else {
          router.push(pathParams);
        }
      }
      if (pane.id) {
        this.$emit("navClick", pane);
      }
    },
    show(e) {
      this.tranLeft = e.pageX + "px";
      this.tranTop = 70 + 20 + "px";
      // 点击的时候显示模态框
      this.showBox = true;
    },
    // 关闭当前标签
    closeCurrent() {
      if (this.activeKey != "home-index") {
        for (var i = 0; i <= this.navigation.length; i++) {
          if (this.navigation[i].key == this.activeKey) {
            var key = this.navigation[i - 1].key;
            this.setActiveKey(key);
            if (this.showType && this.showType == "window") {
                if (key == "home-index") {
                    this.setShowHome(true);
                    router.push({ path: "/" + this.appKey });
                }else{
                    router.push({
                        name: key,
                    });
                }
              
            }
            this.navigation.splice(i, 1);
          }
        }
      }
    },
    // 关闭全部
    whole() {
      let _hom = {
        key: "home-index",
        title: "首页",
        collapsed: false,
      };
      this.setNavigation([_hom]);
      this.setActiveKey("home-index");
      if (this.showType && this.showType == "window") {
        // router.push({
        //   name: "home-index",
        // });
        this.setShowHome(true);
        router.push({ path: "/" + this.appKey });
      }
    },
    //关闭其他
    other() {
      if (this.activeKey != "home-index") {
        let _activeTab = "";
        let _navData = this.navigation;
        this.setNavigation([]);
        for (var i = 0; i < _navData.length; i++) {
          if (_navData[i].key == this.activeKey) {
            _activeTab = _navData[i];
            break;
          }
        }
        let _hom = {
          key: "home-index",
          title: "首页",
          collapsed: false,
        };
        var cont = [_hom, _activeTab];
        this.setNavigation(cont);
      } else {
        this.setNavigation(this.homeArr);
      }
    },
  },
  watch: {
    navigations: function (val, oldVal) {
      if (val) {
        this.hearts = [];
        //先加默认菜单
        this.hearts.push(this.defHeart);
        this.hearts.push(...val);
      }
    },
  },
};
</script>

<style lang="less">
.lanlist_home:hover {
  cursor: pointer;
}
.reuse-tab .lanlist {
  margin-left: 20px;
  margin-top: 7px;
}

.beijing {
  position: fixed;
  width: 100vw;
  height: 100vh;
  top: 0px;
  left: 0px;
  z-index: 9;
}

.show-parent {
  position: absolute;
  background-color: #ffffff;
  box-shadow: 0 0 2px #8c939d;
  z-index: 1;
  border-radius: 5px;
  z-index: 999;
}

.show-parent ul li {
  padding: 10px;
}

.show-parent ul li:hover {
  background-color: #e7f4ff;
}

@reuse-tab-prefix: ~".reuse-tab";
@reuse-tab-height: 52px;
@reuse-tab-bg: #fff;
@reuse-tab-padding: 8px;
@reuse-tab-border-color: #d9d9d9;

@{reuse-tab-prefix} {
  display: block;
  background-color: @reuse-tab-bg;
  padding: @reuse-tab-padding;
  border-bottom: 1px solid @reuse-tab-border-color;
  outline: none;
  user-select: none;

  .ant-tabs-bar {
    margin-bottom: 0;
    border-bottom: none;
  }

  .ant-tabs-nav .ant-tabs-tab {
    padding: 0;
    margin: 0 10px 0 0;

    .name {
      display: inline-block;
      padding: 8px 15px;
    }

    .op {
      display: none;
      position: absolute;
      top: 14px;
      right: 2px;
      margin: 0;
      font-size: 12px;
    }

    &:hover {
      .op1 {
        display: block;
      }
    }
  }
}

.artup {
  &:hover {
    .op {
      display: block;
    }
  }
}

@{reuse-tab-prefix}__cm {
  .ant-menu {
    border: 1px solid #e9e9e9;
  }
}

.ad-rt {
  display: block;
  background-color: #fff;
  padding: 0px 3px;
  margin: 0 -24px 0 -24px;
  border-bottom: 1px solid #d9d9d9;
  outline: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  border-top: 1px solid #d9d9d9;
}

// .ad-rt.fixed {
//     position: absolute;
//     top: 0;
//     left: 0;
//     right: 0;
//     margin: 0;
//     z-index: 10;
//     height: 38px !important;
// }

// .aside-collapsed {
//     .ad-rt.fixed {
//         position: fixed;
//         top: 64px;
//         left: 64px;
//         right: 0;
//         margin: 0;
//         z-index: 10;
//     }
// }
</style>
