<template>
	<div>
		<!--页面定制首页-->
		<FormCustomView v-if="layout.length>0" :layout="layout"></FormCustomView>
		<div class="welcome" v-else >
			<div class="welcomeimg">
				<span><img src="@/image/kong.png"></img></span>
			</div>
			<div style="text-align: center;color:#d8e0fc;font-size:24px;">欢迎使用{{appName}}</div>
		</div>
	</div>
</template>
<script>
import FormCustomView from '@/views/modules/form/core/formComponent/FormCustomView.vue';
import VueGridLayout from 'vue-grid-layout'
import {mapState} from "vuex";
import InsPortalDefApi from "../api/portal/core/insPortalDef";

export default {
	name: "home-index",
	props: ["appId"],
	components: {
		FormCustomView,
		GridLayout: VueGridLayout.GridLayout,
		GridItem: VueGridLayout.GridItem
	},
	computed: {
		...mapState({
			appName: state => state.appSetting.appName,
		})
	},
	data() {
		return {
			layout: []
		}
	},
	created() {
		this.getHomePage();
	},
	methods: {
		getHomePage() {
			var self=this;
			if(this.appId){
				InsPortalDefApi.getCurUserPortalByAppId(this.appId).then(res=>{
					if(res.success && res.data && res.data.layoutJson){
						self.layout = JSON.parse(res.data.layoutJson);
					}
				});
			}
		}
	},
	watch: {}
}
</script>

<style scoped>
.welcome{
	background: white;
	width: 100%;
	height: 100%;
	overflow: hidden;
}
.welcomeimg{
	margin-top: 250px;
	margin-left:calc(50% - 75px);
}
.welcomeimg img{
	width: 150px;
}
</style>