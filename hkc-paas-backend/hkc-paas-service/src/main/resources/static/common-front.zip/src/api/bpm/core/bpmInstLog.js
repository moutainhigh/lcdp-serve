import rxAjax from '@/assets/js/ajax.js';

//流程活动日志 api接口
export const BpmInstLogApi = {};

BpmInstLogApi.baseUrl= '/api-bpm/bpm/core/bpmInstLog';
BpmInstLogApi.exportUrl= BpmInstLogApi.baseUrl + '/export';

//查询列表
BpmInstLogApi.query=function (parameter) {
  var url= BpmInstLogApi.baseUrl + '/query';
  return rxAjax.postJson(url,parameter).then (res => {
    return res.result
  })
}

/**
* 获取单记录
* @param pkId
* @returns {*}
*/
BpmInstLogApi.get =function(pkId) {
  var url= BpmInstLogApi.baseUrl + '/get?pkId=' + pkId;
  return rxAjax.get(url);
}

/**
 * 获得流程实例的活动列表
 */
BpmInstLogApi.getByInstId =function(instId) {
  var url= BpmInstLogApi.baseUrl + '/getByInstId?instId=' + instId;
  return rxAjax.get(url);
}

//删除数据
BpmInstLogApi.del =function(parameter) {
  var url= BpmInstLogApi.baseUrl + '/del';
  return rxAjax.postUrl(url,parameter);
}

export  default BpmInstLogApi;

