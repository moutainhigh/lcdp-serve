<template>
    <ul class="group-ul" style="list-style:none;margin: 0;padding:0;">
        <li class="group-li"   v-if="nodeExecutors.length==1" style="width: 100%;">
            <span >{{nodeExecutors[0].nodeName}}</span>
            <span class="groupBox" v-if="nodeExecutors[0].nodeType=='UserTask' ">
          <span v-if="allowSelectExecutor " class="label">用户</span>
          <div class="contentBox" v-if="allowSelectExecutor ">
            <rx-user-component v-model="nodeExecutors[0].users" :filter="nodeExecutors[0].userFilter" :single="false" :readonly="!allowSelectExecutor"></rx-user-component></div>
          <span v-if="allowSelectGroup " class="">部门</span>
          <div  class="contentBox"  v-if="allowSelectGroup ">
            <rx-group-component v-model="nodeExecutors[0].groups" :filter="nodeExecutors[0].groupFilter" :single="false"  :readonly="!allowSelectGroup"  ></rx-group-component></div>
      </span>
            <span v-else style="margin-right: 0">
            <ul style="list-style:none;">
              <li class="group-li" v-for=" subNodeExe in nodeExecutors[0].outcomeNodeUsers">
               <span>{{subNodeExe.nodeName}}</span>
                <span class="groupBox"  v-if="subNodeExe.nodeType=='UserTask' " style="margin-right: 0">
                   <span v-if="allowSelectExecutor" class="label">用户</span>
                  <div v-if="allowSelectExecutor "  class="contentBox"><rx-user-component v-model="subNodeExe.users" :filter="subNodeExe.userFilter" :single="false"  :readonly="!allowSelectExecutor"></rx-user-component></div>
                   <span v-if="allowSelectGroup " class="">部门</span>
                  <div  v-if="allowSelectGroup " class="contentBox"><rx-group-component v-model="subNodeExe.groups" :filter="subNodeExe.groupFilter" :single="false"  :readonly="!allowSelectGroup"></rx-group-component></div>
                </span>
              </li>
            </ul>
      </span>

        </li>
        <li class="group-li" v-else  v-for="(node,idx) in nodeExecutors" :key="node.nodeId">
      <span>{{node.nodeName}}
        <span class="label">
        <a-radio :value="idx" :checked="node.selected" @change.stop="onChange"> </a-radio>
        </span>
      </span>
            <span class="groupBox"  v-if="node.nodeType=='UserTask' " style="margin-right: 0">
        <span v-if="allowSelectExecutor " class="">用户</span>
        <div   class="contentBox" v-if="allowSelectExecutor ">
            <rx-user-component v-model="node.users" :filter="node.userFilter" :single="false"  :readonly="!allowSelectExecutor"></rx-user-component>
        </div>
        <span v-if="allowSelectGroup " class="">部门</span>
        <div v-if="allowSelectGroup "  class="contentBox">
            <rx-group-component v-model="node.groups" :filter="node.groupFilter" :single="false"  :readonly="!allowSelectGroup"></rx-group-component>
        </div>
      </span>
            <span v-else >
            <ul style="list-style:none;">
              <li class="group-li" v-for=" subNodeExe in node.outcomeNodeUsers">
                <span>{{subNodeExe.nodeName}}</span>
                <span class="groupBox"  v-if="subNodeExe.nodeType=='UserTask' ">
                   <span v-if="allowSelectExecutor " class="label">用户</span>
                   <div v-if="allowSelectExecutor "  class="contentBox"> <rx-user-component v-model="subNodeExe.users" :filter="subNodeExe.userFilter" :single="false"  :readonly="!allowSelectExecutor"></rx-user-component></div>
                   <span v-if="allowSelectGroup " class="">部门</span>
                   <div v-if="allowSelectGroup "  class="contentBox"><rx-group-component v-model="subNodeExe.groups" :filter="subNodeExe.groupFilter" :single="false"  :readonly="!allowSelectGroup"></rx-group-component></div>
                </span>
              </li>
            </ul>
      </span>
        </li>
    </ul>
</template>

<script>
    import {RxUserComponent,RxGroupComponent} from "jpaas-common-lib";

    export default {
        name: "bpm-task-executors",
        components:{
            RxUserComponent,
            RxGroupComponent
        },
        props:{
            nodeExecutors:{
                type: Array,
                default: () =>  []
            },
            allowSelectExecutor:{
                type:Boolean,
                default:false
            },
            allowSelectGroup:{
                type:Boolean,
                default:false
            },
            taskConfig:{
                type: Object
            }
        },
        created(){
            this.convertLocal();
        },
        methods:{
            onChange(e){
                var len=this.nodeExecutors.length;
                for(var i=0;i<len;i++){
                    var obj=this.nodeExecutors[i];
                    var val=e.target.value;
                    obj.selected=val==i;
                }
                this.$forceUpdate();
            },
            convertLocal(){

                if(this.nodeExecutors){
                    for(var i=0;i<this.nodeExecutors.length;i++){
                        var o=this.nodeExecutors[i];
                        if(o.selected==undefined){
                            o.selected=i==0;
                        }
                        this.convertLocalRow(o);
                    }
                }
            },
            convertLocalRow(o){
                if(o.nodeType=="UserTask"){
                    this.convertToLocalExecutors(o);
                }
                else if(o.nodeType.indexOf("Gateway") || o.nodeType.indexOf("SubProcess")){
                    var rows=o.outcomeNodeUsers;
                    for(var i=0;i<rows.length;i++){
                        var row=rows[i];
                        this.convertToLocalExecutors(row);
                    }
                }
            },
            convertToLocalExecutors(o){
                var users=[];
                var groups=[];
                var executors= o.executors;
                for(var i=0;i<executors.length;i++){
                    var executor=executors[i];
                    if(executor.type=='user'){
                        users.push(executor);
                    }
                    else{
                        groups.push(executor);
                    }
                }
                o.users=users;
                o.groups=groups;
            },
            convertUsers(o){
                delete o.executors;
                var executors=[];

                if(o.users){
                    for(var i=0;i<o.users.length;i++){
                        var user=o.users[i];
                        user.type="user";
                        executors.push(user);
                    }
                }

                if(o.groups){
                    for(var i=0;i<o.groups.length;i++){
                        var group=o.groups[i];
                        group.type="group";
                        executors.push(group);
                    }
                }

                o.executors=executors;
            },
            convertData(){
                for(var i=0;i<this.nodeExecutors.length;i++){
                    var o=this.nodeExecutors[i];

                    if(o.nodeType=="UserTask"){
                        this.convertUsers(o);
                    }
                    else if(o.nodeType.indexOf("Gateway") || o.nodeType.indexOf("SubProcess")){
                        var rows=o.outcomeNodeUsers;
                        for(var i=0;i<rows.length;i++){
                            var row=rows[i];
                            if(row.nodeType=="UserTask"){
                                this.convertUsers(row);
                            }
                        }
                    }
                }
            },
            getDestNodeId() {
                if(this.nodeExecutors.length==1){
                    if(this.taskConfig && this.taskConfig.nextHandMode && this.taskConfig.nextHandMode=="condition"){
                        return this.nodeExecutors[0].nodeId;
                    }
                    return "";
                }
                var nodeId="";
                this.nodeExecutors.forEach(item => {
                    if ( item.selected) {
                        nodeId=item.nodeId;
                    }
                })
                return nodeId;
            },
            getNodeUserMap() {
                this.convertData();
                let nodeUserMap = {}
                this.nodeExecutors.forEach(item => {
                    if ( item.nodeType=="UserTask" && item.executors && item.executors.length > 0) {
                        nodeUserMap[item.nodeId] = item.executors
                    }
                    if (item.outcomeNodeUsers && item.outcomeNodeUsers.length > 0) {
                        for (let i = 0; i < item.outcomeNodeUsers.length; i++) {
                            var obj=item.outcomeNodeUsers[i];
                            if (obj.nodeType=="UserTask" && obj.executors && obj.executors.length > 0) {
                                nodeUserMap[obj.nodeId] = obj.executors
                            }
                        }
                    }
                })
                return nodeUserMap;
            },
        },
        watch:{
            "nodeExecutors":{
                handler(val){
                    this.convertLocal();
                },
                deep:true
            }
        }

    }
</script>

<style scoped>
    .group-li{
        display: flex;
    }
    .group-li>span{
        margin-right:40px;
    }
    .groupBox{
        display: flex;
        flex: 1;
    }
    .groupBox .contentBox{
        flex: 1;
        padding: 0 10px;
    }
    .label{
        padding-left: 10px
    }
</style>