<template>
  <rx-form ref="rxForm"> </rx-form>
</template>

<script>
  import {rxForm} from "jpaas-form-component";
  import {Util} from "jpaas-common-lib";
  import FormUtil from "../FormUtil";
  import FormSolutionApi from "@/api/form/core/formSolution";
  import BpmInstApi from "@/api/bpm/core/bpmInst";
  import PublicApi from "@/api/form/core/public";
  import userState from "@/assets/js/userState";
  export default {
    name: "RxFormSolutionShow",
    props: ["config","record"],
    mixins:[userState],
    components: {
      rxForm
    },
    data() {
      return {
        type:"",
        formSolution:""
      }
    },
    created() {
      this.init();
    },
    methods:{
      init(){
        if(!this.config){
          return;
        }
        var self=this;
        if(this.config.isPk=='YES'){
          //主键
          var formPkMapping=Util.deepClone(this.config.formPkMapping);
          for(var i=0;i<formPkMapping.length;i++){
            var formPk=formPkMapping[i];
            if(formPk.valueSource=='param'){
              formPk.valueSource='fixedVar';
              formPk.valueDef=this.record[formPk.valueDef];
            }
          }
          this.getParams(formPkMapping,function(json){
              self.getByAlias(json.pk,{});
          })
        }else{
          //无主键
          var formMapping=Util.deepClone(this.config.formMapping);
          for(var i=0;i<formMapping.length;i++){
            var form=formMapping[i];
            if(form.valueSource=='param'){
              form.valueSource='fixedVar';
              form.valueDef=this.record[form.valueDef];
            }
          }
          this.getParams(formMapping,function(json){
              self.getByAlias(null,json);
          })
        }
      },
      getByAlias(pkId,json){
          FormSolutionApi.getByAlias(this.config.formAlias,pkId,json).then(res=> {
              if(res.metadata){
                  res.metadata = JSON.parse(res.metadata);
              }
              this.type=res.type;
              this.formSolution=res.formSolution;
              if(this.setInitData){
                  res.data=Object.assign(this.setInitData(res.data),res.data);
              }
              var tmp = FormUtil.getTemplate(res);
              res.template = `<div class="previewBox">${tmp}</div>`;
              this.initForm(res);
          })
      },
      getParams(mapping,callback){
          PublicApi.getParams(JSON.stringify(mapping)).then(res=>{
              callback(res);
          }).catch(err=>{
              callback({});
          })
      },
      initForm(res) {
        var curUser = this.user;
        var contextData = {
          type: "form",
          curUserId: curUser.userId,
          curUserName: curUser.fullName,
          account: curUser.account,
          deptId: curUser.deptId
        };
        if (res.data.INST_ID_ && "DELETE" != res.data.INST_STATUS_) {
          BpmInstApi.getInstDetail(res.data.INST_ID_).then(result => {
            var contextDetail = {
              type: "detail",
              instNo: result.bpmInst.instNo,
              instId: res.data.INST_ID_,
              opinionHistorys: result.bpmCheckHistories
            };
            Object.assign(contextData, contextDetail);

            this.$refs.rxForm.loadForm(res, true, contextData);
          })
        } else {
          this.$refs.rxForm.loadForm(res, true, contextData);
        }
      }
    }
  }
</script>

<style scoped>

</style>