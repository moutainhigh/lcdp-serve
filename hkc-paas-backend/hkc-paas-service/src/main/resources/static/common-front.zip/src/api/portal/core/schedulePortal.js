import InsPortalDefApi from './insPortalDef';
import moment from 'moment'
/**
 * 我的日程扩展。
 */
export default {
    data(){
        return {
            calendarMode:"month",
            calendarValue:"",
            hasLoadMonthData:false,
            calendarDayList:[],
            timeParams:{}
        }
    },
    created() {

            let _colId = this.colId ;
            let _day = moment().format('YYYY-MM-DD');
            this.timeParams ={
                colId:_colId,
                calendarMode:this.calendarMode,
                calendarValue:_day
            }


    },
    methods:{
        init_Calendar(){
            var setting = JSON.parse(this.insColumnDef.setTing);
            if(setting.calendarMode){
                this.calendarMode = setting.calendarMode;
                this.calendarValue =this.getCalendarValue(new Date());
                this.getMonthData();
                //查询当天的数据
                this.getDataToSelectDay(true);
            }
        },
        getMonthData(){
            var self_ = this;
            var calendarValue=this.calendarValue;
            if("month" == this.calendarMode){
                var dates =this.calendarValue.split("-")
                calendarValue=dates[0]+"-"+dates[1];
            }
            InsPortalDefApi.getCalendarMonthData(calendarValue).then(res => {
                self_.calendarDayList = res.data;
                self_.hasLoadMonthData=true;
            });
        },
        getCalendarDayListData(value) {

            if(!this.hasLoadMonthData || !this.calendarDayList || this.calendarDayList.length==0){
                return [];
            }
            let listData;
            var calendarValue =this.getCalendarValue(value._d,"month");
            if(this.calendarDayList.indexOf(calendarValue)>-1){
                listData = [
                    { type: 'error', content: '' },
                ];
            }
            return listData || [];
        },
        getDataToSelectDay(isInit){
            var params ={
                colId:this.colId,
                calendarMode:this.calendarMode,
                calendarValue:this.calendarValue
            };
            if(isInit){
                params =  this.timeParams ;
            }
            var self_ =this;
            InsPortalDefApi.getDataByQueryTypeAndVal(params).then(res => {
                self_.data = res.data;
            });
        },
        //日历值变更
        onPanelChange(value, mode) {
            this.hasLoadMonthData=false;
            this.calendarMode = mode;
            this.calendarValue =this.getCalendarValue(value._d,mode);
            this.getDataToSelectDay();
            this.getMonthData();
        },
        //日历日期选择
        onCalendarSelect(value){
            this.hasLoadMonthData=false;
            this.calendarValue =this.getCalendarValue(value._d,this.calendarMode);
            this.getDataToSelectDay();
            this.getMonthData();
        },
        getCalendarValue(value,mode){
            var year = value.getFullYear();
            var month = this.getTenDays(value.getMonth()+1);
            var date = year+"-"+month;
            if("month" ==mode){
                var day = this.getTenDays(value.getDate());
                date+="-"+day;
            }
            return date;
        },
        getTenDays(val){
            return val >=10?val:"0"+val;
        },
    }

}