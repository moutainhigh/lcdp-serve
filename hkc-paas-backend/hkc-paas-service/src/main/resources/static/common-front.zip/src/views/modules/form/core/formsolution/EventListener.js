
import DialogBox from "@/assets/js/DialogBox";
import DialogView from "@/layouts/DialogView";
import {Util} from "jpaas-common-lib";
import FormCustomView from "@/views/modules/form/core/formComponent/FormCustomView";
import FlowUtil from "../../../bpm/js/FlowUtil";

export  default {
	mixins:[FlowUtil],
    data(){
        return {
            tableObj:{}
        }
    },
    created(){
        if(!this.$bus.instance){

            this.$bus.on("formOpenEvent",(obj)=>{
                this.handFormOpen(obj);
            });

            this.$bus.on("bpmInstDetailEvent",(obj)=>{
                this.handBpmInstDetail(obj);
            });

            //处理表单导航事件。
            this.handFormNavEvent();
            //列表按钮点击事件
            this.handListButtonEvent();
            //列表预览事件
            this.handListPreviewEvent();

            this.$bus.instance=true;
        }
    },
    methods:{
        handListButtonEvent(){
            this.$bus.on("listButtonEvent",(obj)=>{
                this.handButtonClick(obj);
            });
        },
        handListPreviewEvent(){
            this.$bus.on("listPreviewEvent",(obj)=>{
                this.handListPreview(obj);
            });
        },
        handListPreview(obj){
            if(!obj){
                return;
            }
            switch (obj.type) {
                case 'openCustom':
                    var baseConf= {
                        "curVm": this,
                        component: FormCustomView,
                        title: "表单定制-"+obj.alias,
                        max:true,
                        "data": {
                            "alias": obj.alias,
                            "params": JSON.stringify(obj.params)
                        }
                    };
                    Util.open(baseConf, function (action) {});
                    break
                case 'openStartFlowDialog':
                    this.tableObj=obj.table;
                    var idfield=obj.idField;
                    var id=obj.record[idfield];
                    var view="modules/bpm/core/BpmInstStart";
                    var component=require(`@/views/${view}`).default;

                    //传入流程ID和主键。
                    let paramsObj = {menuParams:JSON.stringify({defKey:obj.alias}),pkId:id,formData:obj.record};
                    var baseConf = {
                        component: component,
                        data: paramsObj,
                        title: "启动流程",
                        curVm: this,
                        max:true
                    };
                    var self_=this;
                    Util.open(baseConf, function (action, data) {
                        if (action != 'ok') return;
                        if(obj.destroy){
                            obj.destroy(action,data);
                        }else {
                            if (self_.tableObj && self_.tableObj.loadData) {
                                self_.tableObj.loadData();
                            }
                        }
                    });
                    break
                case 'openComponent':
                    DialogBox.openComponent(obj.config, obj.callback);
                    break
                case 'showForm':
                    //{"title":"测试EXCEL导出","alias":"user","pkId":"",
                    // "readOnly":false,"parent":{},"params":{"CREATE_BY_":"1"},
                    // "closeOnSave":true}
                    this.tableObj=obj.table;
                    var readOnly_ = obj.obj.readOnly == 'true' ? true : false;
                    var urlType = readOnly_ ? "Details" : "EditRow";
                    this.showForm({
                        ...obj.obj,
                        isMax:obj.isMax,
                        isShade:obj.isShade,
                        width:obj.width,
                        height:obj.height,
                        urlType: urlType
                    })
                    break
                case 'openForm':
                    if (!obj.formAlias) {
                        this.$message.error("请绑定表单方案！");
                        return;
                    }
                    var formAliasObj = JSON.parse(obj.formAlias);
                    var fieldMap_ = JSON.parse(obj.fieldMap);
                    var readOnly_ = obj.readOnly == 'true' ? true : false;
                    var urlType = readOnly_ ? "Details" : "EditRow";
                    var pkId = "";
                    if (obj.pkField) {
                        pkId = obj.row[obj.pkField];
                    }
                    var self = obj.listVm;
                    var config = {
                        title: formAliasObj.text,
                        curVm: this,
                        data: {
                            alias: formAliasObj.value,
                            pkId: pkId,
                            readOnly: readOnly_,
                            //将表单映射数据提交到表单数据。
                            setInitData(data) {
                                if (obj.row) {
                                    for (var i = 0; i < fieldMap_.length; i++) {
                                        data[fieldMap_[i].destField] = obj.row[fieldMap_[i].srcField];
                                    }
                                }
                                return data;
                            }
                        },
                        max:obj.isMax=='YES',
                        widthHeight:[obj.width + 'px', obj.height + 'px'],
                        shade: obj.isShade=='YES',
                        urlType: urlType,
                    }
                    DialogBox.showForm(config, function (action) {
                        if (obj.callback) {
                            var call = "self." + obj.callback + "(row,self)";
                            eval(call);
                        }
                        self.onRefresh();
                    });
                    break
                case 'showBusSolutionForm':
                    var self=obj.listVm;
                    var readOnly=obj.readOnly;
                    if (obj.obj.readOnly) {
                        readOnly=obj.obj.readOnly ;
                    }
                    var config = {
                        title: self.formBoList.name + '--添加',
                        curVm: this,
                        data: {
                            alias: obj.obj.text,
                            rowData: obj.rowData,
                            busSolId: obj.obj.value,
                            readOnly: readOnly,
                            //将表单映射数据提交到表单数据。
                            setInitData(data) {
                                if (self.formdata) {
                                    Object.assign(data, self.formdata);
                                }
                                return data;
                            }
                        },
                        max: true
                    }
                    DialogBox.showBusSolutionForm(config, function (action) {
                        if (obj.callback) {
                            var call = "self." + obj.callback + "(row,self)";
                            eval(call);
                        }
                        self.onRefresh();
                    });
                    break
                default:
                    break
            }
        },
        handFormOpen(obj){
            var data={};
            if(obj.settingType=='iframe'){
                data.url=obj.url;
            }else if(obj.settingType=='form'){
                var alias=obj.params.alias;
                var pk=obj.params.pk;
                if(!pk && obj.params.params){
                    pk=obj.params.params.pk;
                }
                var readOnly=obj.params.readOnly;
                var parent=obj.params.parent;
                var params=obj.params.params;
                let _obj = {
                    title:obj.title,
                    alias:alias,
                    pkId:pk,
                    readOnly:readOnly,
                    parent:parent,
                    params:params,
                    destroy:obj.destroy,
                    urlType:'Open',
                    isMax:'YES',
                    isShade:'YES',
                    width:650,
                    height:350
                }
                this.showForm(_obj);
                return;
            }else if(obj.settingType=='list'){
                DialogBox.dialog(obj.params.params,{...{curVm:this,max:true},...obj.params.config},obj.destroy);
                return;
            }else{
                data.menu={params:obj.params.params};
                data.currentView=() => import(`@/views/${obj.url}`);
            }
            var conf = {
                component: DialogView,
                curVm:this,
                max:true,
                title: obj.title,
                data:data
            };
            Util.open(conf,function (action, data) {
                if(obj.destroy) {
                    obj.destroy(action, data);
                }
            });
        },
        handButtonClick(obj){
            var action=obj.action;
            action=action.charAt(0).toUpperCase() + action.slice(1);
            this.tableObj=obj.table;
            var self_=this;
            var method="self_.hand" +action +"(obj)";
            eval(method);
        },
        handBpmDetail(obj){
        	var record=obj.record;
			this.openDetail(record.INST_ID_);
		},
        handAdd(obj){
            let _obj = {
                title:"添加-"+obj.name,
                alias:obj.alias,
                pkId:"",
                readOnly:false,
                parent:obj.parent,
                params:obj.formdata,
                urlType:'Add',
                isMax:obj.isMax,
                isShade:obj.isShade,
                width:obj.width,
                height:obj.height,
                destroy:obj.destroy,
                closeOnSave:true
            }
            this.showForm(_obj);
        },
        handEdit(obj){
            let _obj = {
                title:"编辑-"+obj.name,
                alias:obj.alias,
                pkId:obj.pk,
                readOnly:false,
                parent:null,
                urlType:'Edit',
                isMax:obj.isMax,
                isShade:obj.isShade,
                width:obj.width,
                height:obj.height,
                destroy:obj.destroy,
                closeOnSave:true
            }
            this.showForm(_obj);
        },
        handDetail(obj){
            let _obj = {
                title:obj.name +"-明细",
                alias:obj.alias,
                pkId:obj.pk,
                readOnly:true,
                parent:null,
                urlType:'Details',
                isMax:obj.isMax,
                isShade:obj.isShade,
                width:obj.width,
                height:obj.height
            }
            this.showForm(_obj);
        },
        showForm(obj) {

            if(!obj.alias){
                this.$message.error("请绑定表单方案！");
                return;
            }
            if (!obj.readOnly) {
                obj.readOnly = false;
            }
            var data={alias: obj.alias, pkId: obj.pkId, readOnly: obj.readOnly, parent: obj.parent,closeOnSave:obj.closeOnSave,params:obj.params};
            if(obj.params){
                data.setInitData=function(data){
                    Object.assign(data,obj.params);
                    return data;
                }
            }

            var self_ = this;
            DialogBox.showForm({
                title:obj.title,
                curVm: self_,
                data: data,
                max:obj.isMax=='YES',
                widthHeight:[obj.width + 'px', obj.height + 'px'],
                shade: obj.isShade=='YES',
                urlType:obj.urlType
            }, function (action,data) {
                if(obj.destroy){
                    obj.destroy(action,data);
                }
                else{
                    if(self_.tableObj && self_.tableObj.loadData){
                        self_.tableObj.loadData();
                    }
                }
            });
        },
        handBpmInstDetail(item){
        	this.openDetail(item.id);
        },
        loadView  (view)  { // 路由懒加载
            return () => import(`@/views/${view}`)
        },
        /*
        {
            "id": "eevcijy411770",
            "name": "客户信息",
            "name_display": "客户信息<span style='color: #df8a13;margin-left:20px'>已配</span>",
            "params": {
                "type": "form",
                "listComponent": "",
                "listParams": [],
                "formComponent": "{\"text\":\"客户信息\",\"value\":\"customerinfo\"}",
                "paramMapType": "pk",
                "fieldPk": "ID_",
                "fieldPkValMode": "single",
                "fieldMap": [],
                "customComponent": ""
            },
            "parentId": "0",
            "name_editable": true,
            "serial": 1
        }*/
        handFormNavEvent(){
            this.$bus.on('form-nav-event', (settingObj, formNavCtl) => {
                var setting=settingObj.params;
                var component= this.getComponent(setting);
                formNavCtl.setComponent(component,setting)
            })
        } ,
        getComponent(obj){
            var component="";
            if(obj.type=="form"){
                component=  "modules/form/core/FormSolutionComponent.vue";
            }
            else if(obj.type=="list"){
                component=  "modules/form/core/FormBoListPreview.vue";
            }
            else{
                component= obj.customComponent;
            }

            return this.loadView(component);
        },


    }
}