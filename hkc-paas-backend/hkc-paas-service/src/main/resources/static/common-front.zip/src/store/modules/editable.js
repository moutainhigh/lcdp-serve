export default {
  namespaced: true,
  state:{
    editable:false
  },
  mutations:{
    setEdit(state){
      state.editable=true
    },
    setUnEdit(state){
      state.editable=false;
    }
  },
  actions:{
    setEdit(context){
      context.commit("setEdit")
    },
    setUnEdit(context){
      context.commit("setUnEdit")
    }
  }
}
