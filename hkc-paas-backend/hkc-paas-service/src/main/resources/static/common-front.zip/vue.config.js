// Vue.config.js 配置选项
const path = require('path')
function resolve (dir) {
	return path.join(__dirname, dir)
}
const packageName = require('./package.json').name;

const prodExternals = {
	'vue': 'Vue',
	'axios': 'axios',
	'vue-router': 'VueRouter',
	'vuex': 'Vuex',
	'moment': 'moment',
	'@antv/g2': 'G2',
	'@antv/data-set': 'DataSet',
	'ant-design-vue': 'antd'
}

module.exports = {
	publicPath: process.env.BASE_URL,
	outputDir: "dist",
	assetsDir: "static",
	devServer: {
		port: 8888,
		headers: {//解决主应用加载子应用的跨域问题;
			'Access-Control-Allow-Origin': '*',
		},
		overlay: {
			warnings: false,
			errors: false
		}
	},
	lintOnSave:false,
	pluginOptions: {},
	runtimeCompiler: true,
	productionSourceMap:false,

	chainWebpack: config => {
		config.resolve.alias
			.set('@public', resolve('public'))
			.set('@static', resolve('static'))
			.set('@image', resolve('static/image'))
			.set('vue$','vue/dist/vue.esm.js');
		config.module.rule('fonts').use('url-loader').loader('url-loader').options({}).end();
		config.module.rule('images').use('url-loader').loader('url-loader').options({}).end();
	},
	configureWebpack: {
		output: {
			library:  `${packageName}`,//微应用名称
			libraryTarget: 'umd', // 把微应用打包成 umd 库格式
			jsonpFunction: `webpackJsonp_${packageName}`
		},
	},
	css: {
		loaderOptions: {
			less: {
				lessOptions: {
					javascriptEnabled: true
				}

			}
		}
	},
}
